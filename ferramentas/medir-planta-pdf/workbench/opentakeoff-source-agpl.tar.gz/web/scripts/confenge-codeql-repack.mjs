import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readdir, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const app = resolve(process.argv[2] || "dist-confenge-local");
const assets = resolve(app, "assets");
const view3d = (await readdir(assets)).filter(name => /^View3D-[\w-]+\.js$/.test(name));
assert.equal(view3d.length, 1, `expected one View3D bundle, found ${view3d.length}`);

const file = resolve(assets, view3d[0]);
const insecure = "const i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0";
const secure = "const r=new Uint32Array(4);globalThis.crypto.getRandomValues(r);const i=r[0],t=r[1],e=r[2],n=r[3]";
let source = await readFile(file, "utf8");
const insecureMatches = source.split(insecure).length - 1;

if (insecureMatches === 1) {
  source = source.replace(insecure, secure);
  await writeFile(file, source, "utf8");
} else {
  assert.equal(insecureMatches, 0, "unexpected duplicate insecure UUID generator");
}

assert.equal(source.includes(insecure), false, "insecure three.js UUID generator remains");
assert.match(source, /(?:globalThis\.)?crypto\.getRandomValues\(/, "CSPRNG UUID generator missing");
const sha256 = createHash("sha256").update(source).digest("hex");
console.log(`${insecureMatches === 1 ? "patched" : "verified"} ${view3d[0]} sha256=${sha256}`);
