# CONFENGE local runtime build

This source snapshot preserves OpenTakeoff under AGPL-3.0-or-later for the
CONFENGE embedded measurement workbench. It is a local-only build: PDF/image
import, scale calibration, tracing and report/CSV export remain available;
Google Drive, Microsoft 365, cloud sync, BYO AI, model-based OCR/STT/door
detection and upgrade surfaces are replaced by explicit no-network stubs when
`VITE_CONFENGE_RUNTIME=true`. Manual PDF/image import, calibration, drawing
and CSV/report export remain available.

Reproduce with the locked dependency tree already present:

```sh
VITE_CONFENGE_RUNTIME=true npm run build -- \
  --base /ferramentas/medir-planta-pdf/workbench/app/ \
  --outDir dist-confenge-local
node scripts/confenge-postbuild.mjs dist-confenge-local
```

`confenge-postbuild.mjs` applies the CONFENGE control-surface normalization and
checks public JavaScript for scanner-shaped credential assignments. It changes
only generated output. No dependency installation or network service is part
of this build.
