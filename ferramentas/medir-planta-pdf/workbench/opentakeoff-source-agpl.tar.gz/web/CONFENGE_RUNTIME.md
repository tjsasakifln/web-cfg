# CONFENGE local runtime build

This source snapshot preserves OpenTakeoff under AGPL-3.0-or-later for the
CONFENGE embedded measurement workbench. It is a local-only build: PDF/image
import, scale calibration, tracing and report/CSV export remain available;
Google Drive, Microsoft 365, cloud sync, BYO AI, model-based OCR/STT/door
detection and upgrade surfaces are replaced by explicit no-network stubs when
`VITE_CONFENGE_RUNTIME=true`. Manual PDF/image import, calibration, drawing
and CSV/report export remain available.

Reproduce with the locked dependency tree already present:

```sh
VITE_CONFENGE_RUNTIME=true npm run build -- \
  --base /ferramentas/medir-planta-pdf/workbench/app/ \
  --outDir dist-confenge-local
node scripts/confenge-postbuild.mjs dist-confenge-local
```

The CONFENGE build also transforms the `three@0.185.1`
`MathUtils.generateUUID()` seed from `Math.random()` to
`crypto.getRandomValues()`. The transform matches the exact dependency source
and fails the build if that implementation changes. For the already staged
PR #898 bundle, the equivalent auditable one-file normalization is:

```sh
node scripts/confenge-codeql-repack.mjs /path/to/workbench/app
```

That repack preserves the UUID v4 byte layout, public asset name and all import
references; it changes only the four 32-bit entropy words feeding Three.js
object identifiers.

`confenge-postbuild.mjs` applies the CONFENGE control-surface normalization and
checks public JavaScript for scanner-shaped credential assignments. It changes
only generated output. No dependency installation or network service is part
of this build.
