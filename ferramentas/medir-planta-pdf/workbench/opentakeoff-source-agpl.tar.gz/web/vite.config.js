import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The one source of truth for the app version — package.json — inlined as
// __APP_VERSION__ so contributions can carry generator_version without a
// runtime fetch. Guarded with `typeof` at the use site so the Node test
// runner (no Vite, no define) sees plain undefined instead of a crash.
const pkg = JSON.parse(readFileSync(new URL("./package.json", import.meta.url), "utf8"));
const confengeRuntime = process.env.VITE_CONFENGE_RUNTIME === "true";
const offline = (path) => fileURLToPath(new URL(path, import.meta.url));

// CONFENGE's embedded measurement runtime is deliberately local-only. Keep
// upstream integrations in source, but replace cloud/AI boundaries at build
// time so their code and optional credentials never enter this public artifact.
const confengeOfflineAliases = confengeRuntime ? [
  { find: /^.*\/src\/lib\/google\/AuthContext\.jsx$/, replacement: offline("./src/confenge-runtime/google-auth.jsx") },
  { find: /^.*\/src\/lib\/google\/auth\.js$/, replacement: offline("./src/confenge-runtime/google-auth.js") },
  { find: /^.*\/src\/lib\/google\/drive\.js$/, replacement: offline("./src/confenge-runtime/google-drive.js") },
  { find: /^.*\/src\/lib\/msgraph\/config\.js$/, replacement: offline("./src/confenge-runtime/m365-config.js") },
  { find: /^.*\/src\/lib\/msgraph\/(auth|composite|graphDrive)\.js$/, replacement: offline("./src/confenge-runtime/m365-disabled.js") },
  { find: /^.*\/src\/lib\/(cloudStore|sync\/composite)\.js$/, replacement: offline("./src/confenge-runtime/cloud-disabled.js") },
  { find: /^.*\/src\/lib\/ai\.js$/, replacement: offline("./src/confenge-runtime/ai-disabled.js") },
  { find: /^.*\/src\/components\/UpgradeNotice\.jsx$/, replacement: offline("./src/confenge-runtime/UpgradeNotice.jsx") },
  // ML model workers are intentionally omitted: CONFENGE keeps the manual
  // PDF/image takeoff, calibration and CSV workflow without model downloads.
  { find: /^.*\/src\/(ocr|stt|doorDetect)\.worker\.ts$/, replacement: offline("./src/confenge-runtime/ml-disabled.worker.js") },
  { find: /^.*\/src\/lib\/stt\/(recognizer|transformersJs)\.ts$/, replacement: offline("./src/confenge-runtime/ml-disabled.js") },
  { find: /^.*\/src\/lib\/(doorReader|doorVectors|doorSuite)(?:\.(js|ts))?$/, replacement: offline("./src/confenge-runtime/door-disabled.js") },
  { find: /^\.\.?\/lib\/google\/AuthContext\.jsx$/, replacement: offline("./src/confenge-runtime/google-auth.jsx") },
  { find: /^\.\.?\/lib\/google\/auth\.js$/, replacement: offline("./src/confenge-runtime/google-auth.js") },
  { find: /^\.\.?\/lib\/google\/drive\.js$/, replacement: offline("./src/confenge-runtime/google-drive.js") },
  { find: /^\.\.?\/lib\/msgraph\/config\.js$/, replacement: offline("./src/confenge-runtime/m365-config.js") },
  { find: /^\.\.?\/lib\/msgraph\/(auth|composite|graphDrive)\.js$/, replacement: offline("./src/confenge-runtime/m365-disabled.js") },
  { find: /^\.\.?\/lib\/(cloudStore|sync\/composite)\.js$/, replacement: offline("./src/confenge-runtime/cloud-disabled.js") },
  { find: /^\.\.?\/lib\/ai\.js$/, replacement: offline("./src/confenge-runtime/ai-disabled.js") },
  { find: /^\.\/components\/UpgradeNotice\.jsx$/, replacement: offline("./src/confenge-runtime/UpgradeNotice.jsx") },
] : [];

// OpenTakeoff is a client-only static app: the takeoff canvas runs entirely in
// the browser (pdf.js + canvas + the geometry libs), persists to IndexedDB /
// localStorage, and builds to a static `dist/` you can host anywhere (GitHub
// Pages, Vercel, Netlify, an S3 bucket).
//
// The `/ai` proxy is OPTIONAL — it only matters if you run the bring-your-own-
// model AI sandbox in `../server` (see server/README.md). Without it, the app
// works fully; the AI hooks just stay dormant.
export default defineConfig({
  plugins: [react()],
  define: { __APP_VERSION__: JSON.stringify(pkg.version) },
  // On-device OCR (#469): ppu-paddle-ocr imports the bare `onnxruntime-web`,
  // which would bundle ORT's default (jsep) build and ship a second ~24 MB
  // wasm. Point it at the webgpu entry voice already uses, so both share the
  // one asyncify runtime. A regex, not a string key: a string also matches
  // `onnxruntime-web/…` prefixes and would break voice's own subpath imports.
  resolve: {
    alias: [
      { find: /^onnxruntime-web$/, replacement: "onnxruntime-web/webgpu" },
      ...confengeOfflineAliases,
    ],
  },
  // The STT worker (stt.worker.ts, RFC #59) lazy-imports its engine adapter,
  // which needs code-splitting inside the worker bundle — only the ES format
  // supports that (Vite's default iife errors on split worker builds).
  worker: { format: "es" },
  server: {
    port: 5173,
    proxy: {
      // The sandbox's /ai routes are key-locked (server/README.md). Export the
      // same OT_SANDBOX_API_KEY in the shell running `npm run dev` and the
      // proxy stamps the header on — the browser never handles the secret.
      "/ai": {
        target: "http://localhost:8000",
        headers: process.env.OT_SANDBOX_API_KEY
          ? { "X-API-Key": process.env.OT_SANDBOX_API_KEY }
          : {},
      },
    },
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});
