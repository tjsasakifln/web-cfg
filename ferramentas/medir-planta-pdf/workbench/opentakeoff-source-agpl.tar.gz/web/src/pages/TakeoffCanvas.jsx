import { calibratedScaleLabel } from '../lib/calibratedScaleLabel.js';
import { finishLabel, formatMessage, localizeText as uiText, toolFaceLabel, scaleGroups, scaleRatioLabel, measurementCount } from "../lib/i18n/core.js";
import { useTranslation, LanguageSwitcher } from "../lib/i18n/index.jsx";
import { useAnnotationWorkbench } from '../components/AnnotationWorkbench.jsx';
import { nativeTextRuns, markupPatch, applyMarkupPatch } from '../lib/annotationTools.js';
import ReferencePins, { PinButton } from "../components/ReferencePins.jsx";
// Takeoff Canvas — Phase 1 (+ pan/zoom + standard scales).
// Persistent, condition-driven 2D takeoff. Pick a color-coded condition (finish
// tag), click to trace areas; each shape computes SF + perimeter from geometry ×
// calibrated scale. Drawings + scale autosave per project and reload on return.
// Commit sums each condition into ScopeItem.measure and re-runs the takeoff.
//
// Pan/zoom is written DIRECTLY to the DOM (tfRef → style.transform) so dragging
// never triggers a React render — smooth on large sheets. Panning is always at
// hand on every input device: left-drag on open canvas pans (Select), a held
// draw-click that moves becomes a pan, middle-drag / right-drag / Space-drag /
// Pan tool pan always, and continuous trackpad scroll pans both axes. A
// discrete mouse-wheel notch zooms (glided), pinch (ctrl-wheel) zooms, ⇧-wheel
// pans. Geometry math reads tfRef (always current), so drawing stays accurate.

import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { keyText } from "../lib/keys.ts";
import { nextHatchId } from "../lib/takeoffConstants.ts";
import { TRADE_SUITES, ALL_TRADES, tradeHiddenIds, tradeCounts, sanitizeViewTrade, suiteById, conditionTrade } from "../lib/tradeSuites.ts";
import { buildTakeoffDocument, sheetEntry } from "../lib/takeoffDocument.js";
import { flushSync } from "react-dom";
import { Link, useNavigate } from "react-router";
import * as pdfjsLib from "pdfjs-dist";
import workerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import { isPdfSource, rangeParams } from "../lib/pdfSource";
import { store, isStaleTabError, STALE_TAB_MESSAGE, friendlyStoreError, projectIdFromUrl, emptyAnnotations, metaGet, metaPut, metaDelete, sha256Hex } from "../lib/store.js";
import { forgetThumbs, releaseThumbs } from "../lib/thumbs.js";
import { Z } from "../lib/ui.js";
import { getFocusMode, toggleFocusMode, onFocusModeChange } from "../lib/focusMode.js";
import { seedStampLibrary, instantiateStamp, markupToStampElement } from "../lib/stamps.js";
import { extractSvgPrimitives, svgToStamp } from "../lib/svgImport.js";
import { svgPlacedBox } from "../lib/svgpath.js";
import { imagePlacedBox, captureRectToImageGeom, resizeImageFromCorner, aspectFromDims, pickEmbedFormat, filterCaptures } from "../lib/markupImage";
import { rectMidpoint, pendingSourceOutcome, isTraceable, traceLabel } from "../lib/sourceTrace";
import { relativeAge, absoluteUtc } from "../lib/reltime";
import { ingestFiles } from "../lib/ingest.js";
import { parseTakeoffImport, mergeTakeoffImport } from "../lib/importTakeoff.js";
import { pendingByProposal, acceptConditionEditProposal } from "../lib/proposals.js";
import { scopeCollisions, collisionsByCondition } from "../lib/scopeCollision.js";
import { buildProjectArchive, parseProjectArchive, isProjectArchive, downloadArchive } from "../lib/projectArchive.js";
import { buildProfile, parseProfile, applyProfile, resetProfileDefaults, isProfileFile } from "../lib/profile.js";
import ToolMenu from "../components/ToolMenu.jsx";
import PlanNavigator from "../components/PlanNavigator.jsx";
import FirstTakeoffTour from "../components/FirstTakeoffTour.jsx";
import ToolTray from "../components/ToolTray.jsx";
import AssistantWindow from "../components/AssistantWindow.jsx";
import ConnectAI from "../components/ConnectAI.jsx";
import CompanySetup from "../components/CompanySetup.jsx";
import EstimatePanel from "../components/EstimatePanel.jsx";
import { sanitizeEstimateSettings, priceEstimate } from "../lib/estimate.js";
import { sanitizeBidProposal } from "../lib/bidProposal.js";
import { loadEstimatingDefaults } from "../lib/companySetup.js";
import { advanceTour, countFloorShapes, currentStep } from "../lib/firstTakeoff.js";
import { fetchSamplePlan } from "../lib/samplePlan.js";
import ReportPanel from "../components/ReportPanel.jsx";
import RevisionsPanel from "../components/RevisionsPanel.jsx";
import UserGuide from "../components/UserGuide.jsx";
import CopyTextReceipt from "../components/CopyTextReceipt.jsx";
import OcrDownloadNotice from "../components/OcrDownloadNotice.jsx";
import PageReadControl, { readControlPlacement, READ_CONTROL_LEFT } from "../components/PageReadControl.jsx";
import TakeoffsPanel, { clampPanelW, CONDITION_DND_MIME, ConditionAppearanceEditor } from "../components/TakeoffsPanel.jsx";
import { HATCHES, PALETTE, NO_FILL, HatchPattern, HatchSwatch } from "../components/hatches.jsx";
import { shapeFill as glyphFill, renderShapeGlyph } from "../components/shapeGlyphs.jsx";
import { renderMarkupGlyph } from "../components/markupGlyphs.jsx";
import { paintOrderedMarkups, markupsForSheet } from "../lib/markupPaint.ts";
import { Icon } from "../brand/icons.jsx";
import { RENDER_SCALE, MAX_GROUP, STANDARD_SCALES, parseSheetKey, compareSheetKeys, extractSheetNumber, detectScale, extractRegionText, extractTextMarks, extractDimTexts } from "../lib/sheets";
import { serializeSplitView, normalizeSplitView, wouldExceedSheetCap, canSplit } from "../lib/splitView";
import { LOW_MEMORY_DEVICE } from "../lib/deviceClass"; // same switch tilePool.ts sizes its worker pool on (Task 8: also gates split creation/mounting)
import SplitLayout from "../components/SplitLayout.jsx";
import ReferencePane from "../components/ReferencePane.jsx";
import DropZoneOverlay from "../components/DropZoneOverlay.jsx";
import { dropZoneAt, zoneToOrientation, SHEET_TAB_DND_MIME } from "../lib/dropZones";
import { joinAbuttingSpans } from "../lib/textjoin";
import { buildSheetIndex, dropFileFromIndex } from "../lib/planIndex";
import { labelsForFile, labelsOnFileChange, withPageLabel, withFoundLabels, withoutFile, withoutFileKeys, createLabelGens } from "../lib/sheetLabels";
import { snapsToVectors } from "../lib/cursorSnap";
import { textLayerReader, ocrCopyReaders, copyOcrRoute, readCopyText, createReadGate, boxOnPanel, copyIsScanLike, copyStartMiss, copyReaderChain, copyPlan, copyPictureInputs, textChainPageLines, hybridCopyReader, copyUnavailable, outcomeMessage, deliverCopy, makeReceipt, receiptExpires, receiptAfterEsc, receiptPlacement, RECEIPT_MS } from "../lib/copyText";
import { putSheetIndex, createChangeSignal, ocrSheetIndex, acceptsMeasuredPass, acceptsTextPass, readPlanOf, readWhat, mayLookUp, readableFromIndex } from "../lib/planSearch";
import { createOcrSession } from "../lib/ocr/session";
import { createConsentHost, focusAfterNotice } from "../lib/ocr/consentHost";
import { createPageCache } from "../lib/ocr/pageCache";
import { createPageReader, pageReadView, readSignature, backgroundRows, createReadRenderGate } from "../lib/ocr/pageRead";
import { createDocCache, createSheetSource, readHooks, lookupHooks, readdEffects, docIdleMax } from "../lib/ocr/sheetSource";
import { createSheetNamer, forgetSheetNames, markSheetNamesStale } from "../lib/sheetNamer";
import { createPageCounts } from "../lib/pageCounts";
import { getOcrClient } from "../lib/ocr/client";
import { pageTextIndex } from "../lib/pageTextIndex";
import { measurePage } from "../lib/pictures";
import { normalizeLoadedGroups } from "../lib/sheetGroups";
import { isCeilingCondition } from "../lib/ceilingKind.js";
import Lazy3D from "../components/Lazy3D.jsx";   // the 3D view: three.js loads only when the 3D button is pressed
import { isStitchKey, mintStitchId, sanitizeStitches, autoButt, stitchExtent, alignMembers, seamClips, mergePoints, mergeSegs, stitchAlive, stitchLayoutSig, pinnedFiles } from "../lib/stitches";
import { isCanvasBusy } from "../lib/canvasBusy";
import { rowToSeed } from "../lib/scheduleRows";   // the reader (scheduleRead, which loads the sheet graph) is import()ed on use
import { routeScheduleRead, countTextRuns, heldKeyWouldPress, EMPTY_BOX_MESSAGE, OCR_BUSY_MESSAGE, OCR_STARTING_MESSAGE, OCR_WAITING_MESSAGE, ocrReadingMessage } from "../lib/scheduleRoute";
import { readBoxOnDevice } from "../lib/scheduleOcrRead";
import { boxReadWords, boxTooLarge } from "../lib/ocr/boxRead";
import { pageSpans, spansInRect, graphSpans } from "../lib/pageSpans";
import { normalizeTag, newScheduleRows } from "../lib/scheduleEdit";
// Condition twins — the whole inheritance rule is in lib/variants.ts (test/variants.test.ts);
// this file only calls it from the material write paths and the condition deletes.
import {
  mintTwin, variantTag,
  propagateRowPatch, propagateRowAdd, propagateRowRemove,
  markRowLocal, dropRowLocal, followFamily, splitFromFamily, promoteOnDelete
} from "../lib/variants.ts";
import { isGoogleConfigured } from "../lib/google/auth.js";
import { extractVectorGeometry, buildMask, floodRegionSealed, sealRadiiFor, doorWedgeCapPx, minPassRadiusFor, oneClickRing, ringArea, MASK_MAX_DIM, MIN_PASS_FT, SENS_STRICT, SENS_BALANCED, SENS_AGGRESSIVE } from "../lib/oneclick";
import { tidyRing, axisLockPoint } from "../lib/ringTidy";
// The Symbol tool (#264) — the canvas face for the sweep engine. The engine,
// counter-examples, the luminance channel, and label corroboration all live
// as pure web libs already; this file adds only the gesture and the review.
import { sweepSymbols } from "../lib/symbolsweep";
import { labelPlacements } from "../lib/symbollabels";
import { traceConfidence, floodSignals } from "../lib/confidence";
// The scale-acceptance ruler (a calibrated bar drawn on the sheet after a scale
// is set) — the owner's call, 2026-08-24: it serves no purpose on the sheet.
const SHOW_SCALE_GUIDE = false;
const CONFENGE_LOCAL_ONLY = import.meta.env.VITE_CONFENGE_RUNTIME === "true";
const VISIBLE_TRADE_SUITES = CONFENGE_LOCAL_ONLY ? TRADE_SUITES.filter((trade) => trade.id !== "doors") : TRADE_SUITES;
// net engine runs in a worker: a dense sheet's build is 30-90 s of pure
// geometry and must never block the page (measured: "Page Unresponsive"
// on Comfort Inn when it ran on the main thread)
const netWorker = typeof Worker !== "undefined" ? new Worker(new URL("../lib/netroom.worker.js", import.meta.url), { type: "module" }) : null;
const netPending = new Map();   // req → {resolve}
let netReq = 0;
if (netWorker) netWorker.onmessage = (ev) => { const m = ev.data; const p = netPending.get(m.req); if (p) { netPending.delete(m.req); p.resolve(m); } };
function netCall(msg) { return new Promise((resolve) => { const req = ++netReq; netPending.set(req, { resolve }); netWorker.postMessage({ ...msg, req }); }); }
import { buildRasterMask, RASTER_MIN_IMG_FRAC, RASTER_MIN_SEGS, RASTER_RDP_EPS } from "../lib/rastermask";
// PDF layer roles (#85): the pure name→role classifier and the override
// plumbing shared with the MCP session — the canvas consumes buildMask's
// opts.roles seam exactly the way the server does, one engine, one meaning.
import { buildLayerInfos, effectiveLayerRoles, layerRoleCodes, segRoles, sanitizeLayerOverrides } from "../lib/layers";
import { detectCandidateRule, buildRuleFromSeed, applyRuleToProject } from "../lib/rules";
import { deriveTransitionRuns, transitionRefusal } from "../lib/transitions";
import { conditionTotals, verticalWallSf, downloadText } from "../lib/totals.js";
import { rotatePdfPage, reorderPdfPages, deletePdfPage, extractPdfPages, mergePdfDocuments, insertPdfPages } from "../lib/pdfPageTools.ts";
import { rotateTakeoffOnSheet, remapWorkspaceState, buildKeyRemap, formatSheetKey } from "../lib/pageTransforms.ts";
import { measurementBreakdown } from "../lib/measurementBreakdown.js";
import { shapesInZone } from "../lib/zone.js";
import { sanitizeSheetLevels } from "../lib/sheetLevels.js";
import { sanitizeConditionColumns, sanitizeConditionAttrs, renameColumnValue, columnLabel } from "../lib/conditionColumns.js";
import { sanitizeShapeLabels, sanitizeShapeLabelsOnShapes, renameShapeLabel, shapeLabelValue } from "../lib/shapeLabels.js";
import { nextHidden, revealed } from "../lib/conditionVisibility.js";
import { buildMarkedSetPdf, downloadBytes, splitLoadedSheets, skippedPdfsNote } from "../lib/markedset.js";
import { repeatPlan } from "../lib/repeatTool.js";
import { createDragCache, sheetContentSignature, dragFilename, downloadUrlEntry } from "../lib/dragOut.js";
import { counterRows } from "../lib/liveCounter.js";
import { qtyLabels, resolveMarkup } from "../lib/noteFields.ts";
import LiveCounter from "../components/LiveCounter.jsx";
import { loadProfiles } from "../lib/identity.js";
import { resolveBranding, loadBrandingSelection } from "../lib/branding.js";
import { starPath, cloudPath, thinStroke, strokePathD, chiselRibbon, buildSnapGrid, nearestSnap, ANGLE_TOL, angleSnap, closedMetrics, polyWithHolesMetrics, openLen, pointInPoly, hitShape, distToSeg, reflectVertsNorm, ringSelfIntersects, minAreaRect } from "../lib/geometry.js";
// Drawing style (draft chrome look) — one resolved token object (DS in JSX,
// dsRef.current in the imperative movers) replaces the hardcoded cobalt/star
// literals across the in-progress trace, cursor, and selection chrome.
import { DRAW_STYLES, DRAW_STYLE_IDS, resolveDrawStyle, markerPath, drawDashFor, rgbaFromHex, getDrawStyle, setDrawStyle, onDrawStyleChange } from "../lib/drawStyles.js";
import { getDraftOutline, setDraftOutline, onDraftOutlineChange } from "../lib/draftOutline.js";
import { flattenCurve } from "../lib/curve.js";
import { flattenArcRing, arcPathD, arcLength } from "../lib/arc.js";
// Notes are ink on the sheet (lib/markupText): sized in page points, wrapped at
// three inches, floored for legibility on screen — the Marked Set burns the
// same layout, so the print looks like the canvas it was reviewed on.
import { NOTE_PT, inkPx, layoutNote, noteBox, canvasMeasure } from "../lib/markupText.js";
import { snapWeight, LINE_STYLES, LINE_STYLE_IDS, WEIGHT_STEPS } from "../lib/lineStyles.js";
import { nextRfiNumber } from "../lib/rfi.js";
import { libFields, matFieldOverridden, libPushPatch, libRevertPatch, libEntryPatch, matEditPatch } from "../lib/materials.js";
import { assemblyRows } from "../lib/assemblies.js";
import RfiPanel from "../components/RfiPanel.jsx";
import StampPanel from "../components/StampPanel.jsx";
import MaterialUnitSelector from '../components/MaterialUnitSelector.jsx';
import { getMaterialUnit, setMaterialUnit } from '../lib/materialUnits.js';
import ImportSchedulePanel from "../components/ImportSchedulePanel.jsx";
import DoorsSuitePanel from "../components/DoorsSuitePanel.jsx";
import { matchDoorTags, buildDoorSuite, estimateGroups, doorCenter, doorSetColor, DOOR_NEUTRAL, countMarkPoints, openingLine, heldBack, DOOR_KIND_LABEL } from "../lib/doorSuite.ts";
// Roll goods (#136): lib/rollgoods.js is the pure packing engine (untouched
// here), lib/rollTakeoff.js the pure shapes→engine bridge; RollPanel is the
// docked diagram/reorder desk. Cut edits commit through the rollcut command.
import RollPanel from "../components/RollPanel.jsx";
// Layers (#85 phase 2): the docked layer-table desk — stated roles + the
// per-layer Auto/Wall/Off overrides that feed the mask's role short-circuit.
import LayerPanel from "../components/LayerPanel.jsx";
import { rollColorForType } from "../lib/rollgoods.js";
import { computeRollTakeoff, seamLfByShape } from "../lib/rollTakeoff.js";
// In-canvas takeoff agent — BYO-key tool-use loop (lib/agentLoop) aiming the
// registry of deterministic tools (lib/agentTools); this file provides the
// CAPABILITIES those tools close over and the review gate their proposals
// pass through. AiSettings is the config surface for the ai.js seam.
import AgentChat from "../components/AgentChat.jsx";
import "../styles/agentChat.css";
import { useAgentChat } from "../lib/useAgentChat.js";
import { historyMessages, notReadyMessage, withViewContext } from "../lib/agentChat.js";
import { ScanStar, OtLockup } from "../brand/marks.jsx";
import WorkspacePanel from "../components/WorkspacePanel.jsx";
import "../styles/premiumWorkspace.css";
import { WorkspaceNavigator, WorkspaceCommandMenu } from "../components/WorkspaceChrome.jsx";
import { PremiumRail, PremiumTopBar, CanvasSideTabs } from "../components/PremiumChrome.jsx";
import ConditionsDock from "../components/ConditionsDock.jsx";
import { useWorkspaceLayout, WorkspaceLayoutDialog, DockHandle, DockTargets } from "../components/WorkspaceLayout.jsx";
import AiSettings from "../components/AiSettings.jsx";
import { agentToolDefs, executeAgentTool, agentScaleGate } from "../lib/agentTools.js";
import { runAgentLoop } from "../lib/agentLoop.js";
import { runVoiceCommand, isAgentHandoffTrigger, shouldOfferAgentHandoff } from "../lib/voiceActions";
import { createVoiceRecognizerClient } from "../lib/voiceRecognizerClient";
import { startCapture, captureSupported } from "../lib/voiceCapture";
import { aiConfig, isAiConfigured } from "../lib/ai.js";
import AccountChip from "../components/AccountChip.jsx";
import PresenceChip from "../components/PresenceChip.jsx";
import { StylePreview } from "../components/DrawStylePicker.jsx";
import { useGoogleAuth } from "../lib/google/AuthContext.jsx";
import { projectHomeFolderId } from "../lib/projectHome.js";
import { getTheme, toggleTheme, onThemeChange } from "../lib/theme.js";
// Pure data constants (render/zoom budgets, snap tuning, tool descriptors,
// flooring starter conditions) live in lib/canvasConstants.js; the pure
// module-scope helpers (uid, clamp, isDangerMsg, instantiateTemplate,
// seedConditions) in lib/canvasUtil.js. autoRenderScale/invertCanvasPixels
// retired from this file's imports — #86 moved painting into the tile
// worker pool (lib/tileCompositor.ts); both still exist as pure exports
// (renderBudget.test.ts covers autoRenderScale) pending a follow-up cleanup
// pass once the tile path has proven itself in production.
import {
  PANEL_GAP, DETAIL_ENGAGE, DETAIL_MARGIN, SYNC_MS, GESTURE_MS, SNAP_CELL,
  MEASURE_TOOLS, CUT_TOOLS, MARKUP_TOOLS, MARKUP_IDS, HL_INKS, HL_SIZES,
  MARKUP_IMG_MAX, MAX_IMAGE_MARKUP_BYTES, MARKUP_UPLOAD_MAX_BYTES, MARKUP_DECODE_MAX_AREA,
  FLOAT_GAP, SWEEP_PANEL_W, CANVAS_EDGE, RAIL_CLEAR, ZONE_PANEL_W,
} from "../lib/canvasConstants.js";
import { uid, clamp, isDangerMsg, instantiateTemplate, conditionToTemplate, seedConditions } from "../lib/canvasUtil.js";
import { repairConditionMultipliers, describeMultiplierRepair } from "../lib/multiplier.js";
// Tile-pyramid rendering (#86) — pure math in lib/tiles.ts (tested), worker
// pool in lib/tilePool.ts, DOM/Worker orchestration glue here via one
// long-lived compositor instance. Replaces the old single-raster base +
// threshold-gated detail-overlay effects below.
import { createTileCompositor } from "../lib/tileCompositor";
import { createTilePool, TEXT_SCAN_WORKERS } from "../lib/tilePool";
import { requiredDensity as tileRequiredDensity } from "../lib/tiles";
// Shape provenance policy now lives in ONE place: lib/shapeCommands.js. Every
// meaningful mutation of `shapes` (create / reshape / reassign / relabel /
// delete) is a COMMAND applied through dispatchShape below — the chokepoint
// that stamps created_at / stampEdit centrally, tallies deletion counters, and
// records undo/redo. Explicit NON-edits that must NOT stamp (they rewrite
// shape records without a human touching the geometry) either ride the
// `replace` command (rescaleSheet's computed re-price, hydrate) or stay as raw
// setShapes (the label-vocabulary renames, live drag PREVIEW frames, the
// hydrate-time sanitizers, per-shape height/thickness re-pricing).
// nowIso stays imported for the non-shape records (markups, RFIs, conditions).
import { nowIso, mintUuid, setAuthorName, authorName } from "../lib/provenance.js";
import { applyShapeCommand, geomSnapshot, vertsEqual, recordCommand } from "../lib/shapeCommands.js";
import { applyApprovalCommand, sanitizeApprovals, approvalInk, APPROVAL_R } from "../lib/approvals.js";
import { findCutoutParent, subtractCutout, recomposeCutouts, cutRunsAcross } from "../lib/cutout.js";
import { normalizeAgentReview } from "../lib/reviewState.js";
import { oneClickEnabled, ONE_CLICK_GATE_MESSAGE, commandBoxEnabled, ocrEnabled } from "../lib/gate.js";
import { computeShapeMetrics, needsMetrics, recalibrateShapes, linearVerticalFt } from "../lib/shapeMetrics.js";
import { fmtCheckLen, parseLenInput, checkVerdict, M_PER_FT, areaVal, areaUnit, lenVal, lenUnit, calInputToFeet, heightVal, heightUnit, heightInputToFeet, heightStep, dimInputStr, dimLabel, volVal, volUnit } from "../lib/units";
import * as panelGeom from "../lib/panelGeometry.js";

// Carpet roll width — a run reaching this needs a seam. The live cursor readout
// turns amber at/past it so the estimator sees where seams fall while tracing.
const CARPET_ROLL_FT = 12;

// Paint/pick tiers (#116): a filled Area passes hitShape anywhere inside its
// fill, so in raw creation order an Area drawn over a Counter, Line, or Surface
// both paints above it and eats every pick inside it — the covered element
// becomes unselectable. Tiers put fills at the bottom, deducts just above their
// parent fills, runs above that, count pins on top. The renderer paints the
// stack ascending and both pickers scan the SAME stack descending, so what
// reads as on-top is always what a click lands on. Creation order still breaks
// ties within a tier (stable sort), so overlapping Areas keep newest-wins.
const ROLE_TIER = { floor_area: 0, deduct: 1, linear: 2, surface_area: 2, count: 3 };
const tierOf = (s) => ROLE_TIER[s.measure_role] ?? 0;

// The tools whose boundary can bend mid-measure (#284): the same click, the
// same commit, the curve is just a property of the points you placed. Zone is
// a query region, not a quantity, and One-Click traces its own ring.
const CURVABLE = new Set(["area", "deduct", "linear", "surface"]);
// Click-select against a curved line's DRAWN path: flatten the control points and
// hand hitShape a stand-in shape (lib/geometry.js stays byte-identical with Spline's).
function hitShapeC(s, x, y, w, h, thr) {
  if (!s.curved) return hitShape(s, x, y, w, h, thr);
  const flat = flattenCurve((s.verts_norm || []).map(([nx, ny]) => [nx * w, ny * h]));
  return hitShape({ ...s, verts_norm: flat.map(([px, py]) => [px / w, py / h]) }, x, y, w, h, thr);
}

pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;
// What opens a sheet (#580): a byte-range source where the store keeps the
// file as a Blob, so pdf.js reads the cross-reference table and the pages on
// screen, not the whole set; else the file's bytes, as before (cloud mode).
// What needs every byte (export, page tools) still asks for loadPdfData.
const pdfSourceOf = (file) => (typeof store.loadPdfSource === "function" ? store.loadPdfSource(file) : store.loadPdfData(file));
const openPdf = (data) => pdfjsLib.getDocument(isPdfSource(data) ? rangeParams(pdfjsLib.PDFDataRangeTransport, data.blob) : { data });

// Hatch templates, palette, NO_FILL, and the HatchPattern/HatchSwatch pieces
// live in components/hatches.jsx — shared with the TakeoffsPanel.

// Docked Takeoffs panel geometry — per-user UI prefs (localStorage, diff-only
// overrides like the report column prefs), NEVER in the takeoff payload: panel
// width inside buildPayload would show up as noise in every snapshot diff.
// (The width clamp (clampPanelW, wrapping PANEL_MIN_W/PANEL_MAX_W) is exported
// by the panel itself — ONE clamp, so a future range change can't diverge
// between the panel's own drag clamp and the load-time clamp here.)
const PANEL_PREFS_KEY = "opentakeoff_panel";
// The docked panel now starts COLLAPSED: the top-bar palette band (pinned chips
// + the restored active-condition appearance editor) is the primary condition
// surface, so the sidebar stays out of the way until you ask for it — via the
// canvas rail toggle or by double-clicking a palette chip (openConditionInPanel).
// Prefs persist diff-only against these defaults. Because the OLD default was
// open (collapsed:false), a previously-open panel stored no diff and is
// indistinguishable from "never touched", so this flip DOES start those users
// collapsed on first load after the change (a one-time migration, not a per-user
// choice being honored). An explicit COLLAPSE made under the old default is
// preserved; any later toggle re-persists normally.
const PANEL_DEFAULTS = { w: 320, collapsed: true, strip: false, az: false, group: false };

// Narrow-viewport switch (phones). Everything it gates is layout-only — the
// Takeoffs panel presents as an overlay instead of docking (a 240px+ dock
// covers a phone screen), and the live readout drops to a bottom strip.
// ≥701px is byte-for-byte the existing desktop layout.
const NARROW_MQ = "(max-width: 700px)";
function useIsNarrow() {
  const [narrow, setNarrow] = useState(() => typeof window !== "undefined" && window.matchMedia(NARROW_MQ).matches);
  useEffect(() => {
    const mq = window.matchMedia(NARROW_MQ);
    const on = () => setNarrow(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return narrow;
}
// Top-bar quick-access condition palette: a curated handful (≤9) of pinned
// conditions for one-click activation without leaving the canvas. Palette holds
// condition ids (workspace-scoped), so it persists with the annotation payload,
// not the per-user panel prefs. Capped at 9 so it maps 1:1 onto the 1–9 hotkeys.
const PALETTE_MAX = 9;

// status-bar verb column — the armed tool spoken as its MCP verb, so agent and
// human activity read in the same instrument language.
const TOOL_VERB = {
  select: "select", area: "measure_polygon", rect: "measure_polygon",
  deduct: "cut_out", "deduct-rect": "cut_out",
  linear: "measure_line", surface: "measure_surface",
  count: "place_count", oneclick: "one_click", calibrate: "set_scale",
  symbol: "symbol_sweep",
  check: "check_dimension", zone: "zone_check", "stitch-align": "stitch_align",
  schedule: "find_schedule", highlighter: "annotate", cloud: "annotate",
  callout: "annotate", text: "annotate", highlight: "annotate",
  arrow: "annotate", dimension: "annotate", stamp: "annotate", bubble: "annotate",
  textcopy: "read_sheet_text",
};

// Pure geometry helpers (star/cloud paths, snap grid, angle lock, metrics,
// hit-testing) live in lib/geometry.js — byte-identical with Spline's copy.

// The materials/column editors (MaterialsEditor, ColumnSelects, AddValueInput)
// live in components/TakeoffsPanel.jsx — the panel is their only surface now.

// Pure crop math for the detail view (Task 6, #86-family): the visible
// region of surface `d` (in ITS OWN image px), intersected with any seam
// clip, expanded by DETAIL_MARGIN, given the surface's own transform `t`
// ({x,y,scale}) and its container's bounding rect `r` ({width,height}).
// Shared by the primary's multi-panel detail sync (syncTilePanelsRef below,
// one `d` per drawPanels entry, all under the SAME shared `t`/`r`) and the
// reference pane's own single-surface detail sync (paintReferenceDetail
// below, its OWN `t`/`r` — ReferencePane.jsx owns an independent transform
// and viewport, never the primary's) — this is the one place either caller
// could get the margin/clip math subtly wrong, so it exists exactly once.
// Returns null when `d` is fully off-screen; the caller hides its canvas.
function detailCropFor(t, r, d) {
  const vx0 = d.clip ? Math.max(d.x, d.clip.x) : d.x;
  const vy0 = d.clip ? Math.max(d.y, d.clip.y) : d.y;
  const vx1 = d.clip ? Math.min(d.x + d.w, d.clip.x + d.clip.w) : d.x + d.w;
  const vy1 = d.clip ? Math.min(d.y + d.h, d.clip.y + d.clip.h) : d.y + d.h;
  let x0 = Math.max((-t.x) / t.scale, vx0) - d.x;
  let y0 = Math.max((-t.y) / t.scale, vy0) - d.y;
  let x1 = Math.min((r.width - t.x) / t.scale, vx1) - d.x;
  let y1 = Math.min((r.height - t.y) / t.scale, vy1) - d.y;
  if (x1 <= x0 || y1 <= y0) return null; // source off-screen
  const mw = (x1 - x0) * DETAIL_MARGIN, mh = (y1 - y0) * DETAIL_MARGIN;
  x0 = Math.max(0, x0 - mw); y0 = Math.max(0, y0 - mh);
  x1 = Math.min(d.w, x1 + mw); y1 = Math.min(d.h, y1 + mh);
  // Position bases are relative to the canvas's offset parent: the stage for
  // a plain panel, the clipping wrapper for a stitch member (d.clip unset
  // for the reference pane, so xBase/yBase collapse to d.x/d.y there).
  const xBase = d.clip ? d.x - d.clip.x : d.x;
  const yBase = d.clip ? d.y - d.clip.y : d.y;
  return { x0, y0, x1, y1, xBase, yBase };
}

export default function TakeoffCanvas() {
  const { t: tr, language } = useTranslation();
  const measureTools = MEASURE_TOOLS.map((item) => ({ ...item, label: tr(item.label) }));
  const cutTools = CUT_TOOLS.map((item) => ({ ...item, label: tr(item.label) }));
  const markupTools = MARKUP_TOOLS.map((item) => ({ ...item, label: tr(item.label) }));
  // Client-only: a single local workspace in this browser (no project id, no backend).
  const [sheets, setSheets] = useState([]);
  const [active, setActive] = useState("");      // active source PDF file name
  const [page, setPage] = useState(1);           // 1-based page within the active PDF
  const [pageCount, setPageCount] = useState(1); // pages in the active PDF
  const [view, setView] = useState("canvas");    // "gallery"/"picker" overlay the canvas (gallery-first on empty projects)
  // Cloud mode = the active store is a Drive-backed cloudStore (it has listFolder;
  // localStore does not). In cloud mode an empty project shows the Drive file
  // PICKER instead of the local drag-in prompt, so we don't auto-download every
  // PDF in the folder (spec books, as-builts). Stable per mount (store is swapped
  // in before the canvas mounts).
  const cloudMode = typeof store.listFolder === "function";
  // Reactive sign-in state: the "browse team projects" toolbar link is a
  // convenience shortcut for someone ALREADY signed in — it must never appear
  // while signed out, or it'd be a second OAuth entry point (a /projects
  // sign-in wall) in the toolbar, breaking the pre-Drive local-first look.
  const { user: googleUser } = useGoogleAuth();
  // Client-side exit back to the project home (`/`) — main.jsx's gate cleanup
  // restores the local store on the way out, so this navigation is safe.
  const navigate = useNavigate();
  // Two distinct exits out of a cloud project, both needed once every sheet is
  // closed: "Close project" always works (it's just leaving `/?project=` for
  // the local canvas — main.jsx's gate cleanup restores the local store), so
  // it's the one guaranteed path out even on deployments with no Projects root
  // configured. "Browse projects" additionally jumps straight to the team's
  // project list at /projects, when the build names one.
  const closeProject = () => navigate("/");
  const browseProjects = projectHomeFolderId() ? () => navigate("/projects") : null;
  const [openTabs, setOpenTabs] = useState([]);   // sheetKeys open as tabs across the top
  // Sheet-tab strip: past MANY_TABS the row stops wrapping and becomes a
  // horizontal strip with ◀ ▶ arrows (every open sheet stays a visible,
  // clickable tab — no dropdown to hunt through). The active tab is kept in
  // view whenever the sheet changes.
  const MANY_TABS = 8;
  const tabStripRef = useRef(null);
  // Instant, not smooth: smooth scrollBy/scroll-behavior on this strip is cancelled
  // every frame (the canvas render loop keeps the layout hot), so the arrows
  // silently did nothing on prod. A direct scrollLeft write always lands.
  const scrollTabStrip = (dir) => { const el = tabStripRef.current; if (el) el.scrollLeft = Math.max(0, el.scrollLeft + dir * Math.max(160, el.clientWidth * 0.6)); };
  const [galleryLabels, setGalleryLabels] = useState({}); // sheetKey → title-block number, all files
  const [labelsByFile, setLabelsByFile] = useState({}); // { file: { pageNum: "A003" } } from the title block
  const pageLabels = labelsForFile(labelsByFile, active); // the active file's only: page numbers repeat across files
  const [sheetGroup, setSheetGroup] = useState([]);   // sheetKeys shown side-by-side; [] = single-sheet mode
  const [sheetLevels, setSheetLevels] = useState({}); // sheetKey → level label ("L1") — persisted (additive `sheet_levels` key); groups the gallery for multi-floor sets
  const [lastGroup, setLastGroup] = useState([]);     // most recent side-by-side composition — "Regroup" restores it
  const [focusKey, setFocusKey] = useState("");         // panel of the last click — scale/calibrate target in group mode
  // Stitches (#161): persisted match-line composites (lib/stitches.ts) — a
  // stitch opens as ONE panel; its members are a render-time concern only.
  const [stitches, setStitches] = useState([]);
  // Doors suite answers (lib/doorSuite.ts question id → the answer picked), saved with the project
  const [doorAnswers, setDoorAnswers] = useState({});
  // PDF rotation tracking (#591): sheetKey -> { angle, hash } where hash is original file SHA-256
  const [sheetRotations, setSheetRotations] = useState({});
  const sheetRotationsRef = useRef(sheetRotations);
  sheetRotationsRef.current = sheetRotations;
  const [rotatingKey, setRotatingKey] = useState(null); // sheetKey currently reloading rotated tiles (prevents flash)
  const [alignPt, setAlignPt] = useState(null);       // stitch-align first click (stage px) — ephemeral, never persisted
  const [zoneCheck, setZoneCheck] = useState(null);   // ephemeral zone-check region {key, pts (norm)} — never persisted (buildPayload doesn't read it)
  const [zoneExpand, setZoneExpand] = useState(null); // zone panel: condition id with materials expanded
  // Shared reset for the two zone transients — every site that discards
  // OTHER in-flight measurement state (sheet change, snapshot load, hydrate)
  // must discard this too, or the results panel and glow can outlive the
  // region/shapes they described. See the tool-change effect below for the
  // matching `poly` (pending zone trace) reset, which has its own rule.
  const resetZone = () => { setZoneCheck(null); setZoneExpand(null); };
  const [pinSelectedId, setPinSelectedId] = useState(null);
  const [pinsOpen, setPinsOpen] = useState(true);
  const [markups, setMarkups] = useState([]);                // cloud/callout/text annotations (separate from measurement shapes)
  const [approvals, setApprovals] = useState([]);            // approval seals — estimator APPROVED ink + agent AGENT marks (lib/approvals.js; its own family, not markups)
  const [markupDraft, setMarkupDraft] = useState(null);      // in-progress markup first point (cloud/callout/highlight)
  // Source-trace flash (◎, wired by slice 3) — a transient highlight on a
  // capture's ORIGIN region, rendered inside the SOURCE panel's own <g> (so it
  // inherits that panel's xOffset like everything else there). Its OWN state —
  // NEVER written onto a markup: { sheet_id, rect: [[nx0,ny0],[nx1,ny1]] (the
  // src_rect shape, normalized 0..1), token } | null. `token` must change on
  // every trace, even a repeat of the SAME region, so the render can key a
  // fresh remount off it — see the render site for why. Slice 2 only defines
  // and renders this; slice 3 SETS it (via the `flashSource` helper, see
  // traceSource below) and owns its staleness/clear lifecycle — both the
  // panel-left clear effect below AND the one-shot auto-clear timer that
  // `flashSource` arms so the CSS pulse (which holds its last frame forever
  // once its single run finishes) doesn't end up as a permanent opaque box.
  const [sourceFlash, setSourceFlash] = useState(null);
  // Docked LEFT panel — one at a time, never overlapping: null | "markup" | "stamp" | "rfi".
  // The right-rail buttons switch tabs; the dock reflows the canvas (mirrors the
  // docked Takeoffs panel on the right).
  const [leftTab, setLeftTab] = useState(null);
  const [showMarkups, setShowMarkups] = useState(true);       // markup SVG layer visibility (orthogonal to the export checkbox)
  const [hiddenConds, setHiddenConds] = useState(() => new Set()); // condition ids whose takeoffs are hidden on the canvas (#440) — VIEW STATE: never persisted, never touches totals/report/exports
  // the status bar's Trade view (lib/tradeSuites.ts): shows one trade's conditions and shapes, and books new
  // conditions to it. Per-user VIEW STATE in localStorage — never a quantity, never in the project file.
  const [viewTrade, setViewTrade] = useState(() => { try { return sanitizeViewTrade(localStorage.getItem("opentakeoff_view_trade")); } catch { return ALL_TRADES; } });
  useEffect(() => { try { localStorage.setItem("opentakeoff_view_trade", viewTrade); } catch { /* private mode */ } }, [viewTrade]);
  // switching trades moves the active condition to that trade's first one, when it has any
  const pickViewTrade = (raw) => {
    const v = sanitizeViewTrade(raw);
    setViewTrade(v);
    if (v === ALL_TRADES) return;
    const cs = agentStateRef.current.conditions.length ? agentStateRef.current.conditions : conditions;
    const cur = cs.find((c) => c.id === activeCond);
    if (cur && conditionTrade(cur) === v) return;
    const first = cs.find((c) => conditionTrade(c) === v);
    if (first) activateCondition(first.id, { reassign: false });
  };
  const viewTradeRef = useRef(viewTrade);   // mintCondition reads the live value (the agent can mint mid-run on a stale closure)
  viewTradeRef.current = viewTrade;
  const [editor, setEditor] = useState(null);                 // inline on-canvas text editor { left, top, value, multiline, commit } (retires window.prompt; screen-space overlay, NOT an SVG child)
  const [panelEditId, setPanelEditId] = useState(null);       // markup id whose text is being edited inline in the markup panel (off-screen fallback for the ✎ button)
  const [captureQuery, setCaptureQuery] = useState("");       // always-on name filter over the GLOBAL Captures list (transient, mirrors condQuery)
  // Stamp library (browser-global, meta store) — reusable annotation stamps
  // dropped click-to-place (#40). armedStamp holds the stamp picked from the
  // palette; while tool==="stamp" each canvas click instantiates it as normal,
  // editable markups. Persist mirrors the template/material library pattern.
  const [stampLib, setStampLib] = useState({ stamps: [], sets: [] });
  const stampLibRef = useRef({ stamps: [], sets: [] });       // readable outside a render (persist merges)
  const [armedStamp, setArmedStamp] = useState(null);         // stamp armed for click-to-place (tool==="stamp")
  // Docked Takeoffs panel (right side, reflows the canvas): width + collapsed
  // persist per user in localStorage as diffs against PANEL_DEFAULTS.
  const [panelPrefs, setPanelPrefs] = useState(() => {
    try {
      const p = JSON.parse(localStorage.getItem(PANEL_PREFS_KEY) || "{}");
      return { ...PANEL_DEFAULTS, ...(p && typeof p === "object" && !Array.isArray(p) ? p : {}) };
    } catch { return { ...PANEL_DEFAULTS }; }
  });
  // Panel VIEW state (tab, filter, collapsed groups, ⌘/⇧ multi-select) lives
  // in the TakeoffsPanel component. Two hooks back into it from here:
  const [panelEpoch, setPanelEpoch] = useState(0);   // bumped by hydrate — the panel clears the transients that described the replaced conditions
  const panelSelectionRef = useRef(null);            // the panel registers "dismiss the bulk selection" here; activateCondition calls it
  const [templates, setTemplates] = useState([]);             // condition template library (browser-global, meta store)
  const templatesRef = useRef([]);                            // readable inside hydrate (seeding a fresh workspace)
  const [matLib, setMatLib] = useState([]);                   // material library (browser-global; conditions COPY on attach + carry lib_id)
  const labeledFileRef = useRef("");             // which file we've already title-block-scanned
  const textScanRef = useRef(null);       // the running whole-file text scan's token: a new scan, or unmount, ends the old one
  const scanHoldRef = useRef(0);          // performance.now() until which the text scan starts no new read: a sheet is changing
  const wantSheetRef = useRef(new URLSearchParams(window.location.search).get("sheet") || "");
  const [status, setStatus] = useState("loading");
  const [err, setErr] = useState("");

  const [tool, setTool] = useState("select");
  const [panelImgs, setPanelImgs] = useState({}); // { sheetKey: {w,h} } rendered bitmap dims per panel
  const [tf, setTf] = useState({ x: 0, y: 0, scale: 1 }); // render mirror of tfRef
  const [splitView, setSplitView] = useState(null); // null = single canvas; else { orientation, ratio, refKey }
  // Task 8: manual "Restore split" override — lets a user explicitly re-mount
  // an already-open split's reference pane on a device canSplit (below) would
  // otherwise suppress it on (narrow viewport / low-memory). Reset the moment
  // the split itself collapses so a stale override never carries into the
  // NEXT split. Keyed on presence/absence only (not the splitView object
  // itself, whose identity churns every ratio-drag tick and would re-run this
  // pointlessly on every one of those).
  const [splitOverride, setSplitOverride] = useState(false);
  useEffect(() => {
    if (!splitView) setSplitOverride(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- intentionally narrowed to presence/absence (see comment above), not splitView's own churny identity
  }, [!!splitView]);
  // Live drop-zone under a dragged sheet tab (Task 4) — null hides the overlay.
  const [dragZone, setDragZone] = useState(null);
  // ── reference pane resolution (Task 3) — independent of panelImgs/groupKeys ──
  // panelImgs is fully REPLACED on every group render (see setPanelImgs in the
  // group effect below), so a referenced sheet outside the primary group needs
  // its own dims + open/paint lifecycle, never borrowed from that map.
  const [refPanelImg, setRefPanelImg] = useState(null);   // {w,h} for splitView.refKey once resolved; null while unresolved/loading
  const [refInvalid, setRefInvalid] = useState(null);      // the refKey string that's currently known unresolvable, or null
  const [refEpoch, setRefEpoch] = useState(0);              // bumped every time this refKey's compositor entry is (re)opened — repaint signal independent of panelImg's identity
  // Dangling refKey (a stale key from a removed sheet, a bad debug-hook call,
  // an out-of-range page): never frame the wrong sheet — suppress refKey down
  // to null the moment it's known bad, same as "no split reference" at all.
  const rawRefKey = splitView?.refKey || null;
  const effectiveRefKey = rawRefKey && refInvalid === rawRefKey ? null : rawRefKey;
  // The reference pane's tab bar (Task 7): the set of sheets dropped there.
  // normalizeSplitView backfills refSet on every LOAD, but a split minted
  // directly by setSplitView in this file isn't required to set it — same
  // [refKey] fallback the codec uses, kept here so every read site (the bar
  // itself, the handlers below) can trust this array rather than
  // re-deriving the fallback each time.
  const refSet = splitView?.refSet?.length ? splitView.refSet : (rawRefKey ? [rawRefKey] : []);
  // Click a reference-bar chip: re-frame it. A no-op if it's already framed
  // (still a harmless setSplitView call — the resolve effect's `sameKey`
  // check absorbs it without touching refDimsRef/refDetailCancelRef).
  const selectRefTab = (key) => setSplitView((s) => s && { ...s, refKey: key });
  // ✕ on a chip: drop it from the set. Reframes to the sheet at the same
  // INDEX the removed chip held (clamped to the new length) when the removed
  // chip was the one currently framed — same "land where you were, not
  // always the first" idiom as closeTab's own reframe above, so removing
  // chip 2-of-3 lands on the new chip 2, not always back to chip 1.
  // Removing the LAST chip empties the set — Task 8's empty-pane guard:
  // rather than refuse (Task 7's behavior), auto-collapse the whole split.
  // ReferencePane's tab bar shows the ✕ even on a solo chip for exactly this
  // — "remove my only reference sheet" IS "close this split," not a dead end.
  const removeRefTab = (key) => setSplitView((s) => {
    if (!s) return s;
    const set = s.refSet?.length ? s.refSet : [s.refKey];
    const i = set.indexOf(key);
    const next = set.filter((k) => k !== key);
    if (!next.length) return null;
    const refKey = s.refKey === key ? next[Math.min(Math.max(i, 0), next.length - 1)] : s.refKey;
    return { ...s, refSet: next, refKey };
  });
  // Drop a sheet tab onto the reference pane's own surface (Task 7): joins
  // the reference set (if not already a member) and frames it — the
  // reference-pane analog of the primary pane's edge-drop-to-split gesture,
  // except every drop here is a "center" drop (see ReferencePane.jsx's
  // comment on why it skips dropZoneAt's edge/center hit-test entirely).
  // Task 8: refuses (toast, no state change) rather than silently dropping
  // the sheet when adding a NEW member would push the total over
  // SPLIT_MAX_TOTAL_SHEETS — checked here, outside the updater, because the
  // refusal has a side effect (the toast) and a setState updater can run
  // more than once (StrictMode, batched retries). refuseIfOverCap/
  // primaryCount are declared below (near groupKeys/stitchById, which the
  // count needs); referencing them here is safe — this closure only runs
  // later, as a drop handler, well after that declaration has executed.
  const dropOntoReference = (droppedKey) => {
    if (!splitView) return;
    if (!refSet.includes(droppedKey) && refuseIfOverCap(refSet.length + 1)) return;
    setSplitView((s) => {
      if (!s) return s;
      const set = s.refSet?.length ? s.refSet : [s.refKey];
      const next = set.includes(droppedKey) ? set : [...set, droppedKey];
      return { ...s, refSet: next, refKey: droppedKey };
    });
  };

  const [scales, setScales] = useState({});
  const [scaleSources, setScaleSources] = useState({}); // scale provenance for the report — typically "calibrated" | "standard" | "detected", but any string a newer build wrote is kept verbatim; sheets that predate the flag export "unknown"
  // Scale gate — agent proposes, human confirms. A key mapped to false means an
  // AGENT set this sheet's scale (MCP set_scale, arriving by import) and no
  // human has confirmed it; absent = confirmed. Any human scale act
  // (rescaleSheet) clears the flag — the act is the confirmation.
  const [scaleUnconfirmed, setScaleUnconfirmed] = useState({});
  const confirmScale = (key) => setScaleUnconfirmed((m) => { if (!(key in m)) return m; const n = { ...m }; delete n[key]; return n; });
  const [detectedScales, setDetectedScales] = useState({}); // { sheetKey: {upp,label,multi} } read off the plan text
  const isNarrow = useIsNarrow();
  // Task 8: viewport/memory disable. `deviceCanSplit` gates split CREATION
  // (the drag-to-split gesture and the "Reference ▸ Split…" menu items) —
  // unconditionally, no override. `splitMounted` additionally gates whether
  // an ALREADY-open splitView actually mounts its ReferencePane: it honors
  // `splitOverride` (the "Restore split" menu item) so a user who explicitly
  // asks for the pane anyway isn't second-guessed, while the persisted
  // splitView itself is never discarded either way (see the SplitLayout
  // render site below — `reference` goes null, `splitView` state does not).
  const deviceCanSplit = canSplit({ narrow: isNarrow, lowMemory: LOW_MEMORY_DEVICE });
  const splitMounted = deviceCanSplit || splitOverride;
  const [darkMode, setDarkMode] = useState(() => { try { return localStorage.getItem("opentakeoff_dark") === "1"; } catch { return false; } });
  useEffect(() => { try { localStorage.setItem("opentakeoff_dark", darkMode ? "1" : "0"); } catch { /* private mode */ } }, [darkMode]);
  // App chrome theme (light/dark tokens) — independent of the canvas ☾ invert
  // above. lib/theme.js owns the DOM; this state just keeps the glyph current.
  const [theme, setTheme] = useState(getTheme);
  useEffect(() => onThemeChange(setTheme), []);
  // Drawing style (draft chrome look) — same 3-line subscription pattern as the
  // app theme above (picker / other tabs round-trip through the module event).
  // resolveDrawStyle is memoized: the component re-renders ~11 Hz during
  // gestures via the tf mirror, so no fresh deep-merge per render. dsRef is the
  // imperative movers' handle, assigned in the RENDER BODY (never an effect — a
  // pointermove can arrive before effects flush). Canvas ☾ (darkMode) picks the
  // theme's dark deltas, mirroring the invert everything else on the sheet honors.
  const [drawStyleId, setDrawStyleId] = useState(getDrawStyle);
  useEffect(() => onDrawStyleChange(setDrawStyleId), []);
  const [draftOutline, setDraftOutlineState] = useState(getDraftOutline);
  useEffect(() => onDraftOutlineChange(setDraftOutlineState), []);
  const DS = useMemo(() => resolveDrawStyle(drawStyleId, darkMode), [drawStyleId, darkMode]);
  const dsRef = useRef(DS);
  dsRef.current = DS;
  // diff-only prefs (cf. reportColumns): only keys that differ from the
  // defaults persist, so a future default change reaches existing users
  useEffect(() => {
    try {
      const diff = {};
      for (const k of Object.keys(PANEL_DEFAULTS)) if (panelPrefs[k] !== PANEL_DEFAULTS[k]) diff[k] = panelPrefs[k];
      localStorage.setItem(PANEL_PREFS_KEY, JSON.stringify(diff));
    } catch { /* private mode */ }
  }, [panelPrefs]);
  const panelW = clampPanelW(Number(panelPrefs.w) || PANEL_DEFAULTS.w);
  const takeoffsOpen = !panelPrefs.collapsed;
  // Premium layout: the Conditions dock on the right (list + settings card). Open
  // by default, remembered in this browser; the classic table stays one ⋯ away.
  const [condDockOpen, setCondDockOpenRaw] = useState(() => { try { return localStorage.getItem("opentakeoff_conditions_dock") !== "0"; } catch { return true; } });
  const setCondDockOpen = useCallback((v) => setCondDockOpenRaw((cur) => {
    const next = typeof v === "function" ? v(cur) : v;
    try { localStorage.setItem("opentakeoff_conditions_dock", next ? "1" : "0"); } catch { /* session only */ }
    return next;
  }), []);
  // the classic Takeoffs table (library, materials, columns) in the Premium layout:
  // session-only, so a table left open in the classic layout never covers the dock
  const [fullTableOpen, setFullTableOpen] = useState(false);
  const toggleTakeoffs = () => setPanelPrefs((p) => ({ ...p, collapsed: !p.collapsed }));
  // Panel resize lives INSIDE TakeoffsPanel (mid-drag width goes straight to
  // its DOM node; the pref commits ONCE on release via setPanelPrefs). Each
  // committed width change reflows the canvas container — coordinate math is
  // safe (pointer→image reads the rect at event time; the stage transform is
  // anchored top-left, so content stays put and we deliberately do NOT
  // re-fit) — but the hi-res detail crop only re-renders on transform change,
  // so the detail effect also keys on panelW/takeoffsOpen below, and mid-drag
  // the panel holds the gesture window open through this callback (like wheel
  // zoom) so the crop re-renders once per drag, on settle.
  const holdPanelGesture = useCallback(() => { gestureUntilRef.current = performance.now() + GESTURE_MS; }, []);
  // negative view is baked into the canvas PIXELS (invertCanvasPixels), never a
  // CSS filter — track which canvases currently hold inverted pixels (only
  // canvases that finished a render get an entry), + darkMode readable from
  // async render chains
  const canvasInvertedRef = useRef(new Map());
  const darkModeRef = useRef(darkMode);
  const [calib, setCalib] = useState([]);
  const [pendingLen, setPendingLen] = useState("");
  // Display unit system (ft/m toggle beside the scale picker) — DISPLAY LAYER
  // ONLY: all stored takeoff math stays feet (lib/units contract), so toggling
  // never rewrites a shape, a scale, or a coverage rate. Browser default via
  // localStorage; a project that saved a units field overrides on hydrate.
  const [units, setUnits] = useState(() => { return language === "ru" ? "metric" : "imperial"; });
  const [showImperialScales, setShowImperialScales] = useState(false);
  const unitsLanguageRef = useRef(language);
  useEffect(() => { if (unitsLanguageRef.current !== language) { setUnits(language === "ru" ? "metric" : "imperial"); unitsLanguageRef.current = language; } }, [language]);
  useEffect(() => { try { localStorage.setItem("opentakeoff_units", units); } catch { /* private mode */ } }, [units]);
  const [check, setCheck] = useState([]);             // Check tool: 0–2 stage-px points along a printed dimension
  const [checkStated, setCheckStated] = useState(""); // what the drawing says that dimension is
  const [scaleGuide, setScaleGuide] = useState(null); // ephemeral calibrated ruler {key, feet, px, label, at:[x,y]} — never persisted (buildPayload doesn't read it)
  const scaleGuideTimerRef = useRef(0);
  const scaleGuidePreviewRef = useRef(false); // true while the visible guide is a hover PREVIEW of an unaccepted scale — the preview must die with the hover/menu; an accepted bar stays
  // One-slot revert stash: the scale a quantity-changing rescale replaced
  // ({key, upp, source}). An oops-hatch, not an undo history — ephemeral by
  // design (never persisted): a mistyped recalibrate is caught within a menu
  // click, not archaeologically.
  const [prevScale, setPrevScale] = useState(null);

  const [conditions, setConditions] = useState([]);
  const [conditionColumns, setConditionColumns] = useState([]);  // project-level custom-column vocabulary [{ id, name, values }] — assignments live on c.attrs
  const [shapeLabels, setShapeLabels] = useState([]);  // project-level flat vocabulary of phase/area labels (#110) — assignment lives on shape.label
  const [activeCond, setActiveCond] = useState("");
  const [activeLabel, setActiveLabel] = useState(null);   // session-only active phase/area label (#111) — new traces get it; NOT persisted (absent from buildPayload, reset on hydrate)
  const [palette, setPalette] = useState([]);   // ordered condition ids pinned to the top-bar quick-access palette (≤ PALETTE_MAX)
  const [shapes, setShapes] = useState([]);
  const [poly, setPoly] = useState([]);
  // #284 — which of the in-progress trace's points are arc BOW points. Parallel
  // to poly and written ONLY through the three helpers below, so it can never
  // drift out of step with the points it describes.
  const [polyCurve, setPolyCurve] = useState([]);
  // Sticky curve mode — the STACK-style straight/curve switch you flip mid
  // measurement rather than a modifier you hold. In Curve the clicks ALTERNATE:
  // one lands on the bow, the next on the far end, and the circular arc through
  // the vertex you were already on, the bow and the end is unique — so it sits
  // ON a radius wall instead of near it. ⌥ still works, and it INVERTS whatever
  // the mode is. The mode is trace-local; it clears with the trace.
  const [curveMode, setCurveMode] = useState(false);
  const clearPoly = () => { setPoly([]); setPolyCurve([]); setCurveMode(false); };
  const dropLastPoint = () => { setPoly((q) => q.slice(0, -1)); setPolyCurve((q) => q.slice(0, -1)); };
  const addPoint = (pt, curved) => { setPoly((q) => [...q, pt]); setPolyCurve((q) => [...q, !!curved]); };
  // the drawn boundary of the in-progress trace: straight where it was clicked
  // straight, splined through every run of curve points
  const curveIdx = useMemo(() => polyCurve.reduce((a, c, i) => (c ? (a.push(i), a) : a), []), [polyCurve]);
  // Mid-gesture: the last click was a bow point, so the NEXT click closes that
  // arc rather than opening another. The live preview reads the same flag.
  const bowOpen = polyCurve.length > 0 && polyCurve[polyCurve.length - 1] && poly.length >= 2;
  // Ring-tool draft invalidity (drawing styles): a self-crossing area/deduct/
  // zone draft recolors on a theme that sets invalidColor. `!!DS.invalidColor`
  // is the FIRST guard, so drafting (invalidColor null) short-circuits before
  // any geometry runs — parity is structural, not incidental. Computed on
  // PLACED vertices only (per-point via the memo, never per mousemove); ring
  // tools only — an open polyline has no closing edge and must never flip.
  const isRingTool = tool === "area" || tool === "deduct" || tool === "zone";
  const draftInvalid = useMemo(
    () => !!DS.invalidColor && isRingTool && poly.length >= 4 && ringSelfIntersects(poly),
    [DS.invalidColor, isRingTool, poly]
  );
  // ONE restore expression for the draft/rubber/trace stroke, shared by the JSX
  // and the movers so React and imperative writes can never disagree: deduct
  // red (a safety signal in every theme) → invalid flip → theme accent.
  const draftStroke = (t, invalid, ds) => (t === "deduct" ? "#b03a26" : invalid && ds.invalidColor ? ds.invalidColor : ds.accent);
  // Draft totals for the panel chip chromes (Contemporary panelDark / Precision
  // panelCream): placed-edge length sum + partial shoelace cross-sum, assigned
  // IN THE RENDER BODY (the dsRef pattern — a useEffect([poly]) recompute has a
  // stale window: React does not guarantee passive-effect flush before
  // continuous pointer events, so a pointermove could read old sums against a
  // new poly). moveCrosshair adds only the cursor terms — O(1) per move. Gated
  // on the panel chromes so Drafting Table (paper) does literally zero extra work.
  const draftStatsRef = useRef({ len: 0, cross: 0 });
  if (DS.chip.chrome === "panelDark" || DS.chip.chrome === "panelCream") {
    let dLen = 0, dCross = 0;
    for (let i = 1; i < poly.length; i++) {
      const a = poly[i - 1], b = poly[i];
      dLen += Math.hypot(b[0] - a[0], b[1] - a[1]);
      dCross += a[0] * b[1] - b[0] * a[1];
    }
    draftStatsRef.current.len = dLen;
    draftStatsRef.current.cross = dCross;
  }
  const [guideOpen, setGuideOpen] = useState(false);   // the in-app manual overlay (? / the toolbar button)
  // Guided first takeoff (components/FirstTakeoffTour.jsx): null when off, else
  // { done: step ids, baseline: floor shapes that existed before it started }.
  // Session-only on purpose — a reload ends the tour rather than resuming a
  // half-remembered one over a different plan.
  const [tour, setTour] = useState(null);
  const [tourSampleBusy, setTourSampleBusy] = useState(false);
  const [connectOpen, setConnectOpen] = useState(false);   // Connect your AI (components/ConnectAI.jsx)
  // the Assistant window (components/AssistantWindow.jsx): the person's own AI app, talking here
  const [assistantOpen, setAssistantOpen] = useState(false);
  const openAssistant = useCallback(() => setAssistantOpen(true), []);
  const [companySetupOpen, setCompanySetupOpen] = useState(false);   // Company setup (components/CompanySetup.jsx)
  const [companyRev, setCompanyRev] = useState(0);   // bumped on every Company setup save so an open report's masthead re-reads
  const [proposal, setProposal] = useState(null);  // One-Click selection under review: { key, regions: [{kind:'pos'|'neg', seed, poly, area_sf, perim_lf}] } — panel-LOCAL px
  // ── in-canvas takeoff agent state ──────────────────────────────────────────
  // agentProposals are NOT shapes: committed truth stays committed. Each entry
  // {id, sheet_id, condition_id, measure_role, verts_norm, evidence, seed_norm?,
  //  proposed_ts, area_sf, perim_lf} renders as a DASHED pencil outline until
  // the human accepts (→ dispatchShape add with agent_v1 origin) or rejects
  // (→ dropped LOCALLY — dismissed geometry never rides the contribution wire).
  // Ephemeral by design: never persisted (buildPayload doesn't read them).
  const [agentProposals, setAgentProposals] = useState([]);
  // ── correction rules (#88) — one correction, fifty rooms ────────────────────
  // rules PERSIST (project file, buildPayload/hydrate) — they're the captured
  // corrections. ruleOffer/ruleStage are ephemeral review state like
  // agentProposals: the offer banner after a qualifying Cut Out, and the staged
  // batch awaiting the explicit Apply. Staged candidates are NOT shapes —
  // nothing commits until Apply dispatches ONE `ruleApply` command.
  const [rules, setRules] = useState([]);
  const [ruleOffer, setRuleOffer] = useState(null);   // { deduct, seed, tag }
  const [ruleStage, setRuleStage] = useState(null);   // { rule, candidates, proposed_ts }
  // the rule banner's measured height while it shows: the Read page text
  // control (#471) stacks above it instead of under it
  const ruleBannerRef = useRef(null);
  const [ruleBannerH, setRuleBannerH] = useState(0);
  const ruleBannerUp = !!(ruleOffer || ruleStage);
  useLayoutEffect(() => {
    const el = ruleBannerUp ? ruleBannerRef.current : null;
    if (!el) { setRuleBannerH(0); return; }
    const measure = () => setRuleBannerH(el.offsetHeight);
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ruleBannerUp]);
  const [agentOpen, setAgentOpen] = useState(false);      // docked right-rail Agent panel
  const [conditionDetails, setConditionDetails] = useState(true);
  const workspacePrefs = useWorkspaceLayout();
  const workspaceLayout = workspacePrefs.enabled;
  const workspaceArrangement = workspacePrefs.layout;
  // the tool dock floating at the canvas foot (Premium's position; default since 2026-11)
  const dockBottom = workspaceLayout && workspaceArrangement.tools === "bottom";
  // the dock's ⋯ tray — every tool that isn't on the dock itself, laid out at once (Premium's layout)
  const [trayOpen, setTrayOpen] = useState(false);
  const dockWrapRef = useRef(null);
  useEffect(() => {
    if (!trayOpen) return undefined;
    const onDown = (e) => { if (dockWrapRef.current && !dockWrapRef.current.contains(e.target)) setTrayOpen(false); };
    const onKey = (e) => { if (e.key === "Escape") setTrayOpen(false); };
    document.addEventListener("pointerdown", onDown, true);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("pointerdown", onDown, true); document.removeEventListener("keydown", onKey); };
  }, [trayOpen]);
  const [workspaceNavigationOpen, setWorkspaceNavigationOpen] = useState(false);

  const [workspaceControlsOpen, setWorkspaceControlsOpen] = useState(false);
  const [workspaceDetailsOpen, setWorkspaceDetailsOpen] = useState(false);
  const [workspaceSearchOpen, setWorkspaceSearchOpen] = useState(false);
  const [workspaceLayoutOpen, setWorkspaceLayoutOpen] = useState(false);
  const [workspaceDragging, setWorkspaceDragging] = useState(null);

  const [workLocateId, setWorkLocateId] = useState(null);
  const workButtonRef = useRef(null);
  // ── roll goods (#136) — view state; the figured layouts are a memo below ──
  const [rollShow, setRollShow] = useState(true);         // draw the figured cuts over the plan (on: opting a condition in shows its cuts immediately)
  const [rollEdit, setRollEdit] = useState(false);        // cut-edit mode — cuts take pointer events (slide / resize / double-click reset)
  const [rollPanelOpen, setRollPanelOpen] = useState(false); // docked Roll panel (diagram + reorder)
  const rollDragRef = useRef(null);                       // live cut-drag gesture; commit is ONE rollcut command on release
  const agentChat = useAgentChat(projectIdFromUrl());    // the Agent tab's conversation, persisted per project (lib/useAgentChat)
  const [agentRunning, setAgentRunning] = useState(false);
  const [showAiSettings, setShowAiSettings] = useState(false); // BYO-key config modal (ai.js seam)
  const agentAbortRef = useRef(null);                     // live AbortController while a run is in flight
  // Live mirror of the render-scope state the agent's capability closures read:
  // the loop runs across many awaits, so closures must read CURRENT state, not
  // the run-click render's. Updated every render (cheap object build).
  const agentStateRef = useRef({ panels: [], scales: {}, scaleSources: {}, detectedScales: {}, conditions: [], status: "loading" });
  useEffect(() => () => agentAbortRef.current?.abort(), []);   // leaving the canvas stops a live agent run
  const [ocSel, setOcSel] = useState(null);        // selected proposal vertex {ri, vi} — Delete removes just that point
  const [ocHover, setOcHover] = useState(-1);      // proposal region under the cursor — handles reveal on hover
  const [selectedId, setSelectedId] = useState(null);   // selected shape (Select tool)
  // raw text of the per-wall height field while it is being edited; null =
  // mirror the stored value. Same reason as DimParamInput's draft: the field
  // round-trips through a rounded unit conversion, so without this a metric
  // typist watching "2.4" become "2.438" mid-word cannot finish the number.
  const [shapeHDraft, setShapeHDraft] = useState(null);
  // #441 — the selected run's rise/drop inputs mid-edit (raw text, display units)
  const [shapeVertDraft, setShapeVertDraft] = useState({ rise_ft: null, drop_ft: null });
  useEffect(() => { setShapeHDraft(null); }, [selectedId]);   // a draft belongs to ONE wall
  const [selVert, setSelVert] = useState(null);         // selected vertex index of the selected shape — Delete removes just that point
  const [selectedMarkupId, setSelectedMarkupId] = useState(null); // selected markup — mutually exclusive with selectedId
  const [rfis, setRfis] = useState([]);                 // RFI register (Request For Information); linked to markups via markup.rfi_id === rfi.id
  // proposals (#365): the agent's batches (shapes reference them by
  // origin.proposal_id → one Accept pill per batch) and the condition-edit
  // diffs held pending until accepted from the Takeoffs panel. Transport from
  // the MCP export / the app's own save; this canvas only reads and applies.
  const [proposals, setProposals] = useState([]);
  const [conditionEditProposals, setConditionEditProposals] = useState([]);
  // Deletion provenance: shapes leave no record once filtered out of `shapes`,
  // so every delete COMMAND yields a per-origin-method tally (`counted`, keyed
  // by origin.method, "manual" when absent) that dispatchShape merges here.
  // Serialized as provenance_counters — omit-when-empty — so the corpus can
  // see how much machine output was thrown away, not only what survived.
  const [provCounters, setProvCounters] = useState({ shapes_deleted: {} });
  const countDeleted = (tally) => {
    const keys = Object.keys(tally);
    if (!keys.length) return;
    setProvCounters((pc) => {
      const sd = { ...pc.shapes_deleted };
      for (const k of keys) sd[k] = (sd[k] || 0) + tally[k];
      return { ...pc, shapes_deleted: sd };
    });
  };
  // ── the shape-command chokepoint ──────────────────────────────────────────
  // EVERY meaningful `shapes` mutation dispatches a command; the pure apply
  // (lib/shapeCommands.js) owns the provenance policy, this wrapper owns the
  // React side: setShapes the result, merge the deletion tally, and keep the
  // undo/redo stacks. Stacks live in refs (no render on push); applied against
  // the render's `shapes`, which a discrete event always sees current (the
  // undoLast precedent) — NEVER inside a setShapes updater (updaters can
  // double-run; counting/recording there would double-tally).
  //   record: false — apply + count but keep it off the undo stack (the
  //     condition-cascade deletes: their confirm says "can't be undone", and
  //     undoing the shapes without the condition would resurrect orphans);
  //   reset: true — clear BOTH stacks (hydrate / revision restore / rescale:
  //     a restored timeline starts fresh, and a rescale invalidates every
  //     `computed` the recorded commands froze).
  const undoStackRef = useRef([]);   // [{ cmd, inverse }]
  const redoStackRef = useRef([]);
  function dispatchShape(cmd, { record = true, reset = false } = {}) {
    const res = applyShapeCommand(shapes, cmd);
    setShapes(res.shapes);
    if (res.counted) countDeleted(res.counted);
    if (reset) { undoStackRef.current = []; redoStackRef.current = []; }
    else if (record && res.inverse) {
      const st = recordCommand(undoStackRef.current, { cmd, inverse: res.inverse });
      undoStackRef.current = st.undo;
      redoStackRef.current = st.redo;   // a new command discards the redone future
    }
    return res;
  }
  // ⌘Z / ⇧⌘Z — apply the recorded inverse (undo) or the exact-restore command
  // (redo). Undoing swaps the entry's cmd for the inverse-of-the-undo before
  // it lands on the redo stack: that command restores the undone state
  // VERBATIM (same ids, same created_at, same stamped updated_at, same array
  // indices) — replaying the ORIGINAL command would re-mint/re-stamp. Neither
  // direction feeds the deletion counters: undo's inverses are structurally
  // count-free (an add's inverse delete rides noCount, a delete's inverse is
  // a restore-add), so a delete is tallied exactly once, at first dispatch —
  // undo never decrements, redo never re-counts.
  function undoShapeCommand() {
    const entry = undoStackRef.current[undoStackRef.current.length - 1];
    if (!entry) return;
    undoStackRef.current = undoStackRef.current.slice(0, -1);
    // approval entries share the ONE gesture history (family tag, recorded by
    // dispatchApproval below) — same stacks, different pure apply + array.
    if (entry.family === "markup") {
      setMarkups(ms => applyMarkupPatch(ms, entry.patch, "before"));
      redoStackRef.current = [...redoStackRef.current, entry];
      setSelectedMarkupId(null); return;
    }
    if (entry.family === "approval") {
      const res = applyApprovalCommand(approvals, entry.inverse);
      setApprovals(res.approvals);
      redoStackRef.current = [...redoStackRef.current, { family: "approval", cmd: res.inverse, inverse: entry.inverse }];
      return;
    }
    if (entry.family === "page_tool" || typeof entry.undo === "function") {
      entry.undo?.();
      redoStackRef.current = [...redoStackRef.current, entry];
      return;
    }
    const res = applyShapeCommand(shapes, entry.inverse);
    setShapes(res.shapes);
    redoStackRef.current = [...redoStackRef.current, { cmd: res.inverse, inverse: entry.inverse }];
    setSelVert(null);   // vertex counts may have changed — a stale index must not aim the next ⌫
  }
  function redoShapeCommand() {
    const entry = redoStackRef.current[redoStackRef.current.length - 1];
    if (!entry) return;
    redoStackRef.current = redoStackRef.current.slice(0, -1);
    if (entry.family === "markup") {
      setMarkups(ms => applyMarkupPatch(ms, entry.patch, "after"));
      undoStackRef.current = [...undoStackRef.current, entry];
      setSelectedMarkupId(null); return;
    }
    if (entry.family === "approval") {
      const res = applyApprovalCommand(approvals, entry.cmd);
      setApprovals(res.approvals);
      undoStackRef.current = [...undoStackRef.current, { family: "approval", cmd: entry.cmd, inverse: res.inverse }];
      return;
    }
    if (entry.family === "page_tool" || typeof entry.redo === "function") {
      entry.redo?.();
      undoStackRef.current = [...undoStackRef.current, entry];
      // Do not duplicate push: entry.redo() already pushes its own undo entry
      return;
    }
    const res = applyShapeCommand(shapes, entry.cmd);
    setShapes(res.shapes);
    undoStackRef.current = [...undoStackRef.current, { cmd: entry.cmd, inverse: res.inverse }];
    setSelVert(null);   // same stale-index guard as undo
  }
  // ── the approval-command wrapper ──────────────────────────────────────────
  // dispatchShape one size smaller: pure apply (lib/approvals.js) +
  // setApprovals + the SHARED undo/redo stacks, entries tagged family:
  // "approval" so ⌘Z pops seals and shapes in one gesture history. No
  // counters and no reset path — hydrate sets the array directly, and the
  // shape replace-reset clears the shared stacks (approval entries included).
  function dispatchApproval(cmd, { record = true } = {}) {
    const res = applyApprovalCommand(approvals, cmd);
    setApprovals(res.approvals);
    if (record && res.inverse) {
      const st = recordCommand(undoStackRef.current, { family: "approval", cmd, inverse: res.inverse });
      undoStackRef.current = st.undo;
      redoStackRef.current = st.redo;   // a new command discards the redone future
    }
    return res;
  }
  // selecting a shape clears any markup selection and vice-versa — one live
  // selection at a time (bidirectional mutual exclusivity). Passing null clears both.
  const selectShape = (id) => { setSelectedId(id); setSelectedMarkupId(null); };
  const selectMarkup = (id) => { setSelectedMarkupId(id); setSelectedId(null); };
  const pendingFlyRef = useRef(null);   // fly-to target whose sheet is opening this tick (two-phase center once its bitmap loads)
  // Source-trace (◎) equivalent of pendingFlyRef: { sheet_id, rect, token, attempts }
  // for a trace whose SOURCE sheet is opening this tick. Unlike pendingFlyRef it
  // carries no markup id to re-validate against — there's no markup on the source
  // sheet, only a synthetic rect — so it is self-limiting via `attempts` (see the
  // phase-2 effect below and lib/sourceTrace's pendingSourceOutcome, the "never
  // leave a stale trace armed" guard the plan calls the riskiest part of this slice).
  const pendingSourceRef = useRef(null);
  const sourceTraceSeqRef = useRef(0);  // monotonic token minter for sourceFlash — see traceSource

  const [snapOn, setSnapOn] = useState(false);   // snap-to-vector (beta) — off until calibrated on real plans
  const [angleOn, setAngleOn] = useState(true);  // 45°/90° angle guides (polar tracking) — on by default; ⇧ = hard lock
  // One-Click fill sensitivity (0..1) — how eagerly a fill crosses a room's hatch;
  // per-user pref, defaults to the calibrated Balanced preset.
  // scan-path flood sensitivity — fixed; the knob is gone with the fill UI
  const fillSens = SENS_BALANCED;
  // NET ENGINE (test drive, 2026-08-24): route One-Click through the wall-
  // network room detector (lib/netroom) instead of the raster flood. Off by
  // default; persisted so a test session survives a reload. The net for a
  // sheet is built once per (sheet, scale) and cached — seconds on a dense
  // sheet, instant after.
  // The net engine IS One-Click on vector sheets (owner's call, 2026-08-25:
  // the flood has no purpose there). The flood survives only as the SCAN
  // path — a scan has no linework to network — and is never user-visible on
  // a vector sheet.
  const netEngine = true;
  const netCacheRef = useRef(new Map());   // `${sheetKey}:${upp}` → built net
  const netTickRef = useRef(null);          // ticking "reading the walls… N s" timer
  // No mode dial (his call, 2026-08-24: "too technical for users"). A click
  // is a room (walls + doors + drawn finish transitions); ⇧-click is the
  // finish FIELD — grow across the same tile/plank pattern, stop where it
  // stops (teller lines, lobbies, open plans). Same gesture STACK uses.
  const [saveState, setSaveState] = useState("idle");
  const [focusMode, setFocusModeState] = useState(getFocusMode);   // chrome-collapse (F) — lib/focusMode.js is the store+broadcast
  useEffect(() => onFocusModeChange(setFocusModeState), []);
  const [loadError, setLoadError] = useState("");   // annotations load failed — autosave stays disarmed
  // internal state is { text }, minted FRESH on every setCommitMsg call — a
  // byte-identical message (e.g. two "Couldn't open X" in a row) still gets a
  // new object identity, so the effect below (keyed on this object) restarts
  // its clock instead of no-op'ing on an unchanged dep. setCommitMsg(text) is
  // a thin, stable-shaped wrapper so the ~48 call sites below stay untouched.
  const [commitMsgState, setCommitMsgState] = useState({ text: "" });
  const commitMsg = commitMsgState.text;   // misnamed for history; just the message bar
  const setCommitMsg = (text) => setCommitMsgState({ text });
  // transient means transient: every message dismisses itself after ~6s (a
  // repeat message restarts the clock — see above). Three things don't age
  // out on a timer: the stale-tab lockout (STALE_TAB_MESSAGE — sticky until
  // the user reloads; it's the only story this tab has left to tell), any
  // other failure message (isDangerMsg — "Couldn't…"/"Commit failed…" — stays
  // until the NEXT message replaces it, not a clock), and in-progress messages
  // (the file's own "…" convention — "Reading files…", "Building the marked
  // set…", ingestFiles' onProgress strings — which must not vanish mid-op;
  // grep setCommitMsg to see every message and confirm the convention holds).
  useEffect(() => {
    const text = commitMsgState.text;
    if (!text || isDangerMsg(text) || text.endsWith("…")) return;
    const t = setTimeout(() => setCommitMsg(uiText("")), 6000);
    return () => clearTimeout(t);
  }, [commitMsgState]);
  const [showReport, setShowReport] = useState(false);  // Reports overlay (STACK-style breakdown + export)
  const [showRevisions, setShowRevisions] = useState(false); // Revisions overlay (save / compare any two, buy-list deltas, CSV, auto-banked restore)
  const [importRead, setImportRead] = useState(null);        // Import-from-schedule approval read: { rows, skipped, sourceKey, boxTerms? } (null = dialog closed)
  const [scheduleAnchor, setScheduleAnchor] = useState(null); // first marquee corner for the "schedule" tool — ISOLATED from poly so it can never leak into a measure shape
  // The box being read: one at a time. importScheduleFromRect takes the lock
  // for every box (a vector box only for its own short read) as `mine` =
  // { ctl, ocr }; `ocr` is set once the box goes to the on-device reader,
  // and while it is the canvas's window shortcuts are held (Esc cancels the
  // read instead), so keys on the body behind a coming notice, or under the
  // status line, act on nothing. Only the holder writes a result.
  const ocrReadRef = useRef(null);
  // The footer's status line: null | "starting" | "waiting" (another on-device
  // read goes first) | "reading". Never commitMsg. ocrReadProgress: the
  // read's last SeamProgress, for the reading line's raster count.
  const [ocrRead, setOcrRead] = useState(null);
  const [ocrReadProgress, setOcrReadProgress] = useState(null);
  /** End `m`'s hold on the read, if it still has it: the lock and the line go. */
  function releaseImportRead(m) {
    if (ocrReadRef.current !== m) return;
    ocrReadRef.current = null;
    setOcrRead(null);
    setOcrReadProgress(null);
  }
  /** Cancel, Esc, a sheet switch, the gallery, guide, report or revisions,
   *  unmount: stop the read and let go at once, so nothing that can't be
   *  stopped keeps the lock or the line. The render takes the read's signal,
   *  so a render under way is cancelled and its canvas freed
   *  (boxReadWords → rasterizeRegion). Recognitions never overlap: the client keeps an aborted one running until the worker
   *  replies, and a read started right after queues behind it. Aborted while
   *  the notice waits, the session answers this read and closes the notice;
   *  during the download it stops the download, and the next box asks again. */
  function cancelImportRead() {
    const m = ocrReadRef.current;
    if (!m) return;
    m.ctl.abort();
    releaseImportRead(m);
  }
  useEffect(() => { if (view !== "canvas" || guideOpen || showReport || showRevisions) cancelImportRead(); }, [view, guideOpen, showReport, showRevisions]); // eslint-disable-line react-hooks/exhaustive-deps
  // ── the Symbol tool (#264) — same two-click marquee idiom as schedule ─────
  const [symbolAnchor, setSymbolAnchor] = useState(null);     // first marquee corner, isolated like scheduleAnchor
  const [imageAnchor, setImageAnchor] = useState(null);       // first marquee corner for the "image" screenshot tool, isolated like scheduleAnchor/symbolAnchor
  // ── Copy text (#471) — the same two-click marquee idiom ──────────────────
  const [textAnchor, setTextAnchor] = useState(null);         // first marquee corner for the "textcopy" tool, isolated like scheduleAnchor/symbolAnchor
  const [copyReceipt, setCopyReceipt] = useState(null);       // lib/copyText CopyReceipt: what went on the clipboard (null = no receipt)
  // a written copy's receipt lives RECEIPT_MS; a refused one stays (its textarea is the only copy left)
  useEffect(() => {
    if (!copyReceipt || !receiptExpires(copyReceipt)) return;
    const t = setTimeout(() => setCopyReceipt(null), RECEIPT_MS);
    return () => clearTimeout(t);
  }, [copyReceipt]);
  // pdf.js page → { tc, p }: each page's text content, read once and kept, so a
  // box (or Copy page text) on a page already read copies synchronously —
  // inside the click's transient activation (see copyTextFrom)
  const textContentsRef = useRef(new WeakMap());
  const copyGateRef = useRef(null);   // lib/copyText createReadGate: a new copy read aborts the one in flight
  if (!copyGateRef.current) copyGateRef.current = createReadGate();
  const [placingImageId, setPlacingImageId] = useState(null); // an image markup being (re)placed: it follows the cursor until the next click drops it (re-enterable from the panel, not just at capture)
  const placeGrabRef = useRef(null);                          // {key, dx, dy}: cursor→image-centre offset captured on the pointer's FIRST canvas contact during a place, so the image is grabbed where it sits (no teleport) and moves relative after
  // Cross-sheet place flag: holds the markup id when beginPlace (below) armed
  // placement for an image whose CURRENT sheet ISN'T the one now open. Carries
  // that decision to onPointerMove's first-contact grab (~3686), which runs
  // frames later — by then `sheet_id` may already have been rewritten to the
  // panel it first touched, so re-reading it there is unreliable. Keyed on the
  // markup id (not a bare boolean) so a second Place on a DIFFERENT markup can't
  // inherit a stale flag. Cleared everywhere placeGrabRef is cleared.
  const placeCrossSheetRef = useRef(null);
  const [imgThumbs, setImgThumbs] = useState({});             // markupId → tiny JPEG dataURL for the panel row — memory-only, built once per image, NEVER persisted (a 40px <img> of a full 1600px src would decode the whole bitmap and eat the byte budget)
  const thumbBuildingRef = useRef(new Set());                 // ids with a thumb build in flight (dedupe the async decode)
  const [sweep, setSweep] = useState(null);                   // the live review: matches / questions / seed, one sheet, dies on commit or discard
  const sweepRef = useRef(null);
  useEffect(() => { sweepRef.current = sweep; }, [sweep]);
  const [projectName, setProjectName] = useState("");   // optional label for the report header
  const [clientInfo, setClientInfo] = useState({});      // per-project client/job fields for branded output; additive payload field
  const [estimateSettings, setEstimateSettings] = useState(null);   // the project's markups (lib/estimate.js); null until its estimate first opens, then copied from Company setup
  const [bidProposal, setBidProposal] = useState(null);   // the project's proposal text/layout (lib/bidProposal.js); null until its proposal first opens
  const [showEstimate, setShowEstimate] = useState(false);
  const fileInputRef = useRef(null);                    // hidden <input type=file> for "Open PDF"
  const importInputRef = useRef(null);                  // hidden <input type=file> for "Import takeoff…" (the agent-JSON handoff)
  const profileInputRef = useRef(null);                 // hidden <input type=file> for "Import profile…" (#299)
  const imageInputRef = useRef(null);                   // hidden <input type=file> for the Markups-dock "Upload image…" button

  // The gesture/pointer viewport div. SplitLayout is ALWAYS mounted at this
  // subtree's slot (see SplitLayout.jsx's header comment), so this node's
  // identity is stable for the component's whole lifetime — no split
  // enter/exit, flip, or ratio drag ever remounts it, and effects that
  // addEventListener() on it once at setup (wheel, below) don't need to
  // re-subscribe on a node-identity change that no longer happens.
  const containerRef = useRef(null);
  const stageRef = useRef(null);
  const panelCanvasRefs = useRef(new Map()); // sheetKey → <canvas> (base layer — small backing store, coarse pyramid placeholder)
  const pageObjsRef = useRef(new Map());     // sheetKey → pdf.js page object (getOperatorList/getTextContent only — painting moved to the tile worker pool)
  const dimTextsRef = useRef(new Map());     // sheetKey → positioned dim-pattern texts (#320) — RENDER_SCALE px, rescaled at buildMask time
  const renderScalesRef = useRef(new Map()); // sheetKey → RENDER_SCALE, always (see factorFor comment above) — kept so the ~20 factorFor/uppFor call sites are untouched
  // Tile-pyramid compositor (#86) — one instance owning the worker pool +
  // tile LRU cache (see lib/tileCompositor.ts). Lazily created on first
  // real use (getCompositor(), mirroring voiceRecognizerClient.ts's "nothing
  // loads until first use" worker pattern), NOT eagerly in a mount effect —
  // an eager create+dispose pair fought React 18 StrictMode's dev-mode
  // double-invoke in a way pure effect-ordering couldn't reliably fix (this
  // component observably mounts more than the textbook once-cleanup-once
  // cycle on first load — confirmed live via instrumented logging). Nulling
  // the ref on dispose (below) is what makes this resilient to ANY number of
  // create/dispose cycles, not just exactly one: the next real use just
  // recreates it.
  const compositorRef = useRef(null);
  const getCompositor = () => (compositorRef.current ??= createTileCompositor());
  const refDimsRef = useRef(null); // { key: refKey, w, h } for the CURRENTLY resolved reference sheet, or null — read by paintReferenceBase
  const detailCanvasRefs = useRef(new Map()); // sheetKey → <canvas> (one detail/viewport layer PER PANEL now, not one shared global — every group-mode panel gets independent sharpness)
  const detailKeysRef = useRef(new Map());    // sheetKey → last requested crop key (per-panel render-key dedup, generalizing the old single detailKeyRef)
  const detailCancelsRef = useRef(new Map()); // sheetKey → disposer for the in-flight paintDetail call
  const renderTasksRef = useRef(new Map());  // sheetKey → pdf.js RenderTask
  // one pdf.js document per file — the canvas render AND the gallery
  // thumbnails share it. Each is its own worker, so only the files the canvas
  // shows (pinsRef, below) stay loaded for good; past docIdleMax idle ones
  // the least recently used go, and anything else using a document leases
  // it meanwhile. A store that hashes on demand (cloud) gets the digest of
  // the bytes it just gave, started before pdf.js can detach them, so it
  // never downloads them again while the document stays; OCR reads pair a
  // page with the hash of the bytes it came from (#471).
  const pinsRef = useRef({ files: new Set(), stitchById: {} });
  const readerRef = useRef(null);
  const [docCache] = useState(() => createDocCache({
    load: pdfSourceOf,
    open: openPdf,
    hashing: (file) => (ocrEnabled() && typeof store.beginPdfHash === "function" ? store.beginPdfHash(file) : null),
    // asked live: a stopped read's page may still be rasterizing
    pinned: () => {
      const { files, stitchById: byId } = pinsRef.current;
      const reading = (readerRef.current?.active() ?? []).map((r) => r.key);
      return [...files, ...pinnedFiles({ keys: reading, stitchById: byId })];
    },
    maxIdle: docIdleMax(LOW_MEMORY_DEVICE),
  }));
  const [sheetSource] = useState(() => createSheetSource({
    cached: docCache.cached,
    open: docCache.open,
    lease: docCache.lease,
    storeHash: (file) => store.pdfHash(file),
    storeKnown: (file) => (typeof store.pdfHashIfKnown === "function" ? store.pdfHashIfKnown(file) : null),
  }));
  const renderSeqRef = useRef(0);            // monotonic token — stale render chains bail out
  const panRef = useRef(null);
  const spaceRef = useRef(false);
  const crossVRef = useRef(null);
  const crossHRef = useRef(null);
  const rubberRef = useRef(null);
  const arcRef = useRef(null);      // live 3-point arc preview (bow placed → cursor); the rubber band becomes its chord
  const rectRef = useRef(null);
  const cloudRef = useRef(null);       // live cloud preview (first corner → cursor)
  const highlightRef = useRef(null);   // live highlight-box preview (first corner → cursor; own translucent fill, NOT rectRef's condition fill)
  const dimRef = useRef(null);         // live dimension-line preview (first end → cursor; own ref — rubberRef belongs to the measure trace)
  const hlRef = useRef(null);          // in-progress highlighter stroke {pts (stage px), key}
  const hlPathRef = useRef(null);      // live highlighter preview path (imperative, WYSIWYG ink)
  const [hlStyle, setHlStyle] = useState(() => {
    try { return { color: HL_INKS[0], size: 14, tip: "chisel", ...JSON.parse(localStorage.getItem("opentakeoff_hl_style") || "{}") }; }
    catch { return { color: HL_INKS[0], size: 14, tip: "chisel" }; }
  });
  useEffect(() => { try { localStorage.setItem("opentakeoff_hl_style", JSON.stringify(hlStyle)); } catch { /* private mode */ } }, [hlStyle]);
  const snapRef = useRef(null);        // current snapped image point (or null)
  const snapGridsRef = useRef(new Map()); // sheetKey → {cell, map} spatial hash of vector endpoints
  const vectorSegsRef = useRef(new Map()); // sheetKey → flat [x1,y1,x2,y2,…] linework segments (One-Click boundary source)
  const segMetaRef = useRef(new Map());    // sheetKey → per-segment meta bytes (hatch classification input)
  // sheetKey → drawn-figure ranges (SubPath[]): the ink-classification input.
  // Single-panel sheets only — a STITCHED composite merges several sheets'
  // segment arrays, and a subpath's meaning is a contiguous range into ONE of
  // them, so a composite simply carries none and classification degrades to
  // exactly today's behaviour (the optional-field contract).
  const subpathsRef = useRef(new Map());
  const textMarksRef = useRef(new Map());  // sheetKey → positioned text (label-box classification)
  const segLumRef = useRef(new Map());     // sheetKey → per-segment stroke luminance (#260) — the Symbol tool's label leader-chase pen separator
  const textSpansRef = useRef(new Map());  // sheetKey → label text spans (built lazily on first sweep)
  const textTfRef = useRef(new Map());     // sheetKey → viewport transform, for positioning text spans in image px
  // PDF layers (#85): the op walk's per-segment OCG attribution + the sheet's
  // classified layer table. Engine reads go through REFS (rolesForSheet runs
  // inside click paths — a just-resolved table must be visible before React
  // commits); sheetLayers STATE mirrors layerInfosRef for the panel render.
  const layerGeoRef = useRef(new Map());   // sheetKey → { layerIds, layerOf }
  const layerInfosRef = useRef(new Map()); // sheetKey → LayerInfo[] ([] = unlayered)
  const layerOverridesRef = useRef({});    // mirror of layerOverrides — see above
  const [sheetLayers, setSheetLayers] = useState({});        // sheetKey → LayerInfo[] (panel view)
  const [layersOpen, setLayersOpen] = useState(false);       // docked Layers panel
  const [layerOverrides, setLayerOverrides] = useState({});  // sheetKey → { ocgId: "include"|"exclude" } — persisted (additive `layer_overrides`)
  const maskCacheRef = useRef(new Map());  // sheetKey → built boundary mask (lazy, dropped on re-render)
  const sheetStatsRef = useRef(new Map()); // sheetKey → {segCount, imageFrac} — raster-fallback trigger signals
  const panelSourceDimsRef = useRef(new Map()); // stitchKey → { memberKey: {w,h} } — member dims resolved by the render effect (#161)
  const rasterMaskCacheRef = useRef(new Map()); // sheetKey → Promise<MaskObj|null> — scan-pixel mask (lazy, shared across clicks)
  const snapMarkRef = useRef(null);    // SVG snap indicator
  const angleRef = useRef(null);       // current angle-locked image point (or null) — the click commits it
  const aimMarkRef = useRef(null);     // four floating liquid-glass pickets thickening the crosshair crossing
  const aimChipRef = useRef(null);     // readout chip by the cursor (locked angle · live segment length)
  const rubberCasingRef = useRef(null); // casing under-stroke twin of the rubber band (mounted only when DS.casing — Site Glass)
  const closeRef = useRef(null);       // ring tools' close-preview ghost edge (mounted only when DS.closePreview — Contemporary)
  const dragRef = useRef(null);        // {kind:'move'|'vertex'|'edge'|'markupMove', shapeId?/markupId?, vIndex?, start:[x,y], orig:verts_norm/markup coords, moved?, prev: grab-time geomSnapshot (shape drags), shape: grab-time shape, lastVerts/lastComputed: latest preview frame — the release commit's geom command payload}
  const ocDragRef = useRef(null);      // One-Click proposal edit drag: {kind:'oc-vertex'|'oc-edge', ri, vi?/i?/j?, oa?, ob?, sx?, sy?} — poly is panel-LOCAL px
  const ocHoverRef = useRef(-1);       // mirror of ocHover (region index under cursor) — compared per-move to avoid stale-closure churn
  const editingRef = useRef(false);    // true while the inline text editor is open — read in moveCrosshair/onPointerDown/wheel (a REF, never per-mousemove state) to suppress the crosshair and freeze pan/zoom
  const editorRef = useRef(null);      // mirror of the open editor object, so finishEditor can commit without a stale-closure race
  const editorInputRef = useRef(null); // the live <input> element (uncontrolled — value read on commit)
  const lastPtrRef = useRef(null);     // last pointer CLIENT coords — paste targets the sheet under the cursor; ALSO the voice-deixis aim (getAimSeed) — the one pointer tracker
  const aimSeqRef = useRef(0);         // bumps with every lastPtrRef write — the deixis freshness clock (no second tracker, just a tick on the existing one)
  const voiceAimMarkRef = useRef(0);   // aim is LIVE for deixis only while aimSeq > this; re-marked at utterance begin (Command box focus / every run) and on canvas-leave + tab-hide, so a parked-off-canvas or refocus ghost seed can never place a trace
  const pendingClickRef = useRef(null); // deferred draw click {p,cx,cy} — drag >5px converts to a pan
  const rectDragRef = useRef(false);    // Rectangle by drag (Premium tool feel): the press is corner 1, the release corner 2
  const hoverRef = useRef(null);        // hover tooltip div (DOM-direct like the crosshair)
  const insGhostRef = useRef(null);     // edge-insert ghost "+" badge (DOM-direct like the hover readout)
  const hoverIdRef = useRef("");        // shape id currently described by the tooltip
  const lastMeasureRef = useRef("area"); // last armed measure tool — shown on the Measure menu face
  const prevToolRef = useRef("select");   // previous armed tool — detects a LEAVE-zone transition so the shared `poly` array only clears when zone itself was left, not on every tool change
  const statusCoordRef = useRef(null);   // status-bar coords span — direct DOM writes from onPointerMove, never React state per mousemove
  const markTileTopRef = useRef(0);      // MARK tile's viewport top — anchors the fixed highlighter popover beside the rail
  const menuDepthRef = useRef(0);      // >0 while a toolbar menu is open (letter shortcuts pause)
  // ONE stable open/close listener for every toolbar menu — ToolMenu re-fires
  // its onOpenChange effect when the callback identity changes, so an inline
  // arrow here would re-count an open menu on every canvas render
  const onMenuDepth = useCallback((o) => { menuDepthRef.current = Math.max(0, menuDepthRef.current + (o ? 1 : -1)); }, []);
  useEffect(() => {
    if (!workspaceLayout) return;
    const onSearchKey = (e) => {
      const isSearch = (e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k" && !e.altKey && !e.shiftKey;
      // held while a schedule box is read on-device — and kept from the
      // browser's own ⌘K too, so nothing acts behind the coming notice
      if (ocrReadRef.current?.ocr) { if (isSearch) e.preventDefault(); return; }
      if (isSearch && menuDepthRef.current === 0) {
        if (e.target.closest?.("input, textarea, select, [contenteditable=true]")) return;
        e.preventDefault(); setWorkspaceSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onSearchKey);
    return () => window.removeEventListener("keydown", onSearchKey);
  }, [workspaceLayout]);

  const thumbCacheRef = useRef(new Map()); // sheetKey → thumbnail blob URL (lib/thumbs.js) — survives gallery close; persisted twin lives in the meta store
  // sheetKey → SheetIndex for the gallery's plan-set search (#471). Filled by
  // the text passes that already run for sheet numbers and scale notes (the
  // render effect below, and the gallery's thumbnail pump), and by the
  // gallery's own indexing walk for the rest. A ref, like thumbCacheRef: it
  // survives gallery close. Changes are announced on a signal (at most once
  // a frame) the gallery listens to, and the canvas only to keep its Read
  // rows in step (readableByKey below): an index write re-renders the canvas
  // only when a row on it changes. The gallery reads the map fresh when it
  // opens.
  const planIndexRef = useRef(new Map());
  const [indexSignal] = useState(() => createChangeSignal());
  const notifyIndex = indexSignal.notify;
  // store one sheet's entry (a text-layer entry replaces only a seeded one —
  // see putSheetIndex) and re-render the gallery if the map changed
  const onIndexed = useCallback((key, ix) => {
    if (putSheetIndex(planIndexRef.current, key, ix)) notifyIndex();
  }, [notifyIndex]);
  // does the canvas hold this sheet's pdf.js page? The gallery's indexing walk
  // gets the same shared page proxy from getPage and must not clean it up then
  const pageHeld = useCallback((key) => pageObjsRef.current.has(key), []);
  // On-device page reads (#471), one of each for the canvas's life. The
  // session is the one consent path (lib/ocr/session.ts) for these reads and
  // Import from schedule's raster read (#470, importScheduleFromRect); its
  // notice is the OcrDownloadNotice mounted last in the tree, driven by
  // ocrHost. The reader (lib/ocr/pageRead.ts) reads a text-less sheet (cache
  // first), holds each sheet's read status, and feeds every read and cache
  // hit to the search index as an OCR entry. The gallery gets all of it
  // through `ocrApi` below.
  const [ocrNotice, setOcrNotice] = useState(null);   // OcrDownloadNotice's { downloadBytes, progress }, or null
  // Focus: what had it when the notice opened (captured as it opens, before
  // Download's autoFocus takes it), restored when the notice closes;
  // undefined while no notice is up.
  const noticeFocusRef = useRef(undefined);
  const [ocrHost] = useState(() => createConsentHost((v) => {
    if (v && noticeFocusRef.current === undefined) noticeFocusRef.current = document.activeElement;
    setOcrNotice(v);
  }));
  // Esc while the notice is up is the notice's Cancel, wherever focus is (on
  // the body after a click elsewhere): it is the topmost modal, so the guide
  // and the gallery step aside for it (lib/modalKeys otherModalOpen).
  const noticeUp = !!ocrNotice;
  useEffect(() => {
    if (!noticeUp) return;
    const onKey = (e) => {
      if (e.key !== "Escape") return;
      e.preventDefault();
      e.stopPropagation();
      ocrHost.cancel();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [noticeUp, ocrHost]);
  useEffect(() => {
    if (ocrNotice || noticeFocusRef.current === undefined) return;
    const saved = noticeFocusRef.current;
    noticeFocusRef.current = undefined;
    // the gallery card whose Read opened it (its button changed under the
    // notice), else the canvas's Read control
    focusAfterNotice(saved, () => document.querySelector("[data-last-read] button") || document.querySelector("[data-page-read] button"))?.focus();
  }, [ocrNotice]);
  const [ocrSession] = useState(() => createOcrSession({ requestConsent: ocrHost.requestConsent }));
  const [pageReader] = useState(() => createPageReader({
    session: ocrSession,
    cache: createPageCache({ metaGet, metaPut }),
    onLines: (key, lines) => onIndexed(key, ocrSheetIndex(key, lines)),
    // reads never overlap in the worker: each waits for it to be idle
    idle: () => getOcrClient().whenIdle(),
  }));
  readerRef.current = pageReader;   // the doc cache's pins, made before it, ask it
  const [ocrAvail, setOcrAvail] = useState(null);      // the probe's state once asked ("available", "disabled", …), null before
  const [readableByKey, setReadableByKey] = useState({}); // sheet key → what a read of it covers: "page" (a scan), "picture" (a hybrid, #489), or null (nothing to read); planSearch readWhat on its index entry, set as panels are measured and kept in step with the index after (readableFromIndex)
  const measuredRef = useRef(new Set());               // sheet keys the render pass has measured, so each page is measured once
  const [readTick, setReadTick] = useState(0);         // re-render on read status changes the canvas shows
  const readShownRef = useRef([]);                     // the sheet keys on screen (groupKeys), for the signature below
  const [readGate] = useState(() => createReadRenderGate()); // lib/ocr/pageRead: the signature the last render drew
  // a file's bytes are leaving or changing: forget what its pages' text
  // layers and pictures said
  const forgetTextLayer = useCallback((name) => {
    for (const k of [...measuredRef.current]) if (parseSheetKey(k).file === name) measuredRef.current.delete(k);
    setReadableByKey((m) => {
      const keys = Object.keys(m).filter((k) => parseSheetKey(k).file === name);
      if (!keys.length) return m;
      const next = { ...m };
      for (const k of keys) delete next[k];
      return next;
    });
  }, []);
  // The Read rows follow the index (planSearch readableFromIndex), not only
  // the measure moment: a shown sheet's row is re-derived when its entry
  // changes (a gallery adopt after the canvas's measure "failed", a read),
  // and goes when its entry is dropped. Unchanged rows return the same
  // object, so an index write that changes no row doesn't re-render.
  useEffect(() => indexSignal.subscribe(() => setReadableByKey((m) => readableFromIndex(m, planIndexRef.current))), [indexSignal]);
  // Re-render only when what the canvas shows changes: a status of a sheet on
  // screen, or an off-screen read starting, stopping or ending. Off-screen
  // progress and the gallery's lookups don't touch the canvas. Compared with
  // what the last render drew (readGate.rendered, in the render pass below),
  // so a status some other re-render already showed doesn't hide a later
  // change back.
  useEffect(() => pageReader.subscribe(() => {
    if (readGate.changed(readSignature(readShownRef.current, pageReader.status, pageReader.active()))) setReadTick((t) => t + 1);
  }), [pageReader, readGate]);
  useEffect(() => () => pageReader.dispose(), [pageReader]);
  const legacyPinnedRef = useRef(null);    // old `pinned` page numbers awaiting their one-shot tab migration
  const tabInitRef = useRef(false);        // snap to the first restored tab exactly once
  const statusRef = useRef("loading");     // mirror for the gallery's thumbnail worker
  const viewRef = useRef("canvas");        // mirror for the keyboard handlers
  // live mirrors of tool/proposal — oneClickAt is an async function whose
  // closure over `tool`/`proposal` goes stale across an `await` (the user can
  // switch tools or start a proposal on another panel while a raster render is
  // in flight); the post-await guards below read these refs, never the
  // closed-over state, so a slow raster resolve can't act on a world that has
  // since moved on.
  const toolRef = useRef(tool);
  const proposalRef = useRef(proposal);
  const hydrated = useRef(false);
  // Autosave stays holstered until a user-originated edit. hydrate() flips every
  // autosave dep to a fresh identity, so the effect fires once on the post-load
  // render with no edit behind it; that lone run arms this and returns instead of
  // writing — otherwise merely opening a shared ?project= link would CREATE
  // annotations.json in the folder (see #68). Error paths that skip hydrate
  // leave BOTH hydrated and this disarmed: the in-memory state is empty there,
  // so arming would let the first edit overwrite the intact saved takeoff with
  // nothing (the loadError banner explains). A revision Restore reuses hydrate() too, but
  // mid-session it runs with this already armed, so a restore saves — unchanged
  // by this fix. (Restoring on a canvas whose mount load FAILED stays disarmed
  // and is not persisted — the #73 gap, which persists on the LEGACY cloud path.
  // On the opted-in local-first path #73 is RETIRED: loadAnnotations returns local
  // and never throws, so the mount always hydrates + arms, and a restore's setStates
  // re-fire this effect with saves armed → the restored payload persists + pushes.)
  const savesArmed = useRef(false);
  // One-shot suppression for a background reconcile (Slice 5). A remote adopt (mount
  // seed / 4c conflict resolution) re-hydrates via onRemoteUpdate mid-session, when
  // saves are already armed — that hydrate would otherwise re-fire the autosave
  // effect and push the just-adopted content back at synced_rev+1 (rev churn on a
  // seed; a spurious conflict + loser-snapshot on an adopt). Set true right before
  // the reconcile hydrate; the autosave effect swallows exactly the next run.
  // INVARIANT (load-bearing): hydrate() must dirty ≥1 autosave dep so this flag is
  // consumed on the very next commit and can't leak into a later REAL edit (it always
  // does — setConditions/setShapes/setClientInfo mint fresh values unconditionally).
  // And hydrate must not spawn a SECOND autosave-triggering commit that outlives the
  // flag — normalizeLoadedGroups keeps the lastGroup-sync effect a no-op for exactly
  // that reason. A future "skip setState if unchanged" optimization on either would
  // reopen an escape; keep both guarantees.
  const suppressNextSave = useRef(false);
  // Slice 5b defer-gate scratch: `busyStateRef` mirrors the state half of the busy
  // predicate every render so computeBusy can read it via a ref (always fresh, stable
  // to capture); `remotePendingRender` marks a reconcile whose RENDER we deferred
  // because the canvas went busy after the store adopted (Case 2), drained on idle.
  const busyStateRef = useRef({});
  const remotePendingRender = useRef(false);
  // Bumped whenever a busy INTERACTION ref clears (drag/editor/scan end) — those don't
  // trigger a render, so the idle-drain (below) can't observe the busy→idle edge from
  // its state deps alone. idleTick is a drain dep so a ref-only idle transition still
  // drains a deferred render (and un-blocks autosave, which stays suppressed while a
  // render is deferred). Without it, suppression could wedge saves indefinitely.
  const [idleTick, setIdleTick] = useState(0);
  // Only meaningful on the opted-in path (the idle-drain no-ops without a bridge), so
  // gate on syncBridge — this keeps the flag-off / anonymous path free of the extra
  // interaction-end re-renders, preserving byte-for-byte legacy behavior (invariant #4).
  const bumpIdle = () => { if (store.syncBridge) setIdleTick((t) => t + 1); };
  const tfRef = useRef({ x: 0, y: 0, scale: 1 });
  const syncRaf = useRef(0);
  const lastSyncRef = useRef(0);       // last tf mirror sync (perf.now) — scheduleSync throttles against it
  const lastSyncedScaleRef = useRef(1); // scale last written into `tf` — scheduleSync skips a translate-only pan tick when this is unchanged
  const gestureUntilRef = useRef(0);   // wheel/pinch activity horizon — the detail view waits it out
  const panRafRef = useRef(0);         // rAF token coalescing drag-pan pointermoves into one transform write per frame
  const saveDataRef = useRef(null);    // latest serialized annotations — flushed on unmount
  const saveStateRef = useRef("idle"); // mirror of saveState for the unmount/beforeunload guard

  // page 1 keeps the bare file name (pre-paging takeoffs still load); pages 2+ → "name#page"
  const sheetKey = page > 1 ? `${active}#${page}` : active;
  // Most-recently-viewed tab order (Task 7): the "Reference ▸ Split
  // Vertical/Horizontal" menu items default their chosen sheet to the
  // most-recently-used non-active open tab, and openTabs itself is
  // insertion-ordered (append-on-open), not recency-ordered, so it can't
  // answer that on its own. Front-loads sheetKey on every navigation,
  // deduped; a closed tab simply falls out of the openTabs.includes() filter
  // at read time rather than being pruned here.
  const tabMruRef = useRef([]);
  useEffect(() => { tabMruRef.current = [sheetKey, ...tabMruRef.current.filter((k) => k !== sheetKey)]; }, [sheetKey]);
  // toggle a sheet in/out of the side-by-side group; first toggle from single
  // mode seeds the group with the sheet currently on screen
  const toggleInGroup = (key) => setSheetGroup((g) => {
    if (g.includes(key)) { const f = g.filter((k) => k !== key); return f.length >= 2 ? f : []; }
    if (g.length >= MAX_GROUP) return g;
    const base = g.length ? g : (key === sheetKey ? [] : [sheetKey]);
    return base.includes(key) ? base : [...base, key];
  });
  // Ungroup lands you on the sheet you were last working (the focused panel),
  // not whatever sheet the pager held before you grouped — shapes/markups all
  // carry their own sheet_id, so nothing is lost either way.
  const ungroup = () => {
    let k = (focusKey && sheetGroup.includes(focusKey)) ? focusKey : (sheetGroup[0] || sheetKey);
    // ungrouping a stitch lands on its first member — the stitch id itself is
    // not a pageable single sheet (active/page never carry stitch keys)
    if (isStitchKey(k)) k = stitchById[k]?.members[0]?.key || sheets[0]?.name || k;
    const t = parseSheetKey(k);
    setSheetGroup([]);
    if (t.file !== active) setActive(t.file);
    setPage(t.page);
  };
  // Regroup restores the last side-by-side composition — the common flow is
  // ungroup, set each sheet's scale one at a time, then want the combined
  // canvas back without re-picking every sheet in the gallery.
  const regroup = () => {
    if (lastGroup.length < 2) return;
    setOpenTabs((t) => { const m = [...t]; for (const k of lastGroup) if (!m.includes(k)) m.push(k); return m; });
    setSheetGroup(lastGroup);
    setFocusKey(lastGroup.includes(sheetKey) ? sheetKey : lastGroup[0]);
  };
  // single-view a sheet by key (tab click, gallery View, tab restore)
  function goToSheet(key) {
    if (isStitchKey(key)) { openStitch(key); return; }   // a stitch opens as a group of one (#161)
    const t = parseSheetKey(key);
    if (t.file !== active) setActive(t.file);
    setPage(t.page);
    setSheetGroup([]);
  }
  // ── stitches (#161): open / create / delete ────────────────────────────────
  function openStitch(id) {
    if (!stitchById[id]) return;
    setOpenTabs((t) => (t.includes(id) ? t : [...t, id]));
    setSheetGroup([id]);
    setFocusKey(id);
    setView("canvas");
  }
  // Mint a stitch from 2..MAX_GROUP sheet keys: members butt flush left-to-
  // right (match-line alignment is the Align gesture's job), the stitch opens
  // immediately, and it inherits the members' scale when they all agree.
  async function createStitch(keys) {
    const ks = [...new Set(keys)].slice(0, MAX_GROUP);
    if (ks.length < 2 || ks.some((k) => isStitchKey(k))) return;
    const dims = {};
    try {
      for (const k of ks) {
        const t = parseSheetKey(k);
        // a member's file may be in no tab: held while its page is read
        await docCache.withDoc(t.file, async (pdf) => {
          const pg = await pdf.getPage(Math.min(Math.max(1, t.page), pdf.numPages || 1));
          const vp = pg.getViewport({ scale: RENDER_SCALE });
          // EXACT dims — a butt layout at ceil'd widths would open a hairline gap
          // and drift the composite extent (see resolveSource's wf/hf note)
          dims[k] = { w: vp.width, h: vp.height };
        });
      }
    } catch (e) { setCommitMsg(uiText(`Couldn't read those sheets to stitch them: ${e.message || e}`)); return; }
    const st = { id: mintStitchId(), name: ks.map((k) => tabLabel(k)).join(" + "), members: autoButt(ks, dims), created_at: nowIso() };
    setStitches((s) => [...s, st]);
    const upps = ks.map((k) => scales[k]);
    if (upps.every((u) => u != null && Math.abs(u - upps[0]) < 1e-12)) setScales((s) => ({ ...s, [st.id]: upps[0] }));
    setOpenTabs((t) => (t.includes(st.id) ? t : [...t, st.id]));
    setSheetGroup([st.id]);
    setFocusKey(st.id);
    setView("canvas");
    setCommitMsg(uiText("Stitched — drag to pan, then Align (toolbar) joins the match line: click the same point on both sheets."));
  }
  // Deleting a stitch is refused while takeoffs live on it — quantities are
  // never silently orphaned (the close-PDF confirm precedent, but stricter:
  // a stitch has no file to re-add, so there is no restore path).
  function deleteStitch(id) {
    const n = shapes.filter((s) => s.sheet_id === id).length + markups.filter((m) => m.sheet_id === id).length;
    if (n) { setCommitMsg(uiText(`This stitch carries ${n} takeoff${n === 1 ? "" : "s"}/markup${n === 1 ? "" : "s"} — delete or move them first.`)); return; }
    setStitches((s) => s.filter((st) => st.id !== id));
    setOpenTabs((t) => t.filter((k) => k !== id));
    if (sheetGroup.includes(id)) { const f = sheetGroup.filter((k) => k !== id); setSheetGroup(f.length >= 2 || (f.length === 1 && isStitchKey(f[0])) ? f : []); }
    setLastGroup((g) => (g.includes(id) ? [] : g));
  }
  // gallery open: every key becomes a tab; side-by-side also groups (2–4)
  function openSheets(keys, sideBySide) {
    if (!keys.length) return;
    setOpenTabs((t) => { const merged = [...t]; for (const k of keys) if (!merged.includes(k)) merged.push(k); return merged; });
    if (sideBySide && keys.length >= 2) { setSheetGroup(keys.slice(0, MAX_GROUP)); setFocusKey(keys[0]); }
    else goToSheet(keys[0]);
    setView("canvas");
  }
  function closeTab(key) {
    const i = openTabs.indexOf(key);
    const next = openTabs.filter((k) => k !== key);
    setOpenTabs(next);
    if (sheetGroup.includes(key)) { const f = sheetGroup.filter((k) => k !== key); setSheetGroup(f.length >= 2 || (f.length === 1 && isStitchKey(f[0])) ? f : []); }
    // Stale-chip pruning (Task 8, carried from Task 7's flagged gap): a
    // closed tab's sheetKey must not linger in a split's reference set — the
    // reference pane only ever REFERENCES open tabs, never owns them
    // (SplitLayout.jsx's header comment). Drop it; if it was the framed
    // sheet, reframe to another member that's still an open tab, or
    // auto-collapse (setSplitView(null)) if none remain — the
    // dangling-single-chip dead end this task exists to close (a stale chip
    // stuck showing "Drop a sheet here" with no way to remove it short of
    // collapsing the whole split).
    if (splitView && (splitView.refKey === key || splitView.refSet?.includes(key))) {
      setSplitView((s) => {
        if (!s) return s;
        const set = (s.refSet?.length ? s.refSet : [s.refKey]).filter((k) => k !== key);
        if (!set.length) return null;
        const refKey = s.refKey === key ? set.find((k) => next.includes(k)) : s.refKey;
        return refKey ? { ...s, refSet: set, refKey } : null;
      });
    }
    if (!next.length) { setView("gallery"); return; }
    if (!sheetGroup.length && key === sheetKey) { const nb = next[Math.min(Math.max(i, 0), next.length - 1)]; if (nb) goToSheet(nb); }
  }
  const tabLabel = (k) => {
    if (isStitchKey(k)) return stitchById[k]?.name || "Stitched sheets";
    const lvl = sheetLevels[k] ? `${sheetLevels[k]} · ` : "";   // assigned floor/level rides every tab label
    if (galleryLabels[k]) return lvl + galleryLabels[k];
    const t = parseSheetKey(k);
    if (t.file === active && pageLabels[t.page]) return lvl + pageLabels[t.page];
    const base = t.file.replace(/\.pdf$/i, "");
    return lvl + (t.page > 1 ? `${base} · ${t.page}` : base);
  };
  // Every sheet key in the set, for Import from schedule's "on the plans?"
  // check (#498): a file whose pages aren't counted yet is one unknownFiles,
  // not zero sheets (0 is a file that failed to open: no sheets).
  const planSetKeys = () => {
    const keys = [];
    let unknownFiles = 0;
    for (const s of sheets) {
      const n = s.name === active ? pageCount : knownPages[s.name];
      if (n === undefined) { unknownFiles++; continue; }
      for (let i = 0; i < n; i++) keys.push(i ? `${s.name}#${i + 1}` : s.name);
    }
    return { keys, unknownFiles };
  };
  // A sheet's bare identifier for auto-naming an image markup (e.g. "AF101") —
  // tabLabel WITHOUT the mutable "Level 1 · " prefix and with a hyphen so a page-2
  // sheet reads "PLAN-2", not the compound "Level 1 · PLAN · 2" that would nest
  // badly inside an image name like "…-01".
  const sheetBaseLabel = (k) => {
    if (isStitchKey(k)) return stitchById[k]?.name || "Stitched";
    if (galleryLabels[k]) return galleryLabels[k];
    const t = parseSheetKey(k);
    if (t.file === active && pageLabels[t.page]) return pageLabels[t.page];
    const base = t.file.replace(/\.pdf$/i, "");
    return t.page > 1 ? `${base}-${t.page}` : base;
  };

  // ── panels: the ONE rendering model — single-sheet mode is a group of one ──
  // Every coordinate on screen lives in "stage space": panel i's image px plus
  // its xOffset. With one panel xOffset is 0, so stage space IS image space and
  // all the original single-sheet math is unchanged.
  const groupKeys = sheetGroup.length ? sheetGroup : [sheetKey];
  const stitchById = useMemo(() => Object.fromEntries(stitches.map((s) => [s.id, s])), [stitches]);
  // the files on screen or a tab away stay loaded (docCache's pins); one that
  // just left becomes the most recent idle one, so a tab just closed reopens
  // without a reload unless enough other files are used meanwhile. Pins are
  // set before any effect runs; the trim runs in an effect after the render
  // effect (pinSig).
  const pinFiles = pinnedFiles({ keys: [...openTabs, ...groupKeys], stitchById });
  if (active) pinFiles.add(active);
  const pinSig = [...pinFiles].sort().join("\n");
  useLayoutEffect(() => {
    const unpinned = [...pinsRef.current.files].filter((f) => !pinFiles.has(f));
    if (unpinned.length) docCache.touch(unpinned);
    pinsRef.current = { files: pinFiles, stitchById };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- pinSig is pinFiles' identity; stitchById rides along
  }, [pinSig, stitchById, docCache]);
  // Task 8: the primary group's actual live-sheet cost — a stitch panel
  // occupies one groupKeys slot but draws (and tile-composites) every one of
  // its members (see the draw-time expansion into `drawPanels` below), so a
  // stitch counts as its member count here, not 1. This is the "primaryCount"
  // half of wouldExceedSheetCap(primaryCount, refCount); refSet.length above
  // is the other half.
  const primaryCount = groupKeys.reduce((n, k) => n + (isStitchKey(k) ? (stitchById[k]?.members?.length || 1) : 1), 0);
  // Task 8: shared refusal for every split-creation / reference-add site.
  // Side-effecting (the toast), so callers check it in an event handler
  // BEFORE calling setSplitView, never inside a setState updater (which can
  // run more than once). Returns true (and refuses) when adding nextRefCount
  // reference sheets to the current primary would exceed the budget.
  const refuseIfOverCap = (nextRefCount) => {
    if (!wouldExceedSheetCap(primaryCount, nextRefCount)) return false;
    setCommitMsg(uiText("Too many sheets open at once to split — close a sheet first"));
    return true;
  };
  // docEpoch re-keys groupSig when a re-dropped file's BYTES changed under the
  // same name (store.addPdf → revised): the render effect keyed on groupSig is
  // the one path that resets every cache (compositor, pageObjs, snap grids) and
  // reloads docs, so bumping it is how new revision bytes reach the screen
  // without a reload. Same-name-same-bytes drops don't bump — no wasted repaint.
  // The stitch-layout signature joins it (#161): re-aligning a stitch moves its
  // members under the SAME keys, and this effect is the one path that rebuilds
  // the merged snap/mask geometry and member placement.
  const [docEpoch, setDocEpoch] = useState(0);
  const groupSig = JSON.stringify(groupKeys) + "@" + docEpoch + "|" + stitchLayoutSig(groupKeys, stitches);
  readShownRef.current = groupKeys;
  readGate.rendered(readSignature(groupKeys, pageReader.status, pageReader.active()));
  let _px = 0;
  const panels = groupKeys.map((key) => {
    const dims = panelImgs[key] || { w: 0, h: 0 };
    const p = { key, ...parseSheetKey(key), img: dims, xOffset: _px };
    if (dims.w) _px += dims.w + PANEL_GAP;
    return p;
  });
  // Draw-time expansion (#161): a stitch panel paints as its MEMBER canvases
  // (each positioned at its stitch offset, seam-clipped); a plain panel paints
  // as itself with drawKey === key, so the non-stitch DOM is byte-identical.
  // Input math (panelAt/stage space) reads `panels` only and never sees this.
  const drawPanels = panels.flatMap((p) => {
    const st = stitchById[p.key];
    if (!st) return [{ drawKey: p.key, compKey: p.key, x: p.xOffset, y: 0, w: p.img.w, h: p.img.h, clip: null }];
    const dims = panelSourceDimsRef.current.get(p.key);
    if (!dims) return [];   // members not resolved yet — the render effect paints nothing until phase A lands
    const clips = seamClips(st.members, dims);
    return st.members.map((m, i) => ({
      drawKey: `${p.key}::${m.key}`, compKey: `${p.key}::${m.key}`,
      x: p.xOffset + m.dx, y: m.dy,
      // ceil to match the base canvas's integer backing store (dims are exact)
      w: Math.ceil(dims[m.key]?.w || 0), h: Math.ceil(dims[m.key]?.h || 0),
      // clip is the member's VISIBLE box in stage space (wrapper div bounds)
      clip: { x: p.xOffset + clips[i].x0, y: clips[i].y0, w: clips[i].x1 - clips[i].x0, h: clips[i].y1 - clips[i].y0 },
    }));
  });
  // Pure panel-row math (stage extent, nearest-panel routing, the px→feet
  // scale factors) lives in lib/panelGeometry.js; these thin wrappers bind the
  // live panels/scales so every call site below reads unchanged.
  const stage = panelGeom.stageExtent(panels);
  const panelByKey = (k) => panelGeom.panelByKey(panels, k);
  const panelAt = (sx) => panelGeom.panelAt(panels, sx);
  const panelKeySet = new Set(groupKeys);
  // memoized: feeds the per-condition totals map the memoized TakeoffsPanel
  // takes as a prop — identity must hold across canvas-only renders. Builds
  // its own key set from sheetGroup/sheetKey (what groupKeys/panelKeySet above
  // are themselves derived from) rather than depending on groupSig or the
  // panelKeySet instance above — both are new on every render, so depending on
  // either honestly would recompute every render regardless; these are the
  // real, referentially-stable inputs.
  const visibleShapes = useMemo(() => {
    const keys = new Set(sheetGroup.length ? sheetGroup : [sheetKey]);
    return shapes.filter((s) => keys.has(s.sheet_id));
  }, [shapes, sheetGroup, sheetKey]);
  // bottom-to-top paint order (see ROLE_TIER) — the renderer maps this
  // ascending; the click and hover pickers scan it reversed.
  // Hidden conditions (#440) drop out HERE and only here: this list is both
  // what the renderer paints and what the pickers scan, so a hidden shape
  // can't be seen or clicked — while visibleShapes (totals, tally, transition
  // sources) still carries it. Hiding changes the view, never a number.
  // the Trade view hides other trades the same way, on top of the eye toggles (which it never rewrites)
  // the active condition always shows: what you are drawing under never goes invisible
  const tradeHidden = useMemo(() => { const h = tradeHiddenIds(conditions, viewTrade); h.delete(activeCond); return h; }, [conditions, viewTrade, activeCond]);
  const tradeCountMap = useMemo(() => tradeCounts(conditions), [conditions]);
  const viewHidden = useMemo(() => (tradeHidden.size ? new Set([...hiddenConds, ...tradeHidden]) : hiddenConds), [hiddenConds, tradeHidden]);
  const stackedShapes = useMemo(() => {
    const drawn = viewHidden.size ? visibleShapes.filter((s) => !viewHidden.has(s.condition_id)) : visibleShapes;
    return [...drawn].sort((a, b) => tierOf(a) - tierOf(b));
  }, [visibleShapes, viewHidden]);
  // Reference-pane shapes (split screen, Task 5): deliberately NOT filtered
  // through `visibleShapes` — the reference pane can frame a sheet the
  // primary's sheetGroup doesn't include at all (the tab-drop gesture from
  // Task 4 hands it any sheet), and `stackedShapes` above would silently
  // render nothing for that case. Same live `shapes` state and paint-order
  // convention (tierOf) as the primary, just scoped to the referenced sheet
  // instead of the primary's group — so a shape measured/edited in the
  // primary still mirrors live into the reference pane. Hidden conditions
  // drop out here too (#440 parity): a condition hidden on the primary never
  // reappears in the mirror.
  const refStackedShapes = useMemo(
    () => (effectiveRefKey ? shapes.filter((s) => s.sheet_id === effectiveRefKey && !viewHidden.has(s.condition_id)).sort((a, b) => tierOf(a) - tierOf(b)) : []),
    [shapes, effectiveRefKey, viewHidden]
  );
  const visibleMarkups = useMemo(() => {
    const keys = new Set(sheetGroup.length ? sheetGroup : [sheetKey]);
    return markups.filter((m) => !m.reference_only && keys.has(m.sheet_id));
  }, [markups, sheetGroup, sheetKey]);
  // Reference-pane markups (split screen, markup mirror): the same live
  // `markups` state, scoped to the pane's effective refKey and paint-ordered by
  // lib/markupPaint's shared tier rule (the primary's per-panel filter uses the
  // same helper, so the two panes can't stack differently). Same
  // reference-only exclusion as `visibleMarkups` — a pin for the reference rail
  // is not ink on a sheet. A null effective refKey mirrors nothing.
  // Gated on showMarkups for the same reason the primary layer is: the toggle's
  // job is "hide the markup ink on the canvas", and the mirror is canvas ink.
  const refMarkups = useMemo(
    () => (showMarkups ? markupsForSheet(markups, effectiveRefKey) : []),
    [markups, effectiveRefKey, showMarkups]
  );
  // scale is PER PAGE (plan sets are never one uniform scale) — set it once per
  // sheet and it's remembered. In group mode the scale dropdown and hints target
  // the FOCUSED panel (the one last clicked); single mode focuses the lone panel.
  const focusPanel = (focusKey && groupKeys.includes(focusKey) && panelByKey(focusKey)) || panels[0];
  const unitsPerPx = scales[focusPanel.key] ?? null;
  // Guided first takeoff — fold what the canvas can see into the tour's done
  // set. Every step completes on the real action (lib/firstTakeoff.js).
  const tourFloorShapes = tour ? countFloorShapes(shapes) : 0;
  const tourSheetOpen = view === "canvas" && openTabs.length > 0;
  useEffect(() => {
    if (!tour) return;
    const obs = { sheetOpen: tourSheetOpen, scaled: !!unitsPerPx, tool, floorShapes: tourFloorShapes, reportOpen: showReport };
    const next = advanceTour(tour.done, obs, tour.baseline);
    if (next !== tour.done) setTour((t) => (t ? { ...t, done: next } : t));
  }, [tour, tourSheetOpen, unitsPerPx, tool, tourFloorShapes, showReport]);
  const startTour = () => {
    setGuideOpen(false);
    setConnectOpen(false);
    setTour({ done: [], baseline: countFloorShapes(shapes) });
  };
  const loadSampleForTour = async () => {
    if (tourSampleBusy) return;
    setTourSampleBusy(true);
    try { await handleFiles([await fetchSamplePlan()]); } catch { /* the card stays on step 1; the button can be pressed again */ }
    finally { setTourSampleBusy(false); }
  };
  // the room the tour just measured — the newest floor shape, for the done card
  const tourResult = (() => {
    if (!tour || currentStep(tour.done)) return null;
    const last = [...shapes].reverse().find((sh) => (sh.computed?.area_sf || 0) > 0 && sh.measure_role !== "deduct");
    if (!last) return null;
    return { sf: last.computed.area_sf, tag: conditions.find((c) => c.id === last.condition_id)?.finish_tag || "" };
  })();
  const labelFor = (p) => stitchById[p.key]?.name || (p.file === active && pageLabels[p.page]) || (p.page > 1 ? `Sheet ${p.page}` : p.file);
  // Scale semantics (why geometry divides by factorFor and calibration
  // multiplies back to baseline) are documented on the pure functions in
  // lib/panelGeometry.js; these wrappers bind the live scales/renderScalesRef.
  // factorFor is now a constant 1 (renderScalesRef is always pinned to
  // RENDER_SCALE — see the tile-pyramid render effect below): the logical
  // img space no longer varies with what's actually rastered, since nothing
  // is rastered at panel scope anymore, only bounded tiles. Signatures are
  // unchanged so none of factorFor/uppFor's ~20 call sites needed to move.
  const factorFor = (key) => panelGeom.factorFor(renderScalesRef.current, key);
  const uppFor = (key) => panelGeom.uppFor(scales, renderScalesRef.current, key);
  // keep the agent's capability closures reading LIVE state across their awaits
  useEffect(() => {
    agentStateRef.current = { panels, scales, scaleSources, detectedScales, conditions, status };
  });

  // ── roll goods (#136): the figured layouts, one pure pass over the takeoff ──
  // Rendered sheets only — a ring needs bitmap dims (panelImgs) plus a scale to
  // speak feet. Memoized off geometry/config, never the transform: pan/zoom
  // must not re-figure a roll. uppFor reads `scales` (a dep) plus a ref pinned
  // to RENDER_SCALE, so the dep list is honest.
  const rollTakeoff = useMemo(
    () => computeRollTakeoff(conditions, shapes, (k) => panelImgs[k] || null, (k) => uppFor(k)),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- uppFor reads scales (listed) + renderScalesRef pinned to RENDER_SCALE; listing it would re-figure rolls on every render
    [conditions, shapes, panelImgs, scales]   // uppFor: scales + a pinned ref
  );
  const rollByCond = rollTakeoff.byCond;
  const rollCutsByPanel = rollTakeoff.cutsBySheet;
  // Figured seam LF per shape — the basis a "seam_lf" materials row (weld rod,
  // seam tape) divides against. Handed to every conditionTotals scope below so
  // the HUD, the project roll-up, and a zone check agree with the Report on
  // what the layout welds.
  const seamCtx = useMemo(() => ({ seamByShape: seamLfByShape(rollByCond) }), [rollByCond]);

  // Cut drag (#136) — the self-contained element-drag pattern (the panel-resize
  // handle's): the cut's own <g> opts into pointer events in edit mode, captures
  // the pointer, live-PREVIEWS by writing shape.roll_layout through raw
  // setShapes (the sanctioned preview path — see the dispatchShape header), and
  // commits ONE undoable `rollcut` command on release whose inverse is the
  // grab-time row. kind: "body" slides the cut along its lane; "start"/"end"
  // pull the run ends (the installer's call the math can't make — carry into a
  // closet, stop short of a transition). A cut can never get shorter than 3″.
  const beginRollCut = (e, ct, kind) => {
    if (!rollEdit) return;
    e.stopPropagation(); e.preventDefault();
    const shape = shapes.find((s) => s.id === ct.srcId);
    if (!shape) return;
    rollDragRef.current = {
      srcId: ct.srcId, laneIndex: ct.laneIndex, laneCount: ct.laneCount, kind,
      runY: ct.laneAxis === "x", upp: ct.upp, sx: e.clientX, sy: e.clientY,
      base: { runMin: ct.runMin, runMax: ct.runMax },
      prevRow: { id: ct.srcId, ...("roll_layout" in shape ? { roll_layout: shape.roll_layout } : {}) },
      moved: false, lastLayout: null,
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const moveRollCut = (e) => {
    const d = rollDragRef.current; if (!d) return;
    const dFt = ((d.runY ? e.clientY - d.sy : e.clientX - d.sx) / tfRef.current.scale) * d.upp;
    let { runMin, runMax } = d.base;
    if (d.kind === "body") { runMin += dFt; runMax += dFt; }
    else if (d.kind === "start") runMin = Math.min(d.base.runMax - 0.25, d.base.runMin + dFt);
    else runMax = Math.max(d.base.runMin + 0.25, d.base.runMax + dFt);
    d.moved = d.moved || Math.abs(dFt) > 1e-4;
    // Build the target layout SYNCHRONOUSLY, from the grab-time row — never
    // inside the setShapes updater: a fast flick's pointerup can land before
    // React flushes the last move, and a commit that reads updater-written
    // state would silently skip (the house drag pattern: gesture state lives
    // in the ref, the updater only mirrors it). A stored layout from a
    // DIFFERENT lane count is stale (reshaped room) — start fresh rather than
    // resurrect overrides aimed at lanes that moved.
    const prevRl = d.prevRow.roll_layout;
    const prior = prevRl && typeof prevRl === "object" && prevRl.lanes && prevRl.laneCount === d.laneCount ? prevRl.lanes : {};
    d.lastLayout = { laneCount: d.laneCount, lanes: { ...prior, [d.laneIndex]: { ...(prior[d.laneIndex] || {}), runMin, runMax } } };
    setShapes((ss) => ss.map((s) => (s.id === d.srcId ? { ...s, roll_layout: d.lastLayout } : s)));
  };
  const endRollCut = () => {
    const d = rollDragRef.current; if (!d) return;
    rollDragRef.current = null;
    if (!d.moved || !d.lastLayout) return;   // zero-motion = not an edit — no command, no undo entry
    dispatchShape({ type: "rollcut", rows: [{ id: d.srcId, roll_layout: d.lastLayout }], prev: [d.prevRow] });
  };
  // double-click: hand THIS cut back to the figured layout (drop its lane
  // override; the key clears entirely when no other lane holds an edit)
  const resetRollCut = (ct) => {
    const shape = shapes.find((s) => s.id === ct.srcId);
    const rl = shape?.roll_layout;
    if (!rl || !rl.lanes || !(ct.laneIndex in rl.lanes)) return;
    const lanes = { ...rl.lanes };
    delete lanes[ct.laneIndex];
    const row = Object.keys(lanes).length ? { id: ct.srcId, roll_layout: { laneCount: rl.laneCount, lanes } } : { id: ct.srcId };
    dispatchShape({ type: "rollcut", rows: [row] });
  };
  // RollPanel reorder: the dragged order becomes seq overrides (manual cuts
  // pack FIRST, in that order — the engine's skyline re-packs, so a manual
  // order can never overlap) — ONE rollcut command, one undo entry.
  const onReorderRollCuts = (condId, orderedIds) => {
    const ri = rollByCond.get(condId); if (!ri) return;
    const laneCountBySrc = new Map(ri.strips.map((s) => [s.srcId, s.laneCount]));
    const bySrc = new Map();
    orderedIds.forEach((sid, idx) => {
      const i = sid.lastIndexOf(":");
      const srcId = sid.slice(0, i), lane = sid.slice(i + 1);
      if (!bySrc.has(srcId)) bySrc.set(srcId, {});
      bySrc.get(srcId)[lane] = idx;
    });
    const rows = [];
    for (const [srcId, seqByLane] of bySrc) {
      const shape = shapes.find((s) => s.id === srcId); if (!shape) continue;
      const lc = laneCountBySrc.get(srcId);
      const prior = shape.roll_layout?.laneCount === lc && shape.roll_layout.lanes ? shape.roll_layout.lanes : {};
      const lanes = { ...prior };
      for (const [lane, seq] of Object.entries(seqByLane)) lanes[lane] = { ...(lanes[lane] || {}), seq };
      rows.push({ id: srcId, roll_layout: { laneCount: lc, lanes } });
    }
    if (rows.length) dispatchShape({ type: "rollcut", rows });
  };
  // strip only the seq keys — a floor-position edit (runMin/runMax) survives a
  // cutting-order reset; that's a different decision than double-click reset
  const onResetRollOrder = (condId) => {
    const ri = rollByCond.get(condId); if (!ri) return;
    const srcIds = new Set(ri.strips.map((s) => s.srcId));
    const rows = [];
    for (const s of shapes) {
      if (!srcIds.has(s.id) || !s.roll_layout?.lanes) continue;
      let changed = false;
      const lanes = {};
      for (const [k, o] of Object.entries(s.roll_layout.lanes)) {
        if (o && typeof o === "object" && "seq" in o) {
          const { seq: _seq, ...rest } = o;
          changed = true;
          if (Object.keys(rest).length) lanes[k] = rest;
        } else lanes[k] = o;
      }
      if (!changed) continue;
      rows.push(Object.keys(lanes).length ? { id: s.id, roll_layout: { laneCount: s.roll_layout.laneCount, lanes } } : { id: s.id });
    }
    if (rows.length) dispatchShape({ type: "rollcut", rows });
  };

  // ── transform: tfRef is source of truth; write straight to the DOM ─────────
  const applyTf = useCallback(() => {
    const { x, y, scale } = tfRef.current;
    if (stageRef.current) stageRef.current.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
  }, []);
  // Compositor-promote the stage layer for the DURATION OF A GESTURE only.
  // A permanently-promoted layer (will-change: transform in the JSX) freezes
  // its raster scale at promotion time — Chromium deliberately never re-rasters
  // such a layer when only its transform scale changes — so after a zoom-in the
  // SVG overlay (committed boundaries, the in-progress polygon, vertex handles)
  // stays a GPU-magnified bitmap: pixelated, blurry edges while drawing. The
  // detail canvases never showed it because they repaint their own pixels at
  // settle. So promote when a pan/zoom gesture opens (per-frame moves stay
  // compositor-only and cheap) and demote when it settles (in syncTilePanels,
  // keyed off the same gestureUntilRef wheel-quiet signal the detail repaint
  // uses) — a demoted stage transforms at paint time, re-rastering the overlay
  // crisp at whatever zoom the user landed on.
  const promoteStage = useCallback(() => {
    const el = stageRef.current;
    if (el && el.style.willChange !== "transform") el.style.willChange = "transform";
  }, []);
  // Re-apply after every React render so an unrelated re-render mid-drag can't
  // snap the transform back to a stale value.
  useLayoutEffect(() => { applyTf(); });
  // Leading+trailing ~90ms throttle, not per-frame and not trailing-only: the React
  // mirror feeds screen-relative sizes (handle radii, stroke widths, label text, the
  // low-zoom tint switch), so it must track a CONTINUOUS gesture — the old trailing
  // debounce left labels scaling with the stage and shapes flashing sub-pixel until
  // 80ms after the gesture ended. ~11Hz keeps the overlay honest for a trivial render
  // cost; the DOM transform still updates per-event/per-frame.
  const scheduleSync = useCallback(() => {
    if (syncRaf.current) return;                       // a queued tick reads the freshest tfRef
    const wait = Math.max(0, SYNC_MS - (performance.now() - lastSyncRef.current));
    syncRaf.current = setTimeout(() => {
      syncRaf.current = 0; lastSyncRef.current = performance.now();
      const t = tfRef.current;
      // Tile repositioning (#86) is UNCONDITIONAL — it doesn't wait on the tf
      // state mirror below, or a pure low-zoom pan would never resync its
      // crop (see syncTilePanelsRef's comment for why this had to split out).
      syncTilePanelsRef.current();
      // Nothing in the render tree reads tf.x/tf.y — position lives entirely in
      // the CSS transform above. A pure pan (scale unchanged) below this
      // density threshold doesn't need the React mirror at all: skipping the
      // state write avoids re-rendering the whole shape/markup overlay
      // (thousands of SVG els at overview zoom) on every ~90ms pan tick — that
      // wasted reconciliation was the zoomed-out pan flicker + toolbar lag.
      // (DETAIL_ENGAGE is reused here only as a convenient density threshold —
      // this gate is about SVG reconciliation cost, unrelated to raster tiles.)
      if (t.scale === lastSyncedScaleRef.current && t.scale * (window.devicePixelRatio || 1) <= DETAIL_ENGAGE) return;
      lastSyncedScaleRef.current = t.scale;
      setTf({ ...t });
    }, wait);
  }, []);
  const setTfNow = useCallback((next) => { tfRef.current = next; applyTf(); setTf({ ...next }); }, [applyTf]);

  // ── local PDFs (dropped into this browser) ─────────────────────────────────
  const refreshSheets = useCallback(async () => {
    const list = await store.listSheets();
    setSheets(list);
    return list;
  }, []);
  // Stable props for the Drive picker so its folder-load effect doesn't re-fire
  // (and re-hit Drive) on every canvas re-render. `store` is a module binding
  // read at call time, so [] deps are correct.
  const pickerListFolder = useCallback((id) => store.listFolder(id), []);
  const pickerAddSheets = useCallback((items) => store.addSheets(items), []);
  // ── page-count cache (#302) ────────────────────────────────────────────────
  // The gallery used to learn every file's page count by loading its FULL bytes
  // into a pdf.js doc the moment it opened — the one eager read left in an
  // otherwise lazy pipeline (thumbnails render on scroll, the canvas rasters
  // only open tabs). On a large plan set that read IS the sluggishness, so
  // counts persist in the meta store once discovered and the gallery opens a
  // known set without touching a byte of it. Keyed per project scope; entries
  // drop on the only two paths that can change a file's pages — a revision
  // (addPdf revised) and a removal — so the cache can't go stale.
  const pageCacheKey = "sheet_pages:" + (projectIdFromUrl() || "local");
  const [knownPages, setKnownPages] = useState({});
  const knownPagesRef = useRef(knownPages);
  // nothing is saved until the stored counts have loaded (pageCounts.ts):
  // the map is written whole, so an early write would drop every stored count
  // (StrictMode runs this initializer twice in development: two harmless reads)
  const [pageCounts] = useState(() => createPageCounts({
    load: () => metaGet(pageCacheKey),
    save: (m) => metaPut(pageCacheKey, m),
    onChange: (m) => { knownPagesRef.current = m; setKnownPages(m); },
  }));
  const rememberPages = useCallback((name, count) => pageCounts.remember(name, count), [pageCounts]);
  const rotationCacheKey = "sheet_rotations:" + (projectIdFromUrl() || "local");
  useEffect(() => {
    metaGet(rotationCacheKey).then((r) => {
      if (r && typeof r === "object") {
        setSheetRotations(r);
        sheetRotationsRef.current = r;
      }
    }).catch(() => {});
  }, [rotationCacheKey]);
  const saveSheetRotations = useCallback((rots) => {
    setSheetRotations(rots);
    sheetRotationsRef.current = rots;
    metaPut(rotationCacheKey, rots).catch(() => {});
  }, [rotationCacheKey]);
  // Import from schedule's plan set (#498), rebuilt only when the dialog's
  // read or the set's pages change: the dialog re-checks every row against
  // every sheet's index whenever this object changes, so a fresh one per
  // canvas render would redo that on every unrelated update. The index map
  // itself is mutated in place and announced through indexSignal.
  const importPlanSet = useMemo(() => (importRead
    ? { ...planSetKeys(), indexes: planIndexRef.current, sourceKey: importRead.sourceKey, boxTerms: importRead.boxTerms }
    : undefined),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [importRead, sheets, active, pageCount, knownPages]);
  const forgetPages = useCallback((names) => {
    // a file whose bytes are leaving (or changing) takes its thumbnails with it
    forgetThumbs(names, thumbCacheRef.current);
    pageCounts.forget(names);
  }, [pageCounts]);
  // The Sheets tree's numbers (spec §5): Premium layout only; local projects
  // keep one record per file, cloud ones keep names for the session. A new
  // namer per mount (StrictMode mounts twice; each one is stopped).
  const nameScope = projectIdFromUrl() || "local";
  const namerRef = useRef(null);
  const [namer, setNamer] = useState(null);
  useEffect(() => {
    if (!workspaceLayout) return;
    const n = createSheetNamer({ scope: nameScope, persist: !cloudMode, meta: { get: metaGet, put: metaPut }, onError: (e) => console.warn("Sheet numbers:", e) });
    n.start();
    namerRef.current = n;
    setNamer(n);
    return () => { if (namerRef.current === n) namerRef.current = null; setNamer(null); n.stop(); };
  }, [workspaceLayout, cloudMode, nameScope]);
  useEffect(() => { namer?.setFiles(sheets.map((s) => s.name)); }, [namer, sheets]);
  const offerSheetText = useCallback((file, page, gen, tc, vp) => namerRef.current?.offer(file, page, gen, tc, vp), []);
  const namerGen = useCallback((file) => namerRef.current?.gen(file), []);
  // saved numbers go wherever a file's bytes change or it leaves — namer or
  // not (a revision dropped in Classic layout); cloud projects save none
  const forgetNames = useCallback((names) => {
    if (!cloudMode) void forgetSheetNames({ del: metaDelete }, nameScope, names, (e) => console.warn("Couldn't clear saved sheet numbers:", e));
    else markSheetNamesStale(nameScope, names);
    for (const n of names) namerRef.current?.forget(n);
  }, [nameScope, cloudMode]);
  // a file whose bytes changed: the tabs' and pager's title-block numbers
  // name the old revision's sheets, so they go, and the active file's label
  // scan reads the new bytes (the render that follows a re-drop re-runs it)
  const labelGens = useMemo(() => createLabelGens(), []);
  const forgetLabels = useCallback((names) => {
    for (const n of names) {
      labelGens.bump(n); // a scan still reading the old bytes drops its writes
      setGalleryLabels((m) => withoutFileKeys(m, n));
      setLabelsByFile((m) => withoutFile(m, n));
      if (labeledFileRef.current === n) labeledFileRef.current = "";
    }
  }, [labelGens]);
  // Free a departing file's pdf.js worker doc — the doc cache keeps a few
  // idle ones (thumbnails + reopen speed), but a file that LEFT the working
  // set must go now, leased or not (#302).
  // Its search-index entries go too: the file's bytes are leaving or changing
  // (addPdf keys on the NAME, so a revision reuses every sheet key).
  const evictDoc = useCallback((name) => {
    docCache.evict(name);
    if (dropFileFromIndex(planIndexRef.current, name)) notifyIndex();
    // its OCR reads and statuses, memoized hash and text-layer flags go too
    // (a revision reuses the sheet keys; its bytes, and so its text, differ)
    pageReader.dropFile(name);
    store.forgetPdfHash?.(name);
    forgetTextLayer(name);
    // Invariant: whatever drops a file's index entries drops its thumbnail
    // records too (forgetPages does as well; a second forget is a no-op). A
    // record carries the page's text-layer flag, which seeds the index on
    // the next gallery open (planSearch seedFromThumb), so a revision must
    // never keep the old bytes' flag.
    forgetThumbs([name], thumbCacheRef.current);
    forgetNames([name]);
    forgetLabels([name]);
  }, [docCache, notifyIndex, pageReader, forgetTextLayer, forgetNames, forgetLabels]);
  // Reconcile the canvas after a PDF leaves the working set. For a non-empty
  // result the [sheets] effect already prunes openTabs/sheetGroup, but it can't:
  //   • fix `active` when the CLOSED pdf was the one on screen (it never resets
  //     itself), so move to a surviving sheet; and
  //   • prune anything when the set is now EMPTY — that effect early-returns on
  //     `!sheets.length` (it must, to protect restored tabs during load), so the
  //     last-pdf close would otherwise strand a tab pointing at a deleted file.
  const reconcileAfterRemoval = useCallback((name, list) => {
    if (!list.length) {
      setOpenTabs([]); setSheetGroup([]); setLastGroup([]); setActive(""); setPage(1);
      setView("gallery");
      return;
    }
    if (name === active) { setActive(list[0].name); setPage(1); setSheetGroup([]); }
  }, [active]);
  // Close a PDF: drop it from the working set (cloud: manifest only, file stays
  // in Drive; local: deletes the stored bytes), refresh, then reconcile the view.
  // Shapes on the closed sheets persist in annotations and restore on re-add.
  const closePdf = useCallback(async (name) => {
    await store.removePdf(name);
    evictDoc(name);
    forgetPages([name]);
    reconcileAfterRemoval(name, await refreshSheets());
  }, [refreshSheets, reconcileAfterRemoval, evictDoc, forgetPages]);
  // Bulk close (#301): one pass over the manage-mode selection, ONE refresh and
  // reconcile at the end. Per-file semantics are exactly closePdf's — shapes
  // persist in annotations and restore if the same file is re-added.
  const closePdfs = useCallback(async (names) => {
    if (!names.length) return;
    for (const n of names) { await store.removePdf(n); evictDoc(n); }
    forgetPages(names);
    const list = await refreshSheets();
    reconcileAfterRemoval(names.includes(active) ? active : "", list);
    setCommitMsg(uiText(`Removed ${names.length} PDF${names.length === 1 ? "" : "s"} from the plan set — takeoffs on them stay in the project and restore on re-add.`));
  }, [refreshSheets, reconcileAfterRemoval, evictDoc, forgetPages, active]);
  // Remove-from-project (cloud only): the DESTRUCTIVE variant — delete the Drive
  // file, then drop it from the working set.
  const removeFromProject = useCallback(async (name) => {
    if (typeof store.removeFromProject !== "function") return;
    await store.removeFromProject(name);
    // as closePdf: its pdf.js doc, index entries, OCR reads and statuses,
    // text-layer flags, page count and thumbnail records go with it
    evictDoc(name);
    forgetPages([name]);
    reconcileAfterRemoval(name, await refreshSheets());
  }, [refreshSheets, reconcileAfterRemoval, evictDoc, forgetPages]);
  // open dropped/picked files of any kind: PDFs, images, and .zip plan sets all
  // get turned into PDF sheets (in-browser) by ingestFiles, then stashed locally
  async function handleFiles(fileList) {
    const incoming = Array.from(fileList || []);
    if (!incoming.length) return;
    // a dropped .otk is a PROJECT, not a plan — it replaces the workspace
    // (snapshot first) instead of joining the plan set (#300)
    const otk = incoming.find((f) => isProjectArchive(f.name));
    if (otk) {
      await importProjectArchive(otk);
      if (incoming.length > 1) setCommitMsg((m) => `${m} Other dropped files were ignored — open plans separately from a project archive.`);
      return;
    }
    // a dropped .otprofile is the working ENVIRONMENT (#299) — apply it, never
    // ingest it as a plan
    const prof = incoming.find((f) => isProfileFile(f.name));
    if (prof) { await importProfileFile(prof); return; }
    setCommitMsg(uiText("Reading files…"));
    // the render workers boot while the files are read and stored (#580)
    try { getCompositor().prewarm(); } catch { /* no Worker here: the first sheet starts them */ }
    let pdfs = [], skipped = [];
    try { ({ pdfs, skipped } = await ingestFiles(incoming, { onProgress: setCommitMsg })); }
    catch (e) { setCommitMsg(uiText(`Couldn't read those files: ${e.message || e}`)); return; }
    if (!pdfs.length) {
      setCommitMsg(skipped.length
        ? `Nothing to open — ${skipped.length} file${skipped.length === 1 ? "" : "s"} skipped. OpenTakeoff reads PDFs, images, and .zip plan sets.`
        : "No supported files found. Drop a PDF, an image, or a .zip plan set.");
      return;
    }
    const results = [];
    for (const f of pdfs) {
      try {
        let fileToAdd = f;
        const matchingRots = Object.entries(sheetRotationsRef.current).filter(([k, r]) => {
          return parseSheetKey(k).file === f.name && r && r.angle > 0;
        });
        if (matchingRots.length > 0) {
          const incomingBytes = await f.arrayBuffer();
          const incomingHash = await sha256Hex(incomingBytes);
          // Only re-apply stored rotation when the re-added bytes are the original file (#591)
          if (incomingHash === matchingRots[0][1].hash) {
            let curBytes = new Uint8Array(incomingBytes);
            for (const [k, rot] of matchingRots) {
              const { page: pageNum } = parseSheetKey(k);
              curBytes = await rotatePdfPage(curBytes, pageNum, rot.angle);
            }
            fileToAdd = new File([curBytes], f.name, { type: "application/pdf" });
          }
        }
        results.push(await store.addPdf(fileToAdd));
      } catch (e) {
        setCommitMsg(uiText(`Couldn't open ${f.name}: ${e.message || e}`));
      }
    }
    // A re-added name's search entry, OCR reads and thumbnail records (whose
    // text-layer flag seeds the index) start over unless its bytes are known
    // to be the same (readdEffects); a cached read goes back into the
    // emptied slot once the canvas measures its sheets again (forgetTextLayer,
    // as evictDoc: the measure puts the entry in, and the readable-sheets
    // effect looks its read up under that entry's plan; a lookup with no
    // entry would be a whole-page one, planSearch mayLookUp).
    const readd = readdEffects(results.filter(Boolean), { cloud: cloudMode, loaded: (n) => docCache.wasLoaded(n) });
    for (const n of readd.reset) if (dropFileFromIndex(planIndexRef.current, n)) notifyIndex();
    for (const n of readd.reset) { pageReader.dropFile(n); forgetTextLayer(n); }
    forgetThumbs(readd.reset, thumbCacheRef.current);
    forgetNames(readd.reset);
    forgetLabels(readd.reset);
    await refreshSheets();
    // CO-1: a re-drop whose bytes CHANGED is a plan revision, not a re-open.
    // The store archived the old bytes; here the stale pdf.js docs must go
    // (docFor caches by name) and the render effect must re-key so the new
    // revision actually reaches the screen. A cloud re-add may have changed
    // the bytes too, and says nothing: a document opened since its last
    // evict goes the same way, even one trimmed since (wasLoaded).
    const revised = results.filter((r) => r?.revised);
    if (readd.evict.length) {
      for (const n of readd.evict) evictDoc(n);
      // a revision can change the page count — drop the cached counts so the
      // gallery re-learns them from the new bytes (#302)
      forgetPages(readd.evict);
      setDocEpoch((e) => e + 1);
    }
    const names = pdfs.map((f) => f.name);
    const tail = skipped.length ? ` · ${skipped.length} skipped` : "";
    if (names.length === 1) {
      setOpenTabs((t) => (t.includes(names[0]) ? t : [...t, names[0]]));
      goToSheet(names[0]);
      setView("canvas");
    } else {
      setView("gallery");   // a plan set → land in the gallery to pick sheets
    }
    if (revised.length) {
      // "changed under your markups" only when ink actually rides that file —
      // any page of it (sheet_id is `name` for page 1, `name#page` beyond)
      const inked = (n) => shapes.some((s) => s.sheet_id === n || s.sheet_id.startsWith(n + "#"))
        || markups.some((m) => m.sheet_id === n || m.sheet_id.startsWith(n + "#"));
      const hot = revised.filter((r) => inked(r.name));
      const label = (r) => `${r.name} → rev ${r.rev}`;
      setCommitMsg(hot.length
        ? `Sheet changed under your markups: ${hot.map(label).join(", ")} — earlier revision kept; re-check the affected takeoff.`
        : `Sheet updated: ${revised.map(label).join(", ")} — earlier revision kept.`);
    } else {
      setCommitMsg(uiText(`Opened ${names.length} sheet${names.length === 1 ? "" : "s"}${tail}.`));
    }
  }
  // The empty-project landing view (the Drive picker for an empty cloud project,
  // else the gallery) depends on BOTH the sheet list and the annotations (open
  // tabs), which load in two racing mount effects. These flags let whichever
  // finishes LAST make the call exactly once — so the picker never flashes for a
  // project that actually has sheets, and no redundant Drive listing fires.
  const hasSheetsRef = useRef(false);
  const sheetsLoadedRef = useRef(false);
  const noTabsRef = useRef(false);
  useEffect(() => {
    let off = false;
    setStatus("loading");
    store.listSheets()
      .then((list) => {
        if (off) return;
        hasSheetsRef.current = list.length > 0;
        sheetsLoadedRef.current = true;
        setSheets(list);
        if (list.length) setActive(list[0].name);
        else setStatus("empty");
        // decide the landing only once the annotations effect has also reported
        // no open tabs (see hydrate) — avoids a picker→gallery flash + wasted list
        if (noTabsRef.current) setView(cloudMode && !hasSheetsRef.current ? "picker" : "gallery");
      })
      .catch((e) => !off && (setErr(String(e.message || e)), setStatus("error")));
    return () => { off = true; };
  }, [cloudMode]);
  // Keep hasSheetsRef current so a later re-hydration (a revision Restore after the
  // working set changed) reads the LIVE sheet count, not the mount-time value.
  // The mount sheets effect above also sets it synchronously for the initial
  // landing decision (before this post-render effect runs).
  useEffect(() => { hasSheetsRef.current = sheets.length > 0; }, [sheets]);

  // ── load saved annotations once per project ───────────────────────────────
  // hydrate applies a saved payload to state — shared by the mount load and by
  // Restore in the Revisions panel, so a restored revision walks the same
  // defensive path as a page reload.
  const hydrate = (a) => {
    // Same cross-load-transient gap as the panel epoch bump below: a revision
    // Restore runs in-place with the same sheet keys, so a surviving zoneCheck
    // would immediately re-classify the RESTORED shape set against the
    // pre-load polygon — "correct" math against the wrong region. Reset it
    // unconditionally, mirroring the sheet_group/sheet_levels else-clear rule.
    resetZone();
    // agent proposals are ephemeral review state aimed at the PRE-load
    // conditions/sheets — a loaded/restored timeline starts with none pending
    // (nothing is lost: rejected geometry records nothing by design).
    setAgentProposals([]);
    // same rule for the correction-rule review state (#88): an offer/staged
    // batch aimed at pre-load shapes must not survive the load. The RULES
    // themselves are project data and hydrate below.
    setRuleOffer(null); setRuleStage(null);
    setRules(Array.isArray(a.rules) ? a.rules : []);   // additive — old saves without rules load as []
    setProjectName(a.project_name || "");
    // string fields only — a corrupted record must not put an object where
    // the report masthead renders a React child
    setClientInfo(Object.fromEntries(Object.entries(
      a.client_info && typeof a.client_info === "object" && !Array.isArray(a.client_info) ? a.client_info : {}
    ).filter(([, v]) => typeof v === "string")));
    setEstimateSettings(a.estimate_settings && typeof a.estimate_settings === "object" ? sanitizeEstimateSettings(a.estimate_settings) : null);   // unconditional set: a loaded project never inherits the replaced one's markups
    setBidProposal(a.bid_proposal && typeof a.bid_proposal === "object" ? sanitizeBidProposal(a.bid_proposal) : null);   // same unconditional-set rule
    setConditionColumns(sanitizeConditionColumns(a.condition_columns));   // non-array/malformed → [] (unconditional set: snapshot load must not inherit pre-load columns)
    setShapeLabels(sanitizeShapeLabels(a.shape_labels));   // same unconditional-set rule: a snapshot load must not inherit the replaced project's label vocabulary
    setActiveLabel(null);   // active label is session-only — never carry one from the replaced project into a fresh/loaded one
    // multipliers get the same load-time trust pass (#455): a project saved before
    // import refused bad values can still carry a 0 / negative / string — repair it
    // to what it already billed at and say so, rather than let NaN reach the report
    const { conditions: conds, repaired: multRepaired } = repairConditionMultipliers(sanitizeConditionAttrs(a.conditions || []));   // strips corrupt attrs values so every reader can trust them (the client_info precedent)
    if (multRepaired.length) setCommitMsg(describeMultiplierRepair(multRepaired));
    if (conds.length) { setConditions(conds); setActiveCond(conds[0].id); }
    else { const seeded = seedConditions(templatesRef.current); setConditions(seeded); setActiveCond(seeded[0].id); }   // library templates first, flooring defaults as fallback
    // palette holds condition ids — de-dupe (a hand-edited/older payload could
    // repeat one, which would collide React keys and double-map a hotkey), drop
    // any that don't resolve in the loaded set, and cap defensively; a seeded
    // fresh workspace starts with an empty palette
    setPalette(Array.isArray(a.palette) && conds.length ? [...new Set(a.palette)].filter((id) => conds.some((c) => c.id === id)).slice(0, PALETTE_MAX) : []);
    // panel transients reset with the conditions they described — a snapshot
    // Load must not keep a checked set / range anchor / filter / collapsed
    // groups aimed at the PRE-load list (bulk edits would misfire on ids that
    // happen to survive). That state lives in the TakeoffsPanel now: bump its
    // epoch and it clears them in place (panel tab + width survive, as they
    // always did). On the mount load this is a no-op (fresh panel state).
    setPanelEpoch((e) => e + 1);
    // hidden conditions (#440) described the replaced project's view — a load
    // always opens with everything showing
    setHiddenConds((h) => (h.size ? new Set() : h));
    // `replace` command + reset: hydrate is a whole-array non-edit (no stamps,
    // no counters) and a loaded/restored timeline starts with EMPTY undo/redo
    // stacks — recorded inverses from the replaced project must never fire here.
    dispatchShape({ type: "replace", shapes: sanitizeShapeLabelsOnShapes((a.shapes || []).map(normalizeAgentReview)) }, { reset: true });   // normalize legacy review flags and corrupt labels at the load boundary
    // normalize hydrated markups: legacy workspaces may hold markups with no id
    // (pre-dating the id field) — seed a stable id + default rfi_id so the new
    // select / edit / delete / move / RFI-link flows (all keyed on m.id) work on them.
    setMarkups(Array.isArray(a.markups) ? a.markups.map((m) => ({ ...m, id: m.id || uid("mk"), rfi_id: m.rfi_id || "", condition_id: m.condition_id || "" })) : []);
    setApprovals(sanitizeApprovals(a.approvals));   // additive — old saves load as []; load-gated so one corrupt seal can't wedge the render loop
    setRfis(Array.isArray(a.rfis) ? a.rfis : []);   // additive — old saves without rfis load as []
    setProposals(Array.isArray(a.proposals) ? a.proposals.filter((p) => p && typeof p.id === "string") : []);   // additive (#365)
    setConditionEditProposals(Array.isArray(a.condition_edit_proposals) ? a.condition_edit_proposals.filter((p) => p && typeof p.id === "string" && p.proposed && typeof p.proposed === "object") : []);
    // additive provenance_counters — unconditional set (the else-clear rule: a
    // snapshot load must not inherit the replaced project's deletion tallies).
    // Object gate mirrors client_info; number filter keeps the counts trustable.
    const pcIn = a.provenance_counters?.shapes_deleted;
    setProvCounters({
      shapes_deleted: Object.fromEntries(Object.entries(
        pcIn && typeof pcIn === "object" && !Array.isArray(pcIn) ? pcIn : {}
      ).filter(([, v]) => Number.isFinite(v) && v > 0))
    });
    // additive `sheet_levels` key (multi-floor gallery grouping) — old payloads
    // lack it and must clear any pre-load levels (the sheet_group else-clear
    // rule: a snapshot load must not inherit the replaced project's levels).
    // String labels only, mirroring the client_info string-fields gate.
    // Extracted to sanitizeSheetLevels (lib/sheetLevels.js) so this gate has
    // its own unit tests independent of the reducer.
    setSheetLevels(sanitizeSheetLevels(a.sheet_levels));
    // additive `layer_overrides` (#85 — per-sheet PDF-layer Wall/Off overrides
    // for the One-Click mask): same else-clear + shape gate as sheet_levels.
    // Masks are a lazy per-sheet cache — drop them so a loaded snapshot's
    // overrides govern the next flood, not the replaced project's.
    const lov = sanitizeLayerOverrides(a.layer_overrides);
    layerOverridesRef.current = lov;
    setLayerOverrides(lov);
    maskCacheRef.current.clear();
    // additive `stitches` (#161) — sanitize-gated like approvals; else-clear so a
    // snapshot load can't inherit the replaced project's composites. Sanitized
    // BEFORE group normalization: a solo stitch key in sheet_group is only a
    // legitimate group of one while its stitch actually exists.
    const loadedStitches = sanitizeStitches(a.stitches, MAX_GROUP);
    setStitches(loadedStitches);
    // additive `door_answers`: string answers only; else-clear like stitches
    setDoorAnswers(a.door_answers && typeof a.door_answers === "object" && !Array.isArray(a.door_answers)
      ? Object.fromEntries(Object.entries(a.door_answers).filter(([k, v]) => typeof k === "string" && typeof v === "string").slice(0, 5000)) : {});
    setAlignPt(null);
    // else-clear matters at runtime (snapshot load): a payload without groups/
    // tabs must not inherit the pre-load ones — autosave would persist a hybrid.
    // In group mode sheetGroup + lastGroup share ONE instance so the lastGroup-sync
    // effect below is a reference-equal no-op — otherwise its follow-up commit would
    // escape the one-shot save suppression and spuriously re-save (see normalizeLoadedGroups).
    const { sheetGroup: grp, lastGroup: lgFinal } = normalizeLoadedGroups(a, MAX_GROUP,
      (k) => loadedStitches.some((s) => s.id === k));
    setSheetGroup(grp);
    setLastGroup(lgFinal);
    // additive `split_view` (read-only reference pane) — same else-clear rule
    // as sheet_group/sheet_tabs: a payload without the key must not inherit
    // the replaced project's split. normalizeSplitView(undefined) → null.
    setSplitView(normalizeSplitView(a.split_view));
    // gallery-first: tabs restore directly; legacy pinned pages migrate once
    // (over in the sheets effect, where file names are known); nothing open → gallery
    const tabs = Array.isArray(a.sheet_tabs) ? a.sheet_tabs : [];
    noTabsRef.current = false;   // accurate on every (re)hydrate; the no-tabs branch flips it true
    if (tabs.length) setOpenTabs(tabs);
    else if (Array.isArray(a.pinned) && a.pinned.length) legacyPinnedRef.current = a.pinned;
    // no tabs → the sheet chooser. Defer the picker-vs-gallery choice until the
    // sheets effect has loaded the working set (coordinated via the refs) so an
    // empty cloud project lands on the Drive picker without flashing the gallery.
    else {
      setOpenTabs([]);
      noTabsRef.current = true;
      if (sheetsLoadedRef.current) setView(cloudMode && !hasSheetsRef.current ? "picker" : "gallery");
    }
    const sc = {};
    const src = {};
    const unconf = {};
    for (const s of a.sheets || []) if (s.sheet_id && s.units_per_px) {
      sc[s.sheet_id] = s.units_per_px;
      // provenance is additive — old projects lack it (report shows "unknown").
      // Any non-empty string passes through, not just today's known values: a
      // whitelist would silently strip a future value on load and the next
      // autosave would persist the loss. Display already falls back safely.
      if (typeof s.scale_source === "string" && s.scale_source) src[s.sheet_id] = s.scale_source;
      if (s.scale_confirmed === false) unconf[s.sheet_id] = false;   // scale gate: agent-set, awaiting a human
    }
    setScales(sc);
    setScaleSources(src);
    setScaleUnconfirmed(unconf);
    // display units ride the payload (additive) — a metric project opens metric
    // on any machine; payloads without the field keep this browser's toggle
    if (a.units === "metric" || a.units === "imperial") setUnits(language === "ru" ? "metric" : a.units);
  };
  useEffect(() => {
    let off = false;
    // templates load BEFORE annotations: hydrate's fresh-workspace seeding
    // reads templatesRef, so the library must be in hand first
    store.loadTemplates().catch(() => []).then((tpl) => {
      if (!off) { templatesRef.current = tpl; setTemplates(tpl); }
      return store.loadMaterialLibrary().catch(() => []);
    }).then((ml) => {
      if (!off) setMatLib(ml);
      return store.loadAnnotations();
    }).then((a) => {
      if (off) return;
      hydrate(a);
      hydrated.current = true;
    }).catch((e) => {
      // stale-tab failure: leave autosave DISARMED (hydrated stays false). If a
      // blocked tab recovered here with hydrated=true, its still-empty defaults
      // would autosave straight over the other tab's real data. The reload
      // message is the whole story for this tab.
      if (isStaleTabError(e)) { setCommitMsg(STALE_TAB_MESSAGE); return; }
      // Cloud project whose saved takeoff couldn't be read (Drive error / unreadable
      // annotations): same rule as a stale tab — leave autosave DISARMED so empty
      // defaults can't overwrite the real project in Drive. (cloudStore tags these.)
      if (e?.name === "CloudLoadError") { setCommitMsg(e.message || "Couldn't load this project from Drive — reload to retry."); return; }
      // Do NOT arm autosave on any other failed load either: the in-memory
      // state is empty, so the first edit would overwrite the intact saved
      // takeoff with nothing. Leave it disarmed (hydrated stays false) and say
      // so in a banner — a reload retries the read.
      setLoadError(String((e && e.message) || e || "unknown error"));
    });
    return () => { off = true; };
    // run-once mount load — hydrate is intentionally not a dep (re-running would
    // re-hydrate over live edits); the cloudMode/ref it now reads are stable.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Stamp library — independent of hydrate (it seeds no project state), so it
  // loads on its own. A truly empty library gets the flooring defaults, then
  // persists them once so the seeded set is exportable and survives reloads
  // (the seedConditions precedent, but written back because the library is the
  // asset itself, not a per-project derivation). Re-read on tab focus like the
  // other browser-global records.
  useEffect(() => {
    let off = false;
    store.loadStampLibrary().catch(() => ({ stamps: [], sets: [] })).then((raw) => {
      if (off) return;
      const seeded = seedStampLibrary(raw);
      const wasEmpty = !(raw?.stamps || []).length;
      stampLibRef.current = seeded; setStampLib(seeded);
      if (wasEmpty && seeded.stamps.length) store.saveStampLibrary(seeded).catch(() => { /* seed persists on next edit */ });
    });
    const onVis = () => {
      if (document.visibilityState !== "visible") return;
      store.loadStampLibrary().then((lib) => {
        if (JSON.stringify(lib) === JSON.stringify(stampLibRef.current)) return;
        // another tab edited the library — adopt it, INCLUDING an intentional
        // delete-all (an empty library must propagate, not leave stale stamps).
        // The store is shared per-origin, so a persisted empty is a real edit; the
        // first-mount seed self-heals any transient pre-save empty on next focus.
        stampLibRef.current = lib; setStampLib(lib);
        // a cross-tab edit may have removed the armed stamp — don't keep a dangling ref
        setArmedStamp((a) => (a && lib.stamps.some((s) => s.id === a.id) ? a : null));
      }).catch(() => { /* keep what we have */ });
    };
    document.addEventListener("visibilitychange", onVis);
    return () => { off = true; document.removeEventListener("visibilitychange", onVis); };
  }, []);

  // library freshness: BOTH browser-global records — the condition template
  // library AND the material library (each sanitized at load, same as the
  // mount effect above) — may have been edited by another tab since our mount
  // load; re-read each on tab focus. Safe to swap in wholesale because every
  // library mutation persists immediately (nothing unsaved lives only in this
  // tab's state). Skip the setState when the freshly loaded list is
  // byte-identical to what we're already holding (a cheap JSON signature
  // compare) — TakeoffsPanel is memoized on these arrays' identity, and an
  // unconditional set would defeat that memo on every tab focus even when
  // nothing actually changed. This NARROWS the multi-tab last-write-wins
  // window on both records; it doesn't close it.
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState !== "visible") return;
      store.loadTemplates().then((tpl) => {
        if (JSON.stringify(tpl) === JSON.stringify(templatesRef.current)) return;
        templatesRef.current = tpl; setTemplates(tpl);
      }).catch(() => { /* keep what we have */ });
      store.loadMaterialLibrary().then((ml) => {
        setMatLib((cur) => (JSON.stringify(ml) === JSON.stringify(cur) ? cur : ml));
      }).catch(() => { /* keep what we have */ });
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  // leaving the stamp tool disarms the pending stamp — a stray click under a
  // measure/select tool must never drop a stamp
  useEffect(() => { if (tool !== "stamp") setArmedStamp(null); }, [tool]);
  useEffect(() => { if (tool !== "image" && tool !== "pin") setImageAnchor(null); }, [tool]);   // leaving the image marquee drops a half-set anchor (mirrors scheduleAnchor/symbolAnchor reset)
  useEffect(() => { if (tool !== "textcopy") setTextAnchor(null); }, [tool]);   // same for the Copy text marquee; the receipt outlives the tool (the second click returns to Select)
  // Copy text armed: read the visible pages' text ahead, on arming and on every
  // sheet switch while armed, so a box or Copy page text copies inside its click
  useEffect(() => {
    if (tool !== "textcopy" || status !== "ready") return;
    for (const k of groupKeys) prefetchText(k);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool, groupSig, status]);
  // A One-Click proposal is only actionable while One-Click is armed (Enter
  // already requires it) — discard it on tool switch, like the stamp above.
  // Also keeps Create out of the ACTION slot while Finish occupies it, so the
  // slot's reserved width always fits its content (issue #61).
  useEffect(() => { if (tool !== "oneclick") setProposal(null); }, [tool]);
  useEffect(() => { if (tool !== "stitch-align") setAlignPt(null); }, [tool]);   // leaving the align gesture drops its half-set match point
  // Proposal gone (created, discarded, sheet changed) ⇒ drop any handle selection/hover.
  useEffect(() => { if (!proposal) { setOcSel(null); ocHoverRef.current = -1; setOcHover(-1); } }, [proposal]);
  // selection/tool changed under a parked cursor ⇒ the edge-insert ghost's
  // promise is stale — hide it until the next pointer move re-earns it.
  useEffect(() => { if (insGhostRef.current) insGhostRef.current.style.display = "none"; }, [selectedId, tool]);
  // Switching to a different shape (or clearing the selection) drops the vertex pick.
  useEffect(() => { setSelVert(null); }, [selectedId]);

  // remember every live composition so Regroup works after ANY exit from group
  // mode (Ungroup button, tab click, gallery View) — not just the last Ungroup
  useEffect(() => { if (sheetGroup.length >= 2) setLastGroup(sheetGroup); }, [sheetGroup]);

  // a persisted group may reference a since-deleted file — drop those keys; a
  // group of one collapses back to single-sheet mode. A stitch key is live
  // while its stitch exists and every member's file survives (#161), and a
  // solo stitch is a legitimate group of one.
  useEffect(() => {
    if (!sheets.length) return;
    const names = new Set(sheets.map((s) => s.name));
    const keyLive = (k) => (isStitchKey(k)
      ? !!stitchById[k] && stitchAlive(stitchById[k], names)
      : names.has(parseSheetKey(k).file));
    const liveKeys = (g) => {
      const f = g.filter(keyLive);
      return f.length === g.length ? g : (f.length >= 2 || (f.length === 1 && isStitchKey(f[0])) ? f : []);
    };
    setSheetGroup(liveKeys);
    setLastGroup(liveKeys);
    // one-shot migration: legacy `pinned` page numbers were relative to the
    // load-time active file (sheets[0]) — they become tabs, then never resurrect
    if (legacyPinnedRef.current) {
      const file = sheets[0].name;
      const tabs = legacyPinnedRef.current.map((n) => (n > 1 ? `${file}#${n}` : file));
      legacyPinnedRef.current = null;
      setOpenTabs((t) => (t.length ? t : tabs));
    }
    setOpenTabs((t) => { const f = t.filter(keyLive); return f.length === t.length ? t : f; });
    // Task 8: a split's reference set is subject to the same liveness rule —
    // a member pointing at a since-deleted FILE (whole-file removal via
    // Manage, not a single closed tab — closeTab's own pruning above already
    // handles that narrower, more common case) must be dropped, and if the
    // framed refKey itself didn't survive, reframe to another live member or
    // auto-collapse the whole split if none remain (the same dangling-chip
    // dead end closeTab's pruning guards against, generalized to "the file
    // is gone entirely" rather than "this one tab was closed").
    setSplitView((s) => {
      if (!s) return s;
      const rawSet = s.refSet?.length ? s.refSet : [s.refKey];
      const set = rawSet.filter(keyLive);
      if (set.length === rawSet.length) return s;
      if (!set.length) return null;
      const refKey = keyLive(s.refKey) ? s.refKey : set[0];
      return { ...s, refSet: set, refKey };
    });
    // stitchById joins the deps: a stitch created/deleted this session must
    // re-run the same liveness pass its members' files do.
  }, [sheets, stitchById]);

  // land on the first restored tab (the sheet-list effect defaults to sheets[0])
  useEffect(() => {
    if (tabInitRef.current || !openTabs.length || !sheets.length || sheetGroup.length) return;
    tabInitRef.current = true;
    goToSheet(openTabs[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openTabs, sheets]);
  // keep the active tab visible in the scrolling strip (no-op while the row wraps)
  useEffect(() => {
    const strip = tabStripRef.current; if (!strip || openTabs.length <= MANY_TABS) return;
    const el = strip.querySelector('[data-sheet-tab="active"]');
    if (el && typeof el.scrollIntoView === "function") el.scrollIntoView({ block: "nearest", inline: "nearest" });
  }, [sheetKey, sheetGroup, openTabs.length]);

  useEffect(() => { statusRef.current = status; }, [status]);
  useEffect(() => { viewRef.current = view; }, [view]);
  useEffect(() => { toolRef.current = tool; }, [tool]);
  useEffect(() => { proposalRef.current = proposal; }, [proposal]);
  // Tab hidden ⇒ the voice-deixis aim dies: on return the tracked position
  // predates the refocus (rAF suspended, the pointer may be anywhere), so
  // "this room" must wait for a fresh move — the stale-aim bar (RFC #59).
  useEffect(() => {
    const onVis = () => { if (document.visibilityState === "hidden") voiceAimMarkRef.current = aimSeqRef.current; };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  // Bytes come from the store; pdf.js needs them up front (docCache above).
  // Only for a file the canvas pins (on screen, or a tab): anything else
  // leases it (docCache.withDoc, withSheetPage).
  const docFor = useCallback((file) => docCache.doc(file), [docCache]);
  // ── 3D view (components/View3D.jsx, lazy) — one sheet, feet-true, read-only ───────────
  // The page raster is rendered once per open as the ground underlay (≤ 4096 px long side), off
  // the canvas's own render path; the "level above" is another open sheet stacked at the stair's top.
  const [show3d, setShow3d] = useState(null);          // { sheetId } while the 3D view is open
  const [planSkin3d, setPlanSkin3d] = useState(null);
  const [upperSheet3d, setUpperSheet3d] = useState(null);
  const [upperSkin3d, setUpperSkin3d] = useState(null);
  const open3d = () => {
    if (show3d) { setShow3d(null); return; }
    const key = focusPanel?.key;
    if (!key || isStitchKey(key)) { setCommitMsg("3D shows one sheet at a time — open a single sheet."); return; }
    if (!uppFor(key)) { setCommitMsg("Set the sheet scale first — 3D is feet-true or nothing."); return; }
    if (!focusPanel.img?.w) { setCommitMsg("The sheet is still loading — try 3D again in a moment."); return; }
    setShow3d({ sheetId: key, dims: { w: focusPanel.img.w, h: focusPanel.img.h } });
  };
  const rasterSheet3d = useCallback(async (key) => {
    const { file, page } = parseSheetKey(key);
    const pdf = await docFor(file);
    const pg = await pdf.getPage(Math.min(Math.max(1, page || 1), pdf.numPages || 1));
    const vp0 = pg.getViewport({ scale: 1 });
    const k = Math.min(4096 / Math.max(vp0.width, vp0.height), 4);
    const vp = pg.getViewport({ scale: k });
    const cv = document.createElement("canvas");
    cv.width = Math.ceil(vp.width); cv.height = Math.ceil(vp.height);
    await pg.render({ canvasContext: cv.getContext("2d"), viewport: vp, background: "#ffffff" }).promise;
    return cv;
  }, [docFor]);
  useEffect(() => {
    if (!show3d) { setPlanSkin3d(null); return undefined; }
    let dead = false;
    rasterSheet3d(show3d.sheetId).then((cv) => { if (!dead) setPlanSkin3d({ canvas: cv, sheetId: show3d.sheetId }); }).catch(() => { /* no underlay — the 3D view still draws */ });
    return () => { dead = true; };
  }, [show3d, rasterSheet3d]);
  useEffect(() => {
    if (!show3d || !upperSheet3d) { setUpperSkin3d(null); return undefined; }
    let dead = false;
    rasterSheet3d(upperSheet3d).then((cv) => { if (!dead) setUpperSkin3d({ canvas: cv, sheetId: upperSheet3d }); }).catch(() => { /* no stacked level */ });
    return () => { dead = true; };
  }, [show3d, upperSheet3d, rasterSheet3d]);
  // A rendered sheet's page, its file held until release: a one-off that
  // awaits can outlive a switch away, after which nothing pins that file.
  // No page (not rendered, or a stitch): nothing held.
  function holdSheetPage(key) {
    const page = pageObjsRef.current.get(key);
    // only a page whose file is still cached: a lease on a file a forced
    // evict just dropped (removed or revised) would load it afresh before
    // the canvas re-renders
    const { file } = parseSheetKey(key);
    return { page, release: page && docCache.has(file) ? docCache.lease(file) : () => { } };
  }
  async function withSheetPage(key, fn) {
    const { page, release } = holdSheetPage(key);
    try { return await fn(page); } finally { release(); }
  }

  // ── on-device page reads (#471) ─────────────────────────────────────────
  // Read one sheet, by key, whether or not it's on screen: its page from the
  // file's cached doc (sheetSource: the page and the hash its read is stored
  // under come from one document, leased until the read settles), the page
  // released after unless the canvas holds it. A sheet already being read
  // joins that read. What it reads is the plan from the sheet's index entry
  // (planSearch readPlanOf: a scan whole, a hybrid's pictures, #489); a sheet
  // not indexed yet is read whole, as before.
  const readSheet = useCallback((key, { force = false, signal } = {}) => {
    const { file, page } = parseSheetKey(key);
    const hooks = readHooks(sheetSource, file, page);
    return pageReader.read({
      key, file, page, rs: RENDER_SCALE, force, signal, plan: readPlanOf(planIndexRef.current.get(key), RENDER_SCALE),
      pdfHash: hooks.pdfHash, getPage: hooks.getPage, pageHash: hooks.pageHash,
    }).then((r) => {
      const opened = hooks.opened();
      if (opened && pageObjsRef.current.get(key) !== opened) { try { opened.cleanup(); } catch { /* already released */ } }
      if (!r.ok && (r.status === "disabled" || r.status === "uninstalled")) setOcrAvail(r.status);
      return r;
    }).finally(hooks.release);
  }, [sheetSource, pageReader]);
  // A sheet's cached read, if any, into the index (no page, no notice).
  // { known: true }: only a hash already in hand (the gallery's background
  // lookups: a cloud project downloads nothing). Under the same plan as a
  // read, so a hybrid finds only its pictures read; none for a sheet whose
  // entry plans no read (planSearch mayLookUp: the reader would remember the
  // miss).
  const lookupSheet = useCallback((key, opts) => {
    const { file, page } = parseSheetKey(key);
    const ix = planIndexRef.current.get(key);
    if (!mayLookUp(ix)) return Promise.resolve(null);
    return pageReader.lookup({ key, file, page, rs: RENDER_SCALE, plan: readPlanOf(ix, RENDER_SCALE), ...lookupHooks(sheetSource, file) }, opts);
  }, [sheetSource, pageReader]);
  // The probe, asked once (lib/ocr/session availability) and kept in state
  // for the Read controls; disabled / uninstalled hide them.
  const ocrAvailability = useCallback(() => ocrSession.availability().then((a) => { setOcrAvail(a.state); return a; }), [ocrSession]);
  // Everything the gallery needs for its Read and its indexing walk:
  //   enabled            VITE_OCR isn't off (else don't ask anything)
  //   availability()     the probe (cached); resolves OcrProbe
  //   read(key, {force, signal})  → Promise<PageReadResult>, never rejects;
  //                      a finished read is already in the index
  //   cancel(key)        Stopping… until the read settles
  //   status(key)        PageReadStatus | undefined
  //   subscribe(fn)      status changes; returns the unsubscribe
  //   lookup(key, {known})  the cached read into the index, or null (no
  //                      read); known: never fetch a file for the hash
  const ocrApi = useMemo(() => ({
    enabled: ocrEnabled(),
    availability: ocrAvailability,
    read: readSheet,
    cancel: (key) => pageReader.cancel(key),
    status: (key) => pageReader.status(key),
    subscribe: pageReader.subscribe,
    lookup: lookupSheet,
  }), [ocrAvailability, readSheet, lookupSheet, pageReader]);
  // Scans and hybrids on screen (readableByKey): the first one shown asks the
  // probe (lazily, never at load), and each one's cached read, if any, goes
  // into the index silently, so search works after a reload without a new
  // read. Stitch panels aren't pages; their members aren't offered a read.
  // It runs again on status changes too (lookup is memoized per sheet). A
  // file dropped from the index (re-added, removed) loses its rows until its
  // sheets are measured again; the row coming back looks its read up again
  // under the new entry's plan.
  const readableShown = ocrEnabled() ? groupKeys.filter((k) => !isStitchKey(k) && !!readableByKey[k]) : [];
  const readableSig = readableShown.join("\n");
  useEffect(() => {
    if (!readableShown.length) return;
    ocrAvailability().catch(() => { });
    for (const k of readableShown) lookupSheet(k);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- readableSig stands for readableShown
  }, [readableSig, readTick, ocrAvailability, lookupSheet]);

  // ── reference pane: resolve refKey → dims, open + base-paint it (Task 3) ───
  // Independent of the group render effect below: the referenced sheet may not
  // be (and usually isn't) a member of the primary group. Runs the same
  // doc→page→viewport resolution resolveSource does, but never clamps an
  // out-of-range page — a dangling refKey must show the empty state, never a
  // silently-substituted page (see effectiveRefKey above).
  //
  // Keyed on groupSig too: the group effect's resetAll() wipes EVERY
  // compositor entry (base+detail, this pane's `ref::`-prefixed one included)
  // on every primary sheet/group change, so this must re-open+repaint in step
  // or a primary tab switch would silently blank an active reference pane.
  // resetAll() runs synchronously in that effect's body; this effect's actual
  // openSheet call only ever lands after an await, so it always lands after
  // resetAll() regardless of hook declaration order.
  useEffect(() => {
    // Task 8: viewport/memory disable. A splitView the device can't (or
    // isn't overridden to) mount costs nothing beyond the state itself —
    // treat refKey as null exactly like "no split," so this never opens a
    // compositor entry or paints tiles for a pane that isn't on screen.
    // splitMounted flipping true (viewport widened, or the "Restore split"
    // override) re-fires this effect (see the dep array below) and resolves
    // for real at that point.
    const refKey = splitMounted ? rawRefKey : null;
    // Only clear the CURRENT dims/paint state when refKey itself changed —
    // a groupSig-only resync (the primary's resetAll() case, same refKey)
    // must reopen+repaint the compositor entry WITHOUT wiping refPanelImg,
    // or ReferencePane's fit-to-view effect (keyed on panelImg's identity)
    // would re-fit and silently undo the user's own pan/zoom on this pane
    // every time they switch the primary's sheet.
    const sameKey = refKey && refDimsRef.current?.key === refKey;
    if (!sameKey) {
      setRefPanelImg(null); refDimsRef.current = null;
      // Collapse (splitView→null ⇒ refKey→null) OR a SWAP (tab-bar chip
      // click reframes A→B, Task 7): either way the sheet this pane was
      // just showing is no longer current, so cancel any in-flight
      // reference-detail compositor work for it and clear its dedup key —
      // the same shape as the resetAll() and visibilitychange clears below.
      // Without this, a swap's brand-new refKey lands (rawRefKey/
      // effectiveRefKey update immediately) well before this effect's own
      // async doc/page resolution below completes, so ReferencePane's
      // structural detail-repaint effect fires FIRST against the new key
      // while `refDimsRef.current` is still null — paintReferenceDetail's
      // own dims guard short-circuits that call before it ever reaches the
      // cancel-then-replace logic, leaving the OLD sheet's in-flight
      // request to complete (or fail) unattended instead of being
      // superseded the moment the user moved on. The panelImg reset just
      // above (setRefPanelImg(null)) already forces a fresh fit-to-view
      // (and therefore a fresh renderKey) on the next reopen in the common
      // case, but that path depends on ReferencePane's own effect ordering;
      // this clear makes the parent's OWN bookkeeping correct independent
      // of that, matches the other two sites exactly, and stops a
      // genuinely in-flight compositor request from completing against a
      // canvas this pane has since repurposed for a different sheet (or,
      // on collapse, unmounted).
      try { refDetailCancelRef.current?.cancel(); } catch { /* done */ }
      refDetailCancelRef.current = null;
      refDetailKeyRef.current = null;
    }
    if (!refKey) return;
    if (isStitchKey(refKey)) { setRefInvalid(refKey); return; }
    let cancelled = false;
    (async () => {
      try {
        const { file, page: pn } = parseSheetKey(refKey);
        const pdf = await docFor(file);
        if (cancelled) return;
        if (pn < 1 || pn > (pdf.numPages || 1)) throw new Error("page out of range");
        const pageObj = await pdf.getPage(pn);
        if (cancelled) return;
        const viewport = pageObj.getViewport({ scale: RENDER_SCALE });
        const w = Math.ceil(viewport.width), h = Math.ceil(viewport.height);
        getCompositor().openSheet(`ref::${refKey}`, pn, pdfSourceOf(file), w, h);
        refDimsRef.current = { key: refKey, w, h };
        // preserve object identity when dims didn't actually change (the
        // common groupSig-resync case) — see the sameKey comment above
        setRefPanelImg((prev) => (prev && prev.w === w && prev.h === h ? prev : { w, h }));
        setRefInvalid((prev) => (prev === refKey ? null : prev));
        setRefEpoch((e) => e + 1);
      } catch {
        if (cancelled) return;
        refDimsRef.current = null;
        setRefPanelImg(null);
        setRefInvalid(refKey);
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- docFor/getCompositor are stable; groupSig is the resetAll()-invalidation signal, same idiom as the group effect below
  }, [rawRefKey, groupSig, splitMounted]);

  // Dangling-single-chip dead end (Task 8, carried from Task 7's flagged
  // gap): the effect above marks `refInvalid` the instant a FRAMED refKey
  // that IS a live open tab still fails to resolve — an out-of-range page
  // (the file was replaced with fewer pages), a stitch key, or any other
  // async-resolution failure that isn't "the tab got closed" (closeTab's own
  // pruning above already handles that) or "the whole file is gone"
  // (the keyLive reconciliation above already handles that). If another
  // refSet member is still a live open tab, reframe to it and drop the
  // dangling one; if none remain, there's nothing left this pane can show —
  // auto-collapse rather than leaving the tab bar's sole chip stuck over a
  // permanent "Drop a sheet here" empty state.
  useEffect(() => {
    if (!rawRefKey || refInvalid !== rawRefKey) return;
    setSplitView((s) => {
      if (!s || s.refKey !== rawRefKey) return s; // stale by the time this runs
      const set = s.refSet?.length ? s.refSet : [s.refKey];
      const survivor = set.find((k) => k !== rawRefKey && openTabs.includes(k));
      if (!survivor) return null;
      return { ...s, refKey: survivor, refSet: set.filter((k) => k !== rawRefKey) };
    });
  }, [refInvalid, rawRefKey, openTabs]);

  // Deliberately depends on `darkMode` (unlike the rest of this file's
  // tile-paint calls, which read darkModeRef to stay stable across renders):
  // ReferencePane's paint effect below re-fires when THIS callback's identity
  // changes (it's a `paintBase`/`paintDetail` prop dependency), and that is
  // the reference pane's ONLY dark-mode repaint signal — it isn't a member of
  // `drawPanels`, so the primary's dark-toggle effect below never reaches its
  // canvas. Closing over the fresh `darkMode` value (not the ref, which the
  // primary's effect updates in a possibly-later-running sibling effect) also
  // sidesteps any cross-effect ordering question about which fires first.
  const paintReferenceBase = useCallback((drawKey, canvasEl) => {
    if (!canvasEl) return;
    const d = refDimsRef.current;
    if (!d || `ref::${d.key}` !== drawKey) return;
    getCompositor().paintBase(canvasEl, drawKey, d.w, d.h, darkMode);
  }, [darkMode]);

  // Reference-pane analog of the primary's syncTilePanelsRef loop body (Task
  // 6): composites the visible-region detail crop for the SINGLE `ref::`-
  // prefixed surface, using detailCropFor (shared math, see its comment) and
  // this pane's OWN transform/viewport rect instead of the primary's shared
  // `tfRef`/container. Single-slot refs (one surface, not a Map) stand in for
  // detailKeysRef/detailCancelsRef's per-drawKey entries. Stable modulo
  // `darkMode` for the same reason paintReferenceBase is: it's the reference
  // pane's only dark-mode repaint signal for this layer too.
  //
  // No DETAIL_ENGAGE gate, matching syncTilePanelsRef above (see its comment):
  // tiles are the only raster path now, active at every zoom level. Without
  // this the primary and reference could visibly diverge on the SAME sheet at
  // the SAME zoom — the primary painting crisp tiles while this pane fell
  // back to its CSS-stretched base raster in the ~0.9-1.15 scale*dpr band
  // below the old threshold. The only reason left to hide the canvas is the
  // crop itself reporting the source is off-screen.
  const refDetailKeyRef = useRef(null);
  const refDetailCancelRef = useRef(null);
  const paintReferenceDetail = useCallback((drawKey, canvasEl, t, r) => {
    if (!canvasEl) return;
    const dims = refDimsRef.current;
    if (!dims || `ref::${dims.key}` !== drawKey) return;
    const dpr = window.devicePixelRatio || 1;
    const d = { x: 0, y: 0, w: dims.w, h: dims.h, clip: null, drawKey };
    const crop = detailCropFor(t, r, d);
    if (!crop) { canvasEl.style.display = "none"; refDetailKeyRef.current = null; return; }
    const { x0, y0, x1, y1, xBase, yBase } = crop;
    const density = tileRequiredDensity(t.scale, dpr);
    const renderKey = `${drawKey}|${x0.toFixed(1)},${y0.toFixed(1)}|${x1.toFixed(1)},${y1.toFixed(1)}|${density.toFixed(2)}|${darkMode ? 1 : 0}`;
    if (renderKey === refDetailKeyRef.current) return;
    refDetailKeyRef.current = renderKey;
    try { refDetailCancelRef.current?.cancel(); } catch { /* done */ }
    refDetailCancelRef.current = getCompositor().paintDetail(canvasEl, drawKey, xBase, x0, y0, x1, y1, density, darkMode, () => { }, yBase);
  }, [darkMode]);

  // dark toggle: repaint the base layer of every already-loaded panel at the
  // new mode (the detail effect below also depends on darkMode, so it
  // repaints too). Tiles are cached PER MODE (tileCompositor.ts), so a
  // toggle-back is instant once both variants have been seen once. The
  // reference pane's own base/detail canvases are NOT drawPanels members —
  // they repaint via paintReferenceBase/paintReferenceDetail's own `darkMode`
  // dependency above, which is what re-fires ReferencePane's effects.
  useEffect(() => {
    darkModeRef.current = darkMode;
    if (status !== "ready") return;
    for (const d of drawPanels) {
      const cv = panelCanvasRefs.current.get(d.drawKey);
      if (cv && d.w) getCompositor().paintBase(cv, d.drawKey, d.w, d.h, darkMode);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [darkMode]);

  // ── render the sheet group (a single sheet is a group of one) ──────────────
  // Two phases: (A) resolve every panel's LOGICAL dimensions — page-points ×
  // RENDER_SCALE, fixed forever, never rastered directly (see tiles.ts's
  // header comment on why this makes factorFor collapse to a constant) — so
  // the row layout is final before any pixel paints, then (B) hand each sheet
  // to the tile compositor, which paints a small bounded coarse placeholder
  // (the base layer) and opens the sheet in the worker pool for on-demand
  // tile rendering. A monotonic token is checked after EVERY await so a stale
  // chain can never paint, resize, or cancel a newer chain's work.
  useEffect(() => {
    if (!active) return;
    const seq = ++renderSeqRef.current;
    const stale = () => seq !== renderSeqRef.current;
    scanHoldRef.current = performance.now() + 500; // the whole-file text scan waits for this sheet
    // each shown file's generation as this render starts (spec §5.3): text
    // read below is offered under it, so a re-drop meanwhile discards it
    const nameGens = new Map();
    const nameGenOf = (f) => { if (!nameGens.has(f)) nameGens.set(f, namerRef.current?.gen(f)); return nameGens.get(f); };
    for (const k of groupKeys) {
      if (isStitchKey(k)) for (const mem of stitchById[k]?.members ?? []) nameGenOf(parseSheetKey(mem.key).file);
      else nameGenOf(parseSheetKey(k).file);
    }
    nameGenOf(active);
    setStatus("rendering"); setErr(""); clearPoly(); setCalib([]); setPendingLen(""); setCheck([]); setCheckStated(""); setScaleGuide(null); setPrevScale(null); selectShape(null); setProposal(null); setAlignPt(null); resetZone();
    for (const [, rt] of renderTasksRef.current) { try { rt.cancel(); } catch { /* done */ } }
    renderTasksRef.current.clear();
    snapGridsRef.current.clear();
    vectorSegsRef.current.clear();
    segMetaRef.current.clear();
    subpathsRef.current.clear();
    textMarksRef.current.clear();
    layerGeoRef.current.clear();
    layerInfosRef.current.clear();
    setSheetLayers({});
    maskCacheRef.current.clear();
    sheetStatsRef.current.clear();
    rasterMaskCacheRef.current.clear();
    canvasInvertedRef.current.clear();
    // The sheets leaving the screen: let pdf.js free what each page cached
    // (its operator list, its decoded images). The document outlives the
    // sheet, so without this every sheet visited in a big set stayed in
    // memory until its file closed (#580). A page still being read (a
    // thumbnail, an OCR raster) frees itself when that finishes; one shown
    // again reads its operator list again.
    for (const pg of new Set(pageObjsRef.current.values())) { try { pg.cleanup(); } catch { /* its document is already gone */ } }
    pageObjsRef.current.clear();
    renderScalesRef.current.clear();
    getCompositor().resetAll();
    for (const [, c] of detailCancelsRef.current) { try { c.cancel(); } catch { /* done */ } }
    detailCancelsRef.current.clear();
    detailKeysRef.current.clear();
    for (const [, cv] of detailCanvasRefs.current) cv.style.display = "none";
    // Mirror for the reference pane's single-surface detail state (Task 6):
    // resetAll() also invalidates its `ref::`-prefixed compositor entry (the
    // reference-resolve effect below reopens it and bumps refEpoch), but
    // WITHOUT this clear, paintReferenceDetail's render-key dedup could see
    // the exact same computed renderKey after reopen — nothing about the
    // reference's own transform/viewport changed, only the compositor was
    // reset — and silently no-op, leaving a stale/blank detail canvas until
    // the user's next gesture on that pane.
    try { refDetailCancelRef.current?.cancel(); } catch { /* done */ }
    refDetailCancelRef.current = null;
    refDetailKeyRef.current = null;
    // The render workers start on each file's document now, while the main
    // thread opens its own and finds the page: the two used to run one after
    // the other (#580). A file the workers already hold costs nothing.
    if (typeof store.loadPdfSource === "function") {
      const files = new Set(groupKeys.flatMap((k) => (stitchById[k] ? stitchById[k].members.map((m) => parseSheetKey(m.key).file) : [parseSheetKey(k).file])));
      for (const f of files) store.loadPdfSource(f).then((src) => { if (!stale()) getCompositor().warm(src); }).catch(() => { /* the open below reports it */ });
    }
    (async () => {
      // resolve one drawable source: doc → page → viewport at the FIXED logical
      // scale. Every file here is pinned (groupKeys), so docFor holds; a stale
      // chain's doc may be trimmed under it, and it bails
      const resolveSource = async (memberKey) => {
        const { file, page: pn } = parseSheetKey(memberKey);
        const pdf = await docFor(file); if (stale()) return null;
        if (file === active) setPageCount(pdf.numPages || 1);
        // the doc is open anyway: count its pages for the set (the gallery's
        // cache), so a file opened from a tab isn't "pages unknown" (#498)
        rememberPages(file, pdf.numPages);
        namerRef.current?.setNumPages(file, nameGenOf(file), pdf.numPages || 1);
        const pageNum = Math.min(Math.max(1, pn), pdf.numPages || 1);
        const pageObj = await pdf.getPage(pageNum); if (stale()) return null;
        const viewport = pageObj.getViewport({ scale: RENDER_SCALE });
        // wf/hf: the EXACT logical dims — stitch extents must accumulate these,
        // not the ceil'd canvas dims, or a composite of N members drifts up to
        // N px wide. That drift is not cosmetic: the one-click mask downscale
        // (MASK_MAX_DIM/width) is resolution-sensitive, and a 6049px stitch of
        // a 6048px drawing measurably breaks flood fills the 6048px original
        // sustains (reproduced on the split-sheet fixture; same failure occurs
        // feeding 6049 to the ORIGINAL sheet's mask — the drift was the bug,
        // not the merge).
        return { key: memberKey, file, pageNum, pageObj, viewport, w: Math.ceil(viewport.width), h: Math.ceil(viewport.height), wf: viewport.width, hf: viewport.height };
      };
      // phase A — logical dimensions for every panel. A stitch panel (#161)
      // resolves each MEMBER and takes the composite extent; its members'
      // pageObjs register under their own keys (one-off render paths address
      // sheets, not composites), while the merged snap/mask geometry below
      // registers under the STITCH key — the only key the input model sees.
      const metas = [];
      for (const key of groupKeys) {
        const st = stitchById[key];
        if (st) {
          const sources = [];
          const dims = {};   // EXACT member dims — extent, seams and align math all read these
          for (const mem of st.members) {
            const s = await resolveSource(mem.key); if (stale()) return; if (!s) return;
            pageObjsRef.current.set(mem.key, s.pageObj);
            renderScalesRef.current.set(mem.key, RENDER_SCALE);
            dims[mem.key] = { w: s.wf, h: s.hf };
            sources.push({ ...s, drawKey: `${key}::${mem.key}`, dx: mem.dx, dy: mem.dy });
          }
          panelSourceDimsRef.current.set(key, dims);
          renderScalesRef.current.set(key, RENDER_SCALE);
          const ext = stitchExtent(st.members, dims);
          metas.push({ key, file: key, stitch: st, dims, sources, w: ext.w, h: ext.h });
        } else {
          const s = await resolveSource(key); if (stale()) return; if (!s) return;
          pageObjsRef.current.set(key, s.pageObj);     // kept for getOperatorList/getTextContent and the independent one-off render paths (raster-mask, agent vision, schedule marquee) — unrelated to painting, still main-thread
          renderScalesRef.current.set(key, RENDER_SCALE);
          metas.push({ ...s, sources: [{ ...s, drawKey: key, dx: 0, dy: 0 }] });
        }
      }
      setPanelImgs(Object.fromEntries(metas.map((m) => [m.key, { w: m.w, h: m.h }])));
      let rw = 0, rh = 0;
      for (const m of metas) { rw += (rw ? PANEL_GAP : 0) + m.w; rh = Math.max(rh, m.h); }
      fitToView(rw, rh);
      // phase B — open each source sheet in the worker pool + paint its coarse
      // base layer (a stitch contributes one canvas per member, positioned by
      // the drawPanels expansion). Sheets are independent pdf.js docs in the
      // pool now (not one shared canvas context), so there's no reason to
      // serialize them the way the old left-to-right raster loop had to.
      await Promise.all(metas.flatMap((m) => m.sources.map(async (s) => {
        getCompositor().openSheet(s.drawKey, s.pageNum, pdfSourceOf(s.file), s.w, s.h);
        let canvas = panelCanvasRefs.current.get(s.drawKey);
        for (let t = 0; !canvas && t < 10; t++) {
          await new Promise((r) => requestAnimationFrame(r)); if (stale()) return;
          canvas = panelCanvasRefs.current.get(s.drawKey);
        }
        if (!canvas || stale()) return;
        await getCompositor().paintBase(canvas, s.drawKey, s.w, s.h, darkModeRef.current);
      })));
      if (stale()) return;
      // vector geometry per PANEL (best-effort; snap is off until enabled).
      // Plain panels keep the old per-sheet path byte-for-byte; a stitch merges
      // its members' geometry into stitch space, seam-clipped so hidden ink
      // near the match line neither offers snap targets nor walls off the
      // one-click mask (lib/stitches.ts mergePoints/mergeSegs).
      for (const m of metas) {
        if (m.stitch) {
          const clips = seamClips(m.stitch.members, m.dims);
          Promise.all(m.sources.map((s) => s.pageObj.getOperatorList().then((ol) => ({ s, g: extractVectorGeometry(ol, s.viewport.transform, pdfjsLib.OPS) })))).then((parts) => {
            if (stale()) return;
            const byIdx = parts.map(({ s, g }, i) => ({
              points: g.points, segs: g.segs, meta: g.meta, imageArea: g.imageArea,
              dx: s.dx, dy: s.dy,
              clip: { x0: clips[i].x0, y0: clips[i].y0, x1: clips[i].x1, y1: clips[i].y1 },
            }));
            const pts = mergePoints(byIdx);
            const merged = mergeSegs(byIdx);
            snapGridsRef.current.set(m.key, buildSnapGrid(pts, SNAP_CELL));
            vectorSegsRef.current.set(m.key, merged.segs);
            segMetaRef.current.set(m.key, merged.meta);
            sheetStatsRef.current.set(m.key, { segCount: merged.segs.length >> 2, imageFrac: Math.min(1, merged.imageArea / (m.w * m.h)) });
            // verbose stitch tracing, gated like __OT_DETAIL_DEBUG
            if (window.__OT_STITCH_DEBUG) window.__stitchGeom = { key: m.key, clips, members: m.stitch.members, dims: m.dims, w: m.w, h: m.h, segs: merged.segs.length >> 2, perMember: byIdx.map((b) => ({ dx: b.dx, dy: b.dy, clip: b.clip, n: b.segs.length >> 2 })) };
          }).catch(() => {
            if (stale()) return;
            sheetStatsRef.current.set(m.key, { segCount: 0, imageFrac: 1 });
          });
          // scale note: the first member speaks for the composite (members
          // plot at one scale by construction — see createStitch's seeding)
          m.sources[0].pageObj.getTextContent().then((tc) => {
            if (stale()) return;
            offerSheetText(m.sources[0].file, m.sources[0].pageNum, nameGenOf(m.sources[0].file), tc, m.sources[0].viewport);
            const det = detectScale(tc, m.sources[0].viewport);
            if (det) setDetectedScales((d) => (d[m.key]?.label === det.label ? d : { ...d, [m.key]: det }));
          }).catch(() => { });
          continue;
        }
        // snap-to-vector index per panel (best-effort; off until the user enables it)
        const opList = m.pageObj.getOperatorList();
        const textContent = m.pageObj.getTextContent();
        opList.then(async (ol) => {
          if (stale()) return;
          const { points, segs, meta, imageArea, lum, layerOf, layerIds, subpaths } = extractVectorGeometry(ol, m.viewport.transform, pdfjsLib.OPS);
          snapGridsRef.current.set(m.key, buildSnapGrid(points, SNAP_CELL));
          vectorSegsRef.current.set(m.key, segs);
          segMetaRef.current.set(m.key, meta);
          if (subpaths) subpathsRef.current.set(m.key, subpaths);
          if (lum) segLumRef.current.set(m.key, lum);
          textTfRef.current.set(m.key, m.viewport.transform);
          // raster-fallback trigger signals: how much of the sheet is placed
          // image, and whether the vector linework is dense enough to bound rooms
          sheetStatsRef.current.set(m.key, { segCount: segs.length >> 2, imageFrac: Math.min(1, imageArea / (m.w * m.h)) });
          // classify the sheet's PDF layer table (#85): the walk attributed
          // segments to OCG ids; the DOCUMENT declares id → (name, default
          // visibility). buildLayerInfos is the same pure derivation the MCP
          // session runs, so panel and sheet_info can never disagree. An empty
          // table is the (common) unlayered case — the Layers control stays
          // invisible and the mask path is byte-identical to pre-#85. Own
          // try/catch: a failed config read degrades to unlayered, and must
          // never trip the outer catch into the corrupt-op-list stats sentinel.
          let infos = [];
          if (layerIds.length) {
            try {
              const cfg = await (await docFor(m.file)).getOptionalContentConfig();   // pinned: a panel's file
              const groups = cfg ? cfg.getGroups() : null;
              infos = buildLayerInfos(layerIds, layerOf, new Map(Object.entries(groups || {})));
            } catch { /* no resolvable declarations — nothing is stated */ }
          }
          if (stale()) return;
          layerGeoRef.current.set(m.key, { layerIds, layerOf });
          layerInfosRef.current.set(m.key, infos);
          maskCacheRef.current.delete(m.key);   // a mask built before the table resolved was roleless
          setSheetLayers((prev) => ({ ...prev, [m.key]: infos }));
        }).catch(() => {
          if (stale()) return;
          // A rejected op-list (corrupt embedded JBIG2/CCITT — exactly the class of
          // scanned PDFs this feature serves) must not leave stats permanently
          // unset: with no sentinel, rasterEligible and vectorViable both read
          // false forever and oneClickAt is stuck on the vector branch showing
          // "try again in a second" for the sheet's whole lifetime. A sentinel that
          // reads as image-dominant/segment-empty lets the raster fallback engage
          // instead (rasterEligible true, vectorViable false).
          sheetStatsRef.current.set(m.key, { segCount: 0, imageFrac: 1 });
        });
        // the page's text layer and pictures (#471, #489), joined from the two
        // reads above (pictures.ts measurePage; no second op list): a scan
        // (at most SCAN_MAX_TEXT_LINES lines: none, or a stray stamp or
        // label) is decided by its text alone; any other page waits for the
        // op list, and one pdf.js can't produce leaves its pictures "failed".
        // The entry goes to search, and what a read of the sheet would cover
        // (planSearch readWhat on the entry now in the index, which may be a
        // seed's or a read's) drives the Read control and its lookups. Once
        // per page (until its file's bytes change: forgetTextLayer); a pass
        // left behind (stale) records nothing, so the next one measures.
        if (!measuredRef.current.has(m.key)) {
          measurePage(m.key, { getTextContent: () => textContent, getOperatorList: () => opList }, m.viewport, pdfjsLib.OPS).then(({ index, pictures }) => {
            if (stale() || measuredRef.current.has(m.key)) return;
            measuredRef.current.add(m.key);
            // a real measurement lands over another pass's "failed" too
            if (acceptsMeasuredPass(planIndexRef.current.get(m.key), pictures)) onIndexed(m.key, index);
            const what = readWhat(planIndexRef.current.get(m.key) ?? index);
            setReadableByKey((s) => (s[m.key] === what ? s : { ...s, [m.key]: what }));
          }).catch((err) => {
            // measured-failed for this session (until its file's bytes
            // change): no retry on every render pass, and no Read row
            if (stale()) return;
            measuredRef.current.add(m.key);
            console.warn(`Couldn't measure ${m.key}'s text layer and pictures:`, err);
          });
        }
        // read the drawn scale note off this panel's page text (best-effort),
        // and the positioned dimension-pattern texts the dim-string classifier
        // anchors on (#320) — a mask built before they resolved was textless
        textContent.then((tc) => {
          if (stale()) return;
          offerSheetText(m.file, m.pageNum, nameGenOf(m.file), tc, m.viewport);
          const det = detectScale(tc, m.viewport);
          if (det) setDetectedScales((d) => (d[m.key]?.label === det.label ? d : { ...d, [m.key]: det }));
          // positioned text for ink classification — a mask built before this
          // resolved simply had no text evidence (the layer-table precedent)
          const marks = extractTextMarks(tc, m.viewport);
          if (marks.length) { textMarksRef.current.set(m.key, marks); maskCacheRef.current.delete(m.key); }
          const dts = extractDimTexts(tc, m.viewport);
          if (dts.length) { dimTextsRef.current.set(m.key, dts); maskCacheRef.current.delete(m.key); }
        }).catch(() => { });
      }
      if (stale()) return;
      setStatus("ready");
      setRotatingKey(null);
      // title-block labels — current page now, then once per file scan the rest so
      // the pager + pinned tabs + provenance deep-jump can show real sheet numbers
      const lead = metas.find((m) => m.file === active);
      if (!lead) return;
      const labelGen = labelGens.of(active); // a re-drop of this file moves it
      const labelsLive = () => labelGens.of(active) === labelGen;
      lead.pageObj.getTextContent().then((tc) => {
        if (stale()) return;
        const lbl = extractSheetNumber(tc, lead.viewport);
        if (lbl && labelsLive()) setLabelsByFile((m) => withPageLabel(m, active, lead.pageNum, lbl));
        // plan-set search: the same text, at the same RENDER_SCALE viewport,
        // built only where the entry would take a pass without pictures
        // (planSearch acceptsTextPass; the measured pass above brings those)
        if (acceptsTextPass(planIndexRef.current.get(lead.key))) onIndexed(lead.key, pageTextIndex(lead.key, tc, lead.viewport));
      }).catch(() => { });
      if (labeledFileRef.current !== active) {
        labeledFileRef.current = active;
        setLabelsByFile((m) => labelsOnFileChange(m, active)); // drop other files' labels
        // Every other page's text, for the tree's sheet numbers, the noted
        // scales and plan search. The scan belongs to the FILE, not to this
        // render: it runs on through sheet flips, and stops when another file
        // becomes active, this one is re-dropped, or the canvas unmounts.
        // (It used to stop at the first flip and never start again, leaving
        // the tree half numbered.) Where the store gives a byte-range source
        // the pages are read in the render workers, one per worker at a
        // time, and only while no tile is owed (#580); else on the main
        // document, one at a time, as before.
        textScanRef.current?.end?.(); // a scan of another file: its workers go now
        const scan = textScanRef.current = {};
        const scanLive = () => textScanRef.current === scan && labeledFileRef.current === active && labelsLive();
        const nameGen = nameGenOf(active);
        (async () => {
          const pdf = await docFor(active);   // pinned while active
          const total = pdf.numPages || 1;
          const source = typeof store.loadPdfSource === "function" ? await store.loadPdfSource(active).catch(() => null) : null;
          const found = {};
          let dirty = 0;
          const flush = () => { if (dirty && scanLive()) { dirty = 0; setLabelsByFile((m) => withFoundLabels(m, active, { ...found })); } };
          const scales = {};
          const flushScales = () => {
            const batch = Object.entries(scales); if (!batch.length || !scanLive()) return;
            for (const k of Object.keys(scales)) delete scales[k];
            setDetectedScales((d) => { let next = d; for (const [k, det] of batch) if (next[k]?.label !== det.label) { if (next === d) next = { ...d }; next[k] = det; } return next; });
          };
          const take = (n, tc, vp) => {
            const lbl = extractSheetNumber(tc, vp);
            offerSheetText(active, n, nameGen, tc, vp);
            if (lbl) { found[n] = lbl; dirty++; }
            const key = n > 1 ? `${active}#${n}` : active;
            const det = detectScale(tc, vp);
            if (det) scales[key] = det;
            if (acceptsTextPass(planIndexRef.current.get(key))) onIndexed(key, pageTextIndex(key, tc, vp));
          };
          const readOnMain = async (n) => {
            const p2 = await pdf.getPage(n);
            const tc = await p2.getTextContent();
            take(n, tc, p2.getViewport({ scale: RENDER_SCALE }));
          };
          // The scan gives way to the sheet: no read starts while a tile is
          // owed or a sheet change is under way (scanHoldRef, set as each
          // render begins), and a page's text is taken up in an idle period
          // of the main thread, so a flip or a scroll never waits on it.
          const idleTiles = async () => { while (scanLive() && (getCompositor().busy() || performance.now() < scanHoldRef.current)) await new Promise((r) => setTimeout(r, 40)); };
          const idleMain = () => new Promise((r) => { if (typeof requestIdleCallback === "function") requestIdleCallback(() => r(), { timeout: 250 }); else setTimeout(r, 0); });
          // The scan's own workers (lib/tilePool TEXT_SCAN_WORKERS), ended with
          // it: the render pool keeps every one of its workers for the sheet.
          const scanPool = source && TEXT_SCAN_WORKERS > 0 ? createTilePool(TEXT_SCAN_WORKERS) : null;
          scan.end = () => { try { scanPool?.dispose(); } catch { /* already gone */ } };
          const readText = scanPool ? scanPool.requestText : (src, n, scale) => getCompositor().readText(src, n, scale);
          const lanes = !source ? 1 : scanPool ? TEXT_SCAN_WORKERS : Math.max(1, getCompositor().workers - 1);
          let next = 1;
          const lane = async () => {
            for (;;) {
              const n = next++;
              if (n > total || !scanLive()) return;
              if (n === lead.pageNum) continue;
              try {
                if (source) {
                  await idleTiles(); if (!scanLive()) return;
                  const r0 = performance.now();
                  const t = await readText(source, n, RENDER_SCALE);
                  const r1 = performance.now();
                  await idleMain();
                  if (!scanLive()) return;
                  const r2 = performance.now();
                  take(n, t, t.viewport);
                  if (window.__OT_SCAN_DEBUG) (window.__scanT ??= []).push([r1 - r0, r2 - r1, performance.now() - r2, t.items.length]);
                } else {
                  await readOnMain(n); if (!scanLive()) return;
                }
              } catch { /* skip */ }
              // the tree and the scale chips fill in as the scan goes, in
              // batches: one state update per page was most of its cost
              if (dirty >= 24) flush();
              if (Object.keys(scales).length >= 24) flushScales();
            }
          };
          const t0 = performance.now();
          try { performance.mark("sheet-text-scan-start"); } catch { /* unsupported */ }
          try { await Promise.all(Array.from({ length: lanes }, lane)); } finally { scan.end(); }
          flush(); flushScales();
          if (scanLive()) { try { performance.measure("sheet-text-scan", { start: t0, detail: { pages: total } }); } catch { /* unsupported */ } }
        })().catch(() => { });
      }
    })().catch((e) => { if (stale() || e?.name === "RenderingCancelledException") return; setErr(String(e.message || e)); setStatus("error"); });
    // cleanup MUST read the LIVE refs, not a mount-time copy: bumping the current
    // renderSeqRef invalidates in-flight renders, and cancelling the current
    // renderTasksRef set is the whole point. Copying to a variable (the rule's
    // suggestion) would cancel the stale mount-time set and leak the live one.
    // A schedule box still being read belongs to the sheet group being left
    // (a sheet switch, a stitch edit, a re-dropped file's docEpoch, unmount):
    // cancel it and release its lock and status line now.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    return () => { renderSeqRef.current++; for (const [, rt] of renderTasksRef.current) { try { rt.cancel(); } catch { /* done */ } } cancelImportRead(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupSig]);
  // after the render effect, so a group switch starts loading the new files
  // before the old ones are trimmed (pinFiles above)
  useEffect(() => { docCache.trim(); }, [docCache, pinSig]);

  // ── detail view: composite the visible region + margin from cached tiles ──
  // Generalizes the old single-detail-canvas effect to EVERY panel (group
  // mode previously only ever sharpened the last-focused one — see the #86
  // research note) and drops the DETAIL_ENGAGE threshold entirely: tiles are
  // the only raster path now, active at every zoom level, not a sharpening
  // overlay on top of an already-acceptable base. Pixels only — markup is an
  // SVG sibling ABOVE these canvases, and quantities never touch render
  // pixels: both untouched.
  //
  // This is a REF-CALLED FUNCTION, not a plain tf-keyed effect: scheduleSync
  // (below) intentionally skips mirroring tfRef into the `tf` REACT STATE for
  // a pure pan below the old DETAIL_ENGAGE threshold (avoids a full SVG-
  // overlay reconciliation storm on a zoomed-out pan — see its comment). That
  // optimization predates tiles being always-active; if this logic only ran
  // off `tf` state, a low-zoom pan would never reposition the visible-region
  // crop. So scheduleSync calls syncTilePanelsRef.current() on EVERY tick,
  // state-mirror-skip or not, and this effect is just the "also run it after
  // a structural render" path (load, dark toggle, group change, panel resize).
  const syncTilePanelsRef = useRef(() => { });
  useEffect(() => {
    syncTilePanelsRef.current = () => {
      const cont = containerRef.current;
      if (!cont || status !== "ready") return;
      const t = tfRef.current;
      // Mid-gesture bail: resizing a detail canvas mid-pinch would flash the
      // region blank and storm the worker pool with cancelled renders. The
      // previous crop stays correctly anchored in stage space (it rides the
      // same CSS transform everything else does), so leaving it painted is
      // free; self-poll so the settle repaint is guaranteed even if no further
      // input event arrives before the gesture window expires.
      if (panRef.current || performance.now() < gestureUntilRef.current) { scheduleSync(); return; }
      // Gesture settled: demote the stage layer (see promoteStage) so the SVG
      // overlay re-rasters at the zoom the user landed on — this is what
      // un-pixelates a drafted boundary after a scroll-zoom.
      if (stageRef.current && stageRef.current.style.willChange !== "auto") stageRef.current.style.willChange = "auto";
      const r = cont.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const density = tileRequiredDensity(t.scale, dpr);
      // draw-time entries, not input panels: a stitch (#161) sharpens one crop
      // per MEMBER, each clipped to its seam box (the wrapper div does the
      // clipping; the canvas positions relative to it via the x/y bases).
      for (const d of drawPanels) {
        const cv = detailCanvasRefs.current.get(d.drawKey);
        if (!cv || !d.w) continue;
        const hide = () => { cv.style.display = "none"; detailKeysRef.current.delete(d.drawKey); };
        const crop = detailCropFor(t, r, d);
        if (!crop) { hide(); continue; }                         // source off-screen
        const { x0, y0, x1, y1, xBase, yBase } = crop;
        // one composite per distinct crop — the sync loop re-fires this several
        // times around a settle with identical inputs
        const renderKey = `${d.drawKey}|${x0.toFixed(1)},${y0.toFixed(1)}|${x1.toFixed(1)},${y1.toFixed(1)}|${density.toFixed(2)}|${darkModeRef.current ? 1 : 0}`;
        if (renderKey === detailKeysRef.current.get(d.drawKey)) continue;
        detailKeysRef.current.set(d.drawKey, renderKey);
        try { detailCancelsRef.current.get(d.drawKey)?.cancel(); } catch { /* done */ }
        // paintDetail owns position/size/pixels together now and applies all
        // three atomically on reveal — setting them here first would show a
        // correctly-positioned canvas with the OLD crop's (wrongly scaled)
        // pixels for a frame, which is its own flavor of flicker.
        const cancel = getCompositor().paintDetail(cv, d.drawKey, xBase, x0, y0, x1, y1, density, darkModeRef.current, () => { }, yBase);
        detailCancelsRef.current.set(d.drawKey, cancel);
      }
    };
  });
  const [repaintTick, setRepaintTick] = useState(0);
  // panelW/takeoffsOpen: docking or resizing the Takeoffs panel changes the
  // container rect without a transform change. repaintTick: bumped by the
  // visibilitychange recovery below.
  useEffect(() => { syncTilePanelsRef.current(); }, [tf, groupSig, status, panelW, takeoffsOpen, darkMode, repaintTick, splitView]);
  // Chrome reflows need the same existing viewport refresh as a dock resize.
  // This does not change coordinates, scale, tile rendering, or stored geometry.
  useEffect(() => { scheduleSync(); }, [workspaceLayout, workspaceArrangement, workspaceNavigationOpen, workspaceControlsOpen, workspaceDetailsOpen, agentOpen, scheduleSync]);

  // Primary recovery for a stalled tile fetch: a hidden tab can suspend
  // in-flight work indefinitely with no error (Chrome throttles rAF-gated
  // work in hidden tabs) — clear every panel's render key and retry on return.
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState !== "visible") return;
      detailKeysRef.current.clear();
      setRepaintTick((n) => n + 1);
      // Mirror for the reference pane (Task 6): repaintTick only drives
      // syncTilePanelsRef, which walks `drawPanels` — the reference pane's
      // single `ref::`-prefixed surface isn't a member, so a hidden-tab
      // stall there has no OTHER retry path. Clear the dedup key (or a
      // recomputed-identical renderKey would silently no-op, same failure
      // shape as the resetAll case above) and bump refEpoch to actually
      // re-fire ReferencePane's paint effects.
      if (rawRefKey) {
        try { refDetailCancelRef.current?.cancel(); } catch { /* done */ }
        refDetailCancelRef.current = null;
        refDetailKeyRef.current = null;
        setRefEpoch((e) => e + 1);
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [rawRefKey]);

  // the doc cache holds whole PDFs in the worker — tear it down when the
  // project view unmounts or the project changes. The tile compositor (its
  // worker pool + up to BYTE_BUDGET of ImageBitmaps) goes down with it:
  // dispose-and-NULL pairs with getCompositor's lazy ??= creation, which is
  // what makes this safe under StrictMode's extra mount/unmount cycles — a
  // post-dispose render just mints a fresh compositor instead of hitting a
  // permanently-dead pool (the failure mode an eager create/dispose effect
  // pair was observed to cause; see getCompositor's comment).
  useEffect(() => () => {
    docCache.clear();
    textScanRef.current?.end?.();
    textScanRef.current = null; labeledFileRef.current = ""; // the text scan reads through this pool
    try { compositorRef.current?.dispose(); } catch { /* half-built pool */ }
    compositorRef.current = null;
  }, [docCache]);

  // provenance deep-jump: if the URL named a sheet (?sheet=A003), jump once its page is known
  useEffect(() => {
    const want = (wantSheetRef.current || "").toUpperCase().replace(/\s+/g, "");
    if (!want) return;
    const hit = Object.entries(pageLabels).find(([, lbl]) => lbl === want);
    if (hit) { setPage(parseInt(hit[0], 10)); wantSheetRef.current = ""; }
  }, [pageLabels]);

  // fly-to phase 2: a pending fly-to whose sheet just finished opening (its panel
  // now has a real bitmap) gets centered here — never on the same tick openSheets
  // was called (dims are still {0,0} then).
  useEffect(() => {
    const m = pendingFlyRef.current;
    if (!m) return;
    // drop a stale pending fly-to: the target sheet failed to render, or the markup
    // was deleted — either way it will never complete, so don't let it fire later.
    if (status === "error" || !markups.some((x) => x.id === m.id)) { pendingFlyRef.current = null; return; }
    if (status !== "ready" || !panelKeySet.has(m.sheet_id)) return;
    const sp = panels.find((p) => p.key === m.sheet_id);
    // once the panel bitmap exists, center (or give up if the markup has no anchor)
    // and clear the ref regardless, so an unanchored markup can't get stuck pending.
    if (sp && sp.img.w) { centerOnMarkup(m); pendingFlyRef.current = null; }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panelImgs, groupSig, status]);

  // source-trace (◎) phase 2 — mirrors the fly-to phase-2 effect above, but
  // pendingSourceRef has no markup id to re-validate against (there's no markup
  // on the source sheet, only a synthetic {sheet_id, rect}), so it leans on
  // pendingSourceOutcome's three guards instead: status==="error", the source
  // sheet key no longer resolving to a real sheet (deleted file / bad key —
  // same liveness test the sheetGroup-pruning effect uses), or a bounded
  // attempt-budget cap. Every branch below either re-arms `attempts` or nulls
  // the ref — it is NEVER left set past a terminal outcome (give-up or
  // complete), which is the plan's central risk for this slice.
  useEffect(() => {
    const p = pendingSourceRef.current;
    if (!p) return;
    const sheetIsLive = isStitchKey(p.sheet_id)
      ? !!stitchById[p.sheet_id] && stitchAlive(stitchById[p.sheet_id], new Set(sheets.map((s) => s.name)))
      : sheets.some((s) => s.name === parseSheetKey(p.sheet_id).file);
    const sp = panelKeySet.has(p.sheet_id) ? panels.find((pp) => pp.key === p.sheet_id) : null;
    const outcome = pendingSourceOutcome(p, { status, sheetIsLive, panelReady: !!sp?.img?.w });
    if (outcome.action === "give-up") { pendingSourceRef.current = null; return; }
    if (outcome.action === "wait") { pendingSourceRef.current = { ...p, attempts: outcome.attempts }; return; }
    // action === "complete": the rect was already validated (non-null midpoint)
    // when traceSource armed this ref, but re-check rather than trust a ref that
    // sat around — cheap, and keeps this path total on its own.
    const mid = rectMidpoint(p.rect);
    if (mid && centerOnPanelPoint(sp, mid[0], mid[1])) flashSource(p.sheet_id, p.rect, p.token);
    pendingSourceRef.current = null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panelImgs, groupSig, status]);

  // A flash belongs to whichever sheet it's currently drawn on (the render site
  // keys it to `sourceFlash.sheet_id === p.key`, per-panel). Once that sheet
  // leaves the open set — tab closed, group changed, navigated away — clear it
  // rather than let it sit armed: the panel's <g> unmounts and remounts on
  // return, and a CSS keyframes animation restarts on mount, so a stale
  // sourceFlash would silently re-pulse on a LATER, unrelated visit to that
  // sheet. MUST be a functional updater, not a closure read of `sourceFlash`:
  // the pendingSourceRef effect above can, in the SAME batch that just changed
  // groupSig, call setSourceFlash(newFlash) for the sheet that just finished
  // opening — a closure-captured `sourceFlash` here would still be the OLD
  // (now off-panel) value and null out the flash that was just set, in the
  // same flush, before it ever painted. Reading `f` at apply time instead of
  // closure time avoids that race.
  useEffect(() => {
    setSourceFlash((f) => (f && !panelKeySet.has(f.sheet_id) ? null : f));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupSig]);

  // ── autosave (debounced) ──────────────────────────────────────────────────
  // buildPayload is the single serializer — autosave and snapshots must write
  // identical records for the same state (byte-stability matters downstream).
  const buildPayload = (overrides = {}) => buildTakeoffDocument({
    // the envelope — key order, omit-when-empty, the units/palette rules — is
    // decided in lib/takeoffDocument.js, the same writer the MCP server uses
    project_name: overrides.project_name ?? projectName,
    units: overrides.units ?? units,
    client_info: overrides.client_info ?? clientInfo,
    estimate_settings: overrides.estimate_settings ?? estimateSettings,
    bid_proposal: overrides.bid_proposal ?? bidProposal,
    sheets: overrides.sheets ?? Object.entries(scales).map(([sheet_id, units_per_px]) => sheetEntry({ sheet_id, units_per_px, scale_source: scaleSources[sheet_id], scale_confirmed: scaleUnconfirmed[sheet_id] })),
    conditions: overrides.conditions ?? conditions,
    condition_columns: overrides.condition_columns ?? conditionColumns,
    shape_labels: overrides.shape_labels ?? shapeLabels,
    palette: overrides.palette ?? palette,
    shapes: overrides.shapes ?? shapes,
    markups: overrides.markups ?? markups,
    rfis: overrides.rfis ?? rfis,
    approvals: overrides.approvals ?? approvals,
    proposals: overrides.proposals ?? proposals,
    condition_edit_proposals: overrides.condition_edit_proposals ?? conditionEditProposals,
    rules: overrides.rules ?? rules,
    sheet_group: overrides.sheet_group ?? sheetGroup,
    last_group: overrides.last_group ?? lastGroup,
    sheet_tabs: overrides.sheet_tabs ?? openTabs,
    stitches: overrides.stitches ?? stitches,
    // additive `split_view` (read-only reference pane): the writer omits it when
    // null, so a project that never split persists byte-identical to before.
    split_view: overrides.split_view !== undefined ? serializeSplitView(overrides.split_view) : serializeSplitView(splitView),
    sheet_levels: overrides.sheet_levels ?? sheetLevels,
    layer_overrides: overrides.layer_overrides ?? layerOverrides,
    provenance_counters: overrides.provenance_counters ?? provCounters,
    door_answers: overrides.door_answers ?? doorAnswers,
  });
  // Runtime restore of a saved payload — the Revisions panel's Restore lands
  // here. A runtime load (unlike mount) can interrupt work in
  // flight: an unfinished trace/calibration/proposal must not commit into the
  // restored takeoff under a reset activeCond. The check tool and the rescale
  // stash are in that class too — a surviving prevScale would let "Revert
  // scale" re-price the RESTORED takeoff against a scale stashed from the
  // discarded timeline. Zone is in the same class: a surviving zoneCheck would
  // re-classify the RESTORED shape set against the pre-load polygon (hydrate()
  // also resets it, but this caller-side reset covers the pending in-progress
  // trace too). Mid-session, savesArmed is already true, so hydrate's setStates
  // re-fire the autosave effect and the restored payload persists (and pushes,
  // on the sync path) like any other edit.
  const [materialImport, setMaterialImport] = useState(null);
  const chooseImportUnits = () => new Promise(resolve => setMaterialImport({ unit: getMaterialUnit(), resolve }));
  const finishMaterialImport = (ok) => {
    if (ok) setMaterialUnit(materialImport.unit);
    materialImport.resolve(ok); setMaterialImport(null);
  };
  const restoreSavedPayload = (payload) => {
    clearPoly(); setCalib([]); setPendingLen(""); selectShape(null); setProposal(null);
    setCheck([]); setCheckStated(""); setScaleGuide(null); setPrevScale(null);
    resetZone();
    hydrate(payload || {});
  };

  // "Import takeoff…" (Sheet menu) — the file half of the agent handoff: an
  // MCP session's export_takeoff JSON (the app's own autosave schema) lands
  // here. The merge rules are pure and tested (lib/importTakeoff.js): operator
  // state wins, re-import is idempotent. Landed machine shapes keep
  // origin.reviewed:false, so the committed-but-unreviewed path renders them
  // dashed in their condition colors until the Accept banner inks them; the
  // runtime-load path above resets in-flight work, and mid-session savesArmed
  // is already true, so the merged payload autosaves like any other edit.
  const importTakeoffFile = async (file) => {
    if (!file) return;
    try {
      const imported = parseTakeoffImport(await file.text());
      if (!await chooseImportUnits()) return;
      const { payload, note } = mergeTakeoffImport(buildPayload(), imported, sheets.map((s) => s.name));
      restoreSavedPayload(payload);
      const parts = [formatMessage("Imported measurements: {0}", [note.shapes_added])];
      if (note.shapes_pending) parts.push(formatMessage("Measurements pending review: {0}. Accept them after checking", [note.shapes_pending]));
      if (note.conditions_added) parts.push(formatMessage("New conditions: {0}", [note.conditions_added]));
      if (note.conditions_merged) parts.push(formatMessage("Conditions matched by finish tag: {0}", [note.conditions_merged]));
      if (note.unknown_files.length) parts.push(formatMessage("Open the referenced files to see their measurements: {0}", [note.unknown_files.join(", ")]));
      setCommitMsg(parts.join(" · ") + ".");
    } catch (e) {
      // module copy already speaks "Couldn't…" (the sticky danger convention);
      // anything unexpected gets wrapped into it rather than aging out unread
      setCommitMsg(String(e?.message || "").startsWith("Couldn't") ? e.message : `Couldn't import takeoff: ${e?.message || e}`);
    }
  };

  // "Export takeoff…" (Sheet menu) — the other half of the file pair (#285).
  // The app has always READ takeoff_canvas.v1 and never written one to disk,
  // so the only copy of a finished takeoff lived in this browser profile's
  // IndexedDB: a cleared profile, a new machine, or a second estimator and
  // the work was unreachable. This writes the EXACT document autosave writes
  // — no export-only shape, no report flattening — so Import takeoff reads it
  // back into an editable takeoff, and a diff between two exports is a diff
  // between two saves.
  //
  // The plan PDF is deliberately NOT in it: this is the annotation record, the
  // same one the MCP export_takeoff emits, and it names its sheets by file.
  // Restoring means opening the same PDF first — the message says so, since a
  // backup that silently restores to nothing is worse than no backup.
  const exportTakeoffFile = () => {
    const payload = buildPayload();
    const base = (projectName || "takeoff").trim().replace(/[^\w.\- ]+/g, "").replace(/\s+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "takeoff";
    downloadText(`${base}.takeoff.json`, JSON.stringify(payload, null, 2), "application/json");
    const n = shapes.length;
    setCommitMsg(uiText(`Exported ${base}.takeoff.json — ${n} takeoff${n === 1 ? "" : "s"}, ${conditions.length} condition${conditions.length === 1 ? "" : "s"}. The plan PDF isn't in it: to restore, open the same PDF, then Import takeoff.`));
  };

  // "Clear workspace" (#301) — the deliberate start-fresh: every stored PDF
  // goes and the takeoff resets to empty, without touching browser storage by
  // hand. Local mode only (a cloud project's canon lives in Drive — Close
  // project is that mode's exit). Commit before risk: a non-empty takeoff is
  // snapshotted first, so the work is one Revisions-panel restore away — the
  // PDFs themselves are gone either way (local plans aren't stored elsewhere);
  // restored shapes re-attach by sheet name when the same files are re-opened.
  // ── PDF Page Tools (#578) ────────────────────────────────────────────────
  const rotateCurrentSheet = async (angle, targetKey = sheetKey) => {
    const target = targetKey || sheetKey;
    if (!target) return;
    if (isStitchKey(target)) {
      setCommitMsg("To rotate a stitched plan, rotate its source sheets.");
      return;
    }
    const stitchWithTakeoffs = stitches.find(
      (st) =>
        (st.members || []).some((m) => m.key === target) &&
        (shapes.some((s) => s.sheet_id === st.id) ||
          markups.some((m) => m.sheet_id === st.id) ||
          approvals.some((a) => a.sheet_id === st.id))
    );
    if (stitchWithTakeoffs) {
      const msg = `Cannot rotate "${target}": it belongs to stitched plan "${stitchWithTakeoffs.name || stitchWithTakeoffs.id}" which has active takeoffs. Remove stitch takeoffs first.`;
      alert(msg);
      setCommitMsg(msg);
      return;
    }
    const { file, page: targetPage } = parseSheetKey(target);
    setRotatingKey(target);
    try {
      setCommitMsg(`Rotating ${target} ${angle}° clockwise…`);
      const origBytes = await store.loadPdfData(file);
      const rotatedBytes = await rotatePdfPage(new Uint8Array(origBytes), targetPage, angle);

      const prevShapes = shapes;
      const prevMarkups = markups;
      const prevApprovals = approvals;

      // Track cumulative rotation and baseline content hash (#591)
      const prevRotations = { ...sheetRotationsRef.current };
      const prevRot = prevRotations[target];
      const origHash = prevRot?.hash || (await sha256Hex(origBytes));
      const nextAngle = ((prevRot?.angle || 0) + angle) % 360;
      const nextRotations = { ...prevRotations };
      if (nextAngle === 0) {
        delete nextRotations[target];
      } else {
        nextRotations[target] = { angle: nextAngle, hash: origHash };
      }
      saveSheetRotations(nextRotations);

      const dims = panelImgs[target] || { w: stage.w, h: stage.h };
      const rotated = rotateTakeoffOnSheet({ shapes, markups, approvals }, target, angle, dims);

      await store.addPdf(new File([rotatedBytes], file, { type: "application/pdf" }));
      evictDoc(file);
      forgetPages([file]);
      dropDoorReads(file);

      setShapes(rotated.shapes);
      setMarkups(rotated.markups);
      setApprovals(rotated.approvals);

      undoStackRef.current = [
        ...undoStackRef.current,
        {
          family: "page_tool",
          undo: async () => {
            saveSheetRotations(prevRotations);
            await store.addPdf(new File([origBytes], file, { type: "application/pdf" }));
            evictDoc(file);
            forgetPages([file]);
            dropDoorReads(file);
            setShapes(prevShapes);
            setMarkups(prevMarkups);
            setApprovals(prevApprovals);
            setDocEpoch((e) => e + 1);
            await refreshSheets();
            goToSheet(target);
            setCommitMsg(`Undid rotation on ${target}.`);
          },
          redo: async () => {
            await rotateCurrentSheet(angle, target);
          },
        },
      ];

      setDocEpoch((e) => e + 1);
      await refreshSheets();
      setTimeout(() => setRotatingKey(null), 800);
      const count = rotated.shapes?.filter((s) => s.sheet_id === target).length || 0;
      setCommitMsg(`Rotated ${target} ${angle}° clockwise — ${count} takeoff(s) followed.`);
    } catch (e) {
      setRotatingKey(null);
      setCommitMsg(`Couldn't rotate sheet: ${e?.message || e}`);
    }
  };

  const deleteCurrentSheet = async (targetKey = sheetKey) => {
    const target = targetKey || sheetKey;
    if (!target) return;
    if (isStitchKey(target)) {
      setCommitMsg("To delete a sheet, delete from its source document.");
      return;
    }
    const stitchWithTakeoffs = stitches.find(
      (st) =>
        (st.members || []).some((m) => m.key === target) &&
        (shapes.some((s) => s.sheet_id === st.id) ||
          markups.some((m) => m.sheet_id === st.id) ||
          approvals.some((a) => a.sheet_id === st.id))
    );
    if (stitchWithTakeoffs) {
      const msg = `Cannot delete "${target}": it belongs to stitched plan "${stitchWithTakeoffs.name || stitchWithTakeoffs.id}" which has active takeoffs. Remove stitch takeoffs first.`;
      alert(msg);
      setCommitMsg(msg);
      return;
    }
    const { file, page: targetPage } = parseSheetKey(target);
    const origBytes = await store.loadPdfData(file);
    const { PDFDocument } = await import("pdf-lib");
    const srcDoc = await PDFDocument.load(new Uint8Array(origBytes), { updateMetadata: false });
    const curDocPages = srcDoc.getPageCount();
    if (curDocPages <= 1) {
      alert("Cannot delete the only page in the document. Close the PDF instead.");
      return;
    }

    const takeoffsOnPage =
      shapes.filter((s) => s.sheet_id === target).length +
      markups.filter((m) => m.sheet_id === target).length +
      approvals.filter((a) => a.sheet_id === target).length;

    if (takeoffsOnPage > 0) {
      const ok = window.confirm(
        `Sheet "${target}" has ${takeoffsOnPage} takeoff measurement(s)/markup(s). Delete this page? (Undo restores both page and takeoffs)`
      );
      if (!ok) return;
    }

    try {
      setCommitMsg(`Deleting ${target}…`);
      const origBytes = await store.loadPdfData(file);
      const { PDFDocument } = await import("pdf-lib");
      const srcDoc = await PDFDocument.load(new Uint8Array(origBytes), { updateMetadata: false });
      const curDocPages = srcDoc.getPageCount();
      if (curDocPages <= 1) {
        alert("Cannot delete the only page in the document. Close the PDF instead.");
        return;
      }
      const newBytes = await deletePdfPage(new Uint8Array(origBytes), targetPage);

      const prevShapes = shapes;
      const prevMarkups = markups;
      const prevApprovals = approvals;
      const prevScales = scales;
      const prevScaleSources = scaleSources;
      const prevScaleUnconfirmed = scaleUnconfirmed;
      const prevDetectedScales = detectedScales;
      const prevDoorAnswers = doorAnswers;
      const prevSheetLevels = sheetLevels;
      const prevSheetGroup = sheetGroup;
      const prevLastGroup = lastGroup;
      const prevOpenTabs = openTabs;
      const prevStitches = stitches;
      const prevLayerOverrides = layerOverrides;
      const prevRfis = rfis;
      const prevRotations = sheetRotationsRef.current;

      const remap = buildKeyRemap(
        file,
        (p) => (p === targetPage ? null : p > targetPage ? p - 1 : p),
        curDocPages
      );
      const remapped = remapWorkspaceState(
        {
          shapes, markups, approvals, scales, scaleSources, scaleUnconfirmed, detectedScales,
          sheetLevels, sheetGroup, lastGroup, openTabs, stitches, layerOverrides, rfis,
          sheetRotations: prevRotations, doorAnswers,
        },
        remap
      );

      await store.addPdf(new File([newBytes], file, { type: "application/pdf" }));
      evictDoc(file);
      forgetPages([file]);
      dropDoorReads(file);

      setShapes(remapped.shapes);
      setMarkups(remapped.markups);
      setApprovals(remapped.approvals);
      setScales(remapped.scales);
      setScaleSources(remapped.scaleSources);
      setScaleUnconfirmed(remapped.scaleUnconfirmed);
      setDetectedScales(remapped.detectedScales || {});
      setDoorAnswers(remapped.doorAnswers || {});
      setSheetLevels(remapped.sheetLevels);
      setSheetGroup(remapped.sheetGroup);
      setLastGroup(remapped.lastGroup);
      setOpenTabs(remapped.openTabs);
      setStitches(remapped.stitches);
      setLayerOverrides(remapped.layerOverrides);
      setRfis(remapped.rfis);
      saveSheetRotations(remapped.sheetRotations || {});

      const nextPage = Math.max(1, Math.min(targetPage, curDocPages - 1));
      setPage(nextPage);

      undoStackRef.current = [
        ...undoStackRef.current,
        {
          family: "page_tool",
          undo: async () => {
            saveSheetRotations(prevRotations);
            await store.addPdf(new File([origBytes], file, { type: "application/pdf" }));
            evictDoc(file);
            forgetPages([file]);
            dropDoorReads(file);
            setShapes(prevShapes);
            setMarkups(prevMarkups);
            setApprovals(prevApprovals);
            setScales(prevScales);
            setScaleSources(prevScaleSources);
            setScaleUnconfirmed(prevScaleUnconfirmed);
            setDetectedScales(prevDetectedScales);
            setDoorAnswers(prevDoorAnswers);
            setSheetLevels(prevSheetLevels);
            setSheetGroup(prevSheetGroup);
            setLastGroup(prevLastGroup);
            setOpenTabs(prevOpenTabs);
            setStitches(prevStitches);
            setLayerOverrides(prevLayerOverrides);
            setRfis(prevRfis);
            setDocEpoch((e) => e + 1);
            await refreshSheets();
            goToSheet(target);
            setCommitMsg(`Restored page ${targetPage} and its takeoffs.`);
          },
          redo: async () => {
            await deleteCurrentSheet(target);
          },
        },
      ];

      setDocEpoch((e) => e + 1);
      await refreshSheets();
      setCommitMsg(`Deleted page ${targetPage} from ${file}. ⌘Z restores it.`);
    } catch (e) {
      setCommitMsg(`Couldn't delete page: ${e?.message || e}`);
    }
  };

  const reorderDocumentPages = async (fileName, fromPage, toPage) => {
    const file = fileName || active;
    if (!file || fromPage === toPage) return;
    try {
      setCommitMsg(`Reordering pages in ${file}…`);
      const origBytes = await store.loadPdfData(file);
      const { PDFDocument } = await import("pdf-lib");
      const srcDoc = await PDFDocument.load(new Uint8Array(origBytes), { updateMetadata: false });
      const totalPages = srcDoc.getPageCount();
      if (totalPages <= 1) return;

      const order = Array.from({ length: totalPages }, (_, i) => i + 1);
      const [moved] = order.splice(fromPage - 1, 1);
      order.splice(toPage - 1, 0, moved);

      const reorderedBytes = await reorderPdfPages(new Uint8Array(origBytes), order);

      const prevShapes = shapes;
      const prevMarkups = markups;
      const prevApprovals = approvals;
      const prevScales = scales;
      const prevScaleSources = scaleSources;
      const prevScaleUnconfirmed = scaleUnconfirmed;
      const prevDetectedScales = detectedScales;
      const prevDoorAnswers = doorAnswers;
      const prevSheetLevels = sheetLevels;
      const prevSheetGroup = sheetGroup;
      const prevLastGroup = lastGroup;
      const prevOpenTabs = openTabs;
      const prevStitches = stitches;
      const prevLayerOverrides = layerOverrides;
      const prevRfis = rfis;
      const prevRotations = sheetRotationsRef.current;

      const oldToNew = new Map();
      order.forEach((oldP, idx) => oldToNew.set(oldP, idx + 1));
      const remap = buildKeyRemap(file, (oldP) => oldToNew.get(oldP), totalPages);
      const remapped = remapWorkspaceState(
        {
          shapes, markups, approvals, scales, scaleSources, scaleUnconfirmed, detectedScales,
          sheetLevels, sheetGroup, lastGroup, openTabs, stitches, layerOverrides, rfis,
          sheetRotations: prevRotations, doorAnswers,
        },
        remap
      );

      await store.addPdf(new File([reorderedBytes], file, { type: "application/pdf" }));
      evictDoc(file);
      forgetPages([file]);
      dropDoorReads(file);

      setShapes(remapped.shapes);
      setMarkups(remapped.markups);
      setApprovals(remapped.approvals);
      setScales(remapped.scales);
      setScaleSources(remapped.scaleSources);
      setScaleUnconfirmed(remapped.scaleUnconfirmed);
      setDetectedScales(remapped.detectedScales || {});
      setDoorAnswers(remapped.doorAnswers || {});
      setSheetLevels(remapped.sheetLevels);
      setSheetGroup(remapped.sheetGroup);
      setLastGroup(remapped.lastGroup);
      setOpenTabs(remapped.openTabs);
      setStitches(remapped.stitches);
      setLayerOverrides(remapped.layerOverrides);
      setRfis(remapped.rfis);
      saveSheetRotations(remapped.sheetRotations || {});

      undoStackRef.current = [
        ...undoStackRef.current,
        {
          family: "page_tool",
          undo: async () => {
            saveSheetRotations(prevRotations);
            await store.addPdf(new File([origBytes], file, { type: "application/pdf" }));
            evictDoc(file);
            forgetPages([file]);
            dropDoorReads(file);
            setShapes(prevShapes);
            setMarkups(prevMarkups);
            setApprovals(prevApprovals);
            setScales(prevScales);
            setScaleSources(prevScaleSources);
            setScaleUnconfirmed(prevScaleUnconfirmed);
            setDetectedScales(prevDetectedScales);
            setDoorAnswers(prevDoorAnswers);
            setSheetLevels(prevSheetLevels);
            setSheetGroup(prevSheetGroup);
            setLastGroup(prevLastGroup);
            setOpenTabs(prevOpenTabs);
            setStitches(prevStitches);
            setLayerOverrides(prevLayerOverrides);
            setRfis(prevRfis);
            setDocEpoch((e) => e + 1);
            await refreshSheets();
            goToSheet(formatSheetKey(file, fromPage));
            setCommitMsg(`Undid page reorder in ${file}.`);
          },
          redo: async () => {
            await reorderDocumentPages(file, fromPage, toPage);
          },
        },
      ];

      setDocEpoch((e) => e + 1);
      await refreshSheets();
      setCommitMsg(`Reordered ${file} (page ${fromPage} → ${toPage}). Takeoffs followed.`);
    } catch (e) {
      setCommitMsg(`Couldn't reorder pages: ${e?.message || e}`);
    }
  };

  const extractPageRange = async (fileName = active) => {
    const file = fileName || active;
    if (!file) return;
    const origBytes = await store.loadPdfData(file);
    const { PDFDocument } = await import("pdf-lib");
    const srcDoc = await PDFDocument.load(new Uint8Array(origBytes), { updateMetadata: false });
    const totalPages = srcDoc.getPageCount();

    const input = window.prompt(
      `Enter page numbers or ranges to extract (1-${totalPages}), e.g. 1-2, 4:`,
      String(page)
    );
    if (!input) return;

    const pages = new Set();
    for (const part of input.split(/[\s,]+/)) {
      if (!part) continue;
      const m = part.match(/^(\d+)(?:-(\d+))?$/);
      if (!m) continue;
      const s = parseInt(m[1], 10);
      const e = m[2] ? parseInt(m[2], 10) : s;
      for (let p = Math.min(s, e); p <= Math.max(s, e); p++) {
        if (p >= 1 && p <= totalPages) pages.add(p);
      }
    }
    const pageList = [...pages].sort((a, b) => a - b);
    if (!pageList.length) {
      alert("No valid pages specified.");
      return;
    }

    try {
      setCommitMsg(`Extracting ${pageList.length} page(s) from ${file}…`);
      const extractedBytes = await extractPdfPages(new Uint8Array(origBytes), pageList);
      const baseName = file.replace(/\.pdf$/i, "");
      const outName = `${baseName}_extracted.pdf`;
      const otkName = `${baseName}_extracted.otk`;

      const remap = new Map();
      for (let p = 1; p <= totalPages; p++) {
        const oldKey = formatSheetKey(file, p);
        const idx = pageList.indexOf(p);
        remap.set(oldKey, idx >= 0 ? formatSheetKey(outName, idx + 1) : null);
      }
      for (const sh of sheets) {
        if (sh.name !== file) {
          const docB = await store.loadPdfData(sh.name);
          const docD = await PDFDocument.load(new Uint8Array(docB), { updateMetadata: false });
          const count = docD.getPageCount();
          for (let p = 1; p <= count; p++) {
            remap.set(formatSheetKey(sh.name, p), null);
          }
        }
      }

      const carriedState = remapWorkspaceState(
        {
          shapes, markups, approvals, scales, scaleSources, scaleUnconfirmed, detectedScales,
          sheetLevels, layerOverrides, rfis, stitches, doorAnswers,
        },
        remap
      );

      const extractedPayload = buildPayload({
        project_name: `${projectName || "project"} - Extracted`,
        sheets: Object.entries(carriedState.scales || {}).map(([sheet_id, units_per_px]) =>
          sheetEntry({
            sheet_id,
            units_per_px,
            scale_source: carriedState.scaleSources?.[sheet_id],
            scale_confirmed: carriedState.scaleUnconfirmed?.[sheet_id],
          })
        ),
        shapes: carriedState.shapes || [],
        markups: carriedState.markups || [],
        approvals: carriedState.approvals || [],
        rfis: carriedState.rfis || [],
        sheet_levels: carriedState.sheetLevels || {},
        layer_overrides: carriedState.layerOverrides || {},
        sheet_group: [],
        sheet_tabs: [outName],
        stitches: carriedState.stitches || [],
        door_answers: carriedState.doorAnswers || carriedState.door_answers || {},
      });

      const otkData = await buildProjectArchive({
        takeoff: extractedPayload,
        sheets: [{ name: outName }],
        loadPdfData: async () => extractedBytes,
        projectName: `${projectName || "project"} - Extracted`,
        onProgress: setCommitMsg,
      });

      // Download PDF
      const pdfBlob = new Blob([extractedBytes], { type: "application/pdf" });
      const pdfUrl = URL.createObjectURL(pdfBlob);
      const aPdf = document.createElement("a");
      aPdf.href = pdfUrl;
      aPdf.download = outName;
      document.body.appendChild(aPdf);
      aPdf.click();
      aPdf.remove();
      setTimeout(() => URL.revokeObjectURL(pdfUrl), 1000);

      // Download .otk
      downloadArchive(otkName, otkData);

      // Open project remains completely unchanged
      setCommitMsg(`Extracted ${pageList.length} page(s) to ${outName} and ${otkName}. Current project unchanged.`);
    } catch (e) {
      setCommitMsg(`Couldn't extract pages: ${e?.message || e}`);
    }
  };

  const mergePdfSets = async () => {
    if (sheets.length < 2) {
      alert("Open at least 2 PDF files to merge them.");
      return;
    }
    const outName = `${(projectName || "merged").trim().replace(/[^\w.\- ]+/g, "") || "merged"}_set.pdf`;
    try {
      setCommitMsg(`Merging ${sheets.length} PDFs into ${outName}…`);
      const byteList = [];
      const sourceDocs = [];
      const { PDFDocument } = await import("pdf-lib");
      for (const s of sheets) {
        const b = await store.loadPdfData(s.name);
        const u8 = new Uint8Array(b);
        byteList.push(u8);
        const doc = await PDFDocument.load(u8, { updateMetadata: false });
        sourceDocs.push({ name: s.name, pageCount: doc.getPageCount(), bytes: u8 });
      }

      const mergedBytes = await mergePdfDocuments(byteList);
      let curNewPage = 1;
      const remap = new Map();
      for (const s of sourceDocs) {
        for (let p = 1; p <= s.pageCount; p++) {
          remap.set(formatSheetKey(s.name, p), formatSheetKey(outName, curNewPage));
          curNewPage++;
        }
      }

      const prevShapes = shapes;
      const prevMarkups = markups;
      const prevApprovals = approvals;
      const prevScales = scales;
      const prevScaleSources = scaleSources;
      const prevScaleUnconfirmed = scaleUnconfirmed;
      const prevDetectedScales = detectedScales;
      const prevDoorAnswers = doorAnswers;
      const prevSheetLevels = sheetLevels;
      const prevSheetGroup = sheetGroup;
      const prevLastGroup = lastGroup;
      const prevOpenTabs = openTabs;
      const prevStitches = stitches;
      const prevLayerOverrides = layerOverrides;
      const prevRfis = rfis;
      const prevRotations = sheetRotationsRef.current;
      const prevActive = active;
      const prevPage = page;

      const remapped = remapWorkspaceState(
        {
          shapes, markups, approvals, scales, scaleSources, scaleUnconfirmed, detectedScales,
          sheetLevels, sheetGroup, lastGroup, openTabs, stitches, layerOverrides, rfis,
          sheetRotations: prevRotations, doorAnswers,
        },
        remap
      );

      // Merge replaces its source files in one undoable step:
      for (const s of sourceDocs) {
        await store.removePdf(s.name);
        evictDoc(s.name);
      }
      await store.addPdf(new File([mergedBytes], outName, { type: "application/pdf" }));
      evictDoc(outName);
      forgetPages([...sourceDocs.map((s) => s.name), outName]);
      dropDoorReads([...sourceDocs.map((s) => s.name), outName]);

      setShapes(remapped.shapes);
      setMarkups(remapped.markups);
      setApprovals(remapped.approvals);
      setScales(remapped.scales);
      setScaleSources(remapped.scaleSources);
      setScaleUnconfirmed(remapped.scaleUnconfirmed);
      setDetectedScales(remapped.detectedScales || {});
      setDoorAnswers(remapped.doorAnswers || {});
      setSheetLevels(remapped.sheetLevels);
      setSheetGroup(remapped.sheetGroup);
      setLastGroup(remapped.lastGroup);
      setOpenTabs(remapped.openTabs.length ? remapped.openTabs : [outName]);
      setStitches(remapped.stitches);
      setLayerOverrides(remapped.layerOverrides);
      setRfis(remapped.rfis);
      saveSheetRotations(remapped.sheetRotations || {});

      undoStackRef.current = [
        ...undoStackRef.current,
        {
          family: "page_tool",
          undo: async () => {
            saveSheetRotations(prevRotations);
            await store.removePdf(outName);
            evictDoc(outName);
            for (const s of sourceDocs) {
              await store.addPdf(new File([s.bytes], s.name, { type: "application/pdf" }));
              evictDoc(s.name);
            }
            forgetPages([...sourceDocs.map((s) => s.name), outName]);
            dropDoorReads([...sourceDocs.map((s) => s.name), outName]);
            setShapes(prevShapes);
            setMarkups(prevMarkups);
            setApprovals(prevApprovals);
            setScales(prevScales);
            setScaleSources(prevScaleSources);
            setScaleUnconfirmed(prevScaleUnconfirmed);
            setDetectedScales(prevDetectedScales);
            setDoorAnswers(prevDoorAnswers);
            setSheetLevels(prevSheetLevels);
            setSheetGroup(prevSheetGroup);
            setLastGroup(prevLastGroup);
            setOpenTabs(prevOpenTabs);
            setStitches(prevStitches);
            setLayerOverrides(prevLayerOverrides);
            setRfis(prevRfis);
            setDocEpoch((e) => e + 1);
            await refreshSheets();
            setActive(prevActive);
            setPage(prevPage);
            setCommitMsg(`Undid merge: restored original ${sourceDocs.length} files and takeoffs.`);
          },
          redo: async () => {
            await mergePdfSets();
          },
        },
      ];

      setDocEpoch((e) => e + 1);
      await refreshSheets();
      setActive(outName);
      setPage(1);
      setCommitMsg(`Merged ${sheets.length} files into ${outName} (${curNewPage - 1} pages).`);
      setCommitMsg(`Merged ${sourceDocs.length} files into ${outName} (${curNewPage - 1} pages). Takeoffs remapped.`);
    } catch (e) {
      setCommitMsg(`Couldn't merge documents: ${e?.message || e}`);
    }
  };

  const insertPagesFromPdf = () => {
    if (!active) return;
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".pdf";
    input.onchange = async (e) => {
      const file = e.target?.files?.[0];
      if (!file) return;
      try {
        setCommitMsg(`Inserting pages from ${file.name}…`);
        const insertBytes = new Uint8Array(await file.arrayBuffer());
        const curBytes = new Uint8Array(await store.loadPdfData(active));
        const res = await insertPdfPages(curBytes, insertBytes, page);

        const { PDFDocument } = await import("pdf-lib");
        const activeDoc = await PDFDocument.load(curBytes, { updateMetadata: false });
        const curDocPages = activeDoc.getPageCount();
        const insertedCount = res.insertedCount;

        const prevShapes = shapes;
        const prevMarkups = markups;
        const prevApprovals = approvals;
        const prevScales = scales;
        const prevScaleSources = scaleSources;
        const prevScaleUnconfirmed = scaleUnconfirmed;
        const prevDetectedScales = detectedScales;
        const prevDoorAnswers = doorAnswers;
        const prevSheetLevels = sheetLevels;
        const prevSheetGroup = sheetGroup;
        const prevLastGroup = lastGroup;
        const prevOpenTabs = openTabs;
        const prevStitches = stitches;
        const prevLayerOverrides = layerOverrides;
        const prevRfis = rfis;
        const prevRotations = sheetRotationsRef.current;

        const remap = buildKeyRemap(
          active,
          (p) => (p <= page ? p : p + insertedCount),
          curDocPages
        );
        const remapped = remapWorkspaceState(
          {
            shapes, markups, approvals, scales, scaleSources, scaleUnconfirmed, detectedScales,
            sheetLevels, sheetGroup, lastGroup, openTabs, stitches, layerOverrides, rfis,
            sheetRotations: prevRotations, doorAnswers,
          },
          remap
        );

        await store.addPdf(new File([res.pdfBytes], active, { type: "application/pdf" }));
        evictDoc(active);
        forgetPages([active]);
        dropDoorReads(active);

        setShapes(remapped.shapes);
        setMarkups(remapped.markups);
        setApprovals(remapped.approvals);
        setScales(remapped.scales);
        setScaleSources(remapped.scaleSources);
        setScaleUnconfirmed(remapped.scaleUnconfirmed);
        setDetectedScales(remapped.detectedScales || {});
        setDoorAnswers(remapped.doorAnswers || {});
        setSheetLevels(remapped.sheetLevels);
        setSheetGroup(remapped.sheetGroup);
        setLastGroup(remapped.lastGroup);
        setOpenTabs(remapped.openTabs);
        setStitches(remapped.stitches);
        setLayerOverrides(remapped.layerOverrides);
        setRfis(remapped.rfis);
        saveSheetRotations(remapped.sheetRotations || {});

        undoStackRef.current = [
          ...undoStackRef.current,
          {
            family: "page_tool",
            undo: async () => {
              saveSheetRotations(prevRotations);
              await store.addPdf(new File([curBytes], active, { type: "application/pdf" }));
              evictDoc(active);
              forgetPages([active]);
              dropDoorReads(active);
              setShapes(prevShapes);
              setMarkups(prevMarkups);
              setApprovals(prevApprovals);
              setScales(prevScales);
              setScaleSources(prevScaleSources);
              setScaleUnconfirmed(prevScaleUnconfirmed);
              setDetectedScales(prevDetectedScales);
              setDoorAnswers(prevDoorAnswers);
              setSheetLevels(prevSheetLevels);
              setSheetGroup(prevSheetGroup);
              setLastGroup(prevLastGroup);
              setOpenTabs(prevOpenTabs);
              setStitches(prevStitches);
              setLayerOverrides(prevLayerOverrides);
              setRfis(prevRfis);
              setDocEpoch((e) => e + 1);
              await refreshSheets();
              setCommitMsg(`Undid page insertion in ${active}.`);
            },
            redo: async () => {
              // file picker cannot be triggered programmatically without user gesture
            },
          },
        ];

        setDocEpoch((e) => e + 1);
        await refreshSheets();
        setCommitMsg(`Inserted ${insertedCount} page(s) after page ${page}.`);
      } catch (err) {
        setCommitMsg(`Couldn't insert pages: ${err?.message || err}`);
      }
    };
    input.click();
  };

  const exportEditedPdf = async () => {
    if (!active) {
      setCommitMsg("No active plan to export.");
      return;
    }
    try {
      const bytes = await store.loadPdfData(active);
      const base = active.replace(/\.pdf$/i, "");
      downloadArchive(`${base}-edited.pdf`, new Uint8Array(bytes));
      setCommitMsg(`Exported ${base}-edited.pdf.`);
    } catch (e) {
      setCommitMsg(`Couldn't export PDF: ${e?.message || e}`);
    }
  };

  const clearWorkspace = async () => {
    const names = sheets.map((s) => s.name);
    let saved = false;
    if (shapes.length || conditions.length || markups.length) {
      try { await store.saveSnapshot(`Before Clear workspace — ${new Date().toLocaleString()}`, buildPayload()); saved = true; }
      catch { /* best-effort (quota) — clearing continues; message says what happened */ }
    }
    for (const n of names) { try { await store.removePdf(n); } catch { /* already gone */ } evictDoc(n); }
    forgetPages(names);
    releaseThumbs(thumbCacheRef.current);
    setGalleryLabels({});
    setDetectedScales({});
    reconcileAfterRemoval("", await refreshSheets());
    restoreSavedPayload(emptyAnnotations());
    setCommitMsg(saved
      ? `Workspace cleared — ${names.length} PDF${names.length === 1 ? "" : "s"} removed. The takeoff was snapshotted first: Revisions → restore brings it back (re-open the same PDFs to see its shapes).`
      : `Workspace cleared — ${names.length} PDF${names.length === 1 ? "" : "s"} removed.`);
  };

  // "Export project archive…" (#300) — the whole job as ONE portable .otk:
  // every stored plan's bytes plus the exact autosave payload. The other half
  // of the #285 pair: Export takeoff is the annotation record alone (open the
  // same PDF to restore); this is the archive that carries its own paper.
  const exportProjectArchive = async () => {
    if (!sheets.length) { setCommitMsg(uiText("Couldn't export project: no plans are open.")); return; }
    const base = (projectName || "project").trim().replace(/[^\w.\- ]+/g, "").replace(/\s+/g, "-").replace(/^[-.]+|[-.]+$/g, "") || "project";
    try {
      const data = await buildProjectArchive({
        takeoff: buildPayload(),
        sheets,
        loadPdfData: (n) => store.loadPdfData(n),
        projectName,
        onProgress: setCommitMsg,
      });
      downloadArchive(`${base}.otk`, data);
      setCommitMsg(uiText(`Exported ${base}.otk — ${sheets.length} PDF${sheets.length === 1 ? "" : "s"} + the full takeoff (${shapes.length} shape${shapes.length === 1 ? "" : "s"}). Self-contained: open it on any machine, or hand it to another estimator.`));
    } catch (e) {
      setCommitMsg(uiText(`Couldn't export project: ${e?.message || e}`));
    }
  };

  // Open a .otk (drop or file picker): REPLACE the workspace with the archived
  // project. Commit before risk — the current takeoff, if non-empty, is
  // snapshotted first so opening an archive is never a silent overwrite.
  const importProjectArchive = async (file) => {
    try {
      setCommitMsg(uiText(`Opening ${file.name}…`));
      const { takeoff, pdfs } = await parseProjectArchive(new Uint8Array(await file.arrayBuffer()));
      if (shapes.length || conditions.length || markups.length) {
        try { await store.saveSnapshot(`Before opening ${file.name} — ${new Date().toLocaleString()}`, buildPayload()); }
        catch { /* best-effort — the open continues; archives are additive to PDFs */ }
      }
      for (const f of pdfs) {
        setCommitMsg(uiText(`Restoring ${f.name}…`));
        await store.addPdf(f);        // same-name different-bytes archives a revision (CO-1), never a silent overwrite
        evictDoc(f.name);             // stale docs must re-read the restored bytes
      }
      forgetPages(pdfs.map((f) => f.name));
      setDocEpoch((e) => e + 1);
      await refreshSheets();
      restoreSavedPayload(takeoff);
      const n = Array.isArray(takeoff.shapes) ? takeoff.shapes.length : 0;
      setCommitMsg(formatMessage("Opened {0} — PDFs: {1}, takeoffs: {2}.{3}", [file.name, pdfs.length, n,
        shapes.length || conditions.length ? " " + uiText("Your previous takeoff was snapshotted — Revisions restores it.") : ""]));
    } catch (e) {
      setCommitMsg(String(e?.message || "").startsWith("Couldn't") ? e.message : `Couldn't open project: ${e?.message || e}`);
    }
  };

  // ── estimator profile (#299) — export / import / reset the working
  // environment (condition templates, materials, stamps, report setup),
  // never project data. Import and reset both DOWNLOAD the current profile
  // first: the receipt is the rollback (Import profile restores it), so
  // neither needs a second confirmation step.
  const refreshLibraries = async () => {
    const tpl = await store.loadTemplates().catch(() => []);
    templatesRef.current = tpl; setTemplates(tpl);
    setMatLib(await store.loadMaterialLibrary().catch(() => []));
    const lib = await store.loadStampLibrary().catch(() => ({ stamps: [], sets: [] }));
    stampLibRef.current = lib; setStampLib(lib);
  };
  const profileSummary = (p) =>
    `${(p.condition_templates || []).length} condition template${(p.condition_templates || []).length === 1 ? "" : "s"}, ${(p.material_library || []).length} material${(p.material_library || []).length === 1 ? "" : "s"}, ${(p.stamp_library?.stamps || []).length} stamp${(p.stamp_library?.stamps || []).length === 1 ? "" : "s"}, ${(p.report_templates || []).length} report template${(p.report_templates || []).length === 1 ? "" : "s"}`;
  const exportProfileFile = async () => {
    try {
      const p = await buildProfile();
      downloadText("opentakeoff-profile.otprofile", JSON.stringify(p, null, 2), "application/json");
      setCommitMsg(uiText(`Exported opentakeoff-profile.otprofile — ${profileSummary(p)}. Import it on another machine to carry your setup over.`));
    } catch (e) { setCommitMsg(uiText(`Couldn't export profile: ${e?.message || e}`)); }
  };
  const backupProfileFile = async () => {
    const backup = await buildProfile();
    downloadText("opentakeoff-profile-backup.otprofile", JSON.stringify(backup, null, 2), "application/json");
  };
  const importProfileFile = async (file) => {
    if (!file) return;
    try {
      const p = parseProfile(await file.text());
      if (!await chooseImportUnits()) return;
      await backupProfileFile();
      const n = await applyProfile(p);
      await refreshLibraries();
      setCommitMsg(uiText(`Applied profile${p.name ? ` "${p.name}"` : ""} — ${n.templates} condition template${n.templates === 1 ? "" : "s"}, ${n.materials} material${n.materials === 1 ? "" : "s"}, ${n.stamps} stamp${n.stamps === 1 ? "" : "s"}, ${n.reportTemplates} report template${n.reportTemplates === 1 ? "" : "s"}${n.company ? ", company setup" : ""}. Your previous setup downloaded as opentakeoff-profile-backup.otprofile.`));
    } catch (e) {
      setCommitMsg(String(e?.message || "").startsWith("Couldn't") ? e.message : `Couldn't apply profile: ${e?.message || e}`);
    }
  };
  const resetProfile = async () => {
    try {
      await backupProfileFile();
      await resetProfileDefaults();
      await refreshLibraries();
      setCommitMsg(uiText("Profile reset to OpenTakeoff defaults — your previous setup downloaded as opentakeoff-profile-backup.otprofile (Import profile restores it). Project takeoffs are untouched."));
    } catch (e) { setCommitMsg(uiText(`Couldn't reset profile: ${e?.message || e}`)); }
  };

  // markups MUST be in the deps (a cloud/callout/text or an RFI link is real work);
  // omitting it dropped markup saves and could persist a stale markups array.
  useEffect(() => {
    if (!hydrated.current) return;
    // Swallow the hydration echo: the first run after hydrate() carries no user
    // edit (only the fresh-identity setState from loading). Arm and skip it so a
    // link-open reads without writing; every later run is a real edit and saves.
    if (!savesArmed.current) { savesArmed.current = true; return; }
    // Swallow a reconcile re-hydrate's echo (see suppressNextSave): the adopted
    // content is already canonical locally and on Drive at its own rev — re-pushing
    // it would churn revs (seed) or spuriously conflict + loser-snapshot (adopt).
    if (suppressNextSave.current) { suppressNextSave.current = false; return; }
    // A reconcile adopted a remote winner into local (synced_rev is already advanced)
    // but the canvas is still showing the SUPERSEDED pre-adopt content because we
    // deferred the render while busy (Slice 5b Case 2). Persisting/pushing now would
    // send stale content at the winner's rev and silently clobber it. Skip entirely
    // until the idle-drain re-hydrates the winner; any edits made on this superseded
    // canvas are dropped by that re-hydrate (visible supersession, not silent loss —
    // the co-editing casualty the rollout forbids). The drain clears the flag.
    if (remotePendingRender.current) return;
    const payload = buildPayload();
    saveDataRef.current = payload;          // keep the freshest payload for an unmount flush
    setSaveState("saving");
    const t = setTimeout(() => {
      // A render was deferred AFTER this save was scheduled (its closure captured the
      // pre-adopt payload) → don't push stale over the winner; go idle so the canvas
      // can drain and re-hydrate. Closes the last pre-scheduled-save loss window.
      if (remotePendingRender.current) { setSaveState("idle"); return; }
      store.saveAnnotations(payload).then(() => setSaveState("saved")).catch((e) => {
        // surface the failure rather than dropping to a silent "idle" — with inline
        // image markups a QuotaExceededError is a realistic failure mode, and a
        // silent one loses the WHOLE payload (shapes, quantities, everything) with
        // no signal. Stale-tab keeps its sticky lockout copy; anything else (quota,
        // disk) shows the actionable friendlyStoreError text.
        setCommitMsg(isStaleTabError(e) ? STALE_TAB_MESSAGE : friendlyStoreError(e));
        setSaveState("idle");
      });
    }, 700);
    return () => clearTimeout(t);
    // buildPayload is intentionally omitted: this dep list IS the exact set of
    // state it serializes, so listing buildPayload (a new identity each render)
    // would fire a save on every render instead of only on a real change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shapes, conditions, conditionColumns, shapeLabels, palette, scales, scaleSources, scaleUnconfirmed, markups, approvals, rfis, proposals, conditionEditProposals, rules, provCounters, sheetGroup, sheetLevels, layerOverrides, lastGroup, openTabs, stitches, projectName, clientInfo, estimateSettings, bidProposal, units, splitView, doorAnswers]);
  useEffect(() => { saveStateRef.current = saveState; }, [saveState]);

  // Flush a pending debounced save on navigate-away (unmount), and warn before a
  // tab close while a save is in flight — so the tail of a tracing session is never lost.
  useEffect(() => {
    // Pin the store this canvas mounted against: on a client-side exit from a
    // cloud project, React runs the PARENT (ProjectGate) cleanup first, which
    // resets the live `store` binding to localStore — flushing through the live
    // binding here would write the cloud project's annotations into the local
    // store. In-life saves keep the live binding (it never swaps mid-mount).
    const mountStore = store;
    const onBeforeUnload = (e) => { if (saveStateRef.current === "saving") { e.preventDefault(); e.returnValue = ""; } };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      if (hydrated.current && saveStateRef.current === "saving" && saveDataRef.current) {
        mountStore.saveAnnotations(saveDataRef.current).catch(() => { });   // best-effort flush
      }
    };
  }, []);

  // ── Local-first sync bridge (Slices 5a + 5b) ───────────────────────────────
  // On the opted-in path the active store carries a non-enumerable `syncBridge`
  // (main.jsx); on the legacy cloud path (and anonymous local) there is none, so
  // every handler below is a no-op and flag-off behavior is byte-identical.

  // The defer-gate predicate. computeBusy reads ONLY refs (busyStateRef, mirrored
  // from state every render, plus the interaction refs), so it is always fresh yet
  // stable to capture once — no re-registration null window. isCanvasBusy is the
  // pure, unit-tested core (lib/canvasBusy.js); it must report EVERY interaction mode
  // a mid-session re-hydrate would clobber (trace/calibrate/check, One-Click review,
  // a scheduled save, an active drag, the open text editor, an agent run and its
  // staged proposals — hydrate() wipes agentProposals and the
  // conditions a mid-run agent minted, so both defer exactly like One-Click review).
  // importReading: a schedule box read on-device — a hydrate that changes
  // groupSig would cancel the read, and an untouched download notice defers
  // sync like One-Click's `proposal`. ocrRead is set for the whole read, the
  // notice included; a notice opened by a page Read (#471) isn't counted.
  busyStateRef.current = { poly, calib, check, proposal, scaleGuide, prevScale, agentRunning, agentProposals, importReading: !!ocrRead };
  const computeBusy = () => isCanvasBusy({
    ...busyStateRef.current,
    saveState: saveStateRef.current,
    dragging: !!dragRef.current || !!ocDragRef.current,
    editing: editingRef.current,
  });

  // Register both reconcile handlers ONCE. onRemoteUpdate handles CASE 2: the store
  // adopted remote→local, then the canvas went busy in maybeFlush's ~2-IDB-write gap
  // before this fires. Re-check busy at APPLY time — if busy, DEFER the render (local
  // already equals remote on Drive; the idle-drain below re-hydrates) rather than
  // clobber the in-flight work; else suppress the echo and hydrate. EITHER branch
  // nulls saveDataRef so the unmount flush can't push a pre-adopt payload at a fresh
  // rev over the remote winner. (It does NOT stop an already-scheduled debounced save
  // firing stale — that is the documented residual, active-co-editing-only.)
  useEffect(() => {
    const bridge = store.syncBridge;
    if (!bridge) return;
    bridge.isBusy = computeBusy;
    bridge.onRemoteUpdate = (data) => {
      saveDataRef.current = null;
      if (computeBusy()) { remotePendingRender.current = true; return; }
      remotePendingRender.current = false; // this hydrate satisfies any earlier deferred render
      suppressNextSave.current = true;
      hydrate(data || {});
    };
    return () => { bridge.isBusy = null; bridge.onRemoteUpdate = null; };
    // computeBusy + hydrate are stable for a given mount (they read only refs / call
    // setters), so capture once; listing them would re-register every render, opening
    // a null window where an arriving reconcile is dropped.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Presence (#317): tell the heartbeat which sheet is open. Ref-mirrored so
  // the getter registers once (same discipline as the handlers above) yet
  // always reads the current sheet.
  const presenceSheetRef = useRef("");
  presenceSheetRef.current = sheetKey || "";
  useEffect(() => {
    const bridge = store.syncBridge;
    if (!bridge) return;
    bridge.getSheet = () => presenceSheetRef.current || null;
    return () => { bridge.getSheet = null; };
  }, []);

  // Idle-drain. When the canvas goes idle, drain BOTH defer paths:
  //   CASE 1 — the store deferred at its own gate (isBusy true → never adopted,
  //     pendingRemote held, local untouched): flushPending() adopts now and fires
  //     onRemoteUpdate → hydrate.
  //   CASE 2 — we deferred the render above: re-read LOCAL (freshest — the adopt, or a
  //     local edit the user saved during the busy window; stashing the remote data
  //     would silently clobber that saved edit) and hydrate.
  // `saveState` is in the deps because the last thing to clear on going idle is usually
  // the debounced save (saving→saved) — and it must gate re-hydrate anyway so a
  // committed trace's pending save lands before we re-read (CRITICAL-b).
  useEffect(() => {
    const bridge = store.syncBridge;
    if (!bridge || computeBusy()) return;
    let alive = true;
    (async () => {
      // Serialize: drain Case 1 FIRST so a store-deferred adopt lands (and its
      // onRemoteUpdate hydrates + clears remotePendingRender) before the Case 2
      // re-read — otherwise the re-read could race the adopt's IDB writes and read
      // stale local.
      await bridge.flushPending?.();
      // Re-check after the awaits: unmounted, or the user went busy again → bail and
      // leave remotePendingRender set so the NEXT idle retries (never a dropped render).
      if (!alive || !remotePendingRender.current || computeBusy()) return;
      try {
        const a = await store.loadAnnotations(); // freshest local: the adopt, or an interim saved edit
        // A concurrent store-side onRemoteUpdate may have hydrated + cleared the flag
        // during the await — don't double-hydrate (Finding 4).
        if (!alive || computeBusy() || !remotePendingRender.current) return;
        remotePendingRender.current = false;      // clear ONLY after a successful read
        suppressNextSave.current = true;
        hydrate(a || {});
      } catch { /* keep remotePendingRender → retry on the next idle, never drop it */ }
    })();
    return () => { alive = false; };
    // computeBusy/hydrate are stable (refs/setters); the deps below ARE the idle-
    // transition triggers. saveState catches the debounced-save clearing; idleTick
    // catches an interaction ref (drag/editor/scan) clearing with no state change.
    // agentRunning/agentProposals: the run finishing or the last proposal being
    // accepted/rejected is a busy→idle edge that must drain a held remote;
    // ocrRead: a schedule box's on-device read ending is one too.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [poly, calib, check, proposal, scaleGuide, prevScale, saveState, idleTick, agentRunning, agentProposals, ocrRead]);

  function fitToView(w, h) {
    const el = containerRef.current;
    if (!el) return setTfNow({ x: 0, y: 0, scale: 1 });
    const r = el.getBoundingClientRect();
    const scale = Math.min((r.width - 40) / w, (r.height - 40) / h, 1);
    setTfNow({ x: (r.width - w * scale) / 2, y: (r.height - h * scale) / 2, scale });
  }

  const toImage = useCallback((cx, cy) => {
    const r = containerRef.current.getBoundingClientRect();
    const t = tfRef.current;
    return [(cx - r.left - t.x) / t.scale, (cy - r.top - t.y) / t.scale];
  }, []);

  // memoized so the wheel-zoom effect can list it as a dep and still bind its
  // listener once — a plain function would give a new identity each render and
  // re-subscribe the (passive:false) wheel handler on every render.
  const zoomAround = useCallback((cx, cy, factor) => {
    const t = tfRef.current;
    const next = clamp(t.scale * factor);
    const k = next / t.scale;
    tfRef.current = { scale: next, x: cx - (cx - t.x) * k, y: cy - (cy - t.y) * k };
    applyTf(); scheduleSync();
  }, [applyTf, scheduleSync]);

  // wheel: the DEVICE decides between pan and zoom — no toggle, no mode.
  // Continuous trackpad scroll PANS both axes (the two-finger instinct every
  // Mac user brings); a discrete mouse-wheel notch ZOOMS toward the cursor,
  // glided over a few frames so it doesn't step. Pinch (ctrl/meta) always
  // zooms at its original immediate sensitivity; ⇧+wheel always pans.
  //
  // Device telling: the burst-OPENING event decides. macOS runs mouse wheels
  // through scroll acceleration, so the classic wheelDelta ±120 signature is
  // useless there (measured on real hardware: wheelDeltaY is exactly -3×deltaY
  // for BOTH devices). What separates them is the opening magnitude: a wheel
  // notch LANDS at full delta — |deltaY|≈12 minimum on macOS (acceleration
  // floor), ≈100 on Windows — while a trackpad gesture physically RAMPS from
  // finger contact (|deltaY| 0–2 at burst start, violent flicks included).
  // Line/page deltaMode is always a mouse (Firefox wheels). Classification is
  // carried while events keep arriving <300ms apart, so momentum tails keep
  // panning and a fast spin keeps zooming.
  useEffect(() => {
    const el = containerRef.current; if (!el) return;
    let glide = 0, gx = 0, gy = 0, raf = 0;
    let kind = "", kindUntil = 0;   // per-burst wheel-device classification
    const wheelKind = (e) => {
      const now = performance.now();
      if (kind && now < kindUntil) { kindUntil = now + 300; return kind; }
      kind = (e.deltaMode !== 0 || Math.abs(e.deltaY) >= 10) ? "mouse" : "trackpad";
      kindUntil = now + 300;
      return kind;
    };
    const step = () => {
      raf = 0;
      const d = Math.abs(glide) < 0.002 ? glide : glide * 0.35;
      glide -= d;
      if (d) {
        const r = el.getBoundingClientRect();
        zoomAround(gx - r.left, gy - r.top, Math.exp(d));
      }
      if (glide) {
        gestureUntilRef.current = performance.now() + GESTURE_MS;  // glide still moving = still a gesture
        raf = requestAnimationFrame(step);
      }
    };
    const onWheel = (e) => {
      if (editingRef.current) return;   // freeze pan/zoom while the inline editor is pinned to its anchor
      e.preventDefault();
      promoteStage();                   // gesture opening: composite the stage for cheap per-frame moves
      gestureUntilRef.current = performance.now() + GESTURE_MS;  // detail view waits for wheel quiet
      const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1;
      if (e.shiftKey) {
        const t = tfRef.current;
        tfRef.current = { ...t, x: t.x - e.deltaX * unit, y: t.y - e.deltaY * unit };
        applyTf(); scheduleSync();
        return;
      }
      if (e.ctrlKey || e.metaKey) {
        const r = el.getBoundingClientRect();
        zoomAround(e.clientX - r.left, e.clientY - r.top, Math.exp(-e.deltaY * 0.01));
        return;
      }
      if (wheelKind(e) === "trackpad") {
        // two-finger scroll = pan, both axes — the sheet follows the fingers
        const t = tfRef.current;
        tfRef.current = { ...t, x: t.x - e.deltaX * unit, y: t.y - e.deltaY * unit };
        applyTf(); scheduleSync();
        return;
      }
      glide += -e.deltaY * unit * 0.0012;            // one notch (~100) ≈ 12% zoom
      glide = Math.max(-1.2, Math.min(1.2, glide));  // cap queued zoom per direction
      gx = e.clientX; gy = e.clientY;
      if (!raf) raf = requestAnimationFrame(step);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => { el.removeEventListener("wheel", onWheel); if (raf) cancelAnimationFrame(raf); };
  }, [applyTf, scheduleSync, zoomAround, promoteStage]);

  // Space = temporary pan (any tool). Held during a schedule box's on-device
  // read, and kept from pressing a focused button (heldKeyWouldPress): on
  // keydown, which stops the press in Chromium (checked), and on keyup too,
  // where a button's Space press lands.
  useEffect(() => {
    const down = (e) => {
      if (ocrReadRef.current?.ocr) { if (heldKeyWouldPress(e.key, e.target)) e.preventDefault(); return; }
      if (e.code === "Space" && !e.repeat && e.target.tagName !== "INPUT") { spaceRef.current = true; if (containerRef.current) containerRef.current.style.cursor = "grab"; }
    };
    const up = (e) => {
      if (ocrReadRef.current?.ocr && heldKeyWouldPress(e.key, e.target)) e.preventDefault();
      if (e.code === "Space") { spaceRef.current = false; if (containerRef.current) containerRef.current.style.cursor = ""; }
    };
    window.addEventListener("keydown", down); window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, []);

  // Single-letter tool shortcuts (STACK-style) — suppressed while typing or
  // while a toolbar menu is open. ⌘-combos and 1–9 live in their own handlers.
  useEffect(() => {
    const onKey = (e) => {
      const tg = e.target.tagName;
      if (tg === "INPUT" || tg === "SELECT" || tg === "TEXTAREA") return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (menuDepthRef.current > 0) return;
      // held while a schedule box is read on-device: ⏎, g, f, ? must not act
      // behind (or open a dialog under) the coming download notice, and ⏎
      // must not press a focused button either (heldKeyWouldPress)
      if (ocrReadRef.current?.ocr) { if (heldKeyWouldPress(e.key, e.target)) e.preventDefault(); return; }
      // "?" opens the manual. Here rather than in its own listener so it
      // inherits this effect's guards — a "?" typed into a condition tag or
      // with a toolbar menu open must not pop a dialog over the work.
      if (e.key === "?") { e.preventDefault(); setGuideOpen(true); return; }
      if (e.key === "Enter") {
        // router offer confirm takes the key FIRST (RFC #59 slice 5): the
        // offer is the most recent thing the user was told ⏎ does, and it
        // auto-expires — so it can never contest ⏎ for long, and a pending
        // agent-proposal accept resumes the key the moment the offer clears
        if (agentOfferFnsRef.current?.pending()) { e.preventDefault(); agentOfferFnsRef.current.confirm(); return; }
        if (tool === "oneclick" && proposal?.regions.length) { e.preventDefault(); createProposal(); return; }
        const ok = !bowOpen && (((tool === "area" || tool === "deduct") && poly.length >= 3) || (tool === "zone" && poly.length >= 3 && !zoneTraceCross) || ((tool === "linear" || tool === "surface") && poly.length >= 2));
        if (ok) { e.preventDefault(); finishShape(); return; }
        // ⏎ with agent proposals pending on a visible sheet = accept them all —
        // the agent's analogue of one-click's Create gate. Only fires when no
        // trace/proposal claimed the key above, so mid-draw ⏎ is untouched.
        if (agentProposals.some((p) => panelKeySet.has(p.sheet_id))) { e.preventDefault(); acceptAllVisibleAgentProposals(); }
        return;
      }
      const lower = e.key.toLowerCase();
      if (viewRef.current === "gallery") return;
      if (lower === "g") { setView("gallery"); return; }
      if (lower === "f") { toggleFocusMode(); return; }
      if (e.key === "D" && e.shiftKey) { setTool("deduct-rect"); return; }
      // no `p` binding: pan is not a tool — drag open canvas, or Space/middle/right-drag
      // Q with a bendable trace in flight flips the straight/curve switch
      // instead of jumping to the Curve Line tool — switching tools mid-trace
      // would abandon the points already placed, so this binding can only be
      // an improvement on the one it shadows.
      if (lower === "q" && CURVABLE.has(tool) && poly.length) { setCurveMode((c) => !c); return; }
      // Symbol review (#264): while a sweep is under review the keyboard walks
      // the questions — one keystroke per answer, taking priority over tool
      // bindings (stopImmediatePropagation keeps the proposal-Enter handler,
      // registered after this one, from double-acting).
      if (sweepRef.current) {
        const sw = sweepRef.current;
        const hasOpen = sw.questions.some((q) => q.state === "open");
        if ((e.key === "Enter" || lower === "x") && hasOpen) {
          e.preventDefault(); e.stopImmediatePropagation();
          const verdict = e.key === "Enter" ? "accepted" : "dismissed";
          setSweep((s) => {
            const qs = s.questions.map((q, i) => (i === s.qIndex && q.state === "open" ? { ...q, state: verdict } : q));
            let j = s.qIndex;
            for (let i = 1; i <= qs.length; i++) { const k = (s.qIndex + i) % qs.length; if (qs[k].state === "open") { j = k; break; } }
            return { ...s, questions: qs, qIndex: j };
          });
          return;
        }
        if ((e.key === "ArrowRight" || e.key === "ArrowLeft") && hasOpen) {
          e.preventDefault(); e.stopImmediatePropagation();
          const dir = e.key === "ArrowRight" ? 1 : -1;
          setSweep((s) => {
            let j = s.qIndex;
            for (let i = 1; i <= s.questions.length; i++) { const k = (s.qIndex + dir * i + s.questions.length * i) % s.questions.length; if (s.questions[k].state === "open") { j = k; break; } }
            return { ...s, qIndex: j };
          });
          return;
        }
        if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); setSweep(null); return; }
      }
      // T — trace another one like the selected shape: its condition comes
      // active (reassign:false — the selected shape keeps its own quantities),
      // the straight/curve switch follows the record, and the tool that draws
      // that kind of shape arms (a four-corner axis-aligned ring re-arms
      // Rectangle, everything else its own tool — lib/repeatTool). The
      // selection drops the way a fresh trace expects. No selection, or a
      // markup selected: the key says what it wants instead of arming a
      // guess. Only reachable from Select — every other tool's T falls
      // through to nothing (the map below has no "t").
      if (lower === "t") {
        if (tool !== "select") return;
        if (poly.length) return;   // a trace in flight is never abandoned by a shortcut
        const sel = selectedId ? shapes.find((s) => s.id === selectedId) : null;
        const plan = sel ? repeatPlan(sel) : null;
        if (!plan) { setCommitMsg(uiText("Select a shape first — T arms its condition and the tool that drew it.")); return; }
        if (plan.conditionId && conditions.some((c) => c.id === plan.conditionId)) activateCondition(plan.conditionId, { reassign: false });
        setCurveMode(plan.curve);
        selectShape(null);
        setTool(plan.tool);
        const label = [...measureTools, ...cutTools].find((x) => x.id === plan.tool)?.label || plan.tool;
        const tag = condById[plan.conditionId]?.finish_tag;
        setCommitMsg(uiText(`${label} armed${tag ? ` under ${tag}` : ""}${plan.curve ? " · Curve" : ""} — trace the next one.`));
        return;
      }
      if (e.key === "]" && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        rotateCurrentSheet(90);
        return;
      }
      if (e.key === "[" && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        rotateCurrentSheet(270);
        return;
      }
      const map = { v: "select", a: "area", r: "rect", l: "linear", s: "surface", c: "count", d: "deduct", o: "oneclick", k: "check", h: "highlighter", n: "dimension", y: "symbol" };
      const t = map[lower];
      if (t === "oneclick" && !oneClickEnabled()) { setCommitMsg(ONE_CLICK_GATE_MESSAGE); return; }   // the gate (lib/gate.js)
      if (t) setTool(t);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tool, poly, proposal, agentProposals, activeCond, sheetGroup, sheetKey, shapes, scales, selectedId, conditions]);
  // ^ selectedId/conditions joined for T (repeat the selected shape): the
  //   handler reads the selected record and validates its condition id.
  // ^ shapes/scales joined the deps with the agent accept path (the delete-handler
  //   precedent): ⏎ accept dispatches an `add` against the CURRENT array, so a
  //   shapes change with no other dep change must re-subscribe this handler.

  // remember the last armed measure tool — the Measure menu face shows it
  useEffect(() => { if (MEASURE_TOOLS.some((t) => t.id === tool)) lastMeasureRef.current = tool; }, [tool]);

  // Number keys 1–9 switch the active condition (material) fast — through
  // activateCondition with reassign:false: a digit press has no visual
  // reassign affordance (unlike the panel row / strip button), so it must
  // never silently move a selected shape's quantities. It still dismisses a
  // live bulk selection, same as every activation surface. When the palette is
  // curated the digits follow PALETTE ORDER (the cobalt badges on the chips);
  // an un-pinned workspace falls back to condition-array order, so the shortcut
  // works out of the box before anyone pins anything.
  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "SELECT" || e.target.tagName === "TEXTAREA") return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;   // let ⌘/Ctrl+1..9 (native tab switch) through — mirror the letter handler
      if (menuDepthRef.current > 0) return;              // a toolbar menu is open; digits are paused like the letter shortcuts
      if (ocrReadRef.current?.ocr) return;               // held while a schedule box is read on-device
      const n = parseInt(e.key, 10);
      if (n < 1 || n > 9) return;
      const id = palette.length ? palette[n - 1] : conditions[n - 1]?.id;
      if (id) activateCondition(id, { reassign: false });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [conditions, palette, tool, selectedId]); // eslint-disable-line react-hooks/exhaustive-deps

  // Undo a wrong click: Backspace/Delete (or Cmd/Ctrl+Z) removes the last placed
  // point; Escape cancels the whole in-progress shape.
  useEffect(() => {
    const onKey = (e) => {
      const t = e.target.tagName;
      if (t === "INPUT" || t === "SELECT" || t === "TEXTAREA") return;
      if (viewRef.current === "gallery") return;
      // a schedule box read on-device holds these keys; Esc cancels the read
      // (the download notice, when it is up, takes Esc before this sees it).
      // Esc still ends a copy read (#471) exactly when the Escape branch
      // below would: its copy steps run only past the offer, ocSel and selVert.
      if (ocrReadRef.current?.ocr) {
        if (e.key === "Escape") {
          e.preventDefault();
          cancelImportRead();
          if (!agentOfferFnsRef.current?.pending() && !ocSel && selVert == null) { setCopyReceipt(receiptAfterEsc); copyGateRef.current.begin(); }
        }
        return;
      }
      if (e.key === "Backspace" || e.key === "Delete") {
        e.preventDefault();
        if (poly.length) { dropLastPoint(); }
        else if (ocSel && proposal) { deleteSelectedOcVertex(); }
        else if (proposal?.regions.length) { setProposal((pr) => { const rg = pr.regions.slice(0, -1); return rg.length ? { ...pr, regions: rg } : null; }); }
        else if (selVert != null && selectedId) { deleteSelectedShapeVertex(); }
        // route through deleteSelected — a reconciled Cut Out (#137) must
        // revert its hole out of the parent, keyboard and menu alike
        else if (selectedId) { deleteSelected(); }
        else if (selectedMarkupId && showMarkups) { deleteMarkup(selectedMarkupId); setSelectedMarkupId(null); }
        // pop ONLY the armed tool's pending points — calibrate and check both
        // keep two-click state (calib points even render while another tool is
        // armed), and an unguarded pop used to silently cross-slice the other
        // tool's points, on-screen or hidden
        else if (tool === "calibrate") { setCalib((c) => c.slice(0, -1)); }
        else if (tool === "check") { setCheck((c) => c.slice(0, -1)); }
      } else if (e.key === "Escape") { if (agentOfferFnsRef.current?.pending()) { agentOfferFnsRef.current.dismiss(); } else if (ocSel) { setOcSel(null); } else if (selVert != null) { setSelVert(null); } else { clearPoly(); setCalib([]); setCheck([]); setCheckStated(""); setScaleGuide(null); selectShape(null); setMarkupDraft(null); setProposal(null); setArmedStamp(null); setScheduleAnchor(null); setSymbolAnchor(null); setImageAnchor(null); setTextAnchor(null); setCopyReceipt(receiptAfterEsc); copyGateRef.current.begin(); setPlacingImageId(null); placeGrabRef.current = null; placeCrossSheetRef.current = null; setAlignPt(null); resetZone(); hlRef.current = null; if (hlPathRef.current) hlPathRef.current.style.display = "none"; } }
      // ⌘Z: the drawing context wins — mid-trace it still pops the last placed
      // point (with or without ⇧, matching the old behavior byte-for-byte);
      // only with no trace in progress does the command stack engage
      // (⌘Z = undo, ⇧⌘Z = redo).
      else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (poly.length) dropLastPoint();
        else if (e.shiftKey) redoShapeCommand();
        else undoShapeCommand();
      }
      else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "c") { if (selectedId) { e.preventDefault(); copySelected(); } }
      else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "v") { if (clipRef.current.length) { e.preventDefault(); pasteClipboard(); } }
      else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d") { if (selectedId) { e.preventDefault(); duplicateSelected(); } }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // approvals is a real dep: ⌘Z's undoShapeCommand closes over it (the
    // family branch), and a stale capture would undo against a pre-seal array.
  }, [tool, selectedId, selVert, selectedMarkupId, showMarkups, poly, proposal, ocSel, shapes, approvals, sheetKey, groupSig, scales, focusKey]); // eslint-disable-line react-hooks/exhaustive-deps

  // The typed "drawing says" value belongs to ONE completed two-point check.
  // The moment the measurement is no longer complete — third-click restart,
  // Backspace below two points — the stale value must not grade the NEXT span:
  // it would render an instant confident verdict against the previous
  // dimension's number and leave "Recalibrate to this" armed with it.
  useEffect(() => { if (check.length < 2 && checkStated) setCheckStated(""); }, [check.length]); // eslint-disable-line react-hooks/exhaustive-deps
  // Leaving the check tool discards the whole check: rendering is gated on
  // tool === "check", so surviving state would sit invisible and resurface —
  // stale points AND stale stated value — whenever K is pressed again.
  useEffect(() => { if (tool !== "check" && (check.length || checkStated)) { setCheck([]); setCheckStated(""); } }, [tool]); // eslint-disable-line react-hooks/exhaustive-deps
  // Leaving the zone tool clears the zone the same way — the outline and its
  // readout are a reading of the armed tool, never surviving state. The
  // in-progress trace itself must go too: `poly` is the SAME shared array
  // area/deduct/linear/surface commit from, so without this, a mid-trace
  // switch away from zone (a single-letter shortcut while zone has none of
  // its own, or the Zone button re-arming "select") leaves real zone points
  // sitting in `poly` for the NEXT tool's Enter/double-click to commit as a
  // persisted, priced shape — the ephemeral tool's own "nothing is saved"
  // contract broken. Only clear `poly` when the PREVIOUS tool was zone
  // (prevToolRef), not on every tool change — poly is shared, and switching
  // e.g. area → linear must not discard a legitimate in-progress trace.
  useEffect(() => {
    if (tool !== "zone") resetZone();
    if (prevToolRef.current === "zone" && tool !== "zone") clearPoly();
    prevToolRef.current = tool;
  }, [tool]);

  // ── pointer ────────────────────────────────────────────────────────────────
  function onPointerDown(e) {
    if (status !== "ready") return;
    // inline editor open: the blur that follows this click commits it; swallow the
    // canvas interaction so pan/zoom stays frozen and no stray point is placed
    if (editingRef.current) return;
    // Pan WITHOUT leaving the draw tool: middle-drag, right-drag, or Space-drag.
    // (There is no Pan tool — Select's open-canvas drag and the deferred-click
    // hold-drag below cover the rest of the modeless-pan doctrine.)
    if (e.button === 1 || e.button === 2 || spaceRef.current) {
      promoteStage();
      panRef.current = { sx: e.clientX, sy: e.clientY, ox: tfRef.current.x, oy: tfRef.current.y };
      e.currentTarget.setPointerCapture(e.pointerId);
      if (containerRef.current) containerRef.current.style.cursor = "grabbing";
      return;
    }
    if (e.button !== 0) return;   // only left-click places points
    // an image (re)placement is armed → this left-click drops it where it now sits
    // (onPointerMove has been centre-following the cursor). One click ends the mode.
    if (placingImageId) {
      const id = placingImageId;
      // Zero-movement cross-sheet place guard: onPointerMove's first-contact
      // grab (:3755) is the ONLY place that rewrites `sheet_id`/`at` onto the
      // target panel, and it only runs on a pointermove. Click Place, then
      // click the canvas again with NO intervening pointermove (cursor never
      // left this spot) and that grab never fires — placeGrabRef.current is
      // still null, so the image is still sitting on its ORIGIN sheet even
      // though the message below is about to say "Image placed." Mirror the
      // exact first-contact math here, keyed off THIS click's own position
      // (which — since nothing moved — is the same position onPointerMove
      // would have used), so a click-without-move still lands the image on
      // the sheet under the cursor. Same-sheet reposition never sets
      // placeCrossSheetRef, so this block is a no-op for that path.
      if (placeCrossSheetRef.current === id) {
        const q = toImage(e.clientX, e.clientY);
        const tp = panelAt(q[0]);
        if (tp?.img?.w && (!placeGrabRef.current || placeGrabRef.current.key !== tp.key)) {
          const cx = (q[0] - tp.xOffset) / tp.img.w, cy = q[1] / tp.img.h;
          setMarkups((ms) => ms.map((m) => (m.id === id ? { ...m, at: [cx, cy], sheet_id: tp.key } : m)));
        }
      }
      setPlacingImageId(null);
      placeGrabRef.current = null;
      placeCrossSheetRef.current = null;
      // Commit boundary for the place gesture (onPointerMove's centre-follow at
      // :3676 is the live PREVIEW and must stay unstamped): stamp updated_at here
      // so a cross-sheet place isn't silently reverted by a 3-way sync tie
      // (merge tiebreak is updated_at || created_at; equal created_at + no
      // updated_at ⇒ ties → remote wins ⇒ the move vanishes).
      updateMarkup(id, { updated_at: nowIso() });
      selectMarkup(id);
      setCommitMsg(uiText("Image placed."));
      return;
    }
    // snapRef/angleRef are drawing-tool aids maintained by moveCrosshair, which
    // bails for the Select tool — so in Select they'd be STALE. Select does its
    // own endpoint snap (ocSnap) on drop, so it always uses the raw cursor here;
    // otherwise a stale ref freezes the drag or jumps it on grab. The selection
    // boxes want the raw cursor too: a corner snapped to a vector vertex would
    // shift the box off what was aimed at. snapsToVectors is the one rule,
    // shared with moveCrosshair's preview.
    const rawCursor = !snapsToVectors(tool);
    const p = (!rawCursor && snapOn && snapRef.current) ? snapRef.current
      : (!rawCursor && angleOn && angleRef.current) ? angleRef.current
        : toImage(e.clientX, e.clientY);
    const fp = panelAt(p[0]);
    if (fp.key !== focusKey) setFocusKey(fp.key);
    if (tool === "highlighter") {
      // ink is freehand: raw coords (no snap/angle), drag paints — press-drag pan is
      // intentionally unavailable while armed (space/middle/right-drag still pan)
      const raw = toImage(e.clientX, e.clientY);
      hlRef.current = { pts: [raw], key: panelAt(raw[0]).key };
      if (hlPathRef.current) {
        const el = hlPathRef.current;
        const w = hlStyle.size / tfRef.current.scale;
        el.setAttribute("d", "");
        if (hlStyle.tip === "chisel") { el.setAttribute("fill", hlStyle.color); el.setAttribute("fill-opacity", darkModeRef.current ? 0.42 : 0.32); el.setAttribute("stroke", "none"); }
        else { el.setAttribute("fill", "none"); el.setAttribute("stroke", hlStyle.color); el.setAttribute("stroke-opacity", darkModeRef.current ? 0.42 : 0.32); el.setAttribute("stroke-width", w); el.setAttribute("stroke-linecap", "round"); el.setAttribute("stroke-linejoin", "round"); }
        el.style.display = "block";
      }
      e.currentTarget.setPointerCapture(e.pointerId);
      return;
    }
    if (tool === "select") { selectAt(p, e); return; }
    // One-Click proposal handles: a press on a corner/edge grip starts an EDIT drag
    // (select+move a vertex, move a whole edge, or Shift-click to insert a point) —
    // it must win here, before the deferred add-a-region click below.
    if (tool === "oneclick" && proposal && oneClickHandleAt(e)) return;
    // every point-placing tool DEFERS to pointer-up: hold-and-drag (mouse left
    // or one-finger trackpad press) pans mid-measurement instead of placing
    pendingClickRef.current = { p, cx: e.clientX, cy: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  }
  // the deferred click — runs on pointer-up when the press didn't become a pan
  function performClick(p, ev) {
    if (scaleGuide) setScaleGuide(null);
    if (tool === "calibrate") setCalib((c) => (c.length >= 2 ? [p] : [...c, p]));
    else if (tool === "check") setCheck((c) => (c.length >= 2 ? [p] : [...c, p]));
    else if (tool === "oneclick") oneClickAt(p, !!(ev && ev.altKey), undefined, !!(ev && ev.shiftKey));
    // ⌥-click on an area/deduct trace drops a CURVE point (#284): the boundary
    // bends through it instead of turning a corner at it. Every other
    // point-placing tool takes the click as it always has.
    else if (tool === "area" || tool === "deduct" || tool === "linear" || tool === "surface" || tool === "zone") {
      // Curve alternates bow → end → bow → end. A bow needs a vertex behind it
      // to arc away from, so the first point of a trace is always a corner.
      const wantCurve = CURVABLE.has(tool) && (curveMode !== !!(ev && ev.altKey));
      addPoint(p, wantCurve && poly.length > 0 && !bowOpen);
    }
    else if (tool === "count") commitCount(p);
    else if (tool === "rect" || tool === "deduct-rect") {
      if (poly.length === 0) addPoint(p, false);
      else { const a = poly[0]; commitPoly([[a[0], a[1]], [p[0], a[1]], [p[0], p[1]], [a[0], p[1]]], tool === "deduct-rect"); clearPoly(); }
    }
    else if (tool === "schedule") {
      // two-click marquee, isolated state: first click drops the anchor, second reads the box
      if (!scheduleAnchor) setScheduleAnchor(p);
      else { importScheduleFromRect(scheduleAnchor, p); setScheduleAnchor(null); setTool("select"); }
    }
    else if (tool === "textcopy") {
      // Copy text (#471): the first click anchors and starts reading that
      // page's text layer, so the second click can write the clipboard inside
      // its own activation; the second reads the box and returns to Select
      if (!textAnchor) { setTextAnchor(p); prefetchText(panelAt(p[0]).key); }
      else { copyTextFromBox(textAnchor, p); setTextAnchor(null); setTool("select"); }
    }
    else if (tool === "symbol") {
      // the Symbol tool's marquee (#264): tight box around ONE instance
      if (!symbolAnchor) setSymbolAnchor(p);
      else { runSymbolSweep(symbolAnchor, p); setSymbolAnchor(null); }
    }
    else if ((tool === "image" || tool === "pin")) {
      // two-click marquee, isolated state like schedule/symbol — routes ONLY here,
      // never through placeMarkup (which has no image case and would no-op)
      if (!imageAnchor) setImageAnchor(p);
      else { captureRegionMarkup(imageAnchor, p, tool === "pin"); setImageAnchor(null); setTool("select"); }
    }
    else if (tool === "cloud" || tool === "callout" || tool === "text" || tool === "highlight" || tool === "dimension") placeMarkup(p);
    else if (tool === "stamp") placeStamp(p);
    else if (tool === "approve") placeApproval(p);
    else if (tool === "stitch-align") stitchAlignAt(p);
  }
  // ── stitch align (#161) — the Calibrate idiom on the composite: click a
  // point near the match line, then the SAME point where the other sheet
  // draws it; the second sheet translates so the two coincide. Guarded while
  // takeoffs live on the stitch (verts_norm are extent-relative — moving
  // members under committed shapes would silently shift their quantities' ink).
  function stitchAlignAt(p) {
    const st = stitchById[groupKeys[0]];
    if (!st || panels.length !== 1) { setTool("select"); return; }
    const n = shapes.filter((s) => s.sheet_id === st.id).length;
    if (n) { setCommitMsg(uiText(`Align before tracing — ${n} takeoff${n === 1 ? "" : "s"} already live on this stitch. Delete them (or a fresh stitch) to re-align.`)); setTool("select"); return; }
    if (!alignPt) {
      setAlignPt(p);
      setCommitMsg(uiText("Match point set — now click the SAME point where the other sheet draws it."));
      return;
    }
    const dims = panelSourceDimsRef.current.get(st.id) || {};
    const res = alignMembers(st.members, dims, [alignPt[0], alignPt[1]], [p[0], p[1]]);
    setAlignPt(null);
    if (res.error) { setCommitMsg(res.error); return; }
    setStitches((list) => list.map((s) => {
      if (s.id !== st.id) return s;
      const { aligned: _aligned, seam_check: _seamCheck, ...rest } = s;
      return { ...rest, members: res.members };
    }));
    setTool("select");
    setCommitMsg(uiText("Match line joined — the sheets now read as one surface. Trace straight across it."));
  }
  // Markups carry no verts_norm (cloud rect / callout at+target / text at), so
  // hitShape can't test them — this is a purpose-built bbox/point test in the
  // markup's OWN panel frame. p is stage px. Labels are screen-constant, so their
  // extent divides by the current scale.
  function hitMarkup(m, p, thr) {
    const sp = panelByKey(m.sheet_id);
    if (!sp || !sp.img.w) return false;
    const W = sp.img.w, H = sp.img.h, ox = sp.xOffset;
    const X = p[0], Y = p[1], sc = tfRef.current.scale;
    if (m.type === "cloud" && m.rect) {
      const [[a0, b0], [a1, b1]] = m.rect;
      const x0 = Math.min(a0, a1) * W + ox, x1 = Math.max(a0, a1) * W + ox;
      const y0 = Math.min(b0, b1) * H, y1 = Math.max(b0, b1) * H;
      // a cloud renders hollow (fill="none"), so hit only its border band — a shape
      // (or vertex) enclosed by the cloud must stay clickable through the interior.
      const inX = X >= x0 - thr && X <= x1 + thr, inY = Y >= y0 - thr && Y <= y1 + thr;
      const onV = inX && (Math.abs(Y - y0) <= thr || Math.abs(Y - y1) <= thr);
      const onH = inY && (Math.abs(X - x0) <= thr || Math.abs(X - x1) <= thr);
      return onV || onH;
    }
    if ((m.type === "callout" || m.type === "text") && m.at) {
      // the note's box is the SAME layout the renderer draws (lib/markupText), so
      // hit size == render size at every zoom, wrapped lines included
      const ax = m.at[0] * W + ox, ay = m.at[1] * H;
      const fs = inkPx(NOTE_PT, sc);
      // the RESOLVED text ({{qty}} → "5 EA") — the box the renderer actually draws
      const b = noteBox(ax, ay, layoutNote({ text: resolveMarkup(m, noteQtyLabels).m.text, fontPx: fs, measure: canvasMeasure(fs) }));
      if (X >= b.x0 - thr && X <= b.x1 + thr && Y >= b.y0 - thr && Y <= b.y1 + thr) return true;
      if (m.type === "callout" && m.target) {
        const tx = m.target[0] * W + ox, ty = m.target[1] * H;
        if (Math.hypot(X - tx, Y - ty) < thr * 2) return true;
        if (distToSeg(X, Y, tx, ty, ax, ay) < thr) return true;
      }
      return false;
    }
    if (m.type === "highlight" && Array.isArray(m.pts)) {
      // a freehand highlighter stroke — hit the ink band itself (reach = half the
      // stroke width, floored at the shared threshold), never a bounding box, so a
      // stroke over a room shields only what it actually covers.
      if (m.pts.length < 2) return false;
      const w = (m.w || 0.01) * W;
      const reach = Math.max(w / 2, thr);
      const ip = m.pts.map(([nx, ny]) => [nx * W + ox, ny * H]);
      for (let i = 1; i < ip.length; i++) if (distToSeg(X, Y, ip[i - 1][0], ip[i - 1][1], ip[i][0], ip[i][1]) < reach) return true;
      return false;
    }
    if (m.type === "highlight" && m.rect) {
      // a highlight is FILLED and meant to be grabbed — hit its interior (with a
      // small margin) so it selects; precedence in selectAt keeps other markups
      // under it clickable.
      const [[a0, b0], [a1, b1]] = m.rect;
      const x0 = Math.min(a0, a1) * W + ox, x1 = Math.max(a0, a1) * W + ox;
      const y0 = Math.min(b0, b1) * H, y1 = Math.max(b0, b1) * H;
      return X >= x0 - thr && X <= x1 + thr && Y >= y0 - thr && Y <= y1 + thr;
    }
    if ((m.type === "arrow" || m.type === "dimension") && m.from && m.to) {
      // a leader / dimension line — hit its shaft (endpoint tolerance folds into the band)
      const fx = m.from[0] * W + ox, fy = m.from[1] * H, tx = m.to[0] * W + ox, ty = m.to[1] * H;
      return distToSeg(X, Y, fx, fy, tx, ty) < thr * 1.5;
    }
    if (m.type === "bubble" && m.at) {
      // a filled circle — hit its disc; r is normalized to sheet WIDTH
      const cx = m.at[0] * W + ox, cy = m.at[1] * H, rad = (Number(m.r) > 0 ? Number(m.r) : 0.02) * W;
      return Math.hypot(X - cx, Y - cy) < rad + thr;
    }
    if (m.type === "svg" && m.at && Array.isArray(m.vb)) {
      // a vector symbol — hit its placed bbox (same uniform scale off the LONGER
      // viewBox extent the renderer uses, so hit size == render size).
      const { bw, bh } = svgPlacedBox(m.vb, m.w, W);
      const cx = m.at[0] * W + ox, cy = m.at[1] * H;
      return X >= cx - bw / 2 - thr && X <= cx + bw / 2 + thr && Y >= cy - bh / 2 - thr && Y <= cy + bh / 2 + thr;
    }
    if (m.type === "image" && Array.isArray(m.at) && Number(m.w) > 0 && pickEmbedFormat(m.src)) {
      // a raster image — hit its placed box (width-anchored, same box the renderer
      // draws). Gate on a PNG/JPEG DATA url (pickEmbedFormat) so an imported record
      // with a non-data src (e.g. http(s)://) is neither rendered nor selectable.
      const { bw, bh } = imagePlacedBox(m.w, m.aspect, W);
      const cx = m.at[0] * W + ox, cy = m.at[1] * H;
      return X >= cx - bw / 2 - thr && X <= cx + bw / 2 + thr && Y >= cy - bh / 2 - thr && Y <= cy + bh / 2 + thr;
    }
    return false;
  }
  // Select tool: pick a shape (or a vertex of the selected one) and start dragging
  // it. Every shape hit-tests in ITS panel's local frame (stage x minus xOffset).
  function selectAt(p, e) {
    const thr = 8 / tfRef.current.scale;
    const sel = selectedId ? shapes.find((s) => s.id === selectedId) : null;
    const selSp = sel && panelKeySet.has(sel.sheet_id) ? panelByKey(sel.sheet_id) : null;
    setSelVert(null);   // default: this press clears the vertex pick (overridden below on a corner/insert hit)
    // 1. Handles of the ALREADY-selected shape win first, so a shape (or vertex)
    //    enclosed by a markup — e.g. a revision cloud drawn around a room — stays
    //    editable rather than being shielded by the markup's hit area. Same edit
    //    model as One-Click proposals: click a corner to select it (Delete removes
    //    just it), drag a corner to move it, drag an edge grip to move the whole
    //    line (both endpoints), Shift-click an edge to insert a new anchor point —
    //    or just press anywhere else along the edge (where the hover ghost shows
    //    a "+") to insert an anchor at that exact spot, no modifier needed.
    if (sel && selSp && sel.measure_role !== "count") {
      const pts = sel.verts_norm.map(([nx, ny]) => [nx * selSp.img.w + selSp.xOffset, ny * selSp.img.h]);
      const closed = sel.measure_role !== "linear" && sel.measure_role !== "surface_area";
      for (let i = 0; i < pts.length; i++) {
        if (Math.hypot(pts[i][0] - p[0], pts[i][1] - p[1]) < thr * 1.6) {
          setSelVert(i);   // select this corner + arm its move drag
          // prev = the grab-time snapshot the commit-on-release geom command
          // stamps/freezes from; gx/gy only gate the live PREVIEW now (the
          // zero-motion no-stamp guard is structural: no motion ⇒ no command)
          dragRef.current = { kind: "vertex", shapeId: selectedId, vIndex: i, prev: geomSnapshot(sel), shape: sel, gx: e.clientX, gy: e.clientY };
          e.currentTarget.setPointerCapture(e.pointerId); return;
        }
      }
      // edge grips: drag moves the WHOLE line (both endpoints); Shift-click drops a
      // new anchor point there and drags it out in the same gesture.
      const edges = closed ? pts.length : pts.length - 1;
      for (let i = 0; i < edges; i++) {
        const j = (i + 1) % pts.length;
        const a = pts[i], b = pts[j];
        if (Math.hypot((a[0] + b[0]) / 2 - p[0], (a[1] + b[1]) / 2 - p[1]) < thr * 1.4) {
          if (e.shiftKey) {
            // insert at the EXACT edge midpoint (like One-Click's oneClickHandleAt),
            // not the click point — click imprecision can't kink the edge before drag.
            // The insertion itself is gesture-start LIVE state, not a command
            // (a collinear midpoint changes no quantity and never stamped) —
            // `prev` snapshots the POST-insert shape, so a zero-motion ⇧-click
            // still leaves the unstamped anchor behind exactly as before,
            // while any drag commits ONE stamped geom command on release.
            const va = sel.verts_norm[i], vb = sel.verts_norm[j];
            const nv = [(va[0] + vb[0]) / 2, (va[1] + vb[1]) / 2];
            const vnIns = [...sel.verts_norm.slice(0, i + 1), nv, ...sel.verts_norm.slice(i + 1)];
            const inserted = { ...sel, verts_norm: vnIns, computed: recomputeShape({ ...sel, verts_norm: vnIns }) };
            setShapes((ss) => ss.map((s) => (s.id === sel.id ? inserted : s)));
            setSelVert(i + 1);
            dragRef.current = { kind: "vertex", shapeId: selectedId, vIndex: i + 1, prev: geomSnapshot(inserted), shape: inserted, gx: e.clientX, gy: e.clientY };
          } else {
            dragRef.current = { kind: "edge", shapeId: selectedId, i, j, oaN: [...sel.verts_norm[i]], obN: [...sel.verts_norm[j]], start: p, prev: geomSnapshot(sel), shape: sel, gx: e.clientX, gy: e.clientY };
          }
          e.currentTarget.setPointerCapture(e.pointerId); return;
        }
      }
      // anywhere else ALONG an edge (the hover ghost's promise): drop a new
      // anchor at the point projected onto the edge and drag it out in the
      // same gesture — no modifier needed. Same LIVE-insert semantics as the
      // ⇧-midpoint path above (a zero-motion click leaves a collinear,
      // unstamped anchor; any drag commits ONE geom command on release).
      const insHit = edgeInsertHitAt(p);
      if (insHit) {
        const va = sel.verts_norm[insHit.i], vb = sel.verts_norm[insHit.j];
        const nv = [va[0] + (vb[0] - va[0]) * insHit.t, va[1] + (vb[1] - va[1]) * insHit.t];
        const vnIns = [...sel.verts_norm.slice(0, insHit.i + 1), nv, ...sel.verts_norm.slice(insHit.i + 1)];
        const inserted = { ...sel, verts_norm: vnIns, computed: recomputeShape({ ...sel, verts_norm: vnIns }) };
        setShapes((ss) => ss.map((s) => (s.id === sel.id ? inserted : s)));
        setSelVert(insHit.i + 1);
        dragRef.current = { kind: "vertex", shapeId: selectedId, vIndex: insHit.i + 1, prev: geomSnapshot(inserted), shape: inserted, gx: e.clientX, gy: e.clientY };
        if (insGhostRef.current) insGhostRef.current.style.display = "none";
        e.currentTarget.setPointerCapture(e.pointerId); return;
      }
    }
    // 1b. a selected image's bottom-right RESIZE handle wins next (screen-constant,
    //     /z). Gated on the resolved markup being type "image" so this never fires
    //     on another selected markup. Fixed top-left; onPointerMove drives the live
    //     resize via resizeImageFromCorner.
    if (showMarkups && selectedMarkupId) {
      const selMk = markups.find((mm) => mm.id === selectedMarkupId);
      // require the image to be on a VISIBLE panel — panelByKey falls back to
      // panels[0] for an off-group sheet, which would arm the resize against the
      // wrong panel's dims and corrupt an off-view image's w/at.
      if (selMk && !selMk.reference_only && selMk.type === "image" && selMk.at && panelKeySet.has(selMk.sheet_id)) {
        const sp = panelByKey(selMk.sheet_id);
        if (sp && sp.img.w) {
          const { bw, bh } = imagePlacedBox(selMk.w, selMk.aspect, sp.img.w);
          const brx = selMk.at[0] * sp.img.w + sp.xOffset + bw / 2, bry = selMk.at[1] * sp.img.h + bh / 2;
          if (Math.hypot(p[0] - brx, p[1] - bry) < thr * 1.5) {
            const tlx = selMk.at[0] * sp.img.w - bw / 2, tly = selMk.at[1] * sp.img.h - bh / 2;
            dragRef.current = { kind: "markupResize", markupId: selMk.id, tl: { x: tlx, y: tly }, aspect: selMk.aspect, ox: sp.xOffset, imgW: sp.img.w, imgH: sp.img.h, moved: false };
            e.currentTarget.setPointerCapture(e.pointerId); return;
          }
        }
      }
    }
    // 2. markups render ON TOP of shapes (:2137 > :2093), so a markup hit wins over a
    //    plain shape click — but NOT over the selected shape's handles above.
    //    When the markup layer is hidden (showMarkups false), skip the search
    //    entirely — you can't select/delete/fly-to an invisible markup.
    if (showMarkups) {
      const rev = [...visibleMarkups].reverse();
      // a NON-highlight markup hit beats a highlight at the same point (test
      // highlights last), so a linked cloud/callout under a highlight stays
      // clickable; a highlight still wins over a plain shape (it shields it).
      // three tiers: plain markups first, then highlight, then image LAST — so a
      // large image never shadows another markup from selection (an image shields
      // shapes beneath it like a highlight box does; move it to reach what's under).
      const mHit = rev.find((m) => m.type !== "highlight" && m.type !== "image" && hitMarkup(m, p, thr))
        || rev.find((m) => m.type === "highlight" && hitMarkup(m, p, thr))
        || rev.find((m) => m.type === "image" && hitMarkup(m, p, thr));
      if (mHit) {
        selectMarkup(mHit.id);
        // arm a move drag — snapshot the markup's current normalized coords (all four
        // shapes: cloud/highlight rect, callout at+target, text at). The move stays a
        // no-op until it passes the threshold in onPointerMove, so a pure click (or the
        // first click of a double-click re-edit) never nudges the markup.
        const orig = (mHit.type === "highlight" && Array.isArray(mHit.pts)) ? { pts: mHit.pts.map((v) => [...v]) }
          : (mHit.type === "cloud" || mHit.type === "highlight") ? { rect: mHit.rect }
            : mHit.type === "callout" ? { at: mHit.at, target: mHit.target }
              : (mHit.type === "arrow" || mHit.type === "dimension") ? { from: mHit.from, to: mHit.to }
                : { at: mHit.at };   // text + bubble
        // raw start (markups don't snap/angle-lock; matches the raw tracking point in
        // onPointerMove so the delta can't be contaminated by a stale snap/angle ref)
        dragRef.current = { kind: "markupMove", markupId: mHit.id, sheetId: mHit.sheet_id, start: toImage(e.clientX, e.clientY), orig, moved: false };
        e.currentTarget.setPointerCapture(e.pointerId);
        return;
      }
    }
    // 3. move the selected shape if its body (not a handle) was hit
    if (sel && selSp && hitShapeC(sel, p[0] - selSp.xOffset, p[1], selSp.img.w, selSp.img.h, thr)) {
      dragRef.current = { kind: "move", shapeId: selectedId, start: p, orig: sel.verts_norm, prev: geomSnapshot(sel), shape: sel, gx: e.clientX, gy: e.clientY };
      e.currentTarget.setPointerCapture(e.pointerId); return;
    }
    // 4. otherwise pick a shape (or clear the selection)
    const hit = [...stackedShapes].reverse().find((s) => {
      const sp = panelByKey(s.sheet_id);
      return hitShapeC(s, p[0] - sp.xOffset, p[1], sp.img.w, sp.img.h, thr);
    });
    selectShape(hit ? hit.id : null);
    if (hit) { dragRef.current = { kind: "move", shapeId: hit.id, start: p, orig: hit.verts_norm, prev: geomSnapshot(hit), shape: hit, gx: e.clientX, gy: e.clientY }; e.currentTarget.setPointerCapture(e.pointerId); return; }
    // 5. open canvas — drag the paper to PAN (the instinct everyone brings from
    // desktop takeoff tools; no need to reach for the Pan tool). The plain
    // click (no drag) already cleared the selection above, so a stationary
    // press costs nothing.
    promoteStage();
    panRef.current = { sx: e.clientX, sy: e.clientY, ox: tfRef.current.x, oy: tfRef.current.y };
    e.currentTarget.setPointerCapture(e.pointerId);
    if (containerRef.current) containerRef.current.style.cursor = "grabbing";
  }
  // Delete just the selected corner (Delete/⌫), keeping a polygon ≥3 / a run ≥2.
  // At the floor we deselect so the NEXT ⌫ falls through to deleting the whole
  // shape — mirrors the One-Click proposal behavior.
  function deleteSelectedShapeVertex() {
    const sel = shapes.find((s) => s.id === selectedId);
    if (!sel || selVert == null || selVert >= sel.verts_norm.length) { setSelVert(null); return; }   // stale index (shape changed under the selection) — never dispatch a no-op edit
    const closed = sel.measure_role !== "linear" && sel.measure_role !== "surface_area";
    const min = closed ? 3 : 2;
    if (sel.verts_norm.length <= min) {
      setCommitMsg(closed ? "A shape needs at least 3 points — ⌫ again deletes the whole shape." : "A run needs at least 2 points — ⌫ again deletes the whole run.");
      setSelVert(null); return;
    }
    // dropping a corner is as real an edit as dragging one — the vertexDelete
    // command stamps "vertex" centrally, so a machine shape corrected only
    // this way can't read as a clean accept
    const vn = sel.verts_norm.filter((_, j) => j !== selVert);
    dispatchShape({
      type: "geom", id: sel.id, editKind: "vertexDelete",
      verts_norm: vn, computed: recomputeShape({ ...sel, verts_norm: vn }), prev: geomSnapshot(sel),
    });
    setSelVert(null);
  }
  // Geometry from the shape's OWN sheet: its panel's pixel dims × that sheet's
  // scale. This is what makes cross-sheet paste and group-mode edits honest.
  // uppOverride: pass the NEW effective upp when re-pricing right after a
  // setScales — `scales` in this render's closure is still the old map.
  // Canvas-side wrapper over the ONE quantity computer (lib/shapeMetrics.js):
  // panel dims + scale + condition lookup here, the role-aware math there —
  // shared with the load-time heal, which prices shapes on CLOSED sheets too.
  // Hole-aware since #137: a parent carrying verts_norm_holes prices the
  // clipped geometry, not the outer ring.
  function recomputeShape(s, uppOverride) {
    return computeShapeMetrics(s, panelByKey(s.sheet_id).img, uppOverride ?? (uppFor(s.sheet_id) || 0), condById[s.condition_id]);
  }
  // The panel chip chromes' children — built imperatively by moveCrosshair on a
  // __mode change (the chip element stays CHILDLESS in JSX for every chrome;
  // React never renders content into it). textContent-only writes throughout:
  // condition names are user data, so no innerHTML anywhere on this path.
  function buildChipPanel(chip, chrome) {
    chip.textContent = "";
    const vals = {};
    const row = (label, key, unit) => {
      const r = document.createElement("div");
      r.style.display = "flex"; r.style.justifyContent = "space-between"; r.style.gap = "12px";
      const l = document.createElement("span");
      l.textContent = label;
      l.style.opacity = "0.62"; l.style.fontWeight = "500";
      const v = document.createElement("span");
      v.style.fontWeight = "700";
      const val = document.createElement("span");
      v.appendChild(val);
      if (unit) {
        // muted-gray unit span — reads as annotation beside the value, not value
        const u = document.createElement("span");
        u.textContent = " " + unit;
        u.style.color = "#8a8577"; u.style.fontWeight = "500";
        v.appendChild(u);
      }
      r.appendChild(l); r.appendChild(v);
      chip.appendChild(r);
      vals[key] = val;
    };
    if (chrome === "panelDark") {
      row("This segment", "seg");
      row("Total linear", "lin");
      row("Total area", "area");
    } else {
      const head = document.createElement("div");
      head.style.fontWeight = "700"; head.style.marginBottom = "1px";
      chip.appendChild(head);
      vals.head = head;
      const sub = document.createElement("div");
      sub.textContent = "This section only:";
      sub.style.opacity = "0.62"; sub.style.fontSize = "9.5px"; sub.style.marginBottom = "1px";
      chip.appendChild(sub);
      row("Area", "area", areaUnit(units));
      row("Linear", "lin", lenUnit(units));
      row("Segments", "segs");
      row("Points", "pts");
    }
    chip.__vals = vals;
  }
  function moveCrosshair(e) {
    if (editingRef.current) return;   // inline editor open — no aim crosshair (ref check, never per-mousemove state)
    if (tool === "select" || status !== "ready" || !containerRef.current) return;
    const ds = dsRef.current;   // resolved drawing style — refs only in this hot path (render-body assigned, never stale)
    // snap-to-vector: nearest PDF endpoint within threshold becomes the active
    // point — looked up in the hovered panel's grid, in that panel's local frame
    let cur = toImage(e.clientX, e.clientY);
    snapRef.current = null;
    if (snapMarkRef.current) snapMarkRef.current.style.display = "none";
    // the selection boxes never snap (snapsToVectors is false for them): their
    // crosshair and box preview show exactly the corner the click places (raw),
    // so what's drawn is what's read — and no star or "snap" chip
    if (snapOn && snapsToVectors(tool) && !panRef.current && snapGridsRef.current.size) {
      const sc = tfRef.current.scale;
      const sp = panelAt(cur[0]);
      const grid = snapGridsRef.current.get(sp.key);
      const hit = grid ? nearestSnap(grid, cur[0] - sp.xOffset, cur[1], 11 / sc) : null;
      if (hit) {
        const pt = [hit[0] + sp.xOffset, hit[1]];
        snapRef.current = pt; cur = pt;
        if (snapMarkRef.current) { snapMarkRef.current.setAttribute("d", starPath(pt[0], pt[1], 5.5 / sc)); snapMarkRef.current.style.display = "block"; }
      }
    }

    // rubber-band preview: last point → cur (area/deduct/zone); rect preview: corner → cur
    const drawing = (tool === "area" || tool === "deduct" || tool === "linear" || tool === "surface" || tool === "zone");

    // polar tracking: endpoint snap wins (osnap beats polar); otherwise pull the
    // rubber band onto the 45° family. ⇧ forces the lock at any angle. The click
    // path commits angleRef, so the placed vertex is exactly on-axis — not just
    // the preview. The lock reads as a QUIET state change (crosshair brightens,
    // rubber band thickens, chip shows the angle) — no extra chrome on the sheet.
    const anchor = (drawing && poly.length > 0) ? poly[poly.length - 1]
      : (tool === "calibrate" && calib.length === 1 ? calib[0]
        : (tool === "check" && check.length === 1 ? check[0] : null));
    angleRef.current = null;
    let lock = null;
    if (angleOn && anchor && !bowOpen && !snapRef.current && !panRef.current) {
      const sc = tfRef.current.scale;
      if (Math.hypot(cur[0] - anchor[0], cur[1] - anchor[1]) >= 12 / sc)
        lock = angleSnap(anchor, cur, e.shiftKey);
      if (lock) { angleRef.current = lock.pt; cur = lock.pt; }
    }

    // the crosshair IS the cursor — re-assert cursor:none every move because the
    // pan/space handlers restore style.cursor to "" (computed auto) on release
    if (!panRef.current && !spaceRef.current && containerRef.current.style.cursor !== "none")
      containerRef.current.style.cursor = "none";

    // aim visuals ride the EFFECTIVE point (locked/snapped), not the raw mouse
    const t = tfRef.current;
    const ex = cur[0] * t.scale + t.x, ey = cur[1] * t.scale + t.y;
    const lockState = lock ? "1" : "";
    for (const [el, prop, val] of [[crossVRef.current, "left", ex], [crossHRef.current, "top", ey]]) {
      if (!el) continue;
      el.style[prop] = `${val}px`; el.style.display = "block";
      if (el.__lock !== lockState) {
        el.__lock = lockState;
        el.style.background = lock ? ds._hairlineLock.background : ds._hairline;
        el.style.boxShadow = lock ? ds._hairlineLock.boxShadow : ds._hairlineLock.boxShadowBase;
      }
    }
    if (aimMarkRef.current) {
      const el = aimMarkRef.current;
      el.style.transform = `translate3d(${ex}px, ${ey}px, 0)`;
      if (el.__lock !== lockState) {
        el.__lock = lockState;
        const star = el.firstChild;
        if (star) {
          star.style.transform = lock ? "scale(1.3)" : "scale(1)";
          star.style.filter = lock ? `drop-shadow(0 0 5px ${ds._aimGlow}) drop-shadow(0 1px 2px rgba(14,26,46,.3))` : "drop-shadow(0 1px 2px rgba(14,26,46,.3))";
        }
      }
      el.style.display = "block";
    }
    if (aimChipRef.current) {
      const chip = aimChipRef.current;
      const chipT = ds.chip;
      // panel chromes (panelDark/panelCream) replace the single-row live-segment
      // text with a small multi-row readout — ONLY during a poly draft with ≥1
      // placed point on a scaled sheet; every other text (check length, rect
      // W×H, bare angle, "snap") degrades to a single row in the same palette.
      const panelChrome = chipT.chrome === "panelDark" || chipT.chrome === "panelCream";
      const panelActive = panelChrome && drawing && anchor && liveUpp;
      let txt = "", over = false;
      if (tool === "check" && check.length === 1) {
        // live length to the cursor while picking the second end of the dimension.
        // No CARPET_ROLL_FT amber here — a dimension string is not a seam plan.
        const u = uppFor(panelAt(check[0][0]).key);
        if (u) txt = fmtCheckLen(Math.hypot(cur[0] - check[0][0], cur[1] - check[0][1]) * u, units) + (lock ? ` · ${lock.deg}°` : "");
      } else if (tool === "dimension" && markupDraft) {
        // live length while picking the dimension's second end — same readout
        // as check, and like check no roll-width amber: a dimension string is
        // a label, not a seam plan
        const u = uppFor(panelAt(markupDraft[0]).key);
        if (u) txt = fmtCheckLen(Math.hypot(cur[0] - markupDraft[0], cur[1] - markupDraft[1]) * u, units);
      } else if ((tool === "rect" || tool === "deduct-rect") && poly.length === 1 && liveUpp) {
        // rectangle: live W × H + area (SF and SY imperial — carpet is bought in SY)
        const a = poly[0];
        const w = Math.abs(cur[0] - a[0]) * liveUpp, h = Math.abs(cur[1] - a[1]) * liveUpp;
        const sf = w * h;
        txt = `${fmtCheckLen(w, units)} × ${fmtCheckLen(h, units)} · ${num(areaVal(sf, units))} ${areaUnit(units)}${units === "metric" ? "" : ` · ${num(sf / 9)} SY`}`;
        over = w >= CARPET_ROLL_FT - 0.02 || h >= CARPET_ROLL_FT - 0.02;
      } else if (drawing && anchor && liveUpp && !panelActive) {
        // line/polyline: live segment length, ALWAYS (not just under the 45° lock).
        // With a bow open the segment IS the arc, so measure along it — reading
        // the chord here would price a curved wall short the whole time you aim.
        const len = bowOpen
          ? arcLength(poly[poly.length - 2], anchor, cur) * liveUpp
          : Math.hypot(cur[0] - anchor[0], cur[1] - anchor[1]) * liveUpp;
        txt = lock ? `${lock.deg}° · ${fmtCheckLen(len, units)}` : fmtCheckLen(len, units);
        over = len >= CARPET_ROLL_FT - 0.02;
      } else if (!panelActive && lock) {
        txt = `${lock.deg}°`;
      } else if (!panelActive && snapRef.current) txt = "snap";
      if (panelActive) {
        // The rebuild dirty-mark encodes MODE, not just chrome: the same chrome
        // alternates panel (mid-draft) and single-row (check length, rect W×H,
        // bare angle, "snap"), and a chrome-only key would leave the mover
        // updating value nodes a textContent write already wiped, or chip.__t
        // skipping a rewrite over stale panel children. (units joins the key so
        // a ft/m flip rebuilds the panel's baked unit spans.)
        const mode = chipT.chrome + ":panel:" + units;
        if (chip.__mode !== mode) {
          chip.__mode = mode;
          delete chip.__t;   // every panel build clears __t — the next row-mode write must never skip
          buildChipPanel(chip, chipT.chrome);
        }
        // totals = render-body placed sums (draftStatsRef) + O(1) cursor terms.
        // With a bow open the live leg is the arc, so measure segLen along it.
        const st = draftStatsRef.current;
        const segPx = Math.hypot(cur[0] - anchor[0], cur[1] - anchor[1]);
        const segLen = (bowOpen ? arcLength(poly[poly.length - 2], anchor, cur) : segPx) * liveUpp;
        const totLen = (st.len + segPx) * liveUpp;
        const p0 = poly[0], pn = poly[poly.length - 1];
        const crossSum = st.cross + (pn[0] * cur[1] - cur[0] * pn[1]) + (cur[0] * p0[1] - p0[0] * cur[1]);
        const areaSf = (Math.abs(crossSum) / 2) * liveUpp * liveUpp;
        const v = chip.__vals;
        // a shoelace area is meaningless for an OPEN run — the panel shows it
        // only on ring tools (linear/surface drafts read "—" there)
        const ringDraft = tool === "area" || tool === "deduct" || tool === "zone";
        if (chipT.chrome === "panelDark") {
          v.seg.textContent = lock ? `${lock.deg}° · ${fmtCheckLen(segLen, units)}` : fmtCheckLen(segLen, units);
          v.lin.textContent = fmtCheckLen(totLen, units);
          v.area.textContent = ringDraft ? `${num(areaVal(areaSf, units))} ${areaUnit(units)}` : "—";
        } else {
          v.head.textContent = aCond?.finish_tag || "No condition";
          v.area.textContent = ringDraft ? num(areaVal(areaSf, units)) : "—";
          v.lin.textContent = num(lenVal(totLen, units));
          // chain counts INCLUDING the live leg: placed edges + the rubber =
          // poly.length segments, placed vertices + the cursor = poly.length+1
          v.segs.textContent = String(poly.length);
          v.pts.textContent = String(poly.length + 1);
        }
        over = segLen >= CARPET_ROLL_FT - 0.02;
      } else if (txt) {
        const mode = chipT.chrome + ":row";
        // a row-mode write goes through textContent, which wipes any panel
        // children left by the previous mode
        if (chip.__mode !== mode) { chip.__mode = mode; delete chip.__t; chip.__vals = null; }
        if (chip.__t !== txt) { chip.textContent = txt; chip.__t = txt; }
      }
      if (panelActive || txt) {
        // 12 ft roll-width cue — the chip goes amber when a run reaches roll width
        // (a seam falls here); the restore re-applies the ds-resolved base strings
        // (for Drafting Table those are today's exact var(--…) strings)
        const os = over ? "1" : "";
        if (chip.__over !== os) {
          chip.__over = os;
          chip.style.background = over ? chipT.warnBg : chipT.bg;
          chip.style.color = over ? chipT.warnFg : chipT.fg;
          chip.style.borderColor = over ? chipT.warnBorder : chipT.border;
        }
        // anchor "lastVertex" pins the chip to the last placed vertex during a
        // poly draft (Site Glass); every other text and chrome rides the cursor
        const anchorLast = chipT.anchor === "lastVertex" && drawing && poly.length > 0;
        const ax = anchorLast ? poly[poly.length - 1][0] * t.scale + t.x : ex;
        const ay = anchorLast ? poly[poly.length - 1][1] * t.scale + t.y : ey;
        chip.style.transform = `translate3d(${ax + 14}px, ${ay + 18}px, 0)`;
        chip.style.display = "block";
      } else chip.style.display = "none";
    }
    if (rubberRef.current) {
      const cas = rubberCasingRef.current;
      if (!panRef.current && drawing && poly.length > 0) {
        // With a bow open the band runs from the arc's START and goes dashed —
        // it is the chord under the bow, a reference line, not the boundary.
        const last = poly[bowOpen ? poly.length - 2 : poly.length - 1];
        rubberRef.current.setAttribute("x1", last[0]); rubberRef.current.setAttribute("y1", last[1]);
        rubberRef.current.setAttribute("x2", cur[0]); rubberRef.current.setAttribute("y2", cur[1]);
        // screen-constant width, like the JSX default and the dash below (÷ scale):
        // the raw stage-px value this used to write drew a fat, smeared band at
        // deep zoom. The lock reads thicker within the band (or, where a theme
        // sets rubber.lockColor, recolored instead of thickened).
        rubberRef.current.setAttribute("stroke-width", (lock ? ds.rubber.lockWidth : ds.rubber.width) / tfRef.current.scale);
        if (ds.rubber.lockColor) {
          // recolor on lock-CHANGE only (__lockColor dirty mark); the restore is
          // the SAME deduct→invalid→accent expression the JSX declares.
          if (rubberRef.current.__lockColor !== lockState) {
            rubberRef.current.__lockColor = lockState;
            rubberRef.current.setAttribute("stroke", lock ? ds.rubber.lockColor : draftStroke(tool, draftInvalid, ds));
          }
        }
        // With a bow open the band is the dashed chord under the arc; otherwise
        // the theme's own rubber dash (solid for drafting → "").
        const dash = bowOpen ? `${5 / tfRef.current.scale} ${4 / tfRef.current.scale}` : (drawDashFor(ds.rubber.dash, tfRef.current.scale) || "");
        if (rubberRef.current.__dash !== dash) { rubberRef.current.setAttribute("stroke-dasharray", dash); rubberRef.current.__dash = dash; }
        rubberRef.current.style.display = "block";
        // casing under-stroke mirrors the STRAIGHT rubber band (Site Glass) — its
        // JSX twin heals wheel-zoom with a stationary pointer, this mover write
        // heals move cadence. Skipped while a bow is open: the band is then a
        // dashed reference chord, and a white casing under it reads wrong.
        if (cas && ds.casing && !bowOpen) {
          cas.setAttribute("x1", last[0]); cas.setAttribute("y1", last[1]);
          cas.setAttribute("x2", cur[0]); cas.setAttribute("y2", cur[1]);
          cas.setAttribute("stroke-width", ds.casing.width / tfRef.current.scale);
          cas.style.display = "block";
        } else if (cas) cas.style.display = "none";
      } else {
        rubberRef.current.style.display = "none";
        if (cas) cas.style.display = "none";   // the hide branch mirrors the casing too
      }
    }
    // close preview — the ring tools' ghost cursor→first edge (theme-gated; the
    // element only mounts when DS.closePreview is set). Width AND dash are
    // dual-owned exactly like the rubber core: the JSX twin declares both from
    // the ~11 Hz tf mirror, this mover re-writes both from tfRef per move — so
    // width and dash always come from the SAME scale read, in both cadences.
    if (closeRef.current) {
      if (!panRef.current && ds.closePreview && (tool === "area" || tool === "deduct" || tool === "zone") && poly.length >= 2) {
        const csc = tfRef.current.scale;
        closeRef.current.setAttribute("x1", cur[0]); closeRef.current.setAttribute("y1", cur[1]);
        closeRef.current.setAttribute("x2", poly[0][0]); closeRef.current.setAttribute("y2", poly[0][1]);
        closeRef.current.setAttribute("stroke-width", ds.closePreview.width / csc);
        const cd = drawDashFor(ds.closePreview.dash, csc);
        if (cd) closeRef.current.setAttribute("stroke-dasharray", cd);
        else closeRef.current.removeAttribute("stroke-dasharray");
        closeRef.current.style.display = "block";
      } else closeRef.current.style.display = "none";
    }
    // The arc itself — a real SVG conic through (start, bow, cursor), so what
    // you aim with is what commits rather than a preview that flattens later.
    if (arcRef.current) {
      if (!panRef.current && drawing && bowOpen) {
        arcRef.current.setAttribute("d", arcPathD(poly[poly.length - 2], poly[poly.length - 1], cur));
        arcRef.current.setAttribute("stroke-width", ds.draft.lineWidth / tfRef.current.scale);
        arcRef.current.style.display = "block";
      } else arcRef.current.style.display = "none";
    }
    if (rectRef.current) {
      const schedDraw = tool === "schedule" && scheduleAnchor;
      const symDraw = tool === "symbol" && symbolAnchor;
      const imgDraw = (tool === "image" || tool === "pin") && imageAnchor;
      const txtDraw = tool === "textcopy" && textAnchor;
      if (!panRef.current && ((tool === "rect" || tool === "deduct-rect") && poly.length === 1 || schedDraw || symDraw || imgDraw || txtDraw)) {
        const a = txtDraw ? textAnchor : imgDraw ? imageAnchor : symDraw ? symbolAnchor : schedDraw ? scheduleAnchor : poly[0];
        rectRef.current.setAttribute("x", Math.min(a[0], cur[0])); rectRef.current.setAttribute("y", Math.min(a[1], cur[1]));
        rectRef.current.setAttribute("width", Math.abs(cur[0] - a[0])); rectRef.current.setAttribute("height", Math.abs(cur[1] - a[1]));
        rectRef.current.style.display = "block";
      } else rectRef.current.style.display = "none";
    }
    // live cloud preview: first corner (markupDraft, stage px) → cursor
    if (cloudRef.current) {
      if (!panRef.current && tool === "cloud" && markupDraft) {
        cloudRef.current.setAttribute("d", cloudPath(markupDraft[0], markupDraft[1], cur[0], cur[1]));
        cloudRef.current.style.display = "block";
      } else cloudRef.current.style.display = "none";
    }
    // live highlight preview: a translucent box, first corner → cursor (its own
    // ref, NOT rectRef which carries the active condition fill)
    if (highlightRef.current) {
      if (!panRef.current && tool === "highlight" && markupDraft) {
        highlightRef.current.setAttribute("x", Math.min(markupDraft[0], cur[0]));
        highlightRef.current.setAttribute("y", Math.min(markupDraft[1], cur[1]));
        highlightRef.current.setAttribute("width", Math.abs(cur[0] - markupDraft[0]));
        highlightRef.current.setAttribute("height", Math.abs(cur[1] - markupDraft[1]));
        highlightRef.current.style.display = "block";
      } else highlightRef.current.style.display = "none";
    }
    // live dimension-line preview: first end (markupDraft) → cursor
    if (dimRef.current) {
      if (!panRef.current && tool === "dimension" && markupDraft) {
        dimRef.current.setAttribute("x1", markupDraft[0]); dimRef.current.setAttribute("y1", markupDraft[1]);
        dimRef.current.setAttribute("x2", cur[0]); dimRef.current.setAttribute("y2", cur[1]);
        dimRef.current.style.display = "block";
      } else dimRef.current.style.display = "none";
    }
  }
  function hideCrosshair() {
    for (const ref of [crossVRef, crossHRef, rubberRef, rubberCasingRef, closeRef, arcRef, rectRef, cloudRef, highlightRef, dimRef, snapMarkRef, aimMarkRef, aimChipRef]) if (ref.current) ref.current.style.display = "none";
    if (hlRef.current == null && hlPathRef.current) hlPathRef.current.style.display = "none";
    if (hoverRef.current) hoverRef.current.style.display = "none";
    hoverIdRef.current = "";
    angleRef.current = null;
  }
  // Pointer left the canvas: hide the aim chrome AND kill the voice-deixis aim —
  // a pointer parked off-canvas must not leave a ghost seed for "this room".
  // (Other hideCrosshair callers — e.g. the inline editor — keep the aim: the
  // pointer is still parked on the sheet there.)
  function leaveCanvas() {
    hideCrosshair();
    voiceAimMarkRef.current = aimSeqRef.current;
  }
  function describeShape(s) {
    const tag = condById[s.condition_id]?.finish_tag || "?";
    const a = s.computed?.area_sf || 0, lf = s.computed?.perimeter_lf || 0;
    if (s.measure_role === "count") return `${tag} · ${num(s.computed?.count || 1, 0)} EA`;
    // closed shapes carry their ring length too (#283) — a footprint's LF is
    // as much a takeoff number as its SF, and it's already computed
    if (s.measure_role === "deduct") return `${tag} · −${fa(a)} deduct${lf > 0 ? ` · ${fl(lf)} perim` : ""}`;
    if (s.measure_role === "surface_area") {
      // same height semantics as recomputeShape: an override wins outright (even 0).
      // Heights stay feet in both systems — they're ENTERED in feet everywhere.
      const h = s.height_override === true
        ? Number(s.height_ft) || 0
        : Number(s.height_ft) || Number(condById[s.condition_id]?.height_ft) || 0;
      return `${tag} · ${fa(a)} wall (${fl(lf)} × ${num(h, 2)}′)`;
    }
    if (s.measure_role === "linear") return `${tag} · ${fl(lf)}${a > 0 ? ` · ${fa(a)} border` : ""}`;
    return `${tag} · ${faSY(a)}${lf > 0 ? ` · ${fl(lf)} perim` : ""}`;
  }
  // Edge-insert affordance: the nearest point ON an edge of the selected shape,
  // away from its corner diamonds and midpoint grip (those gestures keep
  // priority). A press there drops a new anchor at the projected point and
  // drags it out in the same gesture; the hover ghost telegraphs it first.
  function edgeInsertHitAt(p) {
    if (!selectedId) return null;
    const sel = shapes.find((s) => s.id === selectedId);
    if (!sel || sel.measure_role === "count" || !panelKeySet.has(sel.sheet_id)) return null;
    const sp = panelByKey(sel.sheet_id);
    const thr = 8 / tfRef.current.scale;
    const pts = sel.verts_norm.map(([nx, ny]) => [nx * sp.img.w + sp.xOffset, ny * sp.img.h]);
    const closed = sel.measure_role !== "linear" && sel.measure_role !== "surface_area";
    const edges = closed ? pts.length : pts.length - 1;
    let best = null;
    for (let i = 0; i < edges; i++) {
      const j = (i + 1) % pts.length;
      const a = pts[i], b = pts[j];
      const dx = b[0] - a[0], dy = b[1] - a[1];
      const len2 = dx * dx + dy * dy;
      if (!len2) continue;
      const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / len2));
      const qx = a[0] + t * dx, qy = a[1] + t * dy;
      const d = Math.hypot(qx - p[0], qy - p[1]);
      if (d >= thr || (best && d >= best.d)) continue;
      // clear of the corner diamonds (thr*1.6 hit radius) and the edge grip
      // (thr*1.4) with a little margin, so the ghost never shadows a grip
      if (Math.hypot(qx - a[0], qy - a[1]) < thr * 1.8 || Math.hypot(qx - b[0], qy - b[1]) < thr * 1.8) continue;
      if (Math.hypot((a[0] + b[0]) / 2 - qx, (a[1] + b[1]) / 2 - qy) < thr * 1.6) continue;
      best = { i, j, t, d, qx, qy };
    }
    return best;
  }
  function updateInsGhost(e) {
    const el = insGhostRef.current;
    if (!el) return;
    const off = () => { el.style.display = "none"; };
    if (tool !== "select" || panRef.current || dragRef.current || pendingClickRef.current || status !== "ready") return off();
    const hit = edgeInsertHitAt(toImage(e.clientX, e.clientY));
    if (!hit) return off();
    const t = tfRef.current;
    el.style.left = `${hit.qx * t.scale + t.x - 8}px`;
    el.style.top = `${hit.qy * t.scale + t.y - 8}px`;
    el.style.display = "flex";
  }
  // STACK-style hover readout: small, follows the cursor, gone on hover-off
  function updateHover(e) {
    const el = hoverRef.current;
    if (!el) return;
    if (panRef.current || dragRef.current || pendingClickRef.current || status !== "ready") { el.style.display = "none"; hoverIdRef.current = ""; return; }
    const pt = toImage(e.clientX, e.clientY);
    const thr = 8 / tfRef.current.scale;
    const hit = [...stackedShapes].reverse().find((s) => {
      const sp = panelByKey(s.sheet_id);
      return hitShapeC(s, pt[0] - sp.xOffset, pt[1], sp.img.w, sp.img.h, thr);
    });
    if (!hit) { el.style.display = "none"; hoverIdRef.current = ""; return; }
    if (hoverIdRef.current !== hit.id) { el.textContent = describeShape(hit); hoverIdRef.current = hit.id; }
    const r = containerRef.current.getBoundingClientRect();
    el.style.left = `${e.clientX - r.left + 14}px`;
    el.style.top = `${e.clientY - r.top + 16}px`;
    el.style.display = "block";
  }
  function onPointerMove(e) {
    lastPtrRef.current = [e.clientX, e.clientY];   // paste targets the sheet under the cursor
    aimSeqRef.current++;                           // deixis freshness tick — see getAimSeed
    // (re)placing an image markup: it rides the cursor until the next click drops
    // it. On the pointer's FIRST canvas contact (or when it crosses to a new sheet)
    // we grab the image WHERE IT SITS — recording the cursor→centre offset so it
    // doesn't teleport under the cursor — then move it by the cursor delta after.
    // Live setMarkups mirrors the move-drag; committed on pointerdown below.
    if (placingImageId) {
      const q = toImage(e.clientX, e.clientY);
      const tp = panelAt(q[0]);
      if (tp?.img?.w) {
        const cx = (q[0] - tp.xOffset) / tp.img.w, cy = q[1] / tp.img.h;
        if (!placeGrabRef.current || placeGrabRef.current.key !== tp.key) {
          // cross-sheet place (flagged at Place-button time in placeCrossSheetRef,
          // not by re-reading the markup's sheet_id here — it may already have
          // been rewritten to tp.key by an earlier contact this same gesture):
          // the image's stored `at` is a position on the OTHER sheet and means
          // nothing here, so zero the offset and let it center under the cursor
          // instead of riding a bogus delta.
          if (placeCrossSheetRef.current === placingImageId) {
            placeGrabRef.current = { key: tp.key, dx: 0, dy: 0 };
          } else {
            const m0 = markups.find((m) => m.id === placingImageId);
            const ax = m0 && Array.isArray(m0.at) ? m0.at[0] : cx, ay = m0 && Array.isArray(m0.at) ? m0.at[1] : cy;
            placeGrabRef.current = { key: tp.key, dx: ax - cx, dy: ay - cy };
          }
        }
        const g = placeGrabRef.current;
        setMarkups((ms) => ms.map((m) => (m.id === placingImageId ? { ...m, at: [cx + g.dx, cy + g.dy], sheet_id: tp.key } : m)));
      }
      return;
    }
    // status-bar coords — direct DOM (instrument readout; no React render per move).
    // Sheet feet when the hovered panel has a scale, raw image px otherwise.
    if (statusCoordRef.current) {
      const q = toImage(e.clientX, e.clientY);
      const sp = panelAt(q[0]);
      const u = scales[sp.key];
      statusCoordRef.current.textContent = u
        ? `x ${fmtCheckLen((q[0] - sp.xOffset) * u, units)} · y ${fmtCheckLen(q[1] * u, units)}`
        : `x ${Math.round(q[0] - sp.xOffset)} · y ${Math.round(q[1])} px`;
    }
    if (hlRef.current) {
      // paint: distance-thin at capture, live preview via DOM (no React render per move)
      const st = hlRef.current;
      const q = toImage(e.clientX, e.clientY);
      const last = st.pts[st.pts.length - 1];
      if (Math.hypot(q[0] - last[0], q[1] - last[1]) >= 2.5 / tfRef.current.scale && st.pts.length < 4000) st.pts.push(q);
      if (hlPathRef.current) {
        const w = hlStyle.size / tfRef.current.scale;
        hlPathRef.current.setAttribute("d", hlStyle.tip === "chisel"
          ? (st.pts.length > 1 ? "M" + chiselRibbon(st.pts, w, 45).map((v) => v.join(",")).join(" L") + " Z" : "")
          : strokePathD(st.pts));
      }
      return;
    }
    moveCrosshair(e);                 // full-page aim guide (draw modes), always tracks hover
    // a held draw-click that moves becomes a pan (point placement waits for up)
    if (pendingClickRef.current && !panRef.current) {
      const pc = pendingClickRef.current;
      if (Math.hypot(e.clientX - pc.cx, e.clientY - pc.cy) > 5 && (tool === "rect" || tool === "deduct-rect") && poly.length === 0) {
        // a held Rectangle press that moves draws the box (corner 1 now, corner 2 on release)
        pendingClickRef.current = null;
        rectDragRef.current = true;
        performClick(pc.p, e);
      } else if (Math.hypot(e.clientX - pc.cx, e.clientY - pc.cy) > 5) {
        promoteStage();
        panRef.current = { sx: pc.cx, sy: pc.cy, ox: tfRef.current.x, oy: tfRef.current.y };
        pendingClickRef.current = null;
        if (containerRef.current) containerRef.current.style.cursor = "grabbing";
      }
    }
    updateHover(e);
    if (tool === "select") updateInsGhost(e);
    // One-Click proposal editing: dragging a corner/edge grip, else revealing
    // handles on the region under the cursor. Both work in panel-LOCAL px.
    if (ocDragRef.current) { ocDragMove(e); return; }
    if (tool === "oneclick" && proposal && !panRef.current && !pendingClickRef.current) ocHoverUpdate(e);
    if (dragRef.current) {
      const d = dragRef.current;
      // dragRef is armed only by selectAt (Select tool), where snapRef is stale
      // (moveCrosshair bails for Select) — track the RAW cursor; vertex/edge
      // drags apply their own endpoint snap (ocSnap), and a body move is free.
      const p = toImage(e.clientX, e.clientY);
      // Live PREVIEW only — geometry follows the cursor for feel, but nothing
      // stamps here anymore: provenance is applied exactly once, on release,
      // by the geom command in onPointerUp (whose `prev` is the grab-time
      // snapshot — so stampEdit's freeze still reads the TRUE pre-drag ring).
      // The gx/gy gate keeps a plain select-click's zero-delta pointermove
      // from writing any preview state at all: no motion ⇒ no write ⇒ no
      // command ⇒ no stamp — the old d.stamped flag guard, made structural.
      // vn is computed OUTSIDE the updater (from the grab-time snapshot, which
      // is exact: a gesture only ever moves the verts named by the drag ref)
      // and remembered on the ref (d.lastVerts/d.lastComputed) so the release
      // commit and the preview can never disagree.
      if (d.kind === "vertex" || d.kind === "edge" || d.kind === "move") {
        if (!d.moved && e.clientX === d.gx && e.clientY === d.gy) return;
        d.moved = true;
        const sp = panelByKey(d.shape.sheet_id);
        let vn;
        if (d.kind === "vertex") {
          let [slx, sly] = ocSnap(sp.key, p[0] - sp.xOffset, p[1], !!d.shape.origin?.raster_traced);   // snap the corner to true endpoints (never on a raster-traced shape — see ocSnap)
          // auto-straighten (45° toggle): when no endpoint claimed the point,
          // the dragged vertex locks onto its neighbors' axes — an edited wall
          // stays straight instead of drifting a pixel off square. Osnap wins;
          // toggle 45° off to place genuinely angled vertices freely.
          if (angleOn && slx === p[0] - sp.xOffset && sly === p[1]) {
            const base = d.prev.verts_norm, n0 = base.length;
            const closed = d.shape.measure_role !== "linear" && d.shape.measure_role !== "surface_area";
            const pick = (i) => {
              let k = i;
              if (closed) k = ((i % n0) + n0) % n0; else if (k < 0 || k >= n0) return null;
              const v = base[k];
              return v ? [v[0] * sp.img.w, v[1] * sp.img.h] : null;
            };
            const lock = axisLockPoint([slx, sly], pick(d.vIndex - 1), pick(d.vIndex + 1), 8 / tfRef.current.scale);
            if (lock.locked) [slx, sly] = lock.pt;
          }
          vn = d.prev.verts_norm.map((v, i) => (i === d.vIndex ? [slx / sp.img.w, sly / sp.img.h] : v));
        } else if (d.kind === "edge") {
          // translate BOTH endpoints of the line by the drag delta; each end snaps
          // to the linework independently (normalized → local px → snap → normalized)
          const dx = (p[0] - d.start[0]) / sp.img.w, dy = (p[1] - d.start[1]) / sp.img.h;
          const rt = !!d.shape.origin?.raster_traced;
          const snapN = (nx, ny) => { const [lx, ly] = ocSnap(sp.key, nx * sp.img.w, ny * sp.img.h, rt); return [lx / sp.img.w, ly / sp.img.h]; };
          const na = snapN(d.oaN[0] + dx, d.oaN[1] + dy), nb = snapN(d.obN[0] + dx, d.obN[1] + dy);
          vn = d.prev.verts_norm.map((v, i) => (i === d.i ? na : i === d.j ? nb : v));
        } else {
          // start and p are both stage px, so xOffset cancels in the delta —
          // only the normalizing divisor is the shape's own panel
          const dx = (p[0] - d.start[0]) / sp.img.w, dy = (p[1] - d.start[1]) / sp.img.h;
          vn = d.orig.map(([nx, ny]) => [nx + dx, ny + dy]);
        }
        d.lastVerts = vn;
        // a translation never re-prices (same lengths/areas) — matches the old
        // move updater, which left `computed` untouched
        d.lastComputed = d.kind === "move" ? undefined : recomputeShape({ ...d.shape, verts_norm: vn });
        setShapes((ss) => ss.map((s) => (s.id !== d.shapeId ? s
          : d.kind === "move" ? { ...s, verts_norm: vn }
            : { ...s, verts_norm: vn, computed: d.lastComputed })));
      } else if (d.kind === "markupMove") {
        // raw cursor point — markups aren't snapped/angle-locked, and this matches the
        // raw d.start so the delta can't jump from a stale snap/angle ref.
        const mp = toImage(e.clientX, e.clientY);
        // dblclick-safe: stay inert until the pointer travels past the ~5px pan
        // threshold, so a click / first click of a double-click never moves it
        const sc = tfRef.current.scale;
        if (!d.moved && Math.hypot(mp[0] - d.start[0], mp[1] - d.start[1]) < 5 / sc) return;
        d.moved = true;
        const sp = panelByKey(d.sheetId);
        if (!sp || !sp.img.w) return;
        // start and mp are both stage px, so xOffset cancels in the delta; normalize
        // by the markup's OWN panel dims. Live setMarkups each move (mirrors the shape
        // `move` pattern; NOT commit-on-release). Persistence is automatic.
        const dx = (mp[0] - d.start[0]) / sp.img.w, dy = (mp[1] - d.start[1]) / sp.img.h;
        const o = d.orig;
        setMarkups((ms) => ms.map((m) => {
          if (m.id !== d.markupId) return m;
          if (o.pts) return { ...m, pts: o.pts.map(([nx, ny]) => [nx + dx, ny + dy]) };   // highlighter stroke
          if (o.rect) return { ...m, rect: [[o.rect[0][0] + dx, o.rect[0][1] + dy], [o.rect[1][0] + dx, o.rect[1][1] + dy]] };
          if (o.target) return { ...m, at: [o.at[0] + dx, o.at[1] + dy], target: [o.target[0] + dx, o.target[1] + dy] };
          if (o.from) return { ...m, from: [o.from[0] + dx, o.from[1] + dy], to: [o.to[0] + dx, o.to[1] + dy] };
          return { ...m, at: [o.at[0] + dx, o.at[1] + dy] };   // text + bubble
        }));
      } else if (d.kind === "markupResize") {
        // drag the BR corner while the top-left stays fixed — resizeImageFromCorner
        // clamps width first, then derives the new center so the top-left is
        // invariant even at the clamp rails. Live setMarkups (not commit-on-release);
        // onPointerUp sees a non-shape kind and just releases capture.
        const mp = toImage(e.clientX, e.clientY);
        const pointerLocalX = mp[0] - d.ox;
        const { w, at } = resizeImageFromCorner({ x: d.tl.x, y: d.tl.y }, { x: pointerLocalX, y: mp[1] }, d.aspect, d.imgW, d.imgH);
        d.moved = true;   // a real resize tick occurred — onPointerUp's commit checks this
        setMarkups((ms) => ms.map((m) => (m.id === d.markupId ? { ...m, w, at } : m)));
      }
      return;
    }
    if (!panRef.current) return;
    // rAF-coalesced: pointermove can outrun the display (120Hz+ mice/trackpads) — keep
    // the latest position and write the transform once per frame. Still no React render.
    panRef.current.lx = e.clientX; panRef.current.ly = e.clientY;
    if (!panRafRef.current) panRafRef.current = requestAnimationFrame(() => {
      panRafRef.current = 0;
      const pr = panRef.current; if (!pr) return;
      tfRef.current = { ...tfRef.current, x: pr.ox + (pr.lx - pr.sx), y: pr.oy + (pr.ly - pr.sy) };
      applyTf();
      scheduleSync();   // keeps the tf mirror (labels/strokes) honest during long pans
    });
  }
  function onPointerUp(e) {
    if (hlRef.current) {
      const st = hlRef.current;
      hlRef.current = null;
      if (hlPathRef.current) hlPathRef.current.style.display = "none";
      try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* gone */ }
      if (st.pts.length >= 2) {
        const tp = panelByKey(st.key) || panelAt(st.pts[0][0]);
        const pts = thinStroke(st.pts, 2.5 / tfRef.current.scale)
          .map(([x, y]) => [(x - tp.xOffset) / tp.img.w, y / tp.img.h]);
        // width as a FRACTION of panel width — the stroke scales with the plan like ink,
        // and survives raster-budget changes (screen px ÷ scale ÷ panel width at draw time)
        addMarkup({
          type: "highlight", pts, color: hlStyle.color,
          w: (hlStyle.size / tfRef.current.scale) / tp.img.w, tip: hlStyle.tip
        }, tp.key);
      }
      return;
    }
    if (rectDragRef.current) {
      rectDragRef.current = false;
      const q = (snapOn && snapRef.current) ? snapRef.current : toImage(e.clientX, e.clientY);
      if (tool === "rect" || tool === "deduct-rect") performClick(q, e);
      try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* gone */ }
      return;
    }
    if (pendingClickRef.current) {
      const { p } = pendingClickRef.current;
      pendingClickRef.current = null;
      performClick(p, e);
      try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* gone */ }
      return;
    }
    if (ocDragRef.current) { ocDragRef.current = null; bumpIdle(); try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* gone */ } return; }
    if (dragRef.current) {
      const d = dragRef.current;
      dragRef.current = null;
      bumpIdle();
      // Commit-on-gesture-end: ONE geom command per drag, and only when the
      // geometry actually moved off the grab-time snapshot (a drag that snapped
      // back exactly is not an edit — no command, no stamp). The command's
      // canonical result supersedes the live-preview frames; `prev` carries the
      // grab-time verts/computed/provenance so the stamp freezes the true
      // pre-drag ring and undo restores it exactly. (pointercancel routes here
      // too, so an interrupted drag still lands as a stamped command, never as
      // orphaned preview state.)
      if ((d.kind === "vertex" || d.kind === "edge" || d.kind === "move")
        && d.lastVerts && !vertsEqual(d.lastVerts, d.prev.verts_norm)) {
        dispatchShape({
          type: "geom", id: d.shapeId, editKind: d.kind,
          verts_norm: d.lastVerts,
          ...(d.lastComputed !== undefined ? { computed: d.lastComputed } : {}),
          prev: d.prev,
        });
      } else if ((d.kind === "markupMove" || d.kind === "markupResize") && d.moved) {
        // Same commit-boundary doctrine as the shape geom command above: the
        // per-frame setMarkups calls in onPointerMove (:3799 body/handle drag,
        // :3815 resize) are the live PREVIEW and stay unstamped; this is where
        // the drag actually ends. `d.moved` gates out a plain select-click that
        // arms the drag but never crosses the move threshold / never resizes —
        // that's not an edit, so it gets no stamp (mirrors the shape branch's
        // lastVerts-changed guard above). Without this, a cross-sheet move/resize
        // that leaves created_at untouched is silently reverted on a 3-way sync
        // tie (merge tiebreak: updated_at || created_at, ties → remote wins).
        updateMarkup(d.markupId, { updated_at: nowIso() });
      }
      try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* gone */ }
      return;
    }
    if (panRef.current) {
      panRef.current = null;
      setTf({ ...tfRef.current });   // sync once at end
      if (containerRef.current) containerRef.current.style.cursor = spaceRef.current ? "grab" : "";
      try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* gone */ }
    }
  }

  // Calibrated ruler bar — shows for a few seconds whenever a scale is accepted
  // (scale menu standard pick, the plan-says item, calibration, check-tool
  // recalibrate) so a grossly wrong scale is visually obvious against known
  // elements (a door is ~3′). Takes the NEW upp as an argument — never read
  // `scales` right after setScales (stale closure). Ephemeral: never persisted,
  // dismissed by the next action. `preview` marks a HOVER preview of a scale
  // that was never accepted — it must additionally die with the hover/menu
  // (clearPreviewGuide), while an accepted bar rides out its 8 s.
  function showScaleGuide(key, uppStored, label, preview = false) {
    const p = panelByKey(key);
    if (!p?.img.w || !containerRef.current) return;
    scaleGuidePreviewRef.current = preview;
    const uppBitmap = uppStored / factorFor(key);   // feet per bitmap px, matches uppFor math
    const z = tfRef.current.scale;
    // round guide length picked so the bar is legible (≥160 screen px) at the current zoom
    const CAND = units === "metric" ? [1, 2, 5, 10, 20, 50, 100].map((m) => m / M_PER_FT) : [2, 5, 10, 20, 50, 100, 200];
    const feet = CAND.find((f) => (f / uppBitmap) * z >= 160) ?? CAND[CAND.length - 1];
    const r = containerRef.current.getBoundingClientRect();
    const t = tfRef.current;
    const cx = Math.min(Math.max(((r.width / 2) - t.x) / t.scale, p.xOffset + p.img.w * 0.1), p.xOffset + p.img.w * 0.9);
    const cy = Math.min(Math.max(((r.height * 0.78) - t.y) / t.scale, p.img.h * 0.1), p.img.h * 0.92);
    setScaleGuide({ key, feet, px: feet / uppBitmap, label, at: [cx, cy] });
    clearTimeout(scaleGuideTimerRef.current);
    scaleGuideTimerRef.current = setTimeout(() => setScaleGuide(null), 8000);
  }
  useEffect(() => { setScaleGuide(null); scaleGuidePreviewRef.current = false; }, [tool, groupSig]);
  useEffect(() => () => clearTimeout(scaleGuideTimerRef.current), []);
  // Kill a hover-preview guide (and only a preview — an accepted bar stays).
  // Fired on hover-out of the plan-says item AND whenever the scale menu
  // closes (item click, Escape, outside click — the item button unmounts
  // without a mouseleave, so hover-out alone can't be trusted). Stable
  // identity: it feeds the menu's onOpenChange effect via onScaleMenuDepth.
  const clearPreviewGuide = useCallback(() => {
    if (!scaleGuidePreviewRef.current) return;
    scaleGuidePreviewRef.current = false;
    clearTimeout(scaleGuideTimerRef.current);
    setScaleGuide(null);
  }, []);
  const onScaleMenuDepth = useCallback((o) => { onMenuDepth(o); if (!o) clearPreviewGuide(); }, [onMenuDepth, clearPreviewGuide]);

  // Every user-facing scale acceptance goes through here: store the new scale
  // AND re-price the committed shapes on that sheet. `computed` is priced at
  // draw time, so without this a rescale left every existing SF/LF at the old
  // scale (the same staleness pasteClipboard calls "the legacy bug") — glaring
  // now that the check tool's one-tap recalibrate makes late rescales routine.
  // Hydrate bypasses this on purpose: saved computed matches the saved scale.
  function rescaleSheet(key, upp) {
    // stash the scale this rescale replaces, but only when it actually changes
    // committed quantities (sheet had a scale, the scale moved, shapes exist on
    // it) — that's the case worth a one-step revert (the Scale menu surfaces it)
    const prior = scales[key];
    if (prior === upp) { confirmScale(key); return; } // re-picking the active scale — no reprice churn, no stash (mirrors the MCP guard)
    const sp = panels.find((p) => p.key === key);
    if (!sp?.img?.w && shapes.some((sh) => sh.sheet_id === key && sh.measure_role !== "count")) {
      setCommitMsg(uiText("Open this sheet before recalibrating its measurements."));
      return;
    }
    if (prior != null && shapes.some((sh) => sh.sheet_id === key)) {
      setPrevScale({ key, upp: prior, source: scaleSources[key] || "standard" });
    }
    setScales((s) => ({ ...s, [key]: upp }));
    confirmScale(key);   // scale gate: a human scale act IS the confirmation
    // The vector mask bakes the scale in (its hatch-pitch cap and seal radii
    // are feet-true via mppf), so a recalibrated sheet must rebuild its masks
    // on next use — a mask built against the old calibration is exactly the
    // failure class the scale pinning exists to remove.
    maskCacheRef.current.delete(key);
    rasterMaskCacheRef.current.delete(key);
    if (!sp?.img?.w) return; // no dimensional shapes to reprice
    const uEff = upp / factorFor(key);
    // count shapes keep their computed: EA has no upp dependency at all, and
    // recomputeShape's count branch would clobber a hand-edited / hydrated
    // fractional count (supported data — see totals.js accumulateRole) to 1.
    // A rescale re-price is a whole-array NON-edit (`replace`: no stamps, no
    // counters) and it RESETS both undo stacks: every recorded command froze
    // `computed` at the old scale, and undoing one afterwards would resurrect
    // stale quantities.
    const repriced = new Map(recalibrateShapes(shapes.filter((sh) => sh.sheet_id === key), sp.img, uEff, conditions).map((sh) => [sh.id, sh]));
    dispatchShape({ type: "replace", shapes: shapes.map((sh) => repriced.get(sh.id) || sh) }, { reset: true });
  }

  // Revert the last quantity-changing rescale (the one-slot stash above): runs
  // the same rescaleSheet back — which re-stashes the scale being replaced, so
  // a revert is itself revertible (a two-way toggle, not a history).
  function revertScale() {
    const pv = prevScale;
    if (!pv) return;
    rescaleSheet(pv.key, pv.upp);
    setScaleSources((s) => ({ ...s, [pv.key]: pv.source }));
    showScaleGuide(pv.key, pv.upp, STANDARD_SCALES.find((x) => Math.abs(x.upp - pv.upp) < 1e-9)?.label || pv.source);
  }

  function applyCalibration() {
    const feet = calInputToFeet(parseFloat(pendingLen), units);   // metric users type meters; stored scale stays feet
    if (!(feet > 0) || calib.length !== 2) return;
    const pa = panelAt(calib[0][0]), pb = panelAt(calib[1][0]);
    if (pa.key !== pb.key) {
      setCommitMsg(uiText("Calibrate on one sheet — those two clicks landed on different sheets."));
      setCalib([]); setPendingLen(""); return;
    }
    const px = Math.hypot(calib[1][0] - calib[0][0], calib[1][1] - calib[0][1]);
    if (px <= 0) return;
    // store at BASELINE resolution — the auto hi-res raster has factorFor× denser pixels
    const toBase = factorFor(pa.key);
    rescaleSheet(pa.key, (feet / px) * toBase); // per page — remembered for this sheet
    setScaleSources((s) => ({ ...s, [pa.key]: "calibrated" }));
    showScaleGuide(pa.key, (feet / px) * toBase, "calibrated");
    setCalib([]); setPendingLen("");
  }

  // Check tool's one-tap recalibrate: the measured span IS a calibration line —
  // same math as applyCalibration, sourced from the check points + stated value.
  function recalibrateFromCheck() {
    const feet = parseLenInput(checkStated, units);
    if (!(feet > 0) || check.length !== 2) return;
    const pa = panelAt(check[0][0]);
    if (panelAt(check[1][0])?.key !== pa?.key) return; // cross-panel span — the UI hides the button, but keep the function safe standalone
    const px = Math.hypot(check[1][0] - check[0][0], check[1][1] - check[0][1]);
    if (px <= 0) return;
    const toBase = factorFor(pa.key);
    rescaleSheet(pa.key, (feet / px) * toBase);
    setScaleSources((s) => ({ ...s, [pa.key]: "calibrated" }));
    showScaleGuide(pa.key, (feet / px) * toBase, "calibrated");
    setCheck([]); setCheckStated("");
  }

  // A shape belongs to the panel of its FIRST point — verts normalize against
  // that panel's dims, quantities use that sheet's scale.
  // #137 — try to resolve a freshly-drawn deduct into a REAL hole in a parent
  // floor_area shape (turf boolean subtract, lib/cutout.js) instead of it
  // landing as a second independent overlay. Returns null (caller keeps the
  // legacy path) whenever the resolution is anything but unambiguous:
  //   - zero or 2+ floor_area shapes on this sheet touch the deduct's ring
  //     (ambiguous parent, or it spans more than one condition's shape);
  //   - the boolean op itself degenerates (deduct erases the parent, or
  //     splits it into disjoint pieces — subtractCutout refuses both).
  // A parent that already carries reconciled cutout(s) is a normal target:
  // the new ring subtracts against (outer + existing holes), so N deducts
  // compose into N holes and overlap between cuts never double-deducts.
  function resolveCutout(tp, deductPointsPx, deductShape) {
    // deductPointsPx is ABSOLUTE stage space (commitPoly's `points`, xOffset
    // baked in — same convention as verts_norm's own encode below); candidate
    // rings must land in that SAME frame or containment/overlap comes out
    // wrong the moment more than one sheet is open side by side (group view).
    const candidates = shapes
      .filter((s) => s.sheet_id === tp.key && s.measure_role === "floor_area")
      .map((s) => ({ id: s.id, ringPx: s.verts_norm.map(([x, y]) => [x * tp.img.w + tp.xOffset, y * tp.img.h]) }));
    if (!candidates.length) return null;
    const parentId = findCutoutParent(candidates, deductPointsPx);
    if (!parentId) return null;
    const parent = shapes.find((s) => s.id === parentId);
    const parentRingPx = candidates.find((c) => c.id === parentId).ringPx;
    const parentHolesPx = (parent.verts_norm_holes || []).map((ring) => ring.map(([nx, ny]) => [nx * tp.img.w + tp.xOffset, ny * tp.img.h]));
    const result = subtractCutout(parentRingPx, parentHolesPx, deductPointsPx);
    if (!result) return null;
    const norm = (ring) => ring.map(([x, y]) => [(x - tp.xOffset) / tp.img.w, y / tp.img.h]);
    const upp = uppFor(tp.key);
    const parentNext = {
      verts_norm: norm(result.outer),
      verts_norm_holes: result.holes.map(norm),
      computed: { area_sf: +(result.area * upp * upp).toFixed(2), perimeter_lf: +(result.perim * upp).toFixed(2) },
    };
    // Frozen pre-cut snapshot of the PARENT, durable on the deduct's own
    // origin (not just the ephemeral undo stack) — deleteSelected reads this
    // to revert the parent's geometry when this specific cutout is deleted
    // later, possibly in a different session after the undo stack is long gone.
    const parentPrev = {
      verts_norm: parent.verts_norm.map((v) => [...v]),
      ...("verts_norm_holes" in parent ? { verts_norm_holes: parent.verts_norm_holes.map((r) => r.map((v) => [...v])) } : {}),
      ...("computed" in parent ? { computed: parent.computed } : {}),
    };
    return {
      parentId,
      parentNext,
      deductShape: {
        ...deductShape,
        cuts_shape_id: parentId,
        origin: { method: "cutout_v1", cuts_shape_id: parentId, parent_prev: parentPrev },
      },
    };
  }
  // WALL TILE IS NOT A POLYGON. A Surface Area takeoff is an OPEN run traced
  // in plan × the condition's height, and base/transitions are the same run
  // without one — but every path the Cut Out tool could take resolved against
  // `floor_area` shapes only. Drawing one over a wall run therefore did the
  // worst available thing quietly: it landed an independent deduct overlay
  // whose area came off the condition's FLOOR total, a bucket a wall run
  // never fills (lib/totals accumulateRole), so the wall SF never moved and
  // the floor went negative instead. There was no other way to take a stretch
  // of wall tile back out.
  //
  // Runs now cut: the ring CLIPS the polyline (lib/cutout.cutRunsAcross),
  // quantities scale with the surviving length — exactly right for both
  // roles, since wall SF is LF × height and a border's SF is LF × thickness —
  // and a cut through the middle leaves the far side as its own shape. Every
  // run the ring touches is cut, not one unambiguous parent: a ring dropped
  // on a corner where two runs meet cuts both, which is what was drawn. A
  // CURVED run is left alone — its verts are control points, not the line
  // itself, so clipping them would move the curve it re-smooths through.
  // Returns null when the ring crosses no run at all.
  const RUN_ROLES = new Set(["surface_area", "linear"]);
  function resolveRunCuts(tp, ringPx) {
    const upp = uppFor(tp.key);
    if (!upp) return null;
    const candidates = shapes
      .filter((s) => s.sheet_id === tp.key && RUN_ROLES.has(s.measure_role) && !s.curved && (s.verts_norm || []).length >= 2)
      .map((s) => ({ id: s.id, runPx: s.verts_norm.map(([x, y]) => [x * tp.img.w + tp.xOffset, y * tp.img.h]) }));
    if (!candidates.length) return null;
    const hits = cutRunsAcross(candidates, ringPx);
    if (!hits.length) return null;
    const norm = (run) => run.map(([x, y]) => [(x - tp.xOffset) / tp.img.w, y / tp.img.h]);
    const byId = new Map(shapes.map((s) => [s.id, s]));
    const targets = [], mint = [], deleteIds = [];
    for (const h of hits) {
      if (h.kind === "erased") { deleteIds.push(h.id); continue; }
      const src = byId.get(h.id);
      // quantities ride the length: SF/LF scale by (survived / original), so a
      // per-shape height or a condition thickness stays honoured without this
      // reaching back into the condition at all
      const was = src?.computed?.perimeter_lf || 0;
      const qty = (lenPx) => {
        const lf = +(lenPx * upp).toFixed(2);
        const k = was > 0 ? lf / was : 0;
        return { perimeter_lf: lf, area_sf: +((src?.computed?.area_sf || 0) * k).toFixed(2) };
      };
      const [head, ...rest] = h.runs;
      targets.push({ id: h.id, next: { verts_norm: norm(head), computed: qty(openLen(head)) } });
      for (const piece of rest) {
        const { id: _id, created_at: _ct, ...carry } = src;
        mint.push({ ...carry, verts_norm: norm(piece), computed: qty(openLen(piece)) });
      }
    }
    return { targets, mint, deleteIds };
  }
  const runCutMsg = (runs) => {
    const bits = [];
    if (runs.targets.length) bits.push(`cut ${runs.targets.length} run${runs.targets.length === 1 ? "" : "s"}`);
    if (runs.mint.length) bits.push(`${runs.mint.length} left on the far side of the cut`);
    if (runs.deleteIds.length) bits.push(`removed ${runs.deleteIds.length} outright`);
    return `Cut Out: ${bits.join(" \u00b7 ")}.`;
  };
  // A trace whose points span two side-by-side panels has no coherent
  // quantity — the inter-panel gap would be measured as real feet, and the
  // shape would bind to one sheet with vertices hanging off its edge. Refuse
  // at commit (the calibrate cross-panel precedent) and point at the fix:
  // stitching joins the sheets into ONE panel, where a spanning trace is
  // exactly right (#161).
  function spansPanels(points) {
    if (panels.length < 2) return false;
    const first = panelAt(points[0][0]);
    return points.some((q) => panelAt(q[0]) !== first);
  }
  const SPAN_MSG = "That trace crosses onto another sheet — the gap between sheets isn't real distance. To work a floor split at a match line as one surface, stitch the sheets (Sheets → gallery → select both → Stitch).";
  function commitPoly(points, asDeduct, opts = {}) {
    if (points.length < 3) return;
    if (spansPanels(points)) { setCommitMsg(SPAN_MSG); return; }
    const tp = panelAt(points[0][0]);
    const upp = uppFor(tp.key);
    if (!upp) { setCommitMsg(uiText(`Set the scale for ${labelFor(tp)} first.`)); return; }
    if (!activeCond) { setCommitMsg(uiText("Pick or add a condition first.")); return; }
    const met = closedMetrics(points);
    // id + created_at are minted by the add command — the ONE creation gate
    const shape = {
      sheet_id: tp.key, condition_id: activeCond,
      measure_role: asDeduct ? "deduct" : "floor_area",
      verts_norm: points.map(([x, y]) => [(x - tp.xOffset) / tp.img.w, y / tp.img.h]),
      computed: { area_sf: +(met.area * upp * upp).toFixed(2), perimeter_lf: +(met.perim * upp).toFixed(2) },
      ...(activeLabel ? { label: activeLabel } : {}),
      origin: { method: "manual", ...(opts.curved ? { curved: true } : {}) },
    };
    // #137 — a deduct tries the real-hole path first; anything ambiguous
    // (see resolveCutout) falls straight back to the independent-overlay
    // commit below, unchanged.
    if (asDeduct) {
      // the run half of the ring rides inside the SAME command, so one drawn
      // ring stays one ⌘Z whether it crossed an area, some runs, or both
      const runs = resolveRunCuts(tp, points);
      const cut = resolveCutout(tp, points, shape);
      if (cut) {
        const res = dispatchShape({ type: "cutout", shape: cut.deductShape, parentId: cut.parentId, parentNext: cut.parentNext, ...(runs ? { runs } : {}) });
        if (runs) setCommitMsg(runCutMsg(runs));
        // the deduct is pushed first, any far-side run pieces after it
        maybeOfferRule(res.shapes[res.shapes.length - 1 - (runs ? runs.mint.length : 0)], res.shapes);
        return;
      }
      if (runs) {
        // nothing but runs under the ring — there is no area for a deduct
        // receipt to sit on, so none is minted
        dispatchShape({ type: "cutout", runs });
        setCommitMsg(runCutMsg(runs));
        return;
      }
    }
    const res = dispatchShape({ type: "add", shapes: [shape] });
    // A Cut Out fully inside a same-condition room reads as a correction —
    // offer to make it a rule (#88). Detection only; nothing applies here.
    if (asDeduct) maybeOfferRule(res.shapes[res.shapes.length - 1], res.shapes);
  }
  function commitLinear(points, curved = false, baked = false) {
    if (points.length < 2) return;
    if (spansPanels(points)) { setCommitMsg(SPAN_MSG); return; }
    const tp = panelAt(points[0][0]);
    const upp = uppFor(tp.key);
    if (!upp) { setCommitMsg(uiText(`Set the scale for ${labelFor(tp)} first.`)); return; }
    if (!activeCond) { setCommitMsg(uiText("Pick or add a condition first.")); return; }
    // curved: verts stay the clicked CONTROL points (drag one → re-smooths);
    // length always comes from the flattened spline
    // quantified by the ONE computer (shapeMetrics): border SF from the
    // condition's thickness, and the run's rise/drop (#441) added to its LF
    const draft = {
      sheet_id: tp.key, condition_id: activeCond, measure_role: "linear",
      ...(curved ? { curved: true } : {}),
      verts_norm: points.map(([x, y]) => [(x - tp.xOffset) / tp.img.w, y / tp.img.h]),
      ...(activeLabel ? { label: activeLabel } : {}),
      origin: { method: "manual", ...(baked ? { curved: true } : {}) },
    };
    dispatchShape({ type: "add", shapes: [{ ...draft, computed: computeShapeMetrics(draft, tp.img, upp, aCond) }] });
  }
  // Surface Area — trace the wall run in plan; SF = traced LF × the condition's
  // height. The wall-tile "stack" workflow: set tile height once, trace walls.
  function commitSurface(points, baked = false) {
    if (points.length < 2) return;
    if (spansPanels(points)) { setCommitMsg(SPAN_MSG); return; }
    const tp = panelAt(points[0][0]);
    const upp = uppFor(tp.key);
    if (!upp) { setCommitMsg(uiText(`Set the scale for ${labelFor(tp)} first.`)); return; }
    if (!activeCond) { setCommitMsg(uiText("Pick or add a condition first.")); return; }
    const h = Number(aCond?.height_ft) || 0;
    if (!(h > 0)) { setCommitMsg(uiText(`Set a height for ${aCond?.finish_tag || "this condition"} (H in the condition editor) — Surface Area = traced LF × height.`)); return; }
    const LF = openLen(points) * upp;
    dispatchShape({
      type: "add", shapes: [{
        sheet_id: tp.key, condition_id: activeCond, measure_role: "surface_area", height_ft: h,
        verts_norm: points.map(([x, y]) => [(x - tp.xOffset) / tp.img.w, y / tp.img.h]),
        computed: { area_sf: +(LF * h).toFixed(2), perimeter_lf: +LF.toFixed(2) },
        ...(activeLabel ? { label: activeLabel } : {}),
        origin: { method: "manual", ...(baked ? { curved: true } : {}) },
      }]
    });
  }
  // ── the Symbol tool (#264): marquee one instance → the engine finds every
  // placement; matches light up, near-misses ask, and nothing commits until
  // the estimator says so. Engine + labels are the same pure libs the MCP
  // ships (sweepSymbols / labelPlacements) — canvas and agent cannot disagree.
  async function ensureTextSpans(key) {
    if (textSpansRef.current.has(key)) return textSpansRef.current.get(key);
    const spans = [];
    const { page: pg, release } = holdSheetPage(key);
    try {
      const vt = textTfRef.current.get(key);
      if (pg && vt) {
        const tc = await pg.getTextContent();
        for (const it of tc.items || []) {
          const str = (it.str || "");
          if (!str.trim()) continue;
          const t = pdfjsLib.Util.transform(vt, it.transform);
          // it.width/height are USER-SPACE units (font size already in them) —
          // scale by the VIEWPORT alone, never the composed norm (which folds
          // the font size in a second time and inflates every box ~10×; found
          // live when a 12 px tag grew a 440 px adjacency and labeled the
          // wrong diamond). Same math as the MCP's textSpans, deliberately.
          const vs = Math.hypot(vt[0], vt[1]) || 2;
          const w = (it.width || 0) * vs;
          const h = (it.height || 0) * vs || Math.hypot(t[2], t[3]);
          // the box is the hull of the run's four corners along its own
          // direction, so a quarter-turn tag gets its true tall-narrow box
          // (and can rejoin below); unrotated text reduces to [y − h, y]
          const dn = Math.hypot(t[0], t[1]) || 1, un = Math.hypot(t[2], t[3]) || 1;
          const dx = t[0] / dn, dy = t[1] / dn, ux = t[2] / un, uy = t[3] / un;
          const xs = [t[4], t[4] + w * dx, t[4] + h * ux, t[4] + w * dx + h * ux];
          const ys = [t[5], t[5] + w * dy, t[5] + h * uy, t[5] + w * dy + h * uy];
          const rot = ((Math.round((Math.atan2(dy, dx) * 180) / Math.PI) % 360) + 360) % 360;
          spans.push({ str, x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys), ...(rot ? { rot } : {}) });
        }
      }
    } catch { /* no text layer — labels simply stay absent */ } finally { release(); }
    // runs pdf.js split mid-tag ("WB" + "-" + "01") rejoin — the MCP textSpans
    // does the same, so the Symbol tool labels exactly what the agent reads
    const joined = joinAbuttingSpans(spans);
    textSpansRef.current.set(key, joined);
    return joined;
  }
  async function runSymbolSweep(a, b) {
    const tp = panelAt(a[0]);
    const key = tp.key;
    const rect = [[a[0] - tp.xOffset, a[1]], [b[0] - tp.xOffset, b[1]]];
    const segs = vectorSegsRef.current.get(key);
    if (!segs || !segs.length) { setCommitMsg(uiText("This sheet has no vector linework (likely a scan) — the Symbol tool reads drawn segments.")); return; }
    const lum = segLumRef.current.get(key);
    let res;
    try {
      res = sweepSymbols(segs, rect, lum ? { lum } : {});
    } catch (e) {
      // the engine's refusals (empty marquee, region-sized marquee) are
      // instructions, exactly as the MCP surfaces them
      setCommitMsg(String((e && e.message) || e));
      return;
    }
    let labels = [];
    try {
      const spans = await ensureTextSpans(key);
      labels = labelPlacements(
        [res.seed.center, ...res.matches.map((m) => m.at), ...res.withheld.map((w) => w.at)],
        spans, segs, lum,
      );
    } catch { labels = []; }
    const L = (i) => labels[i] || null;
    const nM = res.matches.length;
    // One physical spot, ONE question. The engine discloses every rotational
    // reading of a near-miss (an instrument's honesty); the review lane must
    // not draw them as stacked rings — and must never let two readings of the
    // same symbol both be accepted into the count. Cluster at a quarter of
    // the marquee diagonal: readings of one instance sit a few px apart,
    // while genuinely adjacent instances (abutting tiles) stay separate.
    const clusterR = Math.max(6, Math.hypot(rect[1][0] - rect[0][0], rect[1][1] - rect[0][1]) / 4);
    const rawQ = res.withheld.map((w, i) => ({ ...w, label: L(1 + nM + i) }));
    const questions = [];
    for (const q of rawQ.sort((a, b) => b.score - a.score)) {
      const twin = questions.find((k) => Math.hypot(k.at[0] - q.at[0], k.at[1] - q.at[1]) <= clusterR);
      if (twin) { twin.readings += 1; continue; }
      questions.push({ ...q, readings: 1, state: "open" });
    }
    setSweep({
      key, img: tp.img,
      seed: { center: res.seed.center, rect: res.seed.rect, segments: res.seed.segments, label: L(0) },
      matches: res.matches.map((m, i) => ({ ...m, label: L(1 + i) })),
      questions,
      complete: res.complete, dropped: res.candidates.dropped,
      includeSeed: true, qIndex: 0, excludedTags: [],
    });
    setTool("select");
  }
  /** The label story in one line: "drawing says P-7 on all 4", or the mix. */
  function sweepLabelLine(rows, seedTag) {
    const tags = rows.map((r) => r.label?.label || null);
    const named = tags.filter(Boolean);
    if (!named.length) return null;
    if (seedTag && named.length === rows.length && named.every((t) => t === seedTag)) return `drawing says ${seedTag} on all ${rows.length}`;
    const byTag = {};
    for (const t of tags) byTag[t || "no label"] = (byTag[t || "no label"] || 0) + 1;
    return Object.entries(byTag).map(([t, n]) => `${t} ×${n}`).join(" · ");
  }
  function commitSweep() {
    const sw = sweep;
    if (!sw) return;
    if (!activeCond) { setCommitMsg(uiText("Pick or add a condition first.")); return; }
    const rows = [];
    const off = new Set(sw.excludedTags);
    const tagKey = (m) => (m.label && m.label.label) || "\u2205";
    if (sw.includeSeed) rows.push({ at: sw.seed.center, score: 1, rotation: 0, mirrored: false, seedRow: true });
    for (const m of sw.matches) if (!off.has(tagKey(m))) rows.push(m);
    for (const q of sw.questions) if (q.state === "accepted") rows.push(q);
    if (!rows.length) { setCommitMsg(uiText("Nothing to commit — no matches and no accepted questions.")); return; }
    // ONE dispatch = one undo step, the whole gesture — same batch discipline
    // as the MCP's set-wide commit
    dispatchShape({
      type: "add", shapes: rows.map((m) => ({
        sheet_id: sw.key, condition_id: activeCond, measure_role: "count",
        verts_norm: [[m.at[0] / sw.img.w, m.at[1] / sw.img.h]], computed: { count: 1 },
        ...(activeLabel ? { label: activeLabel } : {}),
        origin: { method: "symbol_sweep", symbol: { score: m.score, rotation: m.rotation, mirrored: m.mirrored, seed: { source: "instance", sheet: sw.key, ...(m.seedRow ? { seed_instance: true } : {}) } } },
      }))
    });
    const skippedN = sw.matches.length - sw.matches.filter((m) => !off.has(tagKey(m))).length;
    setCommitMsg(uiText(`Committed ${rows.length} EA under ${condById[activeCond]?.finish_tag || "condition"}${sw.includeSeed ? " — seed included" : ""}${skippedN ? ` · ${skippedN} excluded by label` : ""} · one undo step (${keyText(uiText("⌘Z"))}).`));
    setSweep(null);
  }

  function commitCount(p) {
    if (!activeCond) { setCommitMsg(uiText("Pick or add a condition first.")); return; }
    const tp = panelAt(p[0]);
    dispatchShape({
      type: "add", shapes: [{
        sheet_id: tp.key, condition_id: activeCond, measure_role: "count",
        verts_norm: [[(p[0] - tp.xOffset) / tp.img.w, p[1] / tp.img.h]], computed: { count: 1 }, ...(activeLabel ? { label: activeLabel } : {}), origin: { method: "manual" },
      }]
    });
  }

  // ── One-Click Area — click inside a room; the linework bounds it ──────────
  // Flood-fill on a downscaled raster of THIS panel's vector segments (the same
  // op-list walk that feeds snap), traced + RDP-simplified, vertices snapped to
  // true PDF endpoints. Clicks accumulate a PROPOSAL the estimator reviews:
  // click = add a space, ⌥-click = carve an enclosed cutout (column/shaft) —
  // a carve must sit INSIDE a selected space, and mints a deduct. Nothing is a
  // takeoff until Create (⏎) — the gate where provenance is minted (origin on
  // each shape). Mask + proposal live in panel-LOCAL px; a proposal is bound to
  // one panel and dies on sheet change (render effect resets it).
  // The sheet's stated layer roles as buildMask's per-segment codes (#85),
  // with the estimator's Layers-panel overrides applied — include forces hard
  // boundary, exclude drops the ink, the same semantics the MCP layers
  // filters carry. Refs, not state: this runs inside click paths and must see
  // a just-resolved table. null on unlayered sheets (or nothing classified) —
  // buildMask then takes the byte-identical pre-#85 path.
  function rolesForSheet(key) {
    const geo = layerGeoRef.current.get(key);
    const infos = layerInfosRef.current.get(key);
    if (!geo || !infos || !infos.length) return null;
    return segRoles(geo.layerOf, layerRoleCodes(geo.layerIds, effectiveLayerRoles(infos, layerOverridesRef.current[key])));
  }
  function ensureMask(key) {
    let mo = maskCacheRef.current.get(key);
    if (!mo) {
      const segs = vectorSegsRef.current.get(key);
      const dims = panelImgs[key];
      if (!segs || !segs.length || !dims?.w) return null;
      // sheet scale (image px per foot) rides into the mask so the hatch pitch
      // cap and the flood's size guards are feet-true — resolution-independent.
      // rescaleSheet evicts this cache entry when the calibration changes.
      const upp = uppFor(key);
      // A1: pass the BASELINE px/ft too, so the working raster is pinned to the
      // sheet rather than to whatever scale this sheet happens to be rendered at.
      const rsNow = renderScalesRef.current.get(key) || RENDER_SCALE;
      const pxPerFt = upp ? 1 / upp : 0;
      // …and A1/F3: the baseline the raster is pinned to comes from the page in
      // POINTS. `dims` is a ceil() of the render, so deriving the baseline from
      // it leaves the pin render-dependent (see buildMask's F3 note). This is
      // also the only branch that works before a calibration: k comes from the
      // render scales, not from px/ft, so an uncalibrated Hi-Res sheet is pinned
      // too. The mask is cached, so the extra getViewport is once per sheet per
      // calibration.
      const pgVp = pageObjsRef.current.get(key)?.getViewport({ scale: 1 });
      // dim texts were positioned at RENDER_SCALE; segs live at this render —
      // rescale so text and ink share a frame whatever the Hi-Res toggle says
      const dtk = rsNow === RENDER_SCALE ? dimTextsRef.current.get(key) : (dimTextsRef.current.get(key) || []).map((t) => ({ ...t, x: t.x * rsNow / RENDER_SCALE, y: t.y * rsNow / RENDER_SCALE, wPx: t.wPx * rsNow / RENDER_SCALE }));
      mo = buildMask(segs, dims.w, dims.h, MASK_MAX_DIM, segMetaRef.current.get(key), pxPerFt,
        pxPerFt ? pxPerFt * RENDER_SCALE / rsNow : 0,
        pgVp ? { pageW: pgVp.width, pageH: pgVp.height, renderScale: rsNow, baseScale: RENDER_SCALE } : null,
        rolesForSheet(key),
        { subpaths: subpathsRef.current.get(key) || null, texts: textMarksRef.current.get(key) || null, dimTexts: dtk && dtk.length ? dtk : null });
      maskCacheRef.current.set(key, mo);
    }
    return mo;
  }
  // Scan-pixel mask for sheets with no usable linework: a fresh dedicated pdf.js
  // render at mask scale — NEVER the panel canvas (dark mode bakes an inversion
  // into those pixels, and a hi-res panel is a 100MB+ readback) — thresholded by
  // rastermask.ts. Cached as a promise so concurrent clicks share one render.
  function ensureRasterMask(key) {
    let pr = rasterMaskCacheRef.current.get(key);
    if (!pr) {
      const pageObj = pageObjsRef.current.get(key), dims = panelImgs[key];
      if (!pageObj || !dims?.w) return Promise.resolve(null);
      const rs = renderScalesRef.current.get(key) || RENDER_SCALE;
      const ws = Math.min(1, MASK_MAX_DIM / Math.max(dims.w, dims.h, 1));
      const mw = Math.max(2, Math.ceil(dims.w * ws)), mh = Math.max(2, Math.ceil(dims.h * ws));
      // distinct namespace from the panel's own renderTasksRef entry (keyed by
      // `key` alone) so registering this task can't clobber — or get clobbered
      // by — the panel's primary render; group-switch cleanup cancels both.
      const taskKey = `${key}:raster`;
      pr = (async () => {
        const cv = document.createElement("canvas");
        cv.width = mw; cv.height = mh;
        const ctx = cv.getContext("2d", { willReadFrequently: true });
        if (!ctx) throw new Error("2d canvas context unavailable"); // caught below like any other render failure — clear message over a cryptic null-deref
        const rt = pageObj.render({ canvasContext: ctx, viewport: pageObj.getViewport({ scale: rs * ws }), background: "#ffffff" });
        renderTasksRef.current.set(taskKey, rt);
        try {
          await rt.promise;
        } finally {
          renderTasksRef.current.delete(taskKey);
        }
        const px = ctx.getImageData(0, 0, mw, mh);
        cv.width = cv.height = 0;   // drop the backing store
        return buildRasterMask(px.data, mw, mh, ws);
      })().catch(() => {
        // A rejection here (pdf.js render failure — worker restart, a lazily-
        // fetched embedded image erroring; getImageData allocation failure
        // under memory pressure; a buildRasterMask throw) must NOT be cached
        // as a resolved-null forever — that would make every future click on
        // this sheet show the permanent failure message even though a retry
        // would succeed. Evict so the next ensureRasterMask call rebuilds.
        rasterMaskCacheRef.current.delete(key);
        return null;
      });
      rasterMaskCacheRef.current.set(key, pr);
    }
    return pr;
  }
  // Build one one-click region from a flood result — the trace/snap/metrics
  // core shared VERBATIM by the stage path (proposeRegion) and the voice-deixis
  // direct-commit path (settleRegion), so an aimed utterance and an aimed click
  // can never trace differently. Raster differences: a looser RDP eps (scan
  // contours wobble) and NO vertex snapping — there are no true endpoints on a
  // scan, and pulling room corners onto the title-block's vector corners would
  // corrupt the ring. null = no scale, or the ring collapsed (too tiny/thin).
  function buildOneClickRegion(f, tp, local, negative, raster) {
    const upp = uppFor(tp.key);
    if (!upp) return null;
    // THE shared ring — trace-then-snap for vector, looser-eps unsnapped for
    // raster — through oneClickRing so this site cannot drift from the bench's
    // scoring of the production ring.
    const grid = snapGridsRef.current.get(tp.key);
    const ring = raster
      ? oneClickRing(f, { raster: true, rasterEps: RASTER_RDP_EPS })
      : oneClickRing(f, { nearest: (x, y, d) => (grid ? nearestSnap(grid, x, y, d) : null) });
    if (ring.length < 3) return null;
    const area_sf = +(ringArea(ring) * upp * upp).toFixed(2);
    const perim_lf = +(closedMetrics(ring).perim * upp).toFixed(2);
    // Item D: the engine's own account of the trace — tier, seal, wedges,
    // min-passage — scored to a 0–1 confidence with named factors, minted
    // into provenance at the Create gate below.
    const conf = traceConfidence(floodSignals(f, { raster, mppf: f.ws / upp, areaSF: area_sf }));
    // poly0 freezes the MACHINE trace (post-snap, pre-handle-edit) so a
    // corrected region can still report what the fill proposed; sens rides
    // only when the estimator moved the knob off Balanced (vector path
    // only — the raster mask is single-tier, sensitivity is inert there).
    return {
      kind: negative ? "neg" : "pos",
      seed: local,
      poly: ring,
      poly0: ring.map(([x, y]) => [x, y]),
      ...(!raster && fillSens !== SENS_BALANCED ? { sens: fillSens } : {}),
      area_sf,
      perim_lf,
      hf: !!f.hatchFiltered,
      // Whether SENSITIVITY had anything to act on for THIS fill. The knob
      // only tunes escalation past ink the classifier called hatch, so a fill
      // whose boundary is entirely hard ink returns the same region at every
      // setting — and the estimator, watching it stop short, reasonably reaches
      // for the knob and gets nothing. Sheet-level softCount can't answer this
      // (the VA plan classifies plenty of toilet poché while the rooms that
      // stop short touch none of it); only this region's own softHits can.
      // Raster-traced fills are single-tier, where sensitivity is inert by
      // construction.
      shs: raster ? 0 : (f.softHits || 0),
      sl: f.sealedPx || 0,
      gap: f.gapBridged || 0,
      mp: f.minPassDelta ? (f.minPassPx || 0) : 0, mpd: f.minPassDelta || 0,
      wg: f.wedges || 0,
      rw: f.ringWedges || 0,
      rt: !!raster,
      cf: conf.score,
      cff: conf.factors,
    };
  }
  // The propose tail (physical clicks): stage the region for the Create (⏎)
  // gate. Duplicate/carve checks run inside a FUNCTIONAL setProposal so a
  // click racing the first raster render can't clobber state.
  function proposeRegion(f, tp, local, negative, raster, prebuilt) {
    const region = prebuilt || buildOneClickRegion(f, tp, local, negative, raster);
    if (!region) {
      if (uppFor(tp.key)) setCommitMsg(uiText("Couldn't trace that space — trace it with Area (A)."));
      return;
    }
    // Decide accept/dup/carve-reject INSIDE the functional updater, against
    // its own authoritative `prev` — not proposalRef, which only catches up
    // on the next render's passive-effect flush (a macrotask). proposeRegion
    // can resume after an await (the raster path shares a cached
    // ensureRasterMask promise across concurrent clicks on the same panel),
    // and two continuations on that shared promise resume as back-to-back
    // MICROTASK reactions with no render/effect flush able to run in
    // between — so a second click's dedup check would read proposalRef from
    // BEFORE the first click's setProposal landed and wrongly pass.
    //
    // setCommitMsg still must not be called from inside the updater itself
    // — React may invoke it more than once (StrictMode double-invoke, or a
    // discarded concurrent render), and firing a message from inside one
    // would announce a decision that never lands. So the verdict is stashed
    // in this scope-local `outcome` var (a plain reassignment, not a
    // setState call) and acted on AFTER setProposal returns.
    //
    // That read is wrapped in flushSync rather than just trusted to be
    // synchronous: React's "run the updater eagerly, at dispatch time" fast
    // path is an internal bail-out optimization, not a public guarantee, and
    // it does NOT reliably apply here — proposeRegion's raster call always
    // resumes from a promise continuation (after `await ensureRasterMask`),
    // never a discrete DOM event, so React defers the updater to the next
    // render instead of running it inline (confirmed against the real
    // shared-promise race in this file: `outcome` read back as undefined
    // every time, in both dev and a production build, with or without a
    // second racing click). flushSync forces that render to happen, and
    // this updater to run, before setProposal returns, so `outcome` is
    // always populated by the time it's read below — for the ordinary
    // single-click case AND for two clicks racing the same shared promise
    // (the second call's setProposal, and its read of `outcome`, still runs
    // strictly after the first call's flushSync has fully committed).
    let outcome;
    flushSync(() => {
      setProposal((prev) => {
        const rs = prev && prev.key === tp.key ? prev.regions : [];
        if (rs.some((r) => r.kind === region.kind && pointInPoly(local[0], local[1], r.poly))) {
          outcome = "dup";
          return prev;
        }
        if (negative && !rs.some((r) => r.kind === "pos" && pointInPoly(local[0], local[1], r.poly))) {
          outcome = "needsPos";
          return prev;
        }
        outcome = "added";
        return { key: tp.key, regions: [...rs, region] };
      });
    });
    if (outcome === "dup") setCommitMsg(negative ? "That cutout is already carved." : keyText(uiText("Already selected — ⌥-click carves an enclosed cutout; ⏎ creates.")));
    else if (outcome === "needsPos") setCommitMsg(keyText(uiText("⌥-click carves an enclosed area INSIDE the selection (a column or shaft) — click its room first.")));
    // The measurement-policy receipts: when the engine sealed, wedged, or
    // ruled a passage out, the estimator hears it at stage time — the trace is
    // reviewable while the edge in question is still under the cursor.
    else if (!f) { /* net-engine region: the caller already set the message; there is no flood receipt to narrate */ }
    else if (f.wedges && f.ringWedges >= f.wedges) setCommitMsg(uiText(`Measured to include the floor inside ${f.ringWedges === 1 ? "a closed ring" : `${f.ringWedges} closed rings`} drawn on the plan (a round column or a callout bubble) — no door swing was involved. If that is a column you deduct rather than floor you cover, ${keyText(uiText("⌥-click carves it out. ⏎ creates."))}`));
    else if (f.wedges && f.ringWedges) setCommitMsg(uiText(`Measured through the drawn door to the wall opening — the swing area is included. It also includes the floor inside ${f.ringWedges === 1 ? "a closed ring" : `${f.ringWedges} closed rings`} (a round column or callout bubble), which is not a door swing; ${keyText(uiText("⌥-click carves one out if it should be deducted. ⏎ creates."))}`));
    else if (f.wedges) setCommitMsg(uiText("Measured through the drawn door to the wall opening — the swing area is included. ⏎ creates."));
    else if (f.sealedPx) setCommitMsg(f.minPassPx
      ? `That space isn't closed on the drawing — the gap is under ${MIN_PASS_FT} ft, so the minimum-passage rule bridged it rather than measuring through it. That call is at the limit of what this sheet's resolution can decide; review the edge, then ⏎ creates.`
      : "That space wasn't fully enclosed — a small opening (a doorway or line gap) was sealed to bound it. Review the edge, then ⏎ creates.");
    else if (f.minPassDelta) setCommitMsg(uiText(`A passage under ${MIN_PASS_FT} ft wide was treated as not connecting — measuring through it would have added ${Math.round(f.minPassDelta * 100)}% more area. Review that edge, then ⏎ creates.`));
    else setCommitMsg(uiText(""));
  }
  // `direct` (voice deixis, RFC #59): { conditionId, label } — the human aimed
  // the crosshair, so the flood COMMITS in one step through settleRegion →
  // commitOneClickRegions (the same gate ⏎ drives) instead of staging a
  // proposal, and every exit returns { ok, message } so the voice outcome can
  // speak it — a deixis trace never no-ops silently. The condition rides BY
  // VALUE because the utterance armed it in this same handler (the activeCond
  // closure is a render behind). Click callers ignore the return value; their
  // message surface stays setCommitMsg, unchanged.
  async function oneClickAt(p, negative, direct, fieldClick) {
    const say = (message) => { setCommitMsg(message); return { ok: false, message }; };
    if (!oneClickEnabled()) return say(ONE_CLICK_GATE_MESSAGE);   // the TEMPORARY gate (lib/gate.js) — every caller funnels here
    const tp = panelAt(p[0]);
    const upp = uppFor(tp.key);
    if (!upp) return say(`Set the scale for ${labelFor(tp)} first.`);
    if (!(direct ? direct.conditionId : activeCond)) return say("Pick or add a condition first.");
    // a click may EXTEND a same-sheet proposal; voice deixis commits whole and
    // must never swallow a selection the human is still reviewing — ANY pending
    // proposal rejects the utterance
    if (proposal && (direct || proposal.key !== tp.key)) {
      return say(direct
        ? "Finish the pending one-click selection first — ⏎ creates it, Esc discards."
        : `Finish the selection on ${labelFor(panelByKey(proposal.key))} first — ⏎ creates it, Esc discards.`);
    }
    const local = [p[0] - tp.xOffset, p[1]];
    // Trigger policy: vector is exact and always wins where it works — including
    // the fork's hatch escalation (fillSens), which runs untouched here. The
    // raster path engages only where vectors can't bound the room — a scan
    // wrapper (big placed image, near-zero linework) runs raster PRIMARY; a
    // mixed sheet (big image UNDER real linework) retries on pixels only after
    // the vector flood fails. A pure-vector sheet never touches pixels.
    const stats = sheetStatsRef.current.get(tp.key);
    const rasterEligible = !!stats && stats.imageFrac >= RASTER_MIN_IMG_FRAC;
    const vectorViable = !!stats && stats.segCount >= RASTER_MIN_SEGS;
    // NET ENGINE branch — vector sheets only; a scan has no linework to network.
    if (netEngine && !direct && vectorViable) {
      const segs = vectorSegsRef.current.get(tp.key);
      const meta = segMetaRef.current.get(tp.key);
      if (!segs || !meta) return say("Still reading this sheet's linework — One-Click arms as soon as that finishes (a dense sheet can take a few seconds). Try again in a moment.");
      if (!netWorker) return say("One-Click needs Web Workers in this browser — trace it with Area (A).");
      // FRAMES: the vector segments live at the BASELINE render scale; a hi-res
      // sheet's click and its upp are in the hi-res frame (uppFor divides by
      // factorFor). Convert into the segments' frame for the engine and back
      // out for the ring — at 207% zoom every foot-based threshold was off
      // by the zoom factor (the "regressions" that appeared only zoomed in).
      const kF = RENDER_SCALE / (renderScalesRef.current.get(tp.key) || RENDER_SCALE);   // hi-res px → baseline px
      const ftPx = kF / upp;                     // baseline px per foot
      const buildOpts = {};
      const ck = `${tp.key}:${ftPx.toFixed(4)}`;
      let built = netCacheRef.current.get(ck);
      if (!built) {
        // one build per (sheet, scale); concurrent clicks share the promise
        // LOUD, TICKING status: a dense sheet reads for tens of seconds and a
        // silent wait reads as failure (his call, Liminal 2026-08-24)
        const t0 = Date.now();
        setCommitMsg(uiText("Reading the walls on this sheet… 0 s — the first click on a sheet builds its wall network; the page stays live."));
        const tick = setInterval(() => setCommitMsg(uiText(`Reading the walls on this sheet… ${Math.round((Date.now() - t0) / 1000)} s — the first click on a sheet builds its wall network; the page stays live.`)), 1000);
        netTickRef.current = tick;
        const subpathsIn = subpathsRef.current.get(tp.key) || null, textsIn = textMarksRef.current.get(tp.key) || [];
        // diagnostic record of EXACTLY what the engine was handed (read from devtools as window.__netLast)
        try { window.__netLast = { key: ck, sheet: tp.key, nSegs: segs.length >> 2, nMeta: meta.length, nSubpaths: subpathsIn ? subpathsIn.length : 0, nTexts: textsIn.length, ftPx, upp, kF, img: tp.img && { w: tp.img.w, h: tp.img.h }, metaHead: Array.from(meta.slice(0, 12)), segsHead: Array.from(segs.slice(0, 8)).map((v) => +v.toFixed(1)), textHead: textsIn.slice(0, 2) }; } catch { /* diagnostics only */ }
        built = netCall({ type: "build", key: ck, segs, meta, subpaths: subpathsIn, ftPx, texts: textsIn, opts: buildOpts })
          .then((m) => { if (m.error) { netCacheRef.current.delete(ck); throw new Error(m.error); } try { Object.assign(window.__netLast, { faces: m.faces, starved: m.starved, ms: m.ms }); } catch { /* diagnostics only */ } return m; });
        netCacheRef.current.set(ck, built);
      }
      let info;
      try { info = await built; }
      catch (err) { console.error("net engine build failed", err); return say("One-Click couldn't read this sheet's linework — trace it with Area (A)."); }
      finally { if (netTickRef.current) { clearInterval(netTickRef.current); netTickRef.current = null; } }
      if (toolRef.current !== "oneclick" || (proposalRef.current && proposalRef.current.key !== tp.key)) { setCommitMsg(uiText("")); return { ok: false, message: "" }; }
      const field = !!fieldClick;
      const rm = await netCall({ type: "room", key: ck, x: local[0] * kF, y: local[1] * kF, ftPx, mode: field ? "field" : "room" });
      const r = rm.room;
      if (!r) return say(field
        ? "No finish pattern under that ⇧-click — ⇧-click inside the tile or plank pattern to select the whole field."
        : "That click isn't inside an enclosed space — click an open spot, ⇧-click an open finish field, or trace it with Area (A).");
      const ring = r.ring.map(([x, y]) => [x / kF, y / kF]);      // back to the panel's frame
      try { Object.assign(window.__netLast, { lastClick: [local[0], local[1]], lastRing: ring.map(([x, y]) => [+x.toFixed(1), +y.toFixed(1)]), lastFaces: r.faces }); } catch { /* diagnostics only */ }
      const holes = (r.holes || []).map((h) => h.map(([x, y]) => [x / kF, y / kF]));
      const met = polyWithHolesMetrics(ring, holes);
      const area_sf = +(met.area * upp * upp).toFixed(2);
      const perim_lf = +(met.perim * upp).toFixed(2);
      const region = {
        kind: negative ? "neg" : "pos", seed: local, poly: ring, holes, poly0: ring.map(([x, y]) => [x, y]),
        area_sf, perim_lf, hf: false, shs: 0, sl: 0, gap: 0, mp: 0, mpd: 0, wg: 0, rw: 0, rt: false,
        cf: 1, cff: [], net: true, netFaces: r.faces, netStarved: !!r.starved, netMode: field ? "field" : "room",
      };
      setCommitMsg(uiText(`${field ? "Finish field" : "Room"}: ${area_sf.toFixed(0)} SF from ${r.faces} face${r.faces === 1 ? "" : "s"}${r.holes.length ? ` (${r.holes.length} interior void${r.holes.length === 1 ? "" : "s"} subtracted)` : ""}${info && info.ms ? ` · net built in ${(info.ms / 1000).toFixed(1)} s` : ""} — ⏎ creates, Esc discards.`));
      proposeRegion(null, tp, local, negative, false, region);
      return { ok: true, message: "" };
    }
    if (!rasterEligible || vectorViable) {
      const mo = ensureMask(tp.key);
      if (!mo && !rasterEligible) return say("Still reading this sheet's linework — try again in a second.");
      if (mo) {
        // seal radii + wedge cap scale with the sheet: bridge up to a door-width
        // opening (mask px per foot = mask-per-image-px / units-per-image-px)
        const mppf = mo.ws / upp;
        const f = floodRegionSealed(mo, local[0], local[1], fillSens, sealRadiiFor(mppf), doorWedgeCapPx(mppf), minPassRadiusFor(mppf));
        if (f.status === "ok") return settleRegion(f, tp, local, negative, false, direct);
        if (!rasterEligible) {
          return say(f.status === "leak"
            ? "That space isn't enclosed on the plan linework — the fill spilled. Click a more enclosed spot, or trace it with Area (A)."
            : "Landed in dense linework (hatching/text). Zoom in and click an open spot, or trace it with Area (A).");
        }
      }
    }
    setCommitMsg(uiText("Reading the scan…"));
    const seq = renderSeqRef.current;
    const rmo = await ensureRasterMask(tp.key);
    if (seq !== renderSeqRef.current) {   // sheet group changed mid-render — the new sheet must not be left showing a stale "Reading the scan…" ("…" messages never auto-expire, see commitMsg's 6s-timer effect
      setCommitMsg(uiText(""));
      return direct
        ? say("Couldn't place that — the sheet changed while reading the scan. Say it again.")
        : { ok: false, message: "" };
    }
    // The raster render can take real time on a large scan; the user may have
    // switched tools or started a DIFFERENT panel's proposal while it was in
    // flight. renderSeq alone only catches a sheet-GROUP change — re-validate
    // against the LIVE tool/proposal (refs, not the closed-over `tool`/
    // `proposal` — this is an async continuation resuming after other renders)
    // so a late raster result can never silently replace another panel's
    // in-progress proposal or paint a ghost selection in the wrong tool.
    // Voice (direct) is modeless — no tool check — but a proposal appearing
    // mid-await means the human started clicking; the utterance yields loudly
    // rather than race the hand.
    if (direct ? proposalRef.current : (toolRef.current !== "oneclick" || (proposalRef.current && proposalRef.current.key !== tp.key))) {
      setCommitMsg(uiText(""));
      return direct
        ? say("Couldn't place that — a one-click selection started while reading the scan. Finish it (⏎/Esc), then say it again.")
        : { ok: false, message: "" };
    }
    if (!rmo) return say("Couldn't read this scan — trace it with Area (A).");
    // The raster mask is single-tier (softCount 0), so the flood's hatch
    // escalation — and with it the Fill sensitivity knob — is structurally
    // inert on scans; the default sensitivity rides along. Gap sealing still
    // applies — faded scan lines are the raster path's own flavor of open doorway.
    const f = floodRegionSealed(rmo, local[0], local[1], undefined, sealRadiiFor(rmo.ws / upp), doorWedgeCapPx(rmo.ws / upp), minPassRadiusFor(rmo.ws / upp));
    if (f.status !== "ok") {
      return say(f.status === "leak"
        ? "That space isn't enclosed on the scan — the fill escaped through a gap (faded line or open doorway). Click a more enclosed spot, or trace it with Area (A)."
        : "Landed on dense scan ink (text or hatching). Zoom in and click an open spot, or trace it with Area (A).");
    }
    return settleRegion(f, tp, local, negative, true, direct);
  }
  // After a successful flood: a physical click STAGES the region for the
  // ⏎/dblclick Create gate; a voice-deixis trace (direct) COMMITS it now —
  // same builder, same commit gate, no preview-then-Enter. The spoken
  // imperative IS the confirmation (RFC #59 who-aimed-it rule).
  function settleRegion(f, tp, local, negative, raster, direct) {
    if (!direct) { proposeRegion(f, tp, local, negative, raster); return { ok: true, message: "" }; }
    const region = buildOneClickRegion(f, tp, local, negative, raster);
    if (!region) return { ok: false, message: "Couldn't trace that space — trace it with Area (A)." };
    return commitOneClickRegions({ key: tp.key, regions: [region] }, direct);
  }
  // The ONE commit gate for one-click regions — the ⏎/dblclick Create AND a
  // voice-deixis trace both land here, so human-aimed work gets exactly one
  // origin shape (one_click_v1, reviewed) and one undo path. `direct` (voice)
  // pins { conditionId, label } from the utterance BY VALUE — the arming
  // setState hasn't rendered, so the activeCond/activeLabel closures are one
  // render behind (the updateCondition-by-id precedent in voiceActions).
  function commitOneClickRegions(prop, direct) {
    const tp = panels.find((p) => p.key === prop.key && p.img.w);
    const upp = uppFor(prop.key);
    if (!tp || !upp) {
      const message = "Open the proposal's sheet with its scale set before creating measurements.";
      setCommitMsg(message);
      return { ok: false, message };
    }
    const condId = direct ? direct.conditionId : activeCond;
    const label = direct && direct.label !== undefined ? direct.label : (activeLabel || undefined);
    const made = prop.regions.map((r) => ({
      sheet_id: tp.key, condition_id: condId,
      measure_role: r.kind === "neg" ? "deduct" : "floor_area",
      verts_norm: r.poly.map(([x, y]) => [x / tp.img.w, y / tp.img.h]),
      ...(r.holes?.length ? { verts_norm_holes: r.holes.map((h) => h.map(([x, y]) => [x / tp.img.w, y / tp.img.h])) } : {}),
      ...(label ? { label } : {}),
      // the provenance receipt: machine-proposed, human-reviewed at the Create
      // gate (voice deixis: the spoken imperative is the review). A handle-
      // corrected region (touched) records the machine's frozen trace (poly0)
      // as proposed_verts_norm — the one-click correction pair; an untouched
      // region's verts ARE the proposal, so nothing extra rides. Post-Create
      // edits are stamped by stampEdit, which freezes the same field from the
      // pre-edit ring only when Create didn't already.
      origin: { method: r.net ? "net_v1" : "one_click_v1", ...(r.net ? { net_faces: r.netFaces, net_starved: r.netStarved, net_mode: r.netMode } : {}), seed_norm: [r.seed[0] / tp.img.w, r.seed[1] / tp.img.h], reviewed: true, confidence: r.cf ?? 1, ...(r.cff?.length ? { confidence_factors: r.cff } : {}), ...(r.hf ? { hatch_filtered: true } : {}), ...(r.sl ? { gap_sealed_px: r.sl } : {}), ...(r.gap ? { gap_bridged_px: r.gap } : {}), ...(r.mp ? { min_pass_px: r.mp, min_pass_delta: r.mpd } : {}), ...(r.wg ? { door_wedges: r.wg } : {}), ...(r.rw ? { ring_interiors: r.rw } : {}), ...(r.rt ? { raster_traced: true } : {}), ...(r.sens != null ? { fill_sensitivity: r.sens } : {}), ...(r.touched ? { edited_before_create: true, proposed_verts_norm: r.poly0.map(([x, y]) => [x / tp.img.w, y / tp.img.h]) } : {}) },
    })).map((shape) => ({ ...shape, computed: computeShapeMetrics(shape, tp.img, upp) }));
    const res = dispatchShape({ type: "add", shapes: made });   // the creation gate — id/created_at minted by the command
    // ...and the new takeoff is SELECTED. Without this, Create left nothing
    // selected, so the ⌫ that had been deleting the proposal a moment earlier
    // suddenly did nothing and the only way to undo a bad fill was the Edit
    // menu — the one moment in the flow where the keyboard stopped working.
    // Same idiom as pasteClipboard: a plain add appends, so the minted shapes
    // are the array's last N. Deliberately WITHOUT pasteClipboard's
    // setTool("select") — the status message says "Click the next room" and
    // it has to stay true. Selecting while One-Click is armed is safe: a
    // shape's own handles only grab under tool === "select", and the
    // proposal branch sits ahead of `selectedId` in the ⌫ chain, so the next
    // fill's ⌫ still discards that proposal first.
    if (res?.shapes?.length) selectShape(res.shapes[res.shapes.length - 1].id);
    const sf = made.reduce((n, sh) => n + (sh.measure_role === "deduct" ? -sh.computed.area_sf : sh.computed.area_sf), 0);
    // condById is a render closure — a condition minted THIS utterance is only
    // in the live mirror, so fall through to it for the tag
    const tag = (condById[condId] || agentStateRef.current.conditions.find((c) => c.id === condId))?.finish_tag || "";
    const message = `Created ${made.length} takeoff${made.length === 1 ? "" : "s"} — ${fa(sf)} ${tag}. Click the next room.`;
    setCommitMsg(message);
    return { ok: true, message };
  }
  function createProposal() {
    if (!proposal || !proposal.regions.length) return;
    commitOneClickRegions(proposal);
    setProposal(null);
  }

  // ── One-Click proposal geometry editing — correct a fill BEFORE Create ──────
  // A proposal region's `poly` is panel-LOCAL px (image space of proposal.key,
  // no xOffset — same frame the preview draws in). These reuse the existing
  // recompute idiom (ringArea × upp², closedMetrics) and the endpoint snap grid,
  // so a corrected corner lands on the plan's true linework just like a hand
  // trace. Nothing here commits a takeoff — that's still the Create (⏎) gate.
  const ocMetrics = (poly, key, holes = []) => {
    const upp = uppFor(key) || 0;
    const met = polyWithHolesMetrics(poly, holes);
    return { area_sf: +(met.area * upp * upp).toFixed(2), perim_lf: +(met.perim * upp).toFixed(2) };
  };
  // `bypass` (true for a raster region/shape) skips nearestSnap entirely — on a
  // scan wrapper the snap grid holds only the placed-image/clip-rect corners
  // and title-block linework (extractVectorGeometry's few real points, not the
  // scan ink), so snapping a dragged raster corner onto it yanks the point
  // onto geometry unrelated to the room being edited. Same rationale
  // proposeRegion already applies to the initial trace — the handles must not
  // reintroduce it.
  const ocSnap = (key, x, y, bypass) => {
    if (bypass) return [x, y];
    const grid = snapGridsRef.current.get(key);
    const hit = grid ? nearestSnap(grid, x, y, 8 / tfRef.current.scale) : null;
    return hit ? [hit[0], hit[1]] : [x, y];
  };
  // Press on a corner (select + arm move), an edge grip (arm whole-line move),
  // or Shift on an edge (insert a new anchor, arm its move). Returns true if the
  // press was consumed. Hit-tests against RAW cursor px (not the snap/angle-
  // adjusted point) so grabbing a handle is never nudged by an unrelated snap.
  function oneClickHandleAt(e) {
    if (tool !== "oneclick" || !proposal) return false;
    // ⌥ is reserved for carving a cutout (oneClickAt) — never let a handle grab
    // swallow it, or an ⌥-click near a room's own corner/edge could never carve.
    if (e.altKey) return false;
    const tp = panelByKey(proposal.key);
    if (!tp || !tp.img.w) return false;
    const raw = toImage(e.clientX, e.clientY);
    const lx = raw[0] - tp.xOffset, ly = raw[1];
    const thr = 8 / tfRef.current.scale;
    const regions = proposal.regions;
    for (let ri = 0; ri < regions.length; ri++) {          // corners win over edges
      const poly = regions[ri].poly;
      for (let i = 0; i < poly.length; i++) {
        if (Math.hypot(poly[i][0] - lx, poly[i][1] - ly) < thr * 1.6) {
          setOcSel({ ri, vi: i });
          ocDragRef.current = { kind: "oc-vertex", ri, vi: i };
          e.currentTarget.setPointerCapture(e.pointerId);
          return true;
        }
      }
    }
    for (let ri = 0; ri < regions.length; ri++) {          // edge midpoints
      const poly = regions[ri].poly;
      for (let i = 0; i < poly.length; i++) {
        const a = poly[i], b = poly[(i + 1) % poly.length];
        const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
        if (Math.hypot(mx - lx, my - ly) < thr * 1.5) {
          if (e.shiftKey) {                                  // insert a new anchor, then drag it
            setProposal((pr) => {
              if (!pr) return pr;
              const rgs = pr.regions.map((r, idx) => {
                if (idx !== ri) return r;
                const np = [...r.poly.slice(0, i + 1), [mx, my], ...r.poly.slice(i + 1)];
                return { ...r, poly: np, ...ocMetrics(np, pr.key, r.holes) };
              });
              return { ...pr, regions: rgs };
            });
            setOcSel({ ri, vi: i + 1 });
            ocDragRef.current = { kind: "oc-vertex", ri, vi: i + 1 };
          } else {                                           // move BOTH endpoints of this line
            ocDragRef.current = { kind: "oc-edge", ri, i, j: (i + 1) % poly.length, oa: a.slice(), ob: b.slice(), sx: lx, sy: ly };
          }
          e.currentTarget.setPointerCapture(e.pointerId);
          return true;
        }
      }
    }
    return false;
  }
  // Live drag: a corner follows the (snapped) cursor; an edge translates both its
  // endpoints by the drag delta, each end snapping independently to the linework.
  function ocDragMove(e) {
    const d = ocDragRef.current;
    const tp = panelByKey(proposal?.key);
    if (!proposal || !tp || !tp.img.w) { ocDragRef.current = null; bumpIdle(); return; }
    const raw = toImage(e.clientX, e.clientY);
    const lx = raw[0] - tp.xOffset, ly = raw[1];
    setProposal((pr) => {
      if (!pr) return pr;
      const regions = pr.regions.map((r, ri) => {
        if (ri !== d.ri) return r;
        let poly;
        if (d.kind === "oc-vertex") {
          const np = ocSnap(pr.key, lx, ly, r.rt);
          poly = r.poly.map((v, i) => (i === d.vi ? np : v));
        } else {
          const dx = lx - d.sx, dy = ly - d.sy;
          const na = ocSnap(pr.key, d.oa[0] + dx, d.oa[1] + dy, r.rt);
          const nb = ocSnap(pr.key, d.ob[0] + dx, d.ob[1] + dy, r.rt);
          poly = r.poly.map((v, i) => (i === d.i ? na : i === d.j ? nb : v));
        }
        // touched = a handle actually moved this region: Create records the
        // frozen poly0 as origin.proposed_verts_norm only for touched regions
        return { ...r, poly, ...ocMetrics(poly, pr.key, r.holes), touched: true };
      });
      return { ...pr, regions };
    });
  }
  // Reveal handles on the region under the cursor (inside it, or near a corner /
  // edge grip so you can grab a corner to pull it outward). Ref-compared so we
  // only re-render when the hovered region actually changes.
  function ocHoverUpdate(e) {
    const tp = panelByKey(proposal.key);
    let hov = -1;
    if (tp && tp.img.w) {
      const raw = toImage(e.clientX, e.clientY);
      const lx = raw[0] - tp.xOffset, ly = raw[1];
      const near = 14 / tfRef.current.scale;
      for (let ri = 0; ri < proposal.regions.length && hov < 0; ri++) {
        const poly = proposal.regions[ri].poly;
        if (pointInPoly(lx, ly, poly)) { hov = ri; break; }
        for (let i = 0; i < poly.length; i++) {
          const a = poly[i], b = poly[(i + 1) % poly.length];
          const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
          if (Math.hypot(a[0] - lx, a[1] - ly) < near || Math.hypot(mx - lx, my - ly) < near) { hov = ri; break; }
        }
      }
    }
    if (hov !== ocHoverRef.current) { ocHoverRef.current = hov; setOcHover(hov); }
  }
  // Delete just the selected corner (Delete/⌫), keeping a region ≥ 3 points —
  // never collapses the whole space (use ⌫ with nothing selected for that).
  function deleteSelectedOcVertex() {
    if (!ocSel || !proposal) return;
    const r = proposal.regions[ocSel.ri];
    if (!r) { setOcSel(null); return; }
    // Can't thin a triangle further. Deselect so the NEXT ⌫ falls through to the
    // remove-last-region branch — otherwise the ocSel guard keeps re-firing this
    // message and the space can never be dropped without an Esc first.
    if (r.poly.length <= 3) { setOcSel(null); setCommitMsg(uiText("A space needs at least 3 points — ⌫ again drops the whole space.")); return; }
    setProposal((pr) => {
      if (!pr) return pr;
      const regions = pr.regions.map((rr, ri) => {
        if (ri !== ocSel.ri) return rr;
        const np = rr.poly.filter((_, i) => i !== ocSel.vi);
        // dropping a corner is a pre-Create correction too — same touched flag
        return { ...rr, poly: np, ...ocMetrics(np, pr.key, rr.holes), touched: true };
      });
      return { ...pr, regions };
    });
    setOcSel(null);
  }

  // ── copy / paste / duplicate — "draw once, drop it again", same sheet or the
  // one under the cursor. The clipboard carries verts + provenance, never the old
  // computed numbers: every paste recomputes against the TARGET panel's dims and
  // that sheet's scale (this also fixes the legacy bug where pasting after a
  // rescale kept the stale SF).
  const clipRef = useRef([]);
  // A clone keeps its lineage (method + flags + copied: true) but NEVER the
  // source's seed_norm / proposed_verts_norm: an offset paste would read as a
  // phantom correction (machine trace over here, shape over there). The edits
  // map is deep-copied so a stamp on the clone can't alias the source's tally.
  const cloneOrigin = (o) => {
    if (!o) return {};
    const { seed_norm: _seed, proposed_verts_norm: _pvn, ...rest } = o;
    return { origin: { ...rest, ...(rest.edits ? { edits: { ...rest.edits } } : {}), copied: true } };
  };
  // the clipboard payload for one shape: verts deep-copied, provenance kept,
  // `from` remembers the source sheet so paste knows same-sheet vs cross-sheet
  const clipEntry = (sel) => ({
    condition_id: sel.condition_id, measure_role: sel.measure_role,
    verts_norm: sel.verts_norm.map((v) => [...v]), from: sel.sheet_id, height_ft: sel.height_ft,
    ...(sel.height_override ? { height_override: true } : {}), ...(sel.label ? { label: sel.label } : {}), ...cloneOrigin(sel.origin)
  });
  function copySelected() {
    const sel = shapes.find((s) => s.id === selectedId);
    if (!sel) { setCommitMsg(uiText("Select a takeoff to copy.")); return; }
    clipRef.current = [clipEntry(sel)];
    setCommitMsg(uiText("Copied — ⌘V pastes onto the sheet under your cursor."));
  }
  function pasteClipboard(offset = 0.03) {
    if (!clipRef.current.length) return;
    const tp = lastPtrRef.current ? panelAt(toImage(lastPtrRef.current[0], lastPtrRef.current[1])[0]) : focusPanel;
    const needsScale = clipRef.current.some((c) => c.measure_role !== "count");
    if (needsScale && !uppFor(tp.key)) { setCommitMsg(uiText(`Set the scale for ${labelFor(tp)} first — paste recomputes SF/LF there.`)); return; }
    let cross = false;
    const made = clipRef.current.map((c) => {
      const same = c.from === tp.key;
      cross = cross || !same;
      // same sheet: nudge so the copy is visible; other sheet: same relative spot
      const vn = c.verts_norm.map(([x, y]) => (same ? [Math.min(0.999, x + offset), Math.min(0.999, y + offset)] : [x, y]));
      // != null, not truthy: an overridden height of 0 must survive the paste
      const s = { sheet_id: tp.key, condition_id: c.condition_id, measure_role: c.measure_role, verts_norm: vn, ...(c.height_ft != null ? { height_ft: c.height_ft } : {}), ...(c.height_override ? { height_override: true } : {}), ...(c.label ? { label: c.label } : {}), ...cloneOrigin(c.origin) };
      return { ...s, computed: recomputeShape(s) };
    });
    // the add command mints id/created_at; a plain add appends, so the minted
    // clones are the array's last N — select the newest one
    const res = dispatchShape({ type: "add", shapes: made });
    selectShape(res.shapes[res.shapes.length - 1].id);
    setTool("select");
    setCommitMsg(uiText(`Pasted ${made.length} takeoff${made.length === 1 ? "" : "s"}${cross ? ` onto ${labelFor(tp)}` : ""} — drag to position.`));
  }
  function duplicateSelected() {
    const sel = shapes.find((s) => s.id === selectedId);
    if (!sel) { setCommitMsg(uiText("Select a takeoff to duplicate.")); return; }
    clipRef.current = [clipEntry(sel)];
    pasteClipboard();
  }
  // Mirror the selected shape about its own bbox center — an isometry, so SF/LF
  // never change. Routes through the same geom/vertex command path as a manual
  // vertex drag, which gives correct undo/redo and provenance stamping for free.
  function flipSelected(axis) {
    const sel = shapes.find((s) => s.id === selectedId);
    if (!sel || !Array.isArray(sel.verts_norm) || sel.verts_norm.length < 2) {
      setCommitMsg(uiText("Select an area or linear takeoff to flip.")); return;
    }
    const vn = reflectVertsNorm(sel.verts_norm, axis);
    dispatchShape({
      type: "geom", id: sel.id, editKind: "vertex",
      verts_norm: vn, computed: recomputeShape({ ...sel, verts_norm: vn }), prev: geomSnapshot(sel),
    });
  }
  // ── Tidy — one geometry pass on the selected takeoff (ringTidy) ────────────
  // A mask-derived ring (One-Click, detect_rooms, a raster trace) carries
  // dozens–hundreds of staircase vertices no hand can drag straight. One pass:
  // collinear/micro-segment chains collapse, vertices on CAD corners hold
  // (drifted ones pull home), near-square walls square up between anchors;
  // genuinely angled walls survive. Closed rings only — a linear run's
  // vertices are its measurement. The lib refuses any result that moves area
  // >3%; worst case the shape comes back untouched. One command = one ⌘Z.
  function tidySelected() {
    const sel = shapes.find((s) => s.id === selectedId);
    if (!sel) return;
    if (sel.measure_role === "count" || sel.measure_role === "linear" || sel.measure_role === "surface_area") {
      setCommitMsg(uiText("Tidy works on area takeoffs — a linear run's vertices are its measurement.")); return;
    }
    const sp = panelByKey(sel.sheet_id);
    if (!sp || !sp.img.w || (sel.verts_norm || []).length < 3) return;
    const grid = snapGridsRef.current.get(sel.sheet_id);
    const rt = !!sel.origin?.raster_traced;   // no true endpoints on a scan — pure simplify+square
    const ringPx = sel.verts_norm.map(([nx, ny]) => [nx * sp.img.w, ny * sp.img.h]);
    const r = tidyRing(ringPx, { nearest: (x, y, dd) => (!rt && grid ? nearestSnap(grid, x, y, dd) : null) });
    if (!r.changed) { setCommitMsg(uiText("Nothing to tidy — this takeoff is already clean.")); return; }
    const vn = r.ring.map(([x, y]) => [x / sp.img.w, y / sp.img.h]);
    dispatchShape({
      type: "geom", id: sel.id, editKind: "tidy",
      verts_norm: vn, computed: recomputeShape({ ...sel, verts_norm: vn }), prev: geomSnapshot(sel),
    });
    setCommitMsg(uiText(`Tidied — ${ringPx.length} → ${r.ring.length} vertices; corners held to plan lines, near-square walls squared. ⌘Z undoes.`));
  }
  // ── markup (cloud / callout / text) — annotations, not measurements ─────────
  // markupDraft holds STAGE px (so the live preview spans panels); a markup
  // belongs to the panel of its FIRST click and normalizes against that panel.
  function addMarkup(m, key) {
    // created_at rides the defaults so every markup path (hand-drawn, cloud's
    // pre-minted id, stamp instances) is stamped at this single creation gate.
    // condition_id defaults to the ACTIVE condition: an annotation drawn while
    // a condition is selected is almost always about that condition, and a
    // wrong-but-editable link beats an unlinked note nobody ever goes back to
    // attach. Explicit `...m` still wins, so a caller that means "unattached"
    // can pass condition_id: "".
    setMarkups((ms) => [...ms, { id: uid("mk"), created_at: nowIso(), sheet_id: key, rfi_id: "", condition_id: activeCond || "", ...m }]);
    // Drawing a markup by hand surfaces the Markups tab. But a STAMP places several
    // markups via addMarkup — don't yank the user off the Stamps tab mid-placement
    // (keep the current tab, or open Markups only if nothing's open). Highlighter
    // ink flows stroke after stroke — never pop the dock per stroke.
    if (m.type === "highlight" && m.pts) return;
    setLeftTab((t) => (tool === "stamp" ? (t ?? "markup") : "markup"));
  }
  // Marked-set PDF: every sheet carrying takeoffs/markups, work burned in as
  // drawn, legend cover with net totals — built fully in the browser
  // (lib/markedset.js). Exports in the CURRENT view: dark canvas → dark PDF.
  // includeMarkups (from the ReportPanel checkbox, default true) is ORTHOGONAL to
  // the canvas layer-hide (showMarkups): only this flag drops markups from the
  // PDF. Off → pass []; the RFI-only export still works (empty-guard unaffected).
  // A marked-set build's pages: each file leased on its first page and let
  // go once the build settles (a page is drawn after getPage returns, and
  // stitch members interleave files).
  function leasedPages() {
    const held = new Map();
    return {
      getPage: async (file, pageNum) => {
        if (!held.has(file)) held.set(file, docCache.lease(file));
        return (await docCache.doc(file)).getPage(pageNum);
      },
      release: () => { for (const r of held.values()) r(); held.clear(); },
    };
  }
  async function exportMarkedSet(includeMarkups = true) {
    try {
      setCommitMsg(uiText("Building the marked set…"));
      const exportMarkups = includeMarkups ? markups : [];
      // approval seals are ink, not markups — the include-markups checkbox
      // never drops them, and a sheet carrying only a seal still exports
      const allKeys = [...new Set([...shapes.map((s) => s.sheet_id), ...exportMarkups.map((m) => m.sheet_id), ...approvals.map((a) => a.sheet_id)])];
      const plainMeta = allKeys.filter((k) => !isStitchKey(k)).map((key) => {
        const { file, page } = parseSheetKey(key);
        return { key, file, page, label: tabLabel(key) };
      }).sort((a, b) => compareSheetKeys(a.key, b.key));   // canonical sheet order — shared comparator
      // Stitched surfaces (#161 → #200) burn in as composite pages, after the
      // source sheets: each member placed at its stitch offset, seam-clipped,
      // shapes drawn once in the frame they were measured in. A stitch whose
      // record is gone (member file dropped from the set) has nowhere to draw
      // and is skipped — its shapes still ride the Report, as before.
      const stitchMeta = allKeys.filter(isStitchKey).map((key) => {
        const st = stitchById[key];
        if (!st) return null;
        return {
          key, label: st.name || "Stitched sheets",
          stitch: { members: st.members.map((m) => ({ key: m.key, ...parseSheetKey(m.key), label: tabLabel(m.key), dx: m.dx, dy: m.dy })) },
        };
      }).filter(Boolean);
      // A PDF closed out of the plan set keeps its takeoffs, but its bytes are
      // gone — export what's loaded and say what was left out (#462).
      const { kept: sheetMeta, missingFiles } = splitLoadedSheets([...plainMeta, ...stitchMeta], sheets.map((s) => s.name));
      const skipped = skippedPdfsNote(missingFiles);
      if (!sheetMeta.length && missingFiles.length && !rfis.length) {
        setCommitMsg(uiText(`Nothing to export — ${skipped}`));
        return;
      }
      // (source-caption label rides on each capture as m.src_label, frozen at
      // capture time — markedset reads it directly, no per-export resolution.)
      // branding mode decides the cover identity + wordmark + parent credit;
      // resolved per-project (folderId "" ⇒ the single browser-only setting)
      const brand = resolveBranding({ ...(await loadBrandingSelection(projectIdFromUrl())), profiles: loadProfiles().profiles });
      const pages = leasedPages();
      const { bytes, filename } = await buildMarkedSetPdf({
        projectName, clientInfo, company: brand.company, credit: brand.credit, coverTitle: brand.coverTitle,
        dark: darkMode, units, sheets: sheetMeta, shapes, markups: exportMarkups, approvals, rfis, conditions,
        getPage: pages.getPage,
        loadPdfData: (file) => store.loadPdfData(file),
      }).finally(pages.release);
      downloadBytes(filename, bytes);
      setCommitMsg(uiText(`Marked set downloaded — ${filename}${skipped ? ` — ${skipped}` : ""}`));
    } catch (e) {
      setCommitMsg(uiText(`Marked set failed: ${e.message || e}`));
    }
  }

  // ── sheet drag-out (mock) — drag a marked sheet straight out of the app ──
  // Hovering a sheet tab ARMS the drag: the single-sheet marked PDF renders in
  // the background and caches as a blob URL (dragstart is synchronous, so the
  // file must exist before the drag begins — lib/dragOut.js). Dragging the tab
  // then hands Chromium a DownloadURL and the sheet lands in Finder, an email
  // draft, or a chat drop zone as a real PDF. Stitch tabs sit this mock out:
  // which member shapes ride a composite drag is an open decision, and a
  // silent guess would skew the deliverable.
  const sheetDragCacheRef = useRef(null);
  if (!sheetDragCacheRef.current) sheetDragCacheRef.current = createDragCache();
  useEffect(() => () => sheetDragCacheRef.current?.dispose(), []);
  const sheetHasInk = (k) => shapes.some((s) => s.sheet_id === k) || markups.some((m) => m.sheet_id === k) || approvals.some((a) => a.sheet_id === k);
  function armSheetDrag(k) {
    if (isStitchKey(k) || !sheetHasInk(k)) return;
    const sig = sheetContentSignature(k, shapes, markups, approvals);
    sheetDragCacheRef.current.arm(k, sig, async () => {
      const sheetMarkups = markups.filter((m) => m.sheet_id === k);
      // only the RFIs this sheet's markups actually reference — markers keep
      // their numbers without dragging the whole project register along
      const linked = new Set(sheetMarkups.map((m) => m.rfi_id).filter(Boolean));
      const brand = resolveBranding({ ...(await loadBrandingSelection(projectIdFromUrl())), profiles: loadProfiles().profiles });
      const pages = leasedPages();
      const { bytes } = await buildMarkedSetPdf({
        projectName, clientInfo, company: brand.company, credit: brand.credit, coverTitle: brand.coverTitle,
        dark: darkMode, units, sheets: [{ key: k, ...parseSheetKey(k), label: tabLabel(k) }],
        shapes: shapes.filter((s) => s.sheet_id === k), markups: sheetMarkups,
        approvals: approvals.filter((a) => a.sheet_id === k), rfis: rfis.filter((r) => linked.has(r.id)), conditions,
        getPage: pages.getPage,
        loadPdfData: (file) => store.loadPdfData(file),
      }).finally(pages.release);
      return { bytes, filename: dragFilename(projectName, tabLabel(k)) };
    });
  }
  function onSheetTabDragStart(k, e) {
    // split gesture: the tab MIME rides on EVERY sheet-tab drag, ink or not —
    // the canvas drop zones and the reference pane filter on it. The export
    // types are added only when the marked-sheet cache is armed; a drag that
    // starts before that build lands refuses the EXPORT (honest — never ship a
    // stale sheet) while still working as a split drag, and arms the build so
    // the next drag can export.
    e.dataTransfer.setData(SHEET_TAB_DND_MIME, k);
    e.dataTransfer.effectAllowed = "copy";
    const hit = sheetDragCacheRef.current.get(k, sheetContentSignature(k, shapes, markups, approvals));
    if (!hit) {
      if (sheetHasInk(k)) { armSheetDrag(k); setCommitMsg(uiText("Preparing the marked sheet — drag again in a moment.")); }
      return;
    }
    e.dataTransfer.setData("DownloadURL", downloadUrlEntry(hit.filename, hit.url));
    e.dataTransfer.setData("text/plain", hit.filename);
  }

  // ── live counter (mock) — floating running totals, parked anywhere ──
  // Measured quantities per condition (the number that moves as you trace),
  // shaped from the ONE quantity computer (lib/totals.js conditionTotals).
  const liveCounterRows = useMemo(() => counterRows(conditionTotals(conditions, shapes), activeCond), [conditions, shapes, activeCond]);

  // ── inline text editor — a screen-space <input> overlay (retires window.prompt).
  // An HTML input can't live in the zoom/pan-transformed SVG group, so it is
  // absolutely positioned in CONTAINER px, converting the anchor (stage px) through
  // tfRef. Pan/zoom is frozen while editing (onPointerDown / onWheel bail on
  // editingRef) so the overlay stays pinned to its anchor; the crosshair is
  // suppressed via the same ref inside moveCrosshair. Keys are handled on the
  // input's OWN onKeyDown/onBlur — the global window keydown returns early for
  // INPUT targets, so it never interferes.
  function markupAnchorStage(m) {
    const sp = panelByKey(m.sheet_id);
    if (!sp || !sp.img.w) return null;
    let nx, ny;
    if (m.type === "highlight" && Array.isArray(m.pts) && m.pts.length) { const mid = m.pts[Math.floor((m.pts.length - 1) / 2)]; nx = mid[0]; ny = mid[1]; }
    else if ((m.type === "cloud" || m.type === "highlight") && m.rect) { nx = (m.rect[0][0] + m.rect[1][0]) / 2; ny = (m.rect[0][1] + m.rect[1][1]) / 2; }
    else if ((m.type === "arrow" || m.type === "dimension") && m.from && m.to) { nx = (m.from[0] + m.to[0]) / 2; ny = (m.from[1] + m.to[1]) / 2; }
    else if (m.at) { nx = m.at[0]; ny = m.at[1]; }   // text + bubble + callout
    else return null;
    return [nx * sp.img.w + sp.xOffset, ny * sp.img.h];
  }
  function openTextEditor({ anchorStage, value = "", multiline = false, commit }) {
    const el = containerRef.current;
    if (!el) return;
    const t = tfRef.current;
    hideCrosshair();                 // the OS cursor / aim crosshair steps aside while you type
    editingRef.current = true;
    const ed = { left: anchorStage[0] * t.scale + t.x, top: anchorStage[1] * t.scale + t.y, value, multiline, commit };
    editorRef.current = ed;
    setEditor(ed);
  }
  // commit=true → run the editor's commit with the current input text; either way
  // tear down. Guarded on editingRef so the blur that fires when we unmount the
  // focused input (after Enter/Esc) is a harmless no-op — no double commit.
  function finishEditor(commit) {
    if (!editingRef.current) return;
    editingRef.current = false;
    const ed = editorRef.current;
    const val = editorInputRef.current ? editorInputRef.current.value : (ed ? ed.value : "");
    editorRef.current = null;
    setEditor(null);
    if (commit && ed && ed.commit) ed.commit(val);
  }
  // defense-in-depth: editingRef locks pan/zoom/crosshair while the overlay is up.
  // If the input ever unmounts by a route other than finishEditor, this keeps the
  // ref from stranding true and freezing the canvas.
  useEffect(() => { if (!editor) { editingRef.current = false; bumpIdle(); } }, [editor]);
  // double-click a markup (Select tool) to edit its text in place — find the target
  // via toImage + hitMarkup (non-highlight beats highlight, mirroring selectAt) and
  // open the overlay at its anchor.
  function editMarkupAt(e) {
    if (!showMarkups) return;
    const p = toImage(e.clientX, e.clientY);
    const thr = 8 / tfRef.current.scale;
    const rev = [...visibleMarkups].reverse();
    const m = rev.find((mm) => mm.type !== "highlight" && mm.type !== "image" && hitMarkup(mm, p, thr))
      || rev.find((mm) => mm.type === "highlight" && hitMarkup(mm, p, thr))
      || rev.find((mm) => mm.type === "image" && hitMarkup(mm, p, thr));
    if (!m) return;
    // an svg symbol carries no text — select it, but don't open a dead-end editor;
    // a highlighter stroke is pure ink (no text either), same rule
    if (m.type === "svg" || m.type === "image" || (m.type === "highlight" && Array.isArray(m.pts))) { selectMarkup(m.id); return; }
    const anchor = markupAnchorStage(m);
    if (!anchor) return;
    selectMarkup(m.id);
    openTextEditor({ anchorStage: anchor, value: m.text || "", commit: (t) => updateMarkup(m.id, { text: (t || "").trim() }) });
  }

  function placeMarkup(p) {
    const tp = panelAt(p[0]);
    const norm = (q, panel) => [(q[0] - panel.xOffset) / panel.img.w, q[1] / panel.img.h];
    if (tool === "text") {
      // empty text is not committed (preserves the old `if (t && t.trim())` reject)
      openTextEditor({ anchorStage: p, commit: (t) => { const tx = (t || "").trim(); if (tx) addMarkup({ type: "text", at: norm(p, tp), text: tx }, tp.key); } });
    } else if (tool === "cloud") {
      if (!markupDraft) { setMarkupDraft(p); }
      else {
        const dp = panelAt(markupDraft[0]);
        const rect = [norm(markupDraft, dp), norm(p, dp)];
        setMarkupDraft(null);
        // create the cloud NOW (like highlight) so Esc/cancel in the note editor
        // keeps the drawn box — only the optional note is discarded, not the geometry
        const id = uid("mk");
        addMarkup({ id, type: "cloud", rect, text: "" }, dp.key);
        openTextEditor({ anchorStage: p, commit: (t) => updateMarkup(id, { text: (t || "").trim() }) });
      }
    } else if (tool === "highlight") {
      // two-corner like the cloud, but no note prompt — a highlight is a pure
      // translucent box you drop over an area; text/color/line_style come later.
      if (!markupDraft) { setMarkupDraft(p); }
      else {
        const dp = panelAt(markupDraft[0]);
        addMarkup({ type: "highlight", rect: [norm(markupDraft, dp), norm(p, dp)], text: "" }, dp.key);
        setMarkupDraft(null);
      }
    } else if (tool === "callout") {
      if (!markupDraft) { setMarkupDraft(p); }   // first click = the thing you're pointing at
      else {
        const dp = panelAt(markupDraft[0]);
        const target = norm(markupDraft, dp), at = norm(p, dp);
        setMarkupDraft(null);
        // empty callout text is not committed (preserves the old reject)
        openTextEditor({ anchorStage: p, commit: (t) => { const tx = (t || "").trim(); if (tx) addMarkup({ type: "callout", target, at, text: tx }, dp.key); } });
      }
    } else if (tool === "dimension") {
      // a dimension LABELS a real length, so it is the one markup the scale
      // gate applies to — same refusal the measure tools give (mirrors the
      // MCP annotate verb's doctrine). Gate on the FIRST click so the user
      // isn't refused after carefully picking both ends.
      if (!markupDraft) {
        if (!uppFor(tp.key)) { setCommitMsg(uiText(`Set the scale for ${labelFor(tp)} first.`)); return; }
        setMarkupDraft(p);
      } else {
        if (spansPanels([markupDraft, p])) { setCommitMsg(SPAN_MSG); return; }
        const dp = panelAt(markupDraft[0]);
        const upp = uppFor(dp.key);
        const lenFt = Math.hypot(p[0] - markupDraft[0], p[1] - markupDraft[1]) * (upp || 0);
        if (!(lenFt > 0)) return;   // a zero-length click-in-place is a misfire, not a dimension
        addMarkup({ type: "dimension", from: norm(markupDraft, dp), to: norm(p, dp), len_ft: +lenFt.toFixed(2), text: "" }, dp.key);
        setMarkupDraft(null);
      }
    }
  }
  function updateMarkup(mid, patch) { setMarkups((ms) => ms.map((m) => (m.id === mid ? { ...m, ...patch, ...(m.annotation_style ? { annotation_style: { ...m.annotation_style, ...(patch.line_style ? { line_style: patch.line_style } : {}), ...(patch.weight != null ? { stroke_pt: Math.max(.5, Math.min(6, 1.5 * patch.weight)) } : {}), ...(patch.color ? { color: patch.color } : {}), } } : {}) } : m))); }
  function deleteMarkup(mid) { setMarkups((ms) => ms.filter((m) => m.id !== mid)); }

  // ── stamps — reusable annotations dropped click-to-place (#40). The library
  // is browser-global (persists across projects); placed instances are NORMAL
  // markups. Persist mirrors persistTemplates: ref + state + fire-and-forget
  // save, sanitized at the store boundary.
  const persistStampLib = (next) => {
    stampLibRef.current = next; setStampLib(next);
    store.saveStampLibrary(next).catch((e) => setCommitMsg(uiText(`Couldn't save the stamp library: ${e.message || e}`)));
  };
  // Arm a stamp for placement: switch to the stamp tool and hold it in
  // armedStamp. Repeated clicks place multiple copies until you pick another
  // tool or press Escape.
  const armStamp = (stamp) => { setArmedStamp(stamp); setTool("stamp"); setMarkupDraft(null); };
  // Instantiate the armed stamp at the click point — every element becomes a
  // normal markup on the clicked panel's sheet. A `_prompt` element (a bubble
  // whose number you fill in) opens the text editor on the placed instance.
  function placeStamp(p) {
    if (!armedStamp) return;
    const tp = panelAt(p[0]);
    const cx = (p[0] - tp.xOffset) / tp.img.w, cy = p[1] / tp.img.h;
    const instances = instantiateStamp(armedStamp, [cx, cy]);
    if (!instances.length) { setCommitMsg(uiText("This stamp has no placeable elements.")); return; }
    let promptId = null;
    for (const inst of instances) {
      const { _prompt, ...m } = inst;
      const id = uid("mk");
      addMarkup({ ...m, id }, tp.key);
      if (_prompt && !promptId) promptId = id;
    }
    setCommitMsg(uiText(`Placed “${armedStamp.name}”.`));
    if (promptId) openTextEditor({ anchorStage: p, commit: (t) => updateMarkup(promptId, { text: (t || "").trim() }) });
  }
  // ── approval seal (ink, human-only) — the estimator's stamp. One click: on
  // a committed shape → seal that shape (records its id); on empty plan →
  // seal the sheet at that point. A click on an existing seal LIFTS it, so the
  // tool is its own eraser. Both directions are real undo steps — family-
  // tagged entries on the shared ⌘Z stack (dispatchApproval above).
  // Deliberately NOT exposed through MCP or the in-canvas agent: machine
  // verdicts arrive as actor "agent" records through data paths, never here.
  function placeApproval(p) {
    const tp = panelAt(p[0]);
    if (!tp?.img?.w) return;
    const nx = (p[0] - tp.xOffset) / tp.img.w, ny = p[1] / tp.img.h;
    // lift first — distance in width-normalized units (the seal radius is
    // normalized to sheet WIDTH, the bubble convention), topmost wins
    const seal = [...approvals].reverse().find((a) => a.sheet_id === tp.key
      && Math.hypot(nx - a.at[0], (ny - a.at[1]) * (tp.img.h / tp.img.w)) <= APPROVAL_R);
    if (seal) { dispatchApproval({ type: "delete", ids: [seal.id] }); setCommitMsg(uiText("Approval seal lifted (⌘Z restores it).")); return; }
    // topmost committed shape under the click — the selectAt scan, this panel only
    const thr = 8 / tfRef.current.scale;
    const shape = [...stackedShapes].reverse().find((s) => s.sheet_id === tp.key
      && hitShapeC(s, p[0] - tp.xOffset, p[1], tp.img.w, tp.img.h, thr));
    dispatchApproval({ type: "add", approvals: [{ actor: "estimator", sheet_id: tp.key, at: [nx, ny], ...(shape ? { shape_id: shape.id } : {}) }] });
    setCommitMsg(shape
      ? `Approved — seal on ${condById[shape.condition_id]?.finish_tag || "shape"} (⌘Z undoes).`
      : "Sheet point approved — seal placed (⌘Z undoes).");
  }
  // Save the selected markup as a single-element stamp (the palette's define
  // flow). markupToStampElement re-expresses its coords as anchor-relative
  // offsets so the stamp is position independent.
  function saveMarkupAsStamp(m) {
    const el = markupToStampElement(m);
    if (!el) { setCommitMsg(uiText("This markup can't be saved as a stamp.")); return; }
    const name = (window.prompt(uiText("Name this stamp:"), (m.text || el.type).trim() || "Stamp") || "").trim();
    if (!name) return;
    const stamp = { id: uid("stmp"), name, elements: [el] };
    persistStampLib({ ...stampLibRef.current, stamps: [...stampLibRef.current.stamps, stamp] });
    setCommitMsg(uiText(`Saved stamp “${name}”.`));
    setLeftTab("stamp");
  }
  const deleteStamp = (id) => {
    const lib = stampLibRef.current;
    persistStampLib({
      stamps: lib.stamps.filter((s) => s.id !== id),
      sets: lib.sets.map((set) => ({ ...set, stampIds: set.stampIds.filter((sid) => sid !== id) })),
    });
    if (armedStamp?.id === id) setArmedStamp(null);
  };
  const renameStamp = (id, name) => {
    const nm = (name || "").trim();
    if (!nm) return;
    persistStampLib({ ...stampLibRef.current, stamps: stampLibRef.current.stamps.map((s) => (s.id === id ? { ...s, name: nm } : s)) });
  };
  // Export the whole library as JSON (a crew shares one standard set); import
  // MERGES a file's stamps/sets in, replacing same-id entries so a re-import is
  // idempotent. The store sanitizes on save, so a malformed file can't wedge us.
  function exportStamps() {
    const data = JSON.stringify({ schema: "opentakeoff.stamp_library.v1", ...stampLibRef.current }, null, 2);
    downloadBytes("opentakeoff-stamps.json", new TextEncoder().encode(data), "application/json");
  }
  async function importStamps(file) {
    try {
      const parsed = JSON.parse(await file.text());
      const cur = stampLibRef.current;
      const inStamps = Array.isArray(parsed?.stamps) ? parsed.stamps : [];
      const inSets = Array.isArray(parsed?.sets) ? parsed.sets : [];
      const inIds = new Set(inStamps.map((s) => s?.id));
      const inSetIds = new Set(inSets.map((s) => s?.id));
      const merged = {
        stamps: [...cur.stamps.filter((s) => !inIds.has(s.id)), ...inStamps],
        sets: [...cur.sets.filter((s) => !inSetIds.has(s.id)), ...inSets],
      };
      persistStampLib(merged);   // persistStampLib → store sanitizes, dropping any malformed items
      setCommitMsg(uiText(`Imported ${inStamps.length} stamp${inStamps.length === 1 ? "" : "s"}.`));
      setLeftTab("stamp");
    } catch (e) {
      setCommitMsg(uiText(`Couldn't import stamps: ${e.message || e}`));
    }
  }
  // Import a real .svg FILE as a stamp: the browser's DOMParser extracts the
  // drawable primitives (extractSvgPrimitives, with the security gate), then the
  // pure svgToStamp bakes them into vector-path elements. A new stamp is minted
  // and added to the library — mirroring saveMarkupAsStamp.
  async function importSvgStamp(file) {
    try {
      const text = await file.text();
      const base = (file.name || "Imported SVG").replace(/\.svg$/i, "");
      const extracted = extractSvgPrimitives(text, { name: base });
      const stamp = extracted && svgToStamp(extracted);
      if (!stamp || !stamp.elements.length) { setCommitMsg(uiText("Couldn't read that SVG — no drawable vector shapes found.")); return; }
      persistStampLib({ ...stampLibRef.current, stamps: [...stampLibRef.current.stamps, { id: uid("stmp"), name: stamp.name, elements: stamp.elements }] });
      setCommitMsg(uiText(`Imported “${stamp.name}” as a stamp.`));
      setLeftTab("stamp");
    } catch (e) {
      setCommitMsg(uiText(`Couldn't import SVG: ${e.message || e}`));
    }
  }

  // ── RFI register — the dormant markup.rfi_id hook made real. One RFI ↔ many
  // markups (markup.rfi_id === rfi.id); linked markups are DERIVED, never stored
  // twice. rfi.js stays PURE — every date is stamped HERE, at the event, so no
  // renderer computes an RFI field with new Date().
  function raiseRfi(markup) {
    if (!markup) return;
    const id = uid("rfi");
    const number = nextRfiNumber(rfis);
    const rec = {
      id, number, created_at: nowIso(), subject: (markup.text || "").trim(), question: "", status: "open",
      to: "", priority: "normal", cost_impact: false, schedule_impact: false,
      date: new Date().toISOString().slice(0, 10), response: "", response_date: "",
      sheet_id: markup.sheet_id,
    };
    setRfis((rs) => [...rs, rec]);
    updateMarkup(markup.id, { rfi_id: id });
    setLeftTab("rfi");
    setCommitMsg(uiText(`Raised ${number}.`));
  }
  const linkRfi = (markup, rfiId) => { if (markup && rfiId) updateMarkup(markup.id, { rfi_id: rfiId }); };
  const unlinkRfi = (markup) => { if (markup) updateMarkup(markup.id, { rfi_id: "" }); };
  // ── markup ↔ condition. Same shape as the RFI link and deliberately so: one
  // condition ↔ many markups, the link lives on the MARKUP, and membership is
  // derived rather than stored on the condition. Without this an annotation is
  // a floating note — it can't take the condition's colour, can't travel with
  // it into an export, and can't answer "what did we say about this scope".
  const linkCondition = (markup, condId) => { if (markup && condId) updateMarkup(markup.id, { condition_id: condId }); };
  const unlinkCondition = (markup) => { if (markup) updateMarkup(markup.id, { condition_id: "" }); };
  // hard delete: drop the record AND clear the dangling pointer on every linked
  // markup (void is a status; delete removes — both must leave no orphan link)
  function deleteRfi(id) {
    setRfis((rs) => rs.filter((r) => r.id !== id));
    setMarkups((ms) => ms.map((m) => (m.rfi_id === id ? { ...m, rfi_id: "" } : m)));
  }
  // parent-owned update path: the status→response_date auto-stamp lives HERE (not
  // in the view) so the date is data, stamped once on the transition into Answered.
  function updateRfi(id, patch) {
    setRfis((rs) => rs.map((r) => {
      if (r.id !== id) return r;
      const next = { ...r, ...patch };
      if (patch.status && next.status === "answered" && r.status !== "answered" && !next.response_date) {
        next.response_date = new Date().toISOString().slice(0, 10);
      }
      return next;
    }));
  }

  // Fly to a linked markup from the register. Two-phase because openSheets only
  // fires state setters and a sheet's bitmap dims load async: if the target sheet
  // isn't open, stash it in pendingFlyRef + openSheets, and the effect below
  // centers once the panel has non-zero img.w. If already open, center inline.
  function centerOnMarkup(m) {
    const sp = panelByKey(m.sheet_id);
    if (!sp || !sp.img.w) return false;
    let anchor;
    if (m.type === "highlight" && Array.isArray(m.pts) && m.pts.length) anchor = m.pts[Math.floor((m.pts.length - 1) / 2)];
    else if ((m.type === "cloud" || m.type === "highlight") && m.rect) anchor = [(m.rect[0][0] + m.rect[1][0]) / 2, (m.rect[0][1] + m.rect[1][1]) / 2];
    else if (m.type === "callout") anchor = m.at || m.target;
    else if ((m.type === "arrow" || m.type === "dimension") && m.from && m.to) anchor = [(m.from[0] + m.to[0]) / 2, (m.from[1] + m.to[1]) / 2];
    else anchor = m.at;   // text + bubble
    if (!anchor) return false;
    const el = containerRef.current;
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const scale = tfRef.current.scale;
    const sx = anchor[0] * sp.img.w + sp.xOffset, sy = anchor[1] * sp.img.h;
    setTfNow({ x: r.width / 2 - sx * scale, y: r.height / 2 - sy * scale, scale });
    selectMarkup(m.id);
    return true;
  }
  function flyToMarkup(m) {
    if (!m) return;
    // a fly-to and a source-trace both end in setTfNow off the same deps
    // ([panelImgs, groupSig, status]) — starting one must cancel a competing
    // in-flight other, or whichever completes second silently yanks the view
    // the user already stopped looking at.
    pendingSourceRef.current = null;
    setShowMarkups(true);   // flying to a markup reveals the layer, so you never land on an invisible selection
    if (!panelKeySet.has(m.sheet_id)) { pendingFlyRef.current = m; openSheets([m.sheet_id], false); return; }
    // open already, but its bitmap may still be mid-render (img.w === 0) — if the
    // inline center can't run yet, hand off to the phase-2 effect below.
    if (!centerOnMarkup(m)) pendingFlyRef.current = m;
  }
  // Reposition an image markup — the row's Place button. Two cases, branched on
  // whether the image's CURRENT sheet is already open (panelKeySet.has):
  //  - same-sheet: unchanged foundation behavior — fly the view to it (centers
  //    on its stored anchor) and the first-contact grab (onPointerMove ~3699)
  //    preserves the cursor→image offset (no teleport).
  //  - cross-sheet: the image's home sheet isn't open here, so flying there
  //    would defeat placing it on THIS sheet — arm placement in place instead,
  //    and flag placeCrossSheetRef so the first-contact grab zeroes the offset
  //    (the image's stored `at` is a position on the OTHER sheet; centering it
  //    under the cursor is the only sane drop point). See placeCrossSheetRef's
  //    declaration for why the decision has to ride a ref instead of being
  //    re-derived from m.sheet_id at grab time.
  function beginPlace(m) {
    placeGrabRef.current = null;
    placeCrossSheetRef.current = null;
    pendingSourceRef.current = null;   // starting a placement cancels any in-flight source trace — same setTfNow race as flyToMarkup above
    if (panelKeySet.has(m.sheet_id)) {
      flyToMarkup(m);
      setPlacingImageId(m.id);
      setCommitMsg(uiText("Placing image — the view centered on it; move the pointer and click to drop (Esc cancels)."));
    } else {
      pendingFlyRef.current = null;   // an outstanding fly-to (unrelated markup, sheet still opening) must not complete later and recenter the view mid cross-sheet placement — same race class as flyToMarkup clearing pendingSourceRef
      setShowMarkups(true);           // the cross-sheet branch skips flyToMarkup (which sets this for the same-sheet case) — without it, a hidden markup layer means the drag preview is invisible until commit
      placeCrossSheetRef.current = m.id;
      setPlacingImageId(m.id);
      setCommitMsg(uiText("Placing image on this sheet — move the pointer and click to drop (Esc cancels)."));
    }
  }
  // Center the view on a normalized [nx,ny] point within panel `sp` —
  // replicates centerOnMarkup's transform math above verbatim, but keyed off a
  // raw point instead of resolving a markup's anchor. A source trace has no
  // markup on the source sheet to resolve (only a synthetic {sheet_id, rect}),
  // so centerOnMarkup/flyToMarkup can't express this — this is why traceSource
  // doesn't reuse them.
  // Symbol sweep review: bring the selected question into view. q.at is in the
  // sheet's own pixels (the overlay draws it at q.at[0] + xOffset), and the
  // sweep panel floats over the canvas's right side, so center within the part
  // of the canvas left of the panel — otherwise the ring lands under the panel.
  function centerOnSweepQuestion(sw, i) {
    const q = sw?.questions?.[i];
    const sp = q && panelByKey(sw.key);
    const el = containerRef.current;
    if (!q || !sp?.img?.w || !el) return false;
    const r = el.getBoundingClientRect();
    const panelLeft = window.innerWidth - FLOAT_GAP - SWEEP_PANEL_W;
    const visibleW = Math.max(120, Math.min(r.right, panelLeft) - r.left);
    const scale = tfRef.current.scale;
    const sx = q.at[0] + sp.xOffset, sy = q.at[1];
    setTfNow({ x: visibleW / 2 - sx * scale, y: r.height / 2 - sy * scale, scale });
    return true;
  }
  // Follow the review cursor: ↵ / X advance it and → / ← step it, so whenever
  // qIndex moves the view goes with it. Not on the sweep's first render — the
  // person is still looking at the seed they just marqueed.
  const sweepFocusRef = useRef(null);
  useEffect(() => {
    if (!sweep) { sweepFocusRef.current = null; return; }
    const id = `${sweep.key}#${sweep.qIndex}`;
    const prev = sweepFocusRef.current;
    sweepFocusRef.current = id;
    if (prev && prev !== id && prev.startsWith(`${sweep.key}#`)) centerOnSweepQuestion(sweep, sweep.qIndex);
  }, [sweep?.key, sweep?.qIndex]); // eslint-disable-line react-hooks/exhaustive-deps
  function centerOnPanelPoint(sp, nx, ny) {
    if (!sp?.img?.w) return false;
    const el = containerRef.current;
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const scale = tfRef.current.scale;
    const sx = nx * sp.img.w + sp.xOffset, sy = ny * sp.img.h;
    setTfNow({ x: r.width / 2 - sx * scale, y: r.height / 2 - sy * scale, scale });
    return true;
  }
  // Sets the source-trace flash AND arms its one-shot auto-clear — the pulse
  // (app.css `@keyframes pulse`) runs once and then holds its last frame
  // forever unless something nulls the state back out, so without this the
  // flash rect sits as a permanent opaque box. Keyed on `token`, not
  // `sheet_id`: a repeat trace of the same region bumps sourceTraceSeqRef and
  // gets a fresh token, so an older timer's closure (capturing the OLD token)
  // is a no-op against the newer flash it would otherwise stomp — no need to
  // track/cancel the previous timeout explicitly. Both call sites (the
  // inline-ready path in traceSource and the pending-completion effect above)
  // go through this one helper so the timer can't drift between them.
  const SOURCE_FLASH_MS = 2600; // matches app.css pulse's ~2.55s animation length, plus a hair
  function flashSource(sheet_id, rect, token) {
    setSourceFlash({ sheet_id, rect, token });
    setTimeout(() => {
      setSourceFlash((f) => (f && f.token === token ? null : f));
    }, SOURCE_FLASH_MS);
  }
  // Trace a capture back to its ORIGIN sheet+region (◎, button wired by slice
  // 4 — this function, its ref, and its effect are this slice's job). Captures
  // only: m.source === "capture" && src_sheet_id && src_rect (a stitch source
  // sheet works fine here — no suppression, unlike the caption's — openSheets/
  // goToSheet already treat a stitch key as first-class).
  function traceSource(m) {
    if (!m || m.source !== "capture" || !m.src_sheet_id || !m.src_rect) return;
    const mid = rectMidpoint(m.src_rect);
    // a malformed rect arms nothing rather than a pendingSourceRef that can
    // never complete and would burn its whole attempt budget finding that out
    if (!mid) return;
    // Mid-Place guard (plan-mandated): dropping into a trace while an image is
    // still armed for placement must end that gesture FIRST — otherwise the
    // riding image (onPointerMove is still centre-following the cursor) drops
    // onto the SOURCE sheet on the very click that navigates us there.
    if (placingImageId) {
      setPlacingImageId(null);
      placeGrabRef.current = null;
      placeCrossSheetRef.current = null;
    }
    pendingFlyRef.current = null;   // a source trace supersedes any in-flight fly-to (same setTfNow race noted in flyToMarkup)
    const src = m.src_sheet_id, rect = m.src_rect;
    const token = ++sourceTraceSeqRef.current;   // fresh every trace, even a repeat of the same region — see sourceFlash's declaration on why
    if (panelKeySet.has(src)) {
      const sp = panels.find((p) => p.key === src);
      if (sp?.img?.w && centerOnPanelPoint(sp, mid[0], mid[1])) {
        flashSource(src, rect, token);   // no selectMarkup — there's no markup to select on the source sheet
        return;
      }
      // open, but its bitmap hasn't finished rendering yet — the phase-2
      // effect above completes this once panelImgs reports a real width.
      pendingSourceRef.current = { sheet_id: src, rect, token, attempts: 0 };
      return;
    }
    pendingSourceRef.current = { sheet_id: src, rect, token, attempts: 0 };
    openSheets([src], false);
  }

  // ── Doors suite (Trade: Doors & Windows) ──────────────────────────────────
  // Picking the doors trade reads every door on the open sheet from its own
  // linework (lib/doorReader.ts, WebAssembly), matches each to the door
  // schedule by its tag and to the hardware sets in spec 08 71 00
  // (lib/doorSuite.ts), and asks only what the documents leave open. Reads are
  // cached per sheet and run off the paint path; nothing is a quantity until
  // "Add to estimate".
  const doorSuiteOn = !CONFENGE_LOCAL_ONLY && viewTrade === "doors" && view === "canvas";
  const doorRunsRef = useRef(new Map());            // sheet key → text runs in the door frame (unrotated page points)
  const doorSegsRef = useRef(new Map());            // sheet key → the sheet's linework, flat [x0,y0,x1,y1,…], same frame
  const [doorReads, setDoorReads] = useState({});   // sheet key → { status, doors, withheld, rot, w0, h0 }
  // "Find more doors": the door detector (lib/doorDetect), off by default. The switch is remembered; the model
  // downloads once, on the click that turns it on, and runs on WebGPU in a worker. Nothing is uploaded.
  const [doorDetectOn, setDoorDetectOn] = useState(() => { try { return localStorage.getItem("opentakeoff_doors_detector") === "on"; } catch { return false; } });
  const [doorDetect, setDoorDetect] = useState({ gpu: null, cached: null, load: "idle", progress: null, error: null });
  const [doorFound, setDoorFound] = useState({});   // sheet key → { status, doors, withheld, hidden, added, … } (lib/doorDetect/apply.ts)
  const doorDetectClientRef = useRef(null);
  const doorDetectConsentRef = useRef(false);        // the switch was clicked on in this session: the download is allowed
  const doorFoundBusyRef = useRef(new Set());
  // Drop cached door linework and positions for a file after a page mutation (reorder, rotate, delete, merge).
  // The suite reads the sheet again on its own.
  const dropDoorReads = (fileOrFiles) => {
    const files = Array.isArray(fileOrFiles) ? fileOrFiles : [fileOrFiles];
    for (const f of files) {
      for (const k of Array.from(doorRunsRef.current.keys())) {
        if (k === f || k.startsWith(`${f}#`)) doorRunsRef.current.delete(k);
      }
      for (const k of Array.from(doorSegsRef.current.keys())) {
        if (k === f || k.startsWith(`${f}#`)) doorSegsRef.current.delete(k);
      }
    }
    const dropFor = (prev) => {
      let changed = false;
      const next = {};
      for (const [k, v] of Object.entries(prev)) {
        if (files.some((f) => k === f || k.startsWith(`${f}#`))) {
          changed = true;
        } else {
          next[k] = v;
        }
      }
      return changed ? next : prev;
    };
    setDoorReads(dropFor);
    setDoorFound(dropFor);
  };
  const [doorDocs, setDoorDocs] = useState(null);   // { status, schedule, sets } read once per loaded set
  const [doorSel, setDoorSel] = useState(null);     // { key, i } — the door open in the card
  const [doorTab, setDoorTab] = useState("review");
  const [doorCoach, setDoorCoach] = useState(() => { try { return localStorage.getItem("opentakeoff_doors_coach") !== "seen"; } catch { return true; } });
  const doorFileSig = sheets.map((s) => s.name).join("|");
  // the set-wide read: the door schedule (first sheet that has one) and the 08 71 00 hardware sets
  // Reads finish even if the view changes underneath them: a result is keyed by
  // what it read (the file list / the sheet), so it is never stale, and an
  // abandoned read would otherwise leave the suite "reading" for good.
  const doorDocsBusyRef = useRef(null);
  const doorReadBusyRef = useRef(new Set());
  useEffect(() => {
    if (!doorSuiteOn || !sheets.length) return;
    if ((doorDocs && doorDocs.sig === doorFileSig && doorDocs.status === "done") || doorDocsBusyRef.current === doorFileSig) return;
    const sig = doorFileSig;
    doorDocsBusyRef.current = sig;
    setDoorDocs({ sig, status: "reading", schedule: null, sets: [] });
    (async () => {
      const { readDoorSchedule, readHardwareSets, textRuns } = await import("../lib/" + "doorSuite.ts");
      // every page of every loaded file, counted from the documents themselves
      const keys = [];
      for (const f of sheets.map((x) => x.name)) {
        try {
          const n = await docCache.withDoc(f, async (pdf) => pdf.numPages || 1);
          for (let i = 0; i < n; i++) keys.push(i ? `${f}#${i + 1}` : f);
        } catch { /* an image or a file that won't open has no text to read */ }
      }
      let schedule = null, sets = [], setsKey = null;
      for (const k of keys) {
        if (schedule && sets.length) break;
        const t = parseSheetKey(k);
        try {
          await docCache.withDoc(t.file, async (pdf) => {
            const pg = await pdf.getPage(Math.min(Math.max(1, t.page), pdf.numPages || 1));
            const tc = await pg.getTextContent();
            const raw = tc.items.map((it) => it.str).join(" ");
            if (!schedule && /DOOR\s+SCHEDULE/i.test(raw)) {
              const vp = pg.getViewport({ scale: 1 });
              const s = readDoorSchedule(textRuns(tc.items, vp.transform));
              if (s) {
                // the door-type elevations' labels ("F", "FG 2") on the same sheet, for "Show source elevation"
                const runs = textRuns(tc.items, vp.transform);
                const hs = runs.map((r) => r.h).sort((a, b) => a - b);
                const big = hs[Math.floor(hs.length * 0.9)] || 0;
                const types = runs.filter((r) => r.h >= big && r.h > 0 && /^[A-Z]{1,3}\s?\d?$/.test(r.str.trim()));
                schedule = { key: k, rows: s.rows, box: s.box, w: vp.width, h: vp.height, types };
              }
            }
            if (!sets.length && /08\s?71\s?00/.test(raw) && /\bSET\b/i.test(raw)) {
              let text = "", lastY = null;
              for (const it of tc.items) { if (lastY != null && Math.abs(it.transform[5] - lastY) > 2) text += "\n"; text += it.str; lastY = it.transform[5]; if (it.hasEOL) { text += "\n"; lastY = null; } }
              const got = readHardwareSets(text);
              if (got.length) { sets = got; setsKey = k; }
            }
          });
        } catch { /* a page that can't be read is skipped; the suite still runs */ }
      }
      if (doorDocsBusyRef.current === sig) doorDocsBusyRef.current = null;
      setDoorDocs((prev) => (prev && prev.sig !== sig && prev.status === "done" ? prev : { sig, status: "done", schedule, sets, setsKey }));
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doorSuiteOn, doorFileSig]);
  // per open sheet: the doors themselves
  const doorPanelSig = panels.map((p) => p.key).join("|");
  useEffect(() => {
    if (!doorSuiteOn) return;
    (async () => {
      for (const p of panels) {
        const have = doorReads[p.key]?.status;
        if (isStitchKey(p.key) || have === "done" || have === "failed" || doorReadBusyRef.current.has(p.key)) continue;
        doorReadBusyRef.current.add(p.key);
        setDoorReads((prev) => ({ ...prev, [p.key]: { status: "reading" } }));
        try {
          const [{ extractDoorVectors }, { readDoors, DOOR_CUTOFFS }, { textRuns }, { extractVectorGeometry, SEG_CURVE }] = await Promise.all([import("../lib/" + "doorVectors.ts"), import("../lib/" + "doorReader.ts"), import("../lib/" + "doorSuite.ts"), import("../lib/oneclick.ts")]);
          const t = parseSheetKey(p.key);
          const out = await docCache.withDoc(t.file, async (pdf) => {
            const pg = pageObjsRef.current.get(p.key) || await pdf.getPage(Math.min(Math.max(1, t.page), pdf.numPages || 1));
            const vp0 = pg.getViewport({ scale: 1, rotation: 0 });
            const [ol, tc] = await Promise.all([pg.getOperatorList(), pg.getTextContent()]);
            const reading = await readDoors(extractDoorVectors(ol, vp0.transform, pdfjsLib.OPS));
            // not counted until answered: unsure swings, and toilet-partition stall doors (Division 10)
            const held = heldBack(reading.doors, DOOR_CUTOFFS.foundFirst);
            doorRunsRef.current.set(p.key, textRuns(tc.items, vp0.transform));
            // the sheet's linework in the same frame: door-tag symbols around
            // tag text, and each swing's stroke tone (gray = likely existing)
            const geo = extractVectorGeometry(ol, vp0.transform, pdfjsLib.OPS);
            doorSegsRef.current.set(p.key, geo.segs);
            const lums = reading.doors.map((d) => {
              const v = [];
              for (let i = 0, n = 0; i + 3 < geo.segs.length; i += 4, n++) {
                if (!(geo.meta[n] & SEG_CURVE) || !geo.lum) continue;
                const x = (geo.segs[i] + geo.segs[i + 2]) / 2, y = (geo.segs[i + 1] + geo.segs[i + 3]) / 2;
                if (x >= d.box[0] - 1 && x <= d.box[2] + 1 && y >= d.box[1] - 1 && y <= d.box[3] + 1) v.push(geo.lum[n]);
              }
              v.sort((a, b) => a - b);
              return v.length ? v[v.length >> 1] : null;
            });
            const known = lums.filter((x) => x != null).sort((a, b) => a - b);
            const typical = known.length ? known[known.length >> 1] : null;
            const tone = lums.map((l) => (l == null || typical == null ? null : l >= 100 && l >= typical + 45 ? "gray" : "dark"));
            return { status: "done", doors: reading.doors, withheld: held, tone, rot: ((pg.rotate || 0) % 360 + 360) % 360, w0: vp0.width, h0: vp0.height, fpp: reading.fpp };
          });
          setDoorReads((prev) => ({ ...prev, [p.key]: out }));
        } catch (e) {
          setDoorReads((prev) => ({ ...prev, [p.key]: { status: "failed", error: String(e?.message || e) } }));
        } finally {
          doorReadBusyRef.current.delete(p.key);
        }
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doorSuiteOn, doorPanelSig]);
  // Find more doors. Probe once per suite visit: is there WebGPU, is the model already in this browser.
  useEffect(() => {
    if (!doorSuiteOn) return;
    let live = true;
    (async () => {
      const { webGpuAvailable, modelCached } = await import("../lib/doorDetect/" + "client.ts");
      const [gpu, cached] = await Promise.all([webGpuAvailable(), modelCached()]);
      if (live) setDoorDetect((d) => ({ ...d, gpu, cached }));
    })();
    return () => { live = false; };
  }, [doorSuiteOn]);
  const toggleDoorDetect = () => {
    const on = !doorDetectOn;
    if (on) doorDetectConsentRef.current = true;
    else { doorDetectClientRef.current?.cancel(); setDoorDetect((d) => (d.load === "loading" || d.load === "error" ? { ...d, load: "idle", progress: null, error: null } : d)); }
    setDoorDetectOn(on);
    try { localStorage.setItem("opentakeoff_doors_detector", on ? "on" : "off"); } catch { /* private mode */ }
  };
  // Switch on: load the model (from the cache, or downloading it when the switch was clicked in this session),
  // then run it on each open sheet the reader has finished.
  useEffect(() => {
    if (!doorSuiteOn || !doorDetectOn || doorDetect.gpu !== true || doorDetect.load === "error") return;
    let live = true;
    (async () => {
      const { DoorDetectClient, findMoreDoors } = await import("../lib/doorDetect/" + "client.ts");
      const client = (doorDetectClientRef.current ??= new DoorDetectClient());
      if (doorDetect.load !== "ready") {
        if (doorDetect.load === "idle") setDoorDetect((d) => ({ ...d, load: "loading", progress: null, error: null }));
        try {
          await client.load(doorDetectConsentRef.current, (pr) => { if (live) setDoorDetect((d) => ({ ...d, progress: pr })); });
          setDoorDetect((d) => ({ ...d, load: "ready", cached: true, progress: null }));
        } catch (e) {
          if (e?.code === "consent-required") {
            // remembered "on" from an earlier visit, but the model is no longer in this browser: never download unasked
            setDoorDetectOn(false);
            setDoorDetect((d) => ({ ...d, load: "idle", cached: false, progress: null }));
          } else if (e?.code === "aborted") setDoorDetect((d) => ({ ...d, load: "idle", progress: null }));
          else setDoorDetect((d) => ({ ...d, load: "error", progress: null, error: e?.code === "no-webgpu" ? "no-webgpu" : String(e?.message || e) }));
        }
        return;   // the state change runs this effect again
      }
      for (const p of panels) {
        const rd = doorReads[p.key];
        if (isStitchKey(p.key) || rd?.status !== "done" || !rd.doors.length || doorFound[p.key] || doorFoundBusyRef.current.has(p.key)) continue;
        doorFoundBusyRef.current.add(p.key);
        setDoorFound((prev) => ({ ...prev, [p.key]: { status: "running", stage: "render" } }));
        try {
          if (!(rd.fpp > 0)) throw new Error("the sheet's scale could not be read from its doors");
          const t = parseSheetKey(p.key);
          const out = await docCache.withDoc(t.file, async (pdf) => {
            const pg = pageObjsRef.current.get(p.key) || await pdf.getPage(Math.min(Math.max(1, t.page), pdf.numPages || 1));
            return findMoreDoors(pg, rd.doors, rd.fpp, pdfjsLib.OPS, client, (pr) => setDoorFound((prev) => (prev[p.key]?.status === "running" ? { ...prev, [p.key]: { status: "running", ...pr } } : prev)));
          });
          // dev builds only: the last pass per sheet, for the parity check against the Python runner (bench/doors/browserParity.mjs)
          if (import.meta.env.DEV) (window.__otDoorFound ||= {})[p.key] = { ppf: 1 / rd.fpp, det: out.det, preds: out.result.preds, dropped: out.result.dropped.map((d) => ({ ...d.pred, why: d.why })), stats: out.result.stats, tiles: out.tiles, seconds: out.seconds, added: out.added };
          setDoorFound((prev) => ({ ...prev, [p.key]: { status: "done", doors: out.doors, withheld: out.withheld, hidden: out.hidden, added: out.added, rescued: out.rescued, setAside: out.setAside, byKind: out.byKind, tiles: out.tiles, seconds: out.seconds, det: out.det } }));
        } catch (e) {
          setDoorFound((prev) => ({ ...prev, [p.key]: { status: "failed", error: String(e?.message || e) } }));
        } finally {
          doorFoundBusyRef.current.delete(p.key);
        }
      }
    })();
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doorSuiteOn, doorDetectOn, doorDetect.gpu, doorDetect.load, doorPanelSig, doorReads]);
  useEffect(() => () => { doorDetectClientRef.current?.dispose(); doorDetectClientRef.current = null; }, []);
  // What the suite shows: the reader's doors, or with the switch on and the sheet done, the detector's list
  // (the reader's doors in place, some set aside or hidden, plus the doors the detector added).
  const doorReadsEff = useMemo(() => {
    if (!doorDetectOn) return doorReads;
    const out = { ...doorReads };
    for (const [k, f] of Object.entries(doorFound)) {
      const rd = out[k];
      if (f?.status !== "done" || rd?.status !== "done") continue;
      out[k] = { ...rd, doors: f.doors, withheld: f.withheld, hidden: f.hidden, tone: f.doors.map((_, i) => rd.tone?.[i] ?? null) };
    }
    return out;
  }, [doorDetectOn, doorReads, doorFound]);
  // unrotated page point → this panel's image pixels (the frame shapes and overlays draw in)
  const doorToImg = (rd, p, [x, y]) => {
    const { rot, w0, h0 } = rd;
    const [X, Y, W, H] = rot === 90 ? [h0 - y, x, h0, w0] : rot === 180 ? [w0 - x, h0 - y, w0, h0] : rot === 270 ? [y, w0 - x, h0, w0] : [x, y, w0, h0];
    return [(X / W) * p.img.w, (Y / H) * p.img.h];
  };
  // The suite works on the PLAN sheet: a sheet with no doors of its own (the
  // schedule sheet, opened by "Show schedule row") keeps the last plan.
  const [doorPlanKey, setDoorPlanKey] = useState(null);
  const hereKey = panels.find((p) => doorReads[p.key]?.status === "done" && doorReads[p.key].doors.length)?.key || null;   // the reader's own doors decide which sheet is the plan
  useEffect(() => { if (hereKey && hereKey !== doorPlanKey) setDoorPlanKey(hereKey); }, [hereKey, doorPlanKey]);
  const doorKey = hereKey || (doorPlanKey && doorReads[doorPlanKey] ? doorPlanKey : null) || panels[0]?.key || null;
  // Fly to a region of any sheet and flash it: centred in the canvas left of
  // the doors panel, zoomed so the region is plainly visible.
  const doorFlyRef = useRef(null);
  const flyDoorRect = (key, rect, fill = 0.35) => {
    const sp = panels.find((p) => p.key === key);
    const el = containerRef.current;
    if (!sp?.img?.w || !el) { doorFlyRef.current = { key, rect, fill, tries: 0 }; if (!panelKeySet.has(key)) openSheets([key], false); return; }
    doorFlyRef.current = null;
    const r = el.getBoundingClientRect();
    const visibleW = r.width;
    const [[x0, y0], [x1, y1]] = rect;
    const w = Math.max(1, (x1 - x0) * sp.img.w), h = Math.max(1, (y1 - y0) * sp.img.h);
    const scale = Math.min(8, Math.max(tfRef.current.scale, Math.min((visibleW * fill) / w, (r.height * fill) / h)));
    const sx = ((x0 + x1) / 2) * sp.img.w + sp.xOffset, sy = ((y0 + y1) / 2) * sp.img.h;
    setTfNow({ x: visibleW / 2 - sx * scale, y: r.height / 2 - sy * scale, scale });
    flashSource(key, rect, ++sourceTraceSeqRef.current);
  };
  useEffect(() => {
    const f = doorFlyRef.current;
    if (!f) return;
    if (++f.tries > 40) { doorFlyRef.current = null; return; }
    if (panels.find((p) => p.key === f.key)?.img?.w) flyDoorRect(f.key, f.rect, f.fill);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panelImgs, groupSig]);
  const doorView = useMemo(() => {
    const rd = doorKey && doorReadsEff[doorKey];
    if (!doorSuiteOn || !rd || rd.status !== "done") return null;
    const schedule = doorDocs?.schedule ? { rows: doorDocs.schedule.rows, box: doorDocs.schedule.box } : null;
    const tm = matchDoorTags(rd.doors, doorRunsRef.current.get(doorKey) || [], new Set((schedule?.rows || []).map((r) => r.mark)), { segs: doorSegsRef.current.get(doorKey) || null, skip: rd.hidden });
    return buildDoorSuite({ doors: rd.doors, withheld: rd.withheld, hidden: rd.hidden, marks: tm.marks, ambiguous: tm.ambiguous, tone: rd.tone, fpp: rd.fpp, schedule, sets: doorDocs?.sets || [], answers: doorAnswers, sheetLabel: sheetBaseLabel(doorKey) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doorSuiteOn, doorKey, doorReadsEff, doorDocs, doorAnswers]);
  const doorSetOrder = useMemo(() => {
    const fromSpec = (doorDocs?.sets || []).map((s) => s.set);
    const fromSched = (doorDocs?.schedule?.rows || []).map((r) => String(r.hwSet || "").toUpperCase()).filter(Boolean);
    return [...new Set([...fromSpec, ...fromSched])].sort((a, b) => (parseFloat(a) - parseFloat(b)) || a.localeCompare(b));
  }, [doorDocs]);
  const answerDoor = (id, a) => setDoorAnswers((prev) => ({ ...prev, [id]: a }));
  const undoDoor = (id) => setDoorAnswers((prev) => { const n = { ...prev }; delete n[id]; return n; });
  const showDoor = (i, key = doorKey) => {
    const rd = doorReadsEff[key]; const p = panelByKey(key);
    if (!rd?.doors?.[i] || !p?.img?.w) return;
    const d = rd.doors[i];
    const a = doorToImg(rd, p, [d.box[0], d.box[1]]), b = doorToImg(rd, p, [d.box[2], d.box[3]]);
    const pad = 0.01;
    flyDoorRect(key, [[Math.min(a[0], b[0]) / p.img.w - pad, Math.min(a[1], b[1]) / p.img.h - pad], [Math.max(a[0], b[0]) / p.img.w + pad, Math.max(a[1], b[1]) / p.img.h + pad]], 0.18);
    setDoorSel({ key, i });
  };
  const showScheduleRow = (mark) => {
    const s = doorDocs?.schedule; const r = s?.rows.find((x) => x.mark === mark);
    if (!s || !r) return;
    flyDoorRect(s.key, [[r.box[0] / s.w - 0.004, r.box[1] / s.h - 0.003], [r.box[2] / s.w + 0.004, r.box[3] / s.h + 0.003]], 0.85);
  };
  const showElevation = (type) => {
    const s = doorDocs?.schedule; if (!s) return;
    const want = String(type).replace(/\s+/g, "").toUpperCase().split(",")[0];
    const lab = s.types.find((r) => r.str.replace(/\s+/g, "").toUpperCase() === want);
    if (!lab) { setCommitMsg(`No door-type elevation labeled ${type} found on the schedule sheet.`); return; }
    // the elevation sits above its label
    const h = lab.h * 22;
    flyDoorRect(s.key, [[(lab.x - lab.h * 8) / s.w, (lab.y - h) / s.h], [(lab.x + lab.w + lab.h * 8) / s.w, (lab.y + lab.h * 1.5) / s.h]], 0.6);
  };
  // Add (or update) the doors in the estimate: frames per opening, door leaves
  // per leaf, hardware sets per opening, as count marks placed inside each
  // swing (never on the tag). An update replaces the marks the last add made
  // on this sheet, so a second press never double-counts.
  function addDoorsToEstimate() {
    const v = doorView, rd = doorReadsEff[doorKey], p = panelByKey(doorKey);
    if (!v || !rd || !p?.img?.w) return;
    const groups = estimateGroups(v.openings);
    const cs = agentStateRef.current.conditions;
    const condFor = (tag) => cs.find((c) => c.finish_tag === tag) || mintCondition(tag);
    const markSet = new Set((doorDocs?.schedule?.rows || []).map((r) => r.mark));
    const tags = (doorRunsRef.current.get(doorKey) || []).filter((r) => markSet.has(r.str.trim().toUpperCase()) || /^[A-Z]?\d{2,4}[A-Z]{0,2}$/.test(r.str.trim()));
    const norm = ([x, y]) => { const [ix, iy] = doorToImg(rd, p, [x, y]); return [ix / p.img.w, iy / p.img.h]; };
    const add = [];
    for (const g of groups) {
      const label = `${g.type} ${g.size}`.trim();
      // a group of cased openings has frames and no leaves: no empty leaf condition for it
      const frame = condFor(`DR FRAME ${label}`), leaf = g.leaves ? condFor(`DR LEAF ${label}`) : null;
      for (const o of g.openings) {
        const d = rd.doors[o.door];
        const origin = { method: "door_reader", door: o.mark || `door-${o.door}` };
        const pts = countMarkPoints(d, tags);
        add.push({ sheet_id: doorKey, condition_id: frame.id, measure_role: "count", verts_norm: [norm(pts.frame)], computed: { count: 1 }, origin });
        const leafPts = pts.leaves.length >= o.leaves ? pts.leaves.slice(0, o.leaves) : Array.from({ length: o.leaves }, (_, k) => pts.leaves[k] || pts.frame);
        for (const lp of leafPts) add.push({ sheet_id: doorKey, condition_id: leaf.id, measure_role: "count", verts_norm: [norm(lp)], computed: { count: 1 }, origin });
        const set = o.row?.hwSet;
        if (set) add.push({ sheet_id: doorKey, condition_id: condFor(`HW SET ${set}`).id, measure_role: "count", verts_norm: [norm(pts.hardware)], computed: { count: 1 }, origin });
      }
    }
    if (!add.length) return;
    const prior = shapes.filter((s) => s.sheet_id === doorKey && s.origin?.method === "door_reader").map((s) => s.id);
    // one base for both steps (dispatchShape reads the render's `shapes`, so two
    // dispatches in a row would have the second undo the first)
    let base = shapes;
    const step = (cmd) => {
      const res = applyShapeCommand(base, cmd);
      base = res.shapes;
      if (res.inverse) { const st = recordCommand(undoStackRef.current, { cmd, inverse: res.inverse }); undoStackRef.current = st.undo; redoStackRef.current = st.redo; }
    };
    if (prior.length) step({ type: "delete", ids: prior, noCount: true });
    step({ type: "add", shapes: add });
    setShapes(base);
    setDoorAnswers((prev) => ({ ...prev, [`added:${doorKey}`]: nowIso() }));
    setCommitMsg(`${prior.length ? "Updated" : "Added"} ${v.counts.openings} openings (frames), ${v.counts.leaves} door leaves and their hardware sets in the estimate · ${prior.length ? "two undo steps" : "one undo step"} (${keyText("⌘Z")}).`);
  }

  // ── Compare with schedule: the real door schedule sheet beside the plan ──
  // A read-only reference pane (SplitLayout) frames the schedule; each row is
  // boxed in its door's hardware-set colour (dashed amber: no door found on
  // the plan), and a row and its door select each other. Rows are checked off
  // with one click; checks and notes ride `door_answers` with the project.
  const doorSchedKey = doorDocs?.schedule?.key || null;
  const doorCompareOn = !!(splitView && doorSchedKey && splitView.refKey === doorSchedKey);
  const [doorRefFocus, setDoorRefFocus] = useState(null);
  const [doorHover, setDoorHover] = useState(null);   // a schedule mark hovered in the panel or on the sheet
  const doorRefSeqRef = useRef(0);
  const toggleDoorCompare = () => {
    if (doorCompareOn) { setSplitView(null); return; }
    if (!doorSchedKey) return;
    if (splitView) { setSplitView((s) => ({ ...s, refKey: doorSchedKey, refSet: [...new Set([...(s.refSet || [s.refKey]), doorSchedKey])] })); return; }
    if (refuseIfOverCap(1)) return;
    // plan above, schedule below: a schedule is a wide, short table
    setSplitView({ orientation: "h", ratio: 0.58, refKey: doorSchedKey, refSet: [doorSchedKey] });
  };
  const doorRowRect = (r, pad = 1) => {
    const s = doorDocs?.schedule;
    return s ? [[(r.box[0] - 3 * pad) / s.w, (r.box[1] - 1.5 * pad) / s.h], [(r.box[2] + 3 * pad) / s.w, (r.box[3] + 1.5 * pad) / s.h]] : null;
  };
  const focusDoorRow = (mark) => {
    const r = doorDocs?.schedule?.rows.find((x) => x.mark === mark);
    if (!r) return;
    // the row plus its check box, centred in the schedule pane
    const rect = doorRowRect(r, 4);
    if (doorCompareOn && rect) setDoorRefFocus({ rect: [rect[0], [rect[1][0] + 30 / doorDocs.schedule.w, rect[1][1]]], token: ++doorRefSeqRef.current, fill: 0.92 });
  };
  // a row picked (panel list or the sheet): its door is selected and the plan flies there
  const pickDoorRow = (mark) => {
    const o = doorView?.openings.find((x) => x.mark === mark);
    if (o) showDoor(o.door); else if (!doorCompareOn) showScheduleRow(mark);
    focusDoorRow(mark);
  };
  // a door picked on the plan: its row follows in the schedule pane
  const doorSelMark = doorSel && doorView && doorSel.key === doorKey ? doorView.openings.find((o) => o.door === doorSel.i)?.mark || null : null;
  useEffect(() => {
    if (doorSelMark && doorCompareOn) focusDoorRow(doorSelMark);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- follow the selection only; focusDoorRow is a fresh closure every render
  }, [doorSelMark, doorCompareOn]);
  const doorCheck = (mark) => doorAnswers[`check:${mark}`] || null;
  const setDoorCheck = (mark, v) => setDoorAnswers((prev) => {
    const n = { ...prev };
    if (!v || n[`check:${mark}`] === v) { delete n[`check:${mark}`]; if (v === "Needs a look" || !v) delete n[`note:${mark}`]; } else n[`check:${mark}`] = v;
    return n;
  });
  const setDoorNote = (mark, text) => setDoorAnswers((prev) => { const n = { ...prev }; if (text) n[`note:${mark}`] = text.slice(0, 500); else delete n[`note:${mark}`]; return n; });
  const doorPlaced = useMemo(() => new Set((doorView?.openings || []).filter((o) => o.mark && !o.leftOut).map((o) => o.mark)), [doorView]);
  // the schedule rows, boxed — drawn on the schedule sheet wherever it is shown
  // (the reference pane, or the main canvas when it's the open sheet)
  const doorRowBoxes = (img, scale, xOffset = 0) => {
    const s = doorDocs?.schedule;
    if (!s || !img?.w) return null;
    const k = 1 / scale;
    return s.rows.map((r) => {
      const placed = doorPlaced.has(r.mark);
      const color = placed ? doorSetColor(r.hwSet, doorSetOrder) : "#d97706";
      const sel = r.mark === doorSelMark, hot = r.mark === doorHover;
      const x = (r.box[0] / s.w) * img.w + xOffset - 3 * k, y = (r.box[1] / s.h) * img.h - 1.5 * k;
      const w = ((r.box[2] - r.box[0]) / s.w) * img.w + 6 * k, h = ((r.box[3] - r.box[1]) / s.h) * img.h + 3 * k;
      const chk = doorCheck(r.mark);
      const g = Math.min(h * 0.9, 14 * k);
      return (
        <g key={`drow-${r.mark}`}>
          <rect x={x} y={y} width={w} height={h} fill={color} fillOpacity={sel ? 0.28 : hot ? 0.2 : 0.1}
            stroke={color} strokeWidth={(sel ? 3 : 1.6) * k} strokeOpacity={0.9} strokeDasharray={placed ? undefined : `${5 * k} ${3 * k}`}
            style={{ pointerEvents: "all", cursor: "pointer" }}
            onPointerDown={(e) => e.stopPropagation()} onClick={(e) => { e.stopPropagation(); pickDoorRow(r.mark); }}
            onPointerEnter={() => setDoorHover(r.mark)} onPointerLeave={() => setDoorHover((m) => (m === r.mark ? null : m))}>
            <title>{`Door ${r.mark}${placed ? "" : " — not found on the plan"}${chk ? ` · ${chk}` : ""}`}</title>
          </rect>
          <g transform={`translate(${x + w + 3 * k},${y + (h - g) / 2})`} style={{ pointerEvents: "all", cursor: "pointer" }}
            onPointerDown={(e) => e.stopPropagation()} onClick={(e) => { e.stopPropagation(); setDoorCheck(r.mark, "Checked"); }}>
            <title>{chk === "Checked" ? `Row ${r.mark} checked — click to clear` : `Mark row ${r.mark} checked`}</title>
            <rect width={g} height={g} rx={2 * k} fill={chk === "Checked" ? "#0f9d8a" : chk ? "#d97706" : darkMode ? "#1b1f22" : "#ffffff"} stroke={chk ? "none" : color} strokeWidth={1.4 * k} />
            {chk === "Checked" && <path d={`M${g * 0.22},${g * 0.52} L${g * 0.42},${g * 0.72} L${g * 0.8},${g * 0.3}`} fill="none" stroke="#fff" strokeWidth={2 * k} strokeLinecap="round" strokeLinejoin="round" />}
            {chk === "Needs a look" && <text x={g / 2} y={g * 0.78} textAnchor="middle" fontSize={g * 0.8} fontWeight={800} fill="#fff">!</text>}
          </g>
        </g>
      );
    });
  };

  function finishShape() {
    if (tool === "zone") {
      // ephemeral: classify, show, never save. Belongs to the panel of its first point.
      // Cross-panel span — the UI hides the Finish affordance (finishOk), but
      // keep the function safe standalone (Enter is still wired to it): a
      // point on a different panel than poly[0] would normalize to nx/ny
      // outside [0..1] for THAT panel, drawing a region that visually spans
      // a sheet it can never actually count shapes on.
      const tp = poly.length ? panelAt(poly[0][0]) : null;
      if (poly.length >= 3 && tp && poly.every((p) => panelAt(p[0]).key === tp.key)) {
        setZoneCheck({ key: tp.key, pts: poly.map(([x, y]) => [(x - tp.xOffset) / tp.img.w, y / tp.img.h]) });
        setZoneExpand(null);
      }
      clearPoly();
      return;
    }
    // A curved area commits as ONE closed polygon (#284) — the spline is
    // flattened here, at the boundary, so nothing downstream (area, perimeter,
    // Cut Out, hit-testing, the marked PDF, every export) has to learn a second
    // kind of geometry. flattenArcRing is the identity on an all-straight trace.
    const drawn = curveIdx.length ? flattenArcRing(poly, curveIdx, false) : poly;
    if (tool === "surface") commitSurface(drawn, curveIdx.length > 0);
    else if (tool === "linear") commitLinear(drawn, false, curveIdx.length > 0);
    else commitPoly(curveIdx.length ? flattenArcRing(poly, curveIdx, true) : poly, tool === "deduct", { curved: curveIdx.length > 0 });
    clearPoly();
  }
  // #137 — the parent state deleting a reconciled deduct should restore. The
  // deduct's own frozen origin.parent_prev is only correct when it is the
  // parent's SOLE cut: with several reconciled cutouts on one parent, that
  // snapshot predates the OTHER cuts, so restoring it would wipe their holes
  // while their deduct shapes live on. Instead: take the chain's EARLIEST
  // snapshot (the most pristine geometry on record) and re-subtract every
  // surviving deduct's ring in commit order (lib/cutout.recomposeCutouts).
  // Null when the rebuild can't be trusted (panel not mounted, scale unset,
  // or a re-subtract degenerates) — the caller then falls back to a plain
  // delete that leaves the cut baked in, never reverts over survivors.
  function cutoutParentPrevSans(doomed) {
    const chain = shapes.filter((s) => s.cuts_shape_id === doomed.cuts_shape_id && s.origin?.parent_prev);
    const rest = chain.filter((s) => s.id !== doomed.id);
    if (!rest.length) return doomed.origin.parent_prev;
    const parent = shapes.find((s) => s.id === doomed.cuts_shape_id);
    const tp = panelByKey(parent.sheet_id);
    const upp = uppFor(parent.sheet_id);
    if (!tp?.img?.w || !upp) return null;
    const px = (ring) => ring.map(([nx, ny]) => [nx * tp.img.w, ny * tp.img.h]);
    const base = chain[0].origin.parent_prev;
    const r = recomposeCutouts(px(base.verts_norm), (base.verts_norm_holes || []).map(px), rest.map((s) => px(s.verts_norm)));
    if (!r) return null;
    const norm = (ring) => ring.map(([x, y]) => [x / tp.img.w, y / tp.img.h]);
    return {
      verts_norm: norm(r.outer),
      ...(r.holes.length ? { verts_norm_holes: r.holes.map(norm) } : {}),
      computed: { area_sf: +(r.area * upp * upp).toFixed(2), perimeter_lf: +(r.perim * upp).toFixed(2) },
    };
  }
  // #137 — deleting a reconciled deduct reverts its cut out of the parent
  // too: the sole cut restores the frozen origin.parent_prev snapshot
  // (durable — works after a reload, not just within the same undo stack);
  // one of SEVERAL cuts rebuilds the parent from the chain's earliest
  // snapshot minus the survivors (cutoutParentPrevSans). A rebuild that
  // degenerates falls through to the plain delete — the shape goes, its cut
  // stays baked in.
  function deleteSelected() {
    if (!selectedId) return;
    const only = shapes.find((s) => s.id === selectedId);
    if (only?.cuts_shape_id && only.origin?.parent_prev && shapes.some((s) => s.id === only.cuts_shape_id)) {
      const parentPrev = cutoutParentPrevSans(only);
      if (parentPrev) {
        dispatchShape({ type: "cutout", restore: true, deductId: only.id, parentId: only.cuts_shape_id, parentPrev });
        setSelectedId(null);
        return;
      }
    }
    dispatchShape({ type: "delete", ids: [selectedId] }); setSelectedId(null);
  }
  function reassignSelected(condId) { if (selectedId) dispatchShape({ type: "reassign", ids: [selectedId], condition_id: condId }); }
  function reassignSelectedLabel(value) { if (selectedId) dispatchShape({ type: "label", ids: [selectedId], value }); }   // Select-tool single-shape re-label (#111) — value "" / null clears it; label commands never stamp

  // pan/zoom the canvas to fit a condition's takeoffs on the open sheets —
  // the panel's ⌖ / double-click navigation. Fit zoom is capped so a lone
  // count marker doesn't slam the view to maximum magnification.
  // Frame a set of shapes: the viewport fits their union bbox at a working
  // zoom. locateCondition (⌖ on a row) and the scope-collision Look link
  // (#366, which frames the PAIR) share it. Returns false when none of the
  // shapes is on an open sheet.
  function frameShapes(pick) {
    const el = containerRef.current;
    if (!el) return false;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, found = false;
    for (const s of visibleShapes) {
      if (!pick(s)) continue;
      const sp = panelByKey(s.sheet_id);
      for (const [nx, ny] of s.verts_norm) {
        const x = nx * sp.img.w + sp.xOffset, y = ny * sp.img.h;
        x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y);
        found = true;
      }
    }
    if (!found) return false;
    const r = el.getBoundingClientRect();
    const w = Math.max(x1 - x0, 1), h = Math.max(y1 - y0, 1), pad = 90;
    const scale = clamp(Math.min((r.width - pad) / w, (r.height - pad) / h, 1.5));
    setTfNow({ x: (r.width - w * scale) / 2 - x0 * scale, y: (r.height - h * scale) / 2 - y0 * scale, scale });
    return true;
  }
  function locateCondition(id) {
    setHiddenConds((h) => revealed(h, id));   // ⌖ on a hidden condition shows it — never fly to nothing
    if (!frameShapes((s) => s.condition_id === id)) setCommitMsg(uiText(`No takeoffs for ${condById[id]?.finish_tag || "this condition"} on the open sheet${groupKeys.length > 1 ? "s" : ""} yet.`));
  }
  // scope collision (#366): Look frames the PAIR so the estimator sees both
  // rings at once, and selects nothing — deciding which one wins is theirs.
  function lookAtCollision(pair) {
    const ids = new Set([pair.a.shape_id, pair.b.shape_id]);
    if (!panelKeySet.has(pair.sheet_id)) openSheets([pair.sheet_id], false);
    if (!frameShapes((s) => ids.has(s.id))) setCommitMsg(uiText(`Open ${tabLabel(pair.sheet_id)} to look at this pair.`));
  }

  function locateWork(shape) {
    setWorkLocateId(shape.id);
    if (!panelKeySet.has(shape.sheet_id)) openSheets([shape.sheet_id], false);
    setTool("select");
    if (window.matchMedia("(max-width: 1100px)").matches) setAgentOpen(false);
  }
  // Wait for the target sheet's render; the render effect clears selection.
  // Navigation changes only the viewport and selection, never measurement data.
  useEffect(() => {
    if (!workLocateId || status !== "ready") return;
    const shape = shapes.find((s) => s.id === workLocateId);
    const sp = shape && panels.find((p) => p.key === shape.sheet_id);
    const el = containerRef.current;
    if (!shape) { setWorkLocateId(null); return; }
    if (!sp?.img?.w || !el) return;
    const pts = (shape.verts_norm || []).filter((v) => v.length === 2 && v.every(Number.isFinite));
    if (pts.length) {
      const xs = pts.map(([x]) => x * sp.img.w + sp.xOffset), ys = pts.map(([, y]) => y * sp.img.h);
      const x0 = Math.min(...xs), y0 = Math.min(...ys), w = Math.max(1, Math.max(...xs) - x0), h = Math.max(1, Math.max(...ys) - y0);
      const r = el.getBoundingClientRect();
      const scale = clamp(Math.min((r.width - 90) / w, (r.height - 90) / h, 1.5));
      setTfNow({ x: (r.width - w * scale) / 2 - x0 * scale, y: (r.height - h * scale) / 2 - y0 * scale, scale });
    }
    setSelectedId(shape.id); setSelectedMarkupId(null); setWorkLocateId(null);
  }, [workLocateId, status, shapes, panels, setTfNow]);

  // A withheld transition is a QUESTION, and the answer is at a PLACE on the
  // sheet — so its row in the panel jumps there rather than printing raw image
  // pixels at someone. Centers the point at a working zoom; the estimator looks
  // for the door and measures the threshold.
  function locateSheetPoint(sheetId, at) {
    const el = containerRef.current;
    const sp = panelByKey(sheetId);
    if (!el || !sp?.img?.w || !Array.isArray(at)) return;
    const r = el.getBoundingClientRect();
    const scale = clamp(1.2);
    setTfNow({ x: r.width / 2 - (at[0] + sp.xOffset) * scale, y: r.height / 2 - at[1] * scale, scale });
  }

  // ONE condition-minting path — the human +condition button and the agent's
  // create_condition tool both come through here, so the field set and the
  // color/hatch auto-rotation can never drift between the two.
  function mintCondition(tag) {
    // read the LIVE list (agentStateRef) — the agent can mint mid-run, when the
    // render-scope `conditions` closure is stale; the ref is updated per render
    // AND immediately below, so two mints in one model turn rotate correctly.
    const cs = agentStateRef.current.conditions;
    // auto-vary line color AND hatch so each new finish reads distinctly, like a drawing
    const lc = PALETTE[cs.length % PALETTE.length];
    const c = {
      id: uid("cnd"), created_at: nowIso(), finish_tag: tag,
      color: lc,            // line color
      fill: lc,             // fill color (NO_FILL for outline-only)
      hatch: nextHatchId(cs.length),
      multiplier: 1,        // ×N for identical repeated units (measure one, multiply)
      waste_pct: 0,         // flooring waste allowance (manual) — applied in the Report
      materials: [],        // supporting materials (adhesive, grout, …) with coverage rates
      // booked to the trade the canvas is showing, so it stays visible; "All trades" books nothing
      // (the tag prefix, else Finishes, decides — lib/tradeSuites.ts conditionTrade)
      ...(viewTradeRef.current !== ALL_TRADES ? { trade: viewTradeRef.current } : {}),
    };
    agentStateRef.current = { ...agentStateRef.current, conditions: [...cs, c] };
    setConditions((prev) => [...prev, c]);
    return c;
  }
  function addCondition() {
    const tag = (window.prompt(uiText("Finish tag for this condition (e.g. LVT-1):")) || "").trim();
    if (!tag) return;
    const c = mintCondition(tag);
    activateCondition(c.id, { reassign: false });   // no reassign affordance on +condition; still dismisses a live bulk selection
  }

  // ── In-canvas takeoff agent — capabilities, the accept gate, and the run ────
  // The registry (lib/agentTools.js) owns schemas/validation/whitelists; these
  // are the CAPABILITIES its tools close over — each one reads live state via
  // agentStateRef (the loop spans many awaits) and reuses the app's existing
  // deterministic engines verbatim: the pdf.js text layer + extractRegionText
  // (read_sheet_text), the pageSpans builder + the sheet graph's finish reader
  // (read_schedule, the Import from schedule path), the one-click
  // flood/trace/snap pipeline, and the detail-view
  // offscreen render. Nothing here writes to `shapes` — proposals stage into
  // agentProposals and only the accept gate below dispatches an `add` command.
  const AGENT_VIEW_MAX_EDGE = 1024;   // view_region crop cap (vision-model native range)
  const AGENT_TEXT_MAX_ITEMS = 600;   // read_sheet_text cap — a full E-size text layer would drown the context

  const agentPanelFor = (key) => {
    const p = agentStateRef.current.panels.find((x) => x.key === key);
    return p && p.img.w ? p : null;
  };
  const agentUpp = (key) => panelGeom.uppFor(agentStateRef.current.scales, renderScalesRef.current, key);

  // The page text + the region (normalized 0..1 of the panel image, null = the
  // whole sheet) as an image-px rect — shared by read_sheet_text and
  // read_schedule so both read the same box.
  async function agentPageText(key, region) {
    return withSheetPage(key, async (pageObj) => {
      const p = agentPanelFor(key);
      if (!p || !pageObj) throw new Error(`Sheet ${key} isn't rendered yet.`);
      const rs = renderScalesRef.current.get(key) || RENDER_SCALE;
      const vp = pageObj.getViewport({ scale: rs });
      const tc = await pageObj.getTextContent();
      const rect = region
        ? { x0: region.x0 * p.img.w, y0: region.y0 * p.img.h, x1: region.x1 * p.img.w, y1: region.y1 * p.img.h }
        : { x0: 0, y0: 0, x1: p.img.w, y1: p.img.h };
      return { tc, vp, rs, rect, p };
    });
  }

  async function agentTextTokens(key, region) {
    const { tc, vp, rect, p } = await agentPageText(key, region);
    return { tokens: extractRegionText(tc, vp, rect), p };
  }

  async function agentReadSheetText(key, region) {
    const { tokens, p } = await agentTextTokens(key, region);
    return tokens.slice(0, AGENT_TEXT_MAX_ITEMS).map((t) => ({
      text: t.str, x: +(t.x / p.img.w).toFixed(4), y: +(t.y / p.img.h).toFixed(4),
    }));
  }

  // Text layer only — the same spans and reader as Import from schedule's
  // text-layer read; unlike Import, a raster box is not read on-device here.
  // Returns the reader's ScheduleRead: { rows, skipped? } (rows may be [] when
  // skipped codes were all the box held) or { rows: [], refused, title? }
  // (agentTools.js words the refusal and the skipped codes for the model).
  async function agentReadSchedule(key, region) {
    const { tc, vp, rs, rect } = await agentPageText(key, region);
    const { readScheduleSpans } = await import("../lib/scheduleRead");
    return readScheduleSpans(graphSpans(spansInRect(pageSpans(tc.items, vp.transform, rs), rect)));
  }

  // Render just the asked-for crop offscreen (shift its top-left to (0,0)) and
  // hand back a PNG data URL — THE vision tool for scans and ambiguous areas.
  async function agentViewRegion(key, region) {
    return withSheetPage(key, async (pageObj) => {
      const p = agentPanelFor(key);
      if (!p || !pageObj) throw new Error(`Sheet ${key} isn't rendered yet.`);
      const rs = renderScalesRef.current.get(key) || RENDER_SCALE;
      const x0 = region.x0 * p.img.w, y0 = region.y0 * p.img.h;
      const regW = Math.max(1, (region.x1 - region.x0) * p.img.w);
      const regH = Math.max(1, (region.y1 - region.y0) * p.img.h);
      const factor = Math.min(1, AGENT_VIEW_MAX_EDGE / regW, AGENT_VIEW_MAX_EDGE / regH);
      const bw = Math.max(1, Math.round(regW * factor)), bh = Math.max(1, Math.round(regH * factor));
      const cv = document.createElement("canvas");
      cv.width = bw; cv.height = bh;
      await pageObj.render({
        canvasContext: cv.getContext("2d"),
        viewport: pageObj.getViewport({ scale: rs * factor }),
        transform: [1, 0, 0, 1, -x0 * factor, -y0 * factor],
        background: "#ffffff",   // never the panel canvas — dark mode bakes an inversion into those pixels
      }).promise;
      const image_data_url = cv.toDataURL("image/png");
      cv.width = cv.height = 0;
      return { image_data_url, width: bw, height: bh };
    });
  }

  // The one-click engine at an agent-supplied seed — same trigger policy and
  // messages as oneClickAt, WITHOUT touching the interactive proposal state:
  // this probes and returns the ring; committing anything stays behind the gate.
  async function agentOneClickProbe(key, xn, yn) {
    const p = agentPanelFor(key);
    if (!p) return { error: `Sheet ${key} isn't rendered yet — try again in a moment.` };
    const upp = agentUpp(key);
    if (upp == null) return { error: agentScaleGate(key, agentStateRef.current.detectedScales[key]?.label || "") };
    const local = [xn * p.img.w, yn * p.img.h];
    const stats = sheetStatsRef.current.get(key);
    const vectorViable = !!stats && stats.segCount >= RASTER_MIN_SEGS;
    let f = null, raster = false;
    // Vector sheet: the SAME net engine a human click runs — an agent and an
    // estimator must never trace differently (the who-aimed-it rule).
    if (vectorViable) {
      const segs = vectorSegsRef.current.get(key);
      const meta = segMetaRef.current.get(key);
      if (!segs || !meta) return { error: "Still reading this sheet's linework — try again in a moment." };
      if (!netWorker) return { error: "One-Click needs Web Workers in this browser." };
      const kF = RENDER_SCALE / (renderScalesRef.current.get(key) || RENDER_SCALE);
      const ftPx = kF / upp;
      const ck = `${key}:${ftPx.toFixed(4)}`;
      let built = netCacheRef.current.get(ck);
      if (!built) {
        built = netCall({ type: "build", key: ck, segs, meta, subpaths: subpathsRef.current.get(key) || null, ftPx, texts: textMarksRef.current.get(key) || [], opts: {} })
          .then((m) => { if (m.error) { netCacheRef.current.delete(ck); throw new Error(m.error); } return m; });
        netCacheRef.current.set(ck, built);
      }
      try { await built; } catch { return { error: "One-Click couldn't read this sheet's linework — the estimator will have to trace it." }; }
      const rm = await netCall({ type: "room", key: ck, x: local[0] * kF, y: local[1] * kF, ftPx, mode: "room" });
      const r = rm.room;
      if (!r) return { error: "That seed isn't inside an enclosed space on the plan linework. Seed an open spot inside the room." };
      const ring = r.ring.map(([x, y]) => [x / kF, y / kF]);
      if (ring.length < 3) return { error: "Couldn't trace that space into a polygon." };
      const geometry = {
        measure_role: "floor_area",
        verts_norm: ring.map(([x, y]) => [x / p.img.w, y / p.img.h]),
        verts_norm_holes: (r.holes || []).map((h) => h.map(([x, y]) => [x / kF / p.img.w, y / kF / p.img.h])),
      };
      return {
        verts_norm: geometry.verts_norm,
        ...(geometry.verts_norm_holes.length ? { verts_norm_holes: geometry.verts_norm_holes } : {}),
        ...computeShapeMetrics(geometry, p.img, upp),
        seed_norm: [+xn.toFixed(5), +yn.toFixed(5)],
        confidence: 1,
        net_faces: r.faces,
      };
    }
    if (!f) {
      const rmo = await ensureRasterMask(key);
      if (!rmo) return { error: "Couldn't read this scan — the estimator will have to trace it by hand." };
      const r = floodRegionSealed(rmo, local[0], local[1], undefined, sealRadiiFor(rmo.ws / upp), doorWedgeCapPx(rmo.ws / upp), minPassRadiusFor(rmo.ws / upp));
      if (r.status !== "ok") {
        return {
          error: r.status === "leak"
            ? "That space isn't enclosed on the scan — the fill escaped through a gap (faded line or open doorway). Seed a more enclosed spot."
            : "Landed on dense scan ink (text or hatching). Seed an open spot inside the room."
        };
      }
      f = r; raster = true;
    }
    const grid = snapGridsRef.current.get(key);
    const ring = raster
      ? oneClickRing(f, { raster: true, rasterEps: RASTER_RDP_EPS })
      : oneClickRing(f, { nearest: (x, y, d) => (grid ? nearestSnap(grid, x, y, d) : null) });
    if (ring.length < 3) return { error: "Couldn't trace that space into a polygon." };
    const area_sf = +(ringArea(ring) * upp * upp).toFixed(2);
    const conf = traceConfidence(floodSignals(f, { raster, mppf: f.ws / upp, areaSF: area_sf }));
    return {
      verts_norm: ring.map(([x, y]) => [+(x / p.img.w).toFixed(5), +(y / p.img.h).toFixed(5)]),
      area_sf,
      perimeter_lf: +(closedMetrics(ring).perim * upp).toFixed(2),
      seed_norm: [+xn.toFixed(5), +yn.toFixed(5)],
      confidence: conf.score,
      ...(conf.factors.length ? { confidence_factors: conf.factors } : {}),
      ...(f.hatchFiltered ? { hatch_filtered: true } : {}),
      ...(f.sealedPx ? { gap_sealed_px: f.sealedPx } : {}),
      ...(f.minPassDelta ? { min_pass_px: f.minPassPx || 0, min_pass_delta: f.minPassDelta } : {}),
      ...(f.wedges ? { door_wedges: f.wedges } : {}),
      ...(f.ringWedges ? { ring_interiors: f.ringWedges } : {}),
      ...(raster ? { raster_traced: true } : {}),
    };
  }

  // Stage already-whitelisted proposals (the registry validated + whitelisted
  // evidence before calling this). area/perim computed here for the review UI;
  // the accept gate recomputes fresh in case the estimator recalibrates first.
  function stageAgentProposals(shapes) {
    const staged = shapes.map((s) => {
      const p = agentPanelFor(s.sheet);
      const upp = agentUpp(s.sheet) || 0;
      const computed = computeShapeMetrics(s, p.img, upp);
      return {
        id: `agp-${mintUuid()}`,
        sheet_id: s.sheet,
        condition_id: s.condition_id,
        measure_role: s.measure_role,
        verts_norm: s.verts_norm,
        ...(s.verts_norm_holes?.length ? { verts_norm_holes: s.verts_norm_holes } : {}),
        evidence: s.evidence,
        ...(Array.isArray(s.evidence.seed_norm) ? { seed_norm: s.evidence.seed_norm } : {}),
        proposed_ts: nowIso(),
        area_sf: computed.area_sf,
        perim_lf: computed.perimeter_lf,
      };
    });
    setAgentProposals((ps) => [...ps, ...staged]);
    return { staged: staged.length };
  }

  function buildAgentCtx() {
    return {
      listSheets: () => agentStateRef.current.panels.filter((p) => p.img.w).map((p) => ({
        sheet: p.key,
        title: tabLabel(p.key),
        width: p.img.w, height: p.img.h,
        scale_set: agentUpp(p.key) != null,
        ...(agentStateRef.current.scaleSources[p.key] ? { scale_source: agentStateRef.current.scaleSources[p.key] } : {}),
        ...(agentStateRef.current.detectedScales[p.key]?.label ? { detected_label: agentStateRef.current.detectedScales[p.key].label } : {}),
      })),
      sheetDims: (key) => { const p = agentPanelFor(key); return p ? { w: p.img.w, h: p.img.h } : null; },
      uppFor: agentUpp,
      detectedLabel: (key) => agentStateRef.current.detectedScales[key]?.label || "",
      readSheetText: agentReadSheetText,
      readSchedule: agentReadSchedule,
      viewRegion: agentViewRegion,
      oneClick: agentOneClickProbe,
      getConditions: () => agentStateRef.current.conditions.map((c) => ({ id: c.id, finish_tag: c.finish_tag, hatch: c.hatch, waste_pct: c.waste_pct })),
      createCondition: (tag) => { const c = mintCondition(tag); return { id: c.id, finish_tag: c.finish_tag }; },
      proposeShapes: stageAgentProposals,
    };
  }

  // Voice deixis (RFC #59 deixis slice): "carpet one, this room" — the
  // utterance carries WHAT, the crosshair carries WHERE. getAimSeed resolves
  // the existing pointer tracker (lastPtrRef — the same positions the
  // moveCrosshair aim renders from; no second tracker) into a sheet-local
  // seed. null = the aim isn't LIVE: nothing tracked since the utterance
  // began — Command box focus / the previous run — or since the pointer left
  // the canvas or the tab hid (voiceAimMarkRef). sheetId "" = live aim that
  // isn't over a sheet. Both become loud rejects in the dispatcher, checked
  // before any state moves. The seed is the RAW cursor, not the snap/angle-
  // adjusted point: a flood seed targets a room's interior, where snap pull
  // toward a wall endpoint could only hurt — and matches a mid-room click,
  // which never snaps either.
  function getAimSeed() {
    if (status !== "ready" || !lastPtrRef.current) return null;
    if (aimSeqRef.current <= voiceAimMarkRef.current) return null;   // stale — no pointer update since the utterance began / last invalidation
    const p = toImage(lastPtrRef.current[0], lastPtrRef.current[1]);
    const tp = panelAt(p[0]);
    const x = p[0] - tp.xOffset, y = p[1];
    if (!tp.img.w || x < 0 || y < 0 || x >= tp.img.w || y >= tp.img.h) return { x, y, sheetId: "" };
    return { x, y, sheetId: tp.key };
  }
  // The who-aimed-it rule: the human put the crosshair there, so the trace
  // runs the SAME oneClickAt flood a physical click runs and commits DIRECT
  // as human work (one_click_v1 origin, same undo) — one utterance, no
  // preview-then-⏎, and NEVER an agentProposals row (that gate is for agent-
  // INFERRED placement; the line is aim). conditionId/label ride explicitly:
  // the utterance armed them in this same handler, so the render closures are
  // stale. Failures wrap into the commitMsg bar's "Couldn't" convention.
  async function voiceTraceAt(seed, conditionId, label) {
    const tp = panelByKey(seed.sheetId);
    if (!tp || tp.key !== seed.sheetId || !tp.img.w) return { ok: false, message: "Couldn't place that — aim at a sheet." };
    const out = await oneClickAt([seed.x + tp.xOffset, seed.y], false, { conditionId, label });
    if (out.ok) return out;
    const m = out.message || "Couldn't place that — the view changed mid-trace. Say it again.";
    return { ok: false, message: /^couldn'?t/i.test(m) ? m : `Couldn't place that — ${m.charAt(0).toLowerCase()}${m.slice(1)}` };
  }
  // Voice-command capabilities (RFC #59 slice 2) — every entry binds an action
  // the UI already exposes; the dispatcher (voiceActions.ts) never touches
  // state directly. getConditions reads the live mirror (mintCondition updates
  // it mid-handler); the rest are safe render closures because the voice path
  // is synchronous up to traceAt, whose async continuation carries its state
  // by value/ref instead. Programmatic activation passes {reassign:false} —
  // same policy as hotkeys and Library Apply.
  function buildVoiceCtx() {
    return {
      getConditions: () => agentStateRef.current.conditions.map((c) => ({ id: c.id, finish_tag: c.finish_tag })),
      getShapeLabels: () => shapeLabels,
      getActiveConditionId: () => activeCond || "",
      activateCondition: (id) => activateCondition(id, { reassign: false }),
      createCondition: (tag) => mintCondition(tag),
      updateCondition: updateCondById,
      addLabel,
      activateLabel,
      // top-center of the focused sheet: text markups render centered on `at`,
      // and addMarkup auto-opens the Markups dock, so the note is immediately
      // visible and draggable — the anchor is a starting point, not a commitment
      addNote: (text) => addMarkup({ type: "text", at: [0.5, 0.06], text }, focusPanel.key),
      // author declaration (#314) — provenance's one localStorage key; new
      // commits pick it up at mint, nothing re-stamps retroactively
      setAuthor: (v) => setAuthorName(v),
      getAimSeed,
      traceAt: (seed, conditionId, label) => voiceTraceAt(seed, conditionId, label),
    };
  }
  const onVoiceCommand = (text) => {
    const out = runVoiceCommand(buildVoiceCtx(), text);
    // every run consumes the aim (the seed was already read synchronously):
    // repeating "this room" without a fresh pointer move is a stale-aim
    // reject, never a silent double-commit of the same room
    voiceAimMarkRef.current = aimSeqRef.current;
    const finish = (o) => {
      setCommitMsg(o.message);
      // two-tier router (RFC #59 slice 5): a FULLY-unrecognized transcript,
      // with the agent configured, earns an OFFER — never an auto-run. Any
      // other outcome (success, near-miss reject, dispatcher refusal) clears
      // a stale offer so ⏎ can never become a surprise agent run.
      if (shouldOfferAgentHandoff(o, isAiConfigured())) offerAgentHandoff(text);
      else clearAgentOffer();
      return o.ok;
    };
    // deixis traces can resolve async (raster flood awaits a render) — the
    // outcome message lands when it lands; everything else stays synchronous
    return typeof out?.then === "function" ? out.then(finish) : finish(out);
  };

  // ── push-to-talk (RFC #59 recognizer slice) ────────────────────────────────
  // Hold M to dictate; release runs the transcript through the SAME
  // onVoiceCommand the Command box uses; Esc mid-hold discards. Everything is
  // lazy: the worker + model load on the first hold (ingest.js precedent), and
  // decode happens OFF the main thread (stt.worker.ts) so pan/zoom stays
  // smooth. Deliberately NOT re-marking the deixis aim at keydown: for typed
  // commands focus starts the utterance and the pointer moves after; for a
  // hold, the hand is ALREADY resting the pointer on the room — demanding a
  // pointer tick mid-hold would stale-reject every still-handed "this room".
  // The standing invalidations (canvas-leave, tab-hide, previous run) still
  // guard every ghost-seed path the #83 design named.
  const [voiceChip, setVoiceChip] = useState(null); // { text, tone: "live"|"busy"|"info"|"offer" } | null
  const voiceClientRef = useRef(null);
  const voiceCaptureRef = useRef(null);              // live CaptureSession during a hold
  const voiceModelRef = useRef({ phase: "unprobed" });
  const voiceHoldRef = useRef(false);                // physical key/button state
  const voiceFlashRef = useRef(0);                   // transcript-flash timer
  // ── two-tier router offer (RFC #59 slice 5) ───────────────────────────────
  // A thin consent-gated bridge into the EXISTING agent loop: confirm hands
  // the refused transcript to runAgent() — same cfg, tools, Accept gate as the
  // panel; no new tools, no second interpretation. The offer expires (consent
  // hygiene), and the spoken confirm is a fixed literal, never grammar.
  const AGENT_OFFER_TTL_MS = 20000;
  const pendingAgentOfferRef = useRef(null);         // { transcript } | null — the chip is the render, the ref is the logic
  const agentOfferTimerRef = useRef(0);
  function offerAgentHandoff(transcript) {
    clearTimeout(agentOfferTimerRef.current);
    pendingAgentOfferRef.current = { transcript };
    setVoiceChip({ text: 'not a command — ⏎ or say "ask the agent" to run it on YOUR agent (your endpoint, your key) · proposals land for review · Esc dismisses', tone: "offer" });
    agentOfferTimerRef.current = setTimeout(() => clearAgentOffer(), AGENT_OFFER_TTL_MS);
  }
  function clearAgentOffer() {
    if (!pendingAgentOfferRef.current) return;
    clearTimeout(agentOfferTimerRef.current);
    pendingAgentOfferRef.current = null;
    setVoiceChip((c) => (c && c.tone === "offer" ? null : c));
  }
  function confirmAgentHandoff() {
    const t = pendingAgentOfferRef.current?.transcript;
    clearAgentOffer();
    if (!t) return;
    // runAgent self-guards (agentRunning, isAiConfigured, sheet ready); the
    // panel opens so the run — and its Accept gate — happen in plain sight
    setAgentOpen(true);
    void runAgent(t);
  }
  const agentOfferFnsRef = useRef(null);
  agentOfferFnsRef.current = { confirm: confirmAgentHandoff, dismiss: clearAgentOffer, pending: () => !!pendingAgentOfferRef.current };
  function ensureVoiceClient() {
    if (!voiceClientRef.current) {
      voiceClientRef.current = createVoiceRecognizerClient((s) => {
        voiceModelRef.current = s;
        if (s.phase === "loading") setVoiceChip({ text: `voice model loading… ${s.pct}%`, tone: "busy" });
        else if (s.phase === "ready") setVoiceChip((c) => (c && c.tone === "busy" ? null : c));
        else if (s.phase === "uninstalled") { setVoiceChip(null); setCommitMsg(uiText("Voice isn't installed on this deployment — see docs/VOICE.md to stage the model.")); }
        else if (s.phase === "error") { setVoiceChip(null); setCommitMsg(uiText(`Couldn't load the voice model — ${s.message} Hold M to retry.`)); }
      });
    }
    return voiceClientRef.current;
  }
  async function voiceHoldStart() {
    if (voiceCaptureRef.current) return;
    const client = ensureVoiceClient();
    if (voiceModelRef.current.phase !== "ready") {
      // never a silent drop: pressing PTT before the model is ready SAYS so
      // (and kicks off/retries the load, so the affordance is also the fix)
      void client.ensureReady();
      if (voiceModelRef.current.phase === "loading")
        setVoiceChip({ text: `voice model loading… ${voiceModelRef.current.pct ?? 0}% — try again shortly`, tone: "busy" });
      return;
    }
    try {
      const session = await startCapture();
      if (!voiceHoldRef.current) { session.cancel(); return; }  // released during the permission prompt
      session.onEnded(() => {
        session.cancel();
        voiceCaptureRef.current = null;
        setVoiceChip(null);
        setCommitMsg(uiText("Couldn't finish dictation — the microphone was revoked."));
      });
      voiceCaptureRef.current = session;
      setVoiceChip({ text: "listening… release M to run · Esc to discard", tone: "live" });
    } catch (err) {
      setCommitMsg(
        err?.reason === "mic_denied" ? "Couldn't start dictation — microphone permission denied. Allow the mic and try again."
          : err?.reason === "no_mic_device" ? "Couldn't start dictation — no microphone found."
            : "Couldn't start dictation — microphone unavailable.",
      );
    }
  }
  function voiceHoldEnd(commit) {
    const session = voiceCaptureRef.current;
    voiceCaptureRef.current = null;
    if (!session) return;
    if (!commit) { session.cancel(); setVoiceChip(null); return; }
    const pcm = session.stop();
    if (pcm.length < 1600) { setVoiceChip(null); return; }   // <0.1 s — a key tap, not an utterance
    setVoiceChip({ text: "decoding…", tone: "busy" });
    voiceClientRef.current.transcribe(pcm).then((text) => {
      const t = text.trim();
      // the spoken router confirm is a FIXED LITERAL (never grammar): said
      // alone with an offer pending it confirms; without one it says so —
      // and the trigger itself never becomes an offer
      if (isAgentHandoffTrigger(t)) {
        if (pendingAgentOfferRef.current) { setVoiceChip(null); agentOfferFnsRef.current.confirm(); return true; }
        setVoiceChip({ text: "nothing to hand off — say the command first", tone: "info" });
        clearTimeout(voiceFlashRef.current);
        voiceFlashRef.current = setTimeout(() => setVoiceChip((c) => (c && c.tone === "info" ? null : c)), 2400);
        return false;
      }
      // flash what was heard — the transcript is the receipt — then the
      // outcome lands in the commitMsg bar like every other command
      setVoiceChip(t ? { text: `“${t}”`, tone: "info" } : null);
      clearTimeout(voiceFlashRef.current);
      voiceFlashRef.current = setTimeout(() => setVoiceChip((c) => (c && c.tone === "info" ? null : c)), 2400);
      return Promise.resolve(onVoiceCommandRef.current(t));
    }).catch(() => { setVoiceChip(null); setCommitMsg(uiText("Couldn't decode that — try again.")); });
  }
  // live refs — the mount-once keyboard effect must never see stale closures
  const onVoiceCommandRef = useRef(null);
  onVoiceCommandRef.current = onVoiceCommand;
  const voiceFnsRef = useRef(null);
  voiceFnsRef.current = { start: voiceHoldStart, end: voiceHoldEnd };
  useEffect(() => {
    const down = (e) => {
      if (e.key === "Escape" && voiceCaptureRef.current) { voiceFnsRef.current.end(false); return; }
      const tg = e.target.tagName;
      if (tg === "INPUT" || tg === "SELECT" || tg === "TEXTAREA") return;
      if (menuDepthRef.current > 0) return;
      if (ocrReadRef.current?.ocr) return;   // held while a schedule box is read on-device
      if (e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
      if ((e.key || "").toLowerCase() !== "m") return;
      if (!commandBoxEnabled()) return;   // gated off the topbar (lib/gate.js): M arms nothing
      voiceHoldRef.current = true;
      voiceFnsRef.current.start();
    };
    const up = (e) => {
      if ((e.key || "").toLowerCase() !== "m") return;
      if (!voiceHoldRef.current) return;
      voiceHoldRef.current = false;
      voiceFnsRef.current.end(true);
    };
    // tab backgrounded mid-dictation: discard, say so (testing-bar lifecycle)
    const onVis = () => {
      if (document.visibilityState === "hidden" && voiceCaptureRef.current) {
        voiceHoldRef.current = false;
        voiceFnsRef.current.end(false);
        setCommitMsg(uiText("Dictation discarded — the tab went to the background."));
      }
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      document.removeEventListener("visibilitychange", onVis);
      // unmount cleanup — no orphaned audio contexts, workers, or offer timers
      voiceCaptureRef.current?.cancel();
      voiceCaptureRef.current = null;
      voiceClientRef.current?.dispose();
      voiceClientRef.current = null;
      clearTimeout(agentOfferTimerRef.current);
      pendingAgentOfferRef.current = null;
    };
  }, []);

  // ── the accept gate ─────────────────────────────────────────────────────────
  // Accept = the explicit human review one-click's Create models: the shape
  // commits through dispatchShape `add` (id/created_at minted there) with the
  // agent_v1 origin receipt — actor agent, reviewed true, the FROZEN proposed
  // ring, the evidence, and the propose/accept timestamps (local provenance;
  // the contribution wire whitelists evidence only, never timing). Post-accept
  // edits then grade through stampEdit exactly like one-click corrections.
  function acceptAgentProposals(ids) {
    const idSet = new Set(ids);
    const take = agentProposals.filter((p) => idSet.has(p.id));
    if (!take.length) return;
    const made = [], accepted = new Set();
    let skippedClosed = 0;
    for (const pr of take) {
      const tp = panels.find((x) => x.key === pr.sheet_id && x.img.w);
      const upp = uppFor(pr.sheet_id);
      if (!tp || !upp || !condById[pr.condition_id]) { skippedClosed++; continue; }
      made.push({
        sheet_id: pr.sheet_id, condition_id: pr.condition_id, measure_role: pr.measure_role,
        verts_norm: pr.verts_norm.map((v) => [...v]),
        ...(pr.verts_norm_holes?.length ? { verts_norm_holes: structuredClone(pr.verts_norm_holes) } : {}),
        computed: computeShapeMetrics(pr, tp.img, upp, condById[pr.condition_id]),
        origin: {
          method: "agent_v1", actor: "agent", reviewed: true,
          proposed_ts: pr.proposed_ts, accepted_ts: nowIso(),
          proposed_verts_norm: pr.verts_norm.map((v) => [...v]),
          ...(pr.seed_norm ? { seed_norm: pr.seed_norm } : {}),
          ...(pr.evidence ? { evidence: pr.evidence } : {}),
        },
      });
      accepted.add(pr.id);
    }
    if (made.length) dispatchShape({ type: "add", shapes: made });   // ONE command — one undo entry for the batch
    setAgentProposals((ps) => ps.filter((p) => !accepted.has(p.id)));
    if (made.length) setCommitMsg(formatMessage("Accepted agent proposals: {0}.{1}", [made.length,
      skippedClosed ? " " + formatMessage("Skipped proposals: {0}. Open their sheets with scales set to accept them.", [skippedClosed]) : ""]));
    else if (skippedClosed) setCommitMsg(uiText("Open that proposal's sheet (with its scale set) to accept it."));
  }
  const acceptAgentProposal = (id) => acceptAgentProposals([id]);
  const acceptAllVisibleAgentProposals = () => acceptAgentProposals(agentProposals.filter((p) => panelKeySet.has(p.sheet_id)).map((p) => p.id));
  // Reject = drop from the pending list, LOCAL ONLY. Dismissed-proposal
  // geometry never rides the contribution wire — no rejection records, no
  // counters, nothing for contribute.js to even see (the D34 cut-line).
  const rejectAgentProposal = (id) => setAgentProposals((ps) => ps.filter((p) => p.id !== id));

  // ── correction rules (#88) — detect → offer → preview → Apply ──────────────
  // The correction carried information: a deduct hand-drawn fully inside a
  // same-condition room is "this enclosed thing is not finish area on this
  // project". detectCandidateRule (lib/rules.ts, pure + tested) decides; the
  // banner offers; Preview stages candidates as dashed pencil; Apply commits
  // ONE ruleApply command. Never silent, never model-in-the-loop.
  function maybeOfferRule(deductShape, allShapes) {
    const seed = detectCandidateRule(allShapes, deductShape);
    if (!seed) return;
    setRuleStage(null);
    setRuleOffer({ deduct: deductShape, seed, tag: condById[deductShape.condition_id]?.finish_tag || "this condition" });
  }
  function previewRule() {
    if (!ruleOffer) return;
    const rule = buildRuleFromSeed(ruleOffer.deduct, ruleOffer.seed, ruleOffer.tag, { id: `rule-${mintUuid()}`, now: nowIso() });
    // sheet data for every OPEN panel with linework + a scale — the rule scans
    // what the estimator can see and review, nothing off-screen.
    const sheetData = new Map();
    for (const p of panels) {
      if (!p.img?.w) continue;
      const mo = ensureMask(p.key);
      const upp = uppFor(p.key);
      if (!mo || !upp) continue;
      sheetData.set(p.key, { mask: mo, upp, imgW: p.img.w, imgH: p.img.h });
    }
    const candidates = applyRuleToProject(rule, shapes, sheetData);
    setRuleOffer(null);
    if (!candidates.length) { setCommitMsg(uiText("No other enclosed regions match this rule on the open sheets.")); return; }
    setRuleStage({ rule, candidates, proposed_ts: nowIso() });
  }
  function applyStagedRule() {
    if (!ruleStage) return;
    const { rule, candidates, proposed_ts } = ruleStage;
    const ts = nowIso();
    const made = [];
    for (const c of candidates) {
      const tp = panels.find((x) => x.key === c.sheet_id && x.img.w);
      const upp = uppFor(c.sheet_id);
      if (!tp || !upp) continue;
      const ringPx = c.verts_norm.map(([nx, ny]) => [nx * tp.img.w, ny * tp.img.h]);
      made.push({
        sheet_id: c.sheet_id, condition_id: rule.seed_condition_id, measure_role: "deduct",
        verts_norm: c.verts_norm.map((v) => [...v]),
        computed: { area_sf: +(ringArea(ringPx) * upp * upp).toFixed(2), perimeter_lf: +(closedMetrics(ringPx).perim * upp).toFixed(2) },
        // rule_v1 origin — every propagated shape traces back to the rule and
        // the seed correction (the RFC's provenance requirement, verbatim).
        origin: {
          method: "rule_v1", actor: "rule", reviewed: true,
          rule_id: rule.id, seed_shape_id: rule.seed_shape_id,
          container_shape_id: c.container_shape_id,
          proposed_ts, accepted_ts: ts,
          proposed_verts_norm: c.verts_norm.map((v) => [...v]),
        },
      });
    }
    setRuleStage(null);
    if (!made.length) return;
    const res = dispatchShape({ type: "ruleApply", shapes: made });   // ONE command — one undo entry for the whole batch
    const ids = res.shapes.slice(-made.length).map((s) => s.id);
    // the rule persists WITH its audit trail — inspectable in the project file
    setRules((rs) => [...rs.filter((r) => r.id !== rule.id), { ...rule, applied_to: ids }]);
    setCommitMsg(uiText(`Rule applied — ${made.length} deduct${made.length === 1 ? "" : "s"} added (⌘Z undoes all). ${rule.label}.`));
  }

  // ── ⟂ Transitions (#202, canvas side) ──────────────────────────────────────
  // Where two finishes meet is the most mechanical line left on a Division 9
  // takeoff, and an estimator draws it by hand on every job. derive_transitions
  // handed that to the agent; this hands the same thing — and the same refusal —
  // to the person at the canvas.
  //
  // A BUTT JOINT (the two rooms running together inside one open space) commits
  // as dashed pencil on the ACTIVE condition, so the Accept pill already on
  // screen is the gate and ⌘Z undoes the sweep in one step. A WALL-SEPARATED
  // pair never commits: the transition across a partition is a threshold in a
  // doorway, and nothing in a flood trace says where the doorway is. Those come
  // back as a report — length, gap, and a point to look at — for the estimator
  // to place with the drawing in front of them.
  //
  // Sources are scoped to the OPEN sheets (the rule preview's rule): the
  // derivation only proposes what you can see and review.
  const transitionSources = useMemo(() => {
    const rooms = new Map();
    for (const s of visibleShapes) {
      if (s.measure_role !== "floor_area") continue;
      rooms.set(s.condition_id, (rooms.get(s.condition_id) || 0) + 1);
    }
    return conditions.filter((c) => rooms.has(c.id)).map((c) => ({ id: c.id, finish_tag: c.finish_tag, rooms: rooms.get(c.id) }));
  }, [conditions, visibleShapes]);

  function deriveTransitionsOnto(idA, idB) {
    const target = condById[activeCond];
    if (!target) return { error: "Pick the condition the transitions land on first." };
    const ca = condById[idA], cb = condById[idB];
    if (!ca || !cb) return { error: "Pick the two finishes that meet." };
    const roomsOf = (id) => visibleShapes
      .filter((s) => s.condition_id === id && s.measure_role === "floor_area" && (s.verts_norm || []).length >= 3)
      .map((s) => ({ id: s.id, sheet_id: s.sheet_id, verts_norm: s.verts_norm }));
    const a = { tag: ca.finish_tag, shapes: roomsOf(idA) };
    const b = { tag: cb.finish_tag, shapes: roomsOf(idB) };
    // frames for the open panels those rooms actually sit on; an unscaled one
    // refuses the WHOLE call rather than deriving a partial answer — a
    // transition is a real length, and half a sweep reads like a whole one.
    const frames = new Map(), unscaled = [];
    const inPlay = new Set([...a.shapes, ...b.shapes].map((s) => s.sheet_id));
    for (const p of panels) {
      if (!p.img?.w || !inPlay.has(p.key)) continue;
      const upp = uppFor(p.key);
      if (!upp) { unscaled.push(labelFor(p)); continue; }
      frames.set(p.key, { widthPx: p.img.w, heightPx: p.img.h, upp });
    }
    const refusal = transitionRefusal({ activeTag: target.finish_tag, a, b, sheets: frames, unscaled });
    if (refusal) return { error: refusal };
    const { runs, withheld } = deriveTransitionRuns(a, b, frames);
    const tIn = Number(target.thickness_in) || 0;   // a transition strip with a width prices border SF, exactly like a drawn line
    const made = runs.map((r) => ({
      sheet_id: r.sheet_id, condition_id: target.id, measure_role: "linear",
      verts_norm: r.verts_norm.map((v) => [...v]),
      computed: { perimeter_lf: r.length_lf, area_sf: tIn > 0 ? +((r.length_lf * tIn) / 12).toFixed(2) : 0 },
      // the MCP verb's provenance vocabulary, verbatim: both parents, both
      // tags, the measured gap, and `case` always "butt" — a wall-separated run
      // is a question, and questions do not become shapes.
      origin: {
        method: "derived", actor: "canvas", reviewed: false, proposed_ts: nowIso(),
        derived: { between_shape_ids: r.between_shape_ids, between: r.between, case: "butt", gap_in: r.gap_in },
      },
    }));
    if (made.length) dispatchShape({ type: "add", shapes: made });   // ONE command — one undo entry for the whole sweep
    const total_lf = +made.reduce((n, s) => n + s.computed.perimeter_lf, 0).toFixed(2);
    if (made.length) {
      setCommitMsg(uiText(`${made.length} transition${made.length === 1 ? "" : "s"} derived between ${a.tag} and ${b.tag} — ${total_lf} LF onto ${target.finish_tag}, dashed until you Accept (⌘Z undoes the sweep).`));
    } else if (withheld.length) {
      setCommitMsg(uiText(`Nothing to commit — every ${a.tag}/${b.tag} run is across a wall. See the Transitions panel.`));
    } else {
      setCommitMsg(uiText(`${a.tag} and ${b.tag} never meet on the open sheets.`));
    }
    return { committed: made.length, total_lf, withheld, between: [a.tag, b.tag], onto: target.finish_tag };
  }

  // ── the accept gate, for shapes already IN the data ─────────────────────────
  // An imported MCP takeoff arrives committed but unreviewed (origin.reviewed
  // === false) — those render dashed pencil and gate the Accept pill. Accept
  // routes through the `review` command (ONE undo entry), which flips reviewed
  // + stamps accepted_ts and nothing else: affirmation, not an edit. Rejecting
  // one is just deleting it — select and Delete, like any shape.
  const pendingCommitted = useMemo(() => visibleShapes.filter((s) => s.origin?.reviewed === false || s.flagged_for_revision || s.origin?.flagged_for_revision), [visibleShapes]);
  // proposals (#365): the visible pending shapes grouped by batch — one pill
  // per proposal on the Accept surface, the un-batched remainder as its own
  // pill. Accept is the SAME review command as the single pill (one undo
  // entry); Reject deletes the batch's pending shapes (⌘Z restores them).
  const pendingGroups = useMemo(() => pendingByProposal(pendingCommitted, proposals), [pendingCommitted, proposals]);
  // scope collision (#366): every pair of floor shapes claiming the same
  // floor, measured by the same module the MCP verbs read — so the badge on a
  // condition row and scope_duplicates over the wire never disagree. Sheets
  // not on canvas (no bitmap dims) are unmeasured here, not zero.
  const scopeResult = useMemo(() => scopeCollisions(shapes, conditions, (key) => {
    const p = panels.find((x) => x.key === key && x.img?.w);
    return p ? { w: p.img.w, h: p.img.h, upp: uppFor(key) || 0 } : null;
  }), [shapes, conditions, panels, scales]);   // eslint-disable-line react-hooks/exhaustive-deps -- uppFor reads scales + the render-scale ref
  const scopeByCond = useMemo(() => collisionsByCondition(scopeResult), [scopeResult]);
  const revisionFlaggedByCond = useMemo(() => {
    const set = new Set();
    for (const s of shapes) {
      if (s.flagged_for_revision || s.origin?.flagged_for_revision) {
        set.add(s.condition_id);
      }
    }
    return set;
  }, [shapes]);
  function acceptProposalGroup(g) {
    if (!g?.ids.length) return;
    dispatchShape({ type: "review", ids: g.ids });
    setCommitMsg(uiText(`Accepted ${g.proposal ? `“${g.proposal.label}” — ` : ""}${g.ids.length} shape${g.ids.length === 1 ? "" : "s"} — pencil is now ink (⌘Z undoes).`));
  }
  function rejectProposalGroup(g) {
    if (!g?.ids.length) return;
    dispatchShape({ type: "delete", ids: g.ids, reason: "proposal-reject" });
    setCommitMsg(uiText(`Rejected ${g.proposal ? `“${g.proposal.label}” — ` : ""}${g.ids.length} proposed shape${g.ids.length === 1 ? "" : "s"} removed (⌘Z restores).`));
  }
  // condition-edit proposals (#365): accept applies the diff through the same
  // patch path the panel editor writes (updateCondById), so the condition
  // afterwards is exactly what typing the values would have produced; reject
  // drops the diff and touches nothing. Neither lands on the shape undo
  // stack — condition edits never have (the editor's own knobs don't either).
  function acceptConditionEdit(id) {
    const p = conditionEditProposals.find((x) => x.id === id);
    if (!p) return;
    const r = acceptConditionEditProposal(conditions, p, nowIso);
    if (r.error) { setCommitMsg(uiText(`Couldn't accept the proposed change: ${r.error}`)); return; }
    setConditions(r.conditions);
    agentStateRef.current = { ...agentStateRef.current, conditions: r.conditions };
    setConditionEditProposals((ps) => ps.filter((x) => x.id !== id));
    const tag = r.conditions.find((c) => c.id === p.condition_id)?.finish_tag || "";
    setCommitMsg(uiText(`Accepted the proposed change on ${tag}.`));
  }
  function rejectConditionEdit(id) {
    const p = conditionEditProposals.find((x) => x.id === id);
    if (!p) return;
    setConditionEditProposals((ps) => ps.filter((x) => x.id !== id));
    setCommitMsg(uiText(`Rejected the proposed change on ${condById[p.condition_id]?.finish_tag || "that condition"} — nothing changed.`));
  }
  const rejectAllAgentProposals = () => setAgentProposals([]);

  // ── the run ────────────────────────────────────────────────────────────────
  // One chat message = one agent-loop run. Earlier turns ride along as plain
  // text context (lib/agentChat historyMessages, as many as the Conversation
  // memory setting allows); the loop's events — streamed text deltas
  // included — fold into the message's turn (steps, answer, staged count).
  async function runAgent(goal) {
    if (agentRunning) return;
    if (!isAiConfigured()) { setShowAiSettings(true); return; }
    const notReady = notReadyMessage(agentStateRef.current.status);
    if (notReady) { agentChat.apply(agentChat.begin(goal), { type: "error", message: uiText(notReady) }); return; }
    const ctl = new AbortController();
    agentAbortRef.current = ctl;
    setAgentRunning(true);
    const cfg = aiConfig();
    const history = historyMessages(agentChat.turnsRef.current, cfg.historyTurns);   // "Conversation memory" (AI settings)
    const turnId = agentChat.begin(goal);
    const ctx = buildAgentCtx();
    try {
      await runAgentLoop({
        cfg, goal: withViewContext(goal, { sheetKey, sheetLabel: sheetKey ? tabLabel(sheetKey) : "" }), history, tools: agentToolDefs(),
        execute: (name, args) => executeAgentTool(ctx, name, args),
        onEvent: (ev) => agentChat.apply(turnId, ev),
        signal: ctl.signal,
      });
    } finally {
      agentChat.settle(turnId);
      setAgentRunning(false);
      agentAbortRef.current = null;
    }
  }
  const stopAgent = () => agentAbortRef.current?.abort();

  // ── Copy text (#471) ──────────────────────────────────────────────────────
  // A box (or the whole page) → the reader chain → reading-order lines → the
  // clipboard → the receipt. The decisions are lib/copyText's; this binds
  // them to the live page. A page whose text content is already in hand
  // copies synchronously, inside the click's activation (browsers may refuse
  // a clipboard write that isn't inside a click); a first read awaits
  // getTextContent first, and where the browser refuses the write, the
  // receipt keeps the text in a textarea.
  function textContentOf(pageObj) {
    const had = textContentsRef.current.get(pageObj);
    if (had) return had;
    const entry = { tc: null, p: null };
    entry.p = pageObj.getTextContent().then((tc) => { entry.tc = tc; return tc; });
    entry.p.catch(() => textContentsRef.current.delete(pageObj));   // a failed read is retried next time
    textContentsRef.current.set(pageObj, entry);
    return entry;
  }
  function prefetchText(key) { const pg = pageObjsRef.current.get(key); if (pg) textContentOf(pg); }
  // rect in the page's rs-viewport px; null = the whole page
  function copyTextFrom(key, rect, scope) {
    if (status !== "ready") { setCommitMsg(uiText("Sheet still loading — try again in a moment.")); return; }
    // held until the copy settles: its text, or a box read waiting its turn,
    // can outlive a switch away
    const { page: pageObj, release } = holdSheetPage(key);
    const blocked = copyUnavailable({ stitch: isStitchKey(key), hasPage: !!pageObj });
    if (blocked) { release(); setCommitMsg(blocked); return; }
    // a throw before the copy is under way lets it go at once
    try {
      const rs = renderScalesRef.current.get(key) || RENDER_SCALE;
      const vp = pageObj.getViewport({ scale: rs });
      // a scan for Copy text (copyIsScanLike): the page rule on this page's
      // text, and the page may hold an image (a vector cover sheet's few title
      // lines copy from the text layer at once); a hybrid's pictures come from
      // its index entry (copyPictureInputs), as the Read control's do (readWhat)
      const imageFrac = () => sheetStatsRef.current.get(key)?.imageFrac;
      const scanLikeOf = (tc) => copyIsScanLike(tc, vp, imageFrac());
      // OCR known off (and no read in memory): the chain starts with that
      // miss, asks no OCR reader, and an empty copy still says why
      const startMiss = copyStartMiss({ enabled: ocrEnabled(), avail: ocrAvail, hasRead: !!pageReader.lines(key) });
      const seq = renderSeqRef.current;   // a sheet switch mid-await must not post a receipt for a page you left
      const signal = copyGateRef.current.begin();   // and a newer box (or page copy) replaces this one
      // an on-device read posts an in-progress line (sticky, it ends in "…");
      // whatever ends this copy takes it down again, unless a newer message
      // has replaced it
      let busy = null;
      const clearBusy = () => { if (busy) { const b = busy; busy = null; setCommitMsgState((m) => (m === b ? { text: "" } : m)); } };
      // hybrid: the copy took copyPlan's "hybrid" chain (#489), which is never
      // called a scan, and whose unread image is a picture
      const settle = (o, tc, hybrid) => {
        clearBusy();
        if (o.kind === "aborted" || signal.aborted) return;
        if (o.kind !== "text") { setCommitMsg(outcomeMessage(o, scope, scanLikeOf(tc), hybrid)); return; }
        // after an on-device read the click's activation is usually gone and
        // the write is refused: the receipt then holds the text in its textarea
        deliverCopy(o.text, navigator.clipboard).then((ok) => setCopyReceipt(makeReceipt(o, { failed: !ok, scope, key, hybrid })));
      };
      // a box read's line: nothing while the download notice is up, then
      // "Waiting…" until its turn in the engine, then "Reading…"
      const postBusy = (text) => {
        if (!busy) signal.addEventListener("abort", clearBusy, { once: true });   // Esc, or a newer box
        busy = { text };
        setCommitMsgState(busy);
      };
      // OCR (lib/copyText): which OCR this copy may use (copyOcrRoute: none on
      // a sheet with a text layer and no placed image), then ocrCopyReaders: the page's own
      // read (in memory, else the cache; a read of it under way is waited for),
      // then, only if the page has no read, an on-device read of the box, not
      // kept; copyReaderChain puts them after the text layer, or first on a
      // scan. Copy page text on a scan is the page read itself
      // (readSheet: kept, indexed, shown on the Read control with its Cancel,
      // and it goes on if this copy is replaced).
      // the page's read: in memory; else, with OCR on, the read under way
      // (waited for) or the cached one
      const pageLinesOrLookup = () => {
        if (!ocrEnabled()) return null;
        if (pageReader.status(key)?.state === "reading") return readSheet(key).then((r) => (r.ok ? r.lines : null));
        return lookupSheet(key).then((h) => h?.lines ?? null);
      };
      // why OCR can't run here, if it can't
      const ocrOff = () => (!ocrEnabled() ? "disabled" : ocrAvail === "disabled" || ocrAvail === "uninstalled" ? ocrAvail : null);
      // a one-off read of a box (not kept)
      const readBoxOf = (r, sig) => {
        const off = ocrOff();
        if (off) return Promise.resolve({ ok: false, status: off });
        return pageReader.readBox({
          file: parseSheetKey(key).file, rs, rect: r, getPage: async () => pageObj, signal: sig,
          onPhase: (ph) => { if (!sig?.aborted) postBusy(ph === "waiting" ? "Waiting for another read…" : "Reading that box with the on-device text reader (OCR)…"); },
        });
      };
      const ocrReadersFor = (tc) => {
        const route = copyOcrRoute({ scope, scanLike: scanLikeOf(tc), imageFrac: imageFrac(), ocrOff: !!startMiss });
        if (route === "none") return [];
        return ocrCopyReaders({
          // on a hybrid, none (copyText textChainPageLines): its read covers
          // only the pictures, and this chain's box is off them or a sliver
          pageLines: textChainPageLines(planIndexRef.current.get(key), () => pageReader.lines(key) ?? pageLinesOrLookup()),
          readBox: (r, sig) => {
            const off = ocrOff();
            if (off) return Promise.resolve({ ok: false, status: off });
            if (route === "page") return readSheet(key).then((res) => (res.ok ? { ok: true, lines: res.lines } : { ok: false, status: res.status, message: res.message }));
            // the whole page reaches OCR only on a scan, which is the page
            // route above; a page with a text layer never gets a one-off read
            if (!r) return Promise.resolve({ ok: true, lines: [] });
            return readBoxOf(r, sig);
          },
        });
      };
      const read = (tc) => {
        // Which chain (lib/copyText copyPlan, #489): a box over a hybrid's
        // picture is ONE combining reader (the text layer, and OCR for the
        // picture: the page's read in memory, else the cached read or the one
        // under way, else a read of each box ∩ picture). Otherwise the reader
        // chain, asked in order; the first with any token answers: the text
        // layer, then OCR — or, on a scan, OCR, then the text layer.
        const failed = () => { clearBusy(); setCommitMsg(uiText("Couldn't read that region.")); };
        const scan = scanLikeOf(tc);
        const plan = copyPlan({ scope, rect, scan, ...copyPictureInputs(planIndexRef.current.get(key)), rs, pageRead: !!pageReader.lines(key) });
        const hybrid = plan.kind === "hybrid";
        let out;
        try {
          const readers = hybrid
            ? [hybridCopyReader({ tc, viewport: vp, ocrRects: plan.ocrRects, startMiss, pageLines: () => pageReader.lines(key), lookup: () => Promise.resolve(pageLinesOrLookup()), readBox: readBoxOf })]
            : copyReaderChain({ scanLike: scan, textLayer: textLayerReader(tc, vp), ocr: ocrReadersFor(tc) });
          out = readCopyText(readers, rect, { signal }, [], startMiss);
        }
        catch { failed(); return; }
        if (out instanceof Promise) return out.then((o) => { if (seq === renderSeqRef.current) settle(o, tc, hybrid); else clearBusy(); }).catch(failed);
        settle(out, tc, hybrid);
      };
      const e = textContentOf(pageObj);
      const done = e.tc
        ? read(e.tc)
        : e.p.then((tc) => { if (seq === renderSeqRef.current && !signal.aborted) return read(tc); }).catch(() => setCommitMsg(uiText("Couldn't read that sheet's text.")));
      Promise.resolve(done).finally(release);
    } catch (e) { release(); throw e; }
  }
  // two stage-px corners → the box on one sheet
  function copyTextFromBox(a, b) {
    const pa = panelAt(a[0]);
    const box = boxOnPanel(a, b, pa, panelAt(b[0]));
    if ("error" in box) { setCommitMsg(box.error === "cross" ? "Draw the box within a single sheet." : "Drag a larger box around the text."); return; }
    copyTextFrom(pa.key, box.rect, "box");
  }
  // arming drops the shape selection (a copy box never edits a shape)
  function armCopyText() {
    setTool((t) => (t === "textcopy" ? "select" : "textcopy"));
    if (tool !== "textcopy") { selectShape(null); setTextAnchor(null); }
  }

  // ── Import from schedule ────────────────────────────────────────────────────
  // Read the marqueed box and open the approval dialog. Nothing leaves the
  // device. The page's text inside the box is read first: it becomes the
  // sheet graph's spans (pageSpans, the MCP's builder), cropped to the box,
  // and the sheet graph's finish reader reads them (scheduleRead
  // .readScheduleSpans, loaded on first use). scheduleRoute.ts decides what
  // the box becomes — rows, a refusal, the re-drag hint, or, when its text
  // holds no table and at most a few runs (a raster schedule, or an empty
  // box), a read with the on-device OCR reader (#470): the box is read as a
  // page read is, tiled at OCR's DPI (lib/ocr/boxRead.ts, #484; a box past
  // the tile cap is refused before the engine starts), and its words go to
  // the same finish reader
  // (scheduleOcrRead.readBoxOnDevice). That read asks for the engine's
  // download the first time (the notice), shows its status line with Cancel
  // in the footer, and is cancelled by Cancel, Esc, a sheet switch, or the
  // gallery, guide, report or revisions opening. One box at a time: a box drawn meanwhile is
  // told so.
  // Corners a,b are stage px (raw cursor, snapping exempted at pointer-down).
  async function importScheduleFromRect(a, b) {
    // The lock, taken before any await so two quick boxes can't both read.
    if (ocrReadRef.current) { setCommitMsg(OCR_BUSY_MESSAGE); return; }
    const mine = { ctl: new AbortController(), ocr: false };
    ocrReadRef.current = mine;
    const seq = renderSeqRef.current;                 // a sheet switch mid-await must not pop a dialog for a page you left
    const isCurrent = () => ocrReadRef.current === mine && !mine.ctl.signal.aborted && seq === renderSeqRef.current;
    let release = () => { };
    try {
      if (status !== "ready") { setCommitMsg(uiText("Sheet still loading — try again in a moment.")); return; }
      const panel = panelAt(a[0]);
      if (panelAt(b[0]).key !== panel.key) { setCommitMsg(uiText("Draw the box within a single sheet, around its schedule table.")); return; }
      const held = holdSheetPage(panel.key);
      release = held.release;
      const pageObj = held.page;
      if (!pageObj) { setCommitMsg(uiText("Open a sheet first.")); return; }
      const rs = renderScalesRef.current.get(panel.key) || RENDER_SCALE;
      // rect in image (rs-viewport) px, clamped to the panel as
      // captureRegionMarkup does; the same rect is cropped and rendered
      const cl = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
      const rect = {
        x0: cl(Math.min(a[0], b[0]) - panel.xOffset, 0, panel.img.w), y0: cl(Math.min(a[1], b[1]), 0, panel.img.h),
        x1: cl(Math.max(a[0], b[0]) - panel.xOffset, 0, panel.img.w), y1: cl(Math.max(a[1], b[1]), 0, panel.img.h),
      };
      if (!(rect.x1 - rect.x0 >= 4 && rect.y1 - rect.y0 >= 4)) { setCommitMsg(EMPTY_BOX_MESSAGE); return; }
      let spans, pageHasText, readScheduleSpans, boxTerms;
      try {
        const vp = pageObj.getViewport({ scale: rs });
        const tc = await pageObj.getTextContent();
        ({ readScheduleSpans } = await import("../lib/scheduleRead"));   // the reader chunk loads on first use
        if (!isCurrent()) return;
        const page = pageSpans(tc.items, vp.transform, rs);
        pageHasText = page.length > 0;   // the box's own source (pageSpans drops blank runs), so "box empty, page not" is consistent
        spans = graphSpans(spansInRect(page, rect));
        // the box's terms as the sheet's plan-search entry counts them (the
        // same runs, pageTextIndex's reader): the dialog's "on the plans?"
        // check (#498) subtracts them from the schedule's own sheet
        boxTerms = buildSheetIndex("box", extractRegionText(tc, vp, rect)).terms;
      } catch { if (isCurrent()) setCommitMsg(uiText("Couldn't read that region.")); return; }
      const box = { textRuns: countTextRuns(spans), pageHasText };
      const route = routeScheduleRead(readScheduleSpans(spans), box);
      if (route.kind === "rows") { setImportRead({ rows: route.rows, skipped: route.skipped ?? [], sourceKey: panel.key, boxTerms }); return; }
      if (route.kind === "message") { setCommitMsg(route.text); return; }
      // On-device: the status line replaces the footer message, unless that
      // is the stale-tab lockout or another job's in-progress "…" line.
      mine.ocr = true;
      setCommitMsgState((m) => (m.text === STALE_TAB_MESSAGE || (m.text || "").endsWith("…") ? m : { text: "" }));
      setOcrRead("starting");
      const result = await readBoxOnDevice({
        session: ocrSession,
        readWords: boxReadWords(pageObj, rs, rect, isCurrent),
        tooLarge: () => boxTooLarge(pageObj, rs, rect),
        onProgress: (p) => { if (isCurrent()) setOcrReadProgress(p); },
        read: (ocrSpans) => readScheduleSpans(ocrSpans, { ocr: true }),   // the OCR words' blank-band section reset
        isCurrent,
        whenIdle: () => getOcrClient().whenIdle(),   // a page read or copy read (#471) under way goes first
        onWaiting: () => { if (isCurrent()) setOcrRead("waiting"); },
        onReading: () => { if (isCurrent()) setOcrRead("reading"); },
        signal: mine.ctl.signal,
        box,
      });
      if (!isCurrent()) return;
      if (result.kind === "rows") setImportRead({ rows: result.rows, skipped: result.skipped ?? [], sourceKey: panel.key });
      else if (result.kind === "message") setCommitMsg(result.text);
    } catch {
      if (isCurrent()) setCommitMsg(uiText("Couldn't read that region."));
    } finally {
      release();
      releaseImportRead(mine);
    }
  }

  // ── image markup (#…) — two entry points, one record type ────────────────
  // Marquee screenshot: a,b are the two marquee corners in stage px. Render the
  // boxed region of the plan offscreen (shift its top-left to (0,0), downscaled
  // to at most MARKUP_IMG_MAX px a side) and store it as
  // a floating `image` markup anchored at the box center. Guards mirror
  // importScheduleFromRect: sheet ready, both corners in one panel, a real source
  // page (refuse a stitched composite), a non-degenerate box.
  async function captureRegionMarkup(a, b, referenceOnly = false) {
    if (status !== "ready") { setCommitMsg(uiText("Sheet still loading — try again in a moment.")); return; }
    const panel = panelAt(a[0]);
    if (panelAt(b[0]).key !== panel.key) { setCommitMsg(uiText("Draw the box within a single sheet.")); return; }
    return withSheetPage(panel.key, async (pageObj) => {
      if (!pageObj) { setCommitMsg(uiText("Capture a region on a single sheet (not a stitched view).")); return; }
      const rs = renderScalesRef.current.get(panel.key) || RENDER_SCALE;
      // rect in image (rs-viewport) px, clamped to the panel bounds so an over-drag
      // past the sheet edge never parks the geometry off-sheet
      const cl = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
      const x0 = cl(Math.min(a[0], b[0]) - panel.xOffset, 0, panel.img.w);
      const x1 = cl(Math.max(a[0], b[0]) - panel.xOffset, 0, panel.img.w);
      const y0 = cl(Math.min(a[1], b[1]), 0, panel.img.h);
      const y1 = cl(Math.max(a[1], b[1]), 0, panel.img.h);
      const regW = x1 - x0, regH = y1 - y0;
      if (!(regW >= 4 && regH >= 4)) { setCommitMsg(uiText("Drag a larger box to capture.")); return; }
      // downscale to MARKUP_IMG_MAX (1600px) on the longest side
      const factor = Math.min(1, MARKUP_IMG_MAX / regW, MARKUP_IMG_MAX / regH);
      const bw = Math.max(1, Math.round(regW * factor)), bh = Math.max(1, Math.round(regH * factor));
      let src;
      try {
        const vp = pageObj.getViewport({ scale: rs * factor });
        const canvas = document.createElement("canvas");
        canvas.width = bw; canvas.height = bh;
        await pageObj.render({
          canvasContext: canvas.getContext("2d"),
          viewport: vp,
          transform: [1, 0, 0, 1, -x0 * factor, -y0 * factor],
        }).promise;
        src = canvas.toDataURL("image/png");
      } catch { setCommitMsg(uiText("Couldn't capture that region.")); return; }
      const { at, w, aspect } = captureRectToImageGeom({ x0, y0, x1, y1 }, panel.img.w, panel.img.h);
      if (!(w > 0)) return;
      // FROZEN origin label. sheetBaseLabel resolves a detected sheet number only for
      // the ACTIVE file (or an already gallery-scanned sheet); on the non-active panel
      // of a multi-FILE side-by-side group it would fall back to the file base. Since
      // that panel is rendered here anyway, scan its title block NOW (the same
      // extractSheetNumber the active-file scan at ~:2056 uses) so the frozen number is
      // real — but only when it isn't already known, and only as a best-effort upgrade:
      // a null result (unusual title block) keeps the file-base fallback, never worse.
      let srcLabel = sheetBaseLabel(panel.key);
      const pk = parseSheetKey(panel.key);
      const labelKnown = isStitchKey(panel.key) || !!galleryLabels[panel.key] || (pk.file === active && !!pageLabels[pk.page]);
      if (!labelKnown) {
        try {
          const lbl = extractSheetNumber(await pageObj.getTextContent(), pageObj.getViewport({ scale: RENDER_SCALE }));
          if (lbl) srcLabel = lbl;
        } catch { /* title block unreadable — keep the file-base fallback */ }
      }
      // Capture-only provenance fields (uploads have no source, so addImageFromFile
      // omits them): src_sheet_id is the ORIGIN sheet (sheet_id tracks where the
      // image currently lives and moves on a cross-sheet place — see imageProvenance
      // below). src_rect reuses the ALREADY-CLAMPED x0..y1 above, NOT the raw marquee
      // corners a/b (they carry xOffset and are unclamped) and NOT bw/bh (the 1600px
      // capture raster size) — normalizing by those would silently drift the traced
      // region off the real source box. src_label is the FROZEN origin sheet name,
      // resolved just above (sheetBaseLabel, upgraded via a title-block scan when the
      // number isn't cached for a non-active side-by-side file): both the canvas caption
      // and the marked-set PDF read this stored string, so they can never diverge on
      // runtime label state (which sheetBaseLabel derives only for the active file).
      addImageMarkup({
        at, w, aspect, src, source: "capture", labelBase: srcLabel,
        ...(referenceOnly ? { reference_only: true } : {}),
        src_sheet_id: panel.key,
        src_rect: [[x0 / panel.img.w, y0 / panel.img.h], [x1 / panel.img.w, y1 / panel.img.h]],
        src_label: srcLabel,
        source_label: false,
      }, panel.key);
    });
  }

  // The aggregate-budget gate shared by both entry points: refuse a new image when
  // the project's total image-markup bytes would exceed the cap (N capped images
  // otherwise defeat the per-image cap and push the annotations blob past quota).
  // This is a SOFT guard read from the render-closure `markups`; two back-to-back
  // async adds could momentarily race it, but the per-image 1600px cap already
  // bounds each one, so the worst case is a single image slipping just over the
  // budget — not a correctness or safety issue, and the quota surfacing in the
  // autosave catch is the real backstop.
  function addImageMarkup(m, key) {
    const used = markups.reduce((n, x) => n + (x.type === "image" && typeof x.src === "string" ? x.src.length : 0), 0);
    if (used + m.src.length > MAX_IMAGE_MARKUP_BYTES) { setCommitMsg(uiText("Too many/large images on this project — delete some before adding more.")); return; }
    // Auto-name (stored in `text`, which the panel renders and the ✎ edits): the
    // sheet base + a per-sheet sequence ("AF101-01"). Uploads carry the file name.
    // Collisions after a delete are tolerated (a simple count, not a high-water
    // counter). Stamp the declared author (git-style; absent ⇒ omitted).
    // labelBase lets a caller pin the base to a resolved label (a capture passes its
    // frozen src_label) so the row NAME and the source CAPTION agree even in the
    // non-active-panel case sheetBaseLabel can't resolve here; absent ⇒ sheetBaseLabel.
    const { name: given, labelBase, ...rest } = m;
    const seq = markups.filter((x) => x.type === "image" && x.sheet_id === key).length + 1;
    const base = (typeof labelBase === "string" && labelBase.trim()) ? labelBase : sheetBaseLabel(key);
    const text = (typeof given === "string" && given.trim()) || `${base}-${String(seq).padStart(2, "0")}`;
    const by = authorName();
    if (rest.reference_only) {
      const pinId = uid("mk");
      setMarkups(ms => [...ms, { id: pinId, type: "image", sheet_id: key, rfi_id: "", condition_id: "", ...rest, text, created_at: new Date().toISOString() }]);
      setPinSelectedId(pinId); setPinsOpen(true);
      setCommitMsg(uiText("Pinned — switch sheets and keep this reference beside your takeoff."));
      return;
    }
    addMarkup({ type: "image", ...rest, text, ...(by ? { author: by } : {}) }, key);
    setCommitMsg(uiText("Image placed."));
  }

  // Lazy, memory-only panel thumbnail: decode the src ONCE, downscale to a ~48px
  // JPEG, cache by markup id. Returns null while building (the row shows a
  // placeholder) or on a bad src; the build's setImgThumbs re-renders the row.
  function ensureThumb(m) {
    if (imgThumbs[m.id]) return imgThumbs[m.id];
    if (!thumbBuildingRef.current.has(m.id) && m.src && pickEmbedFormat(m.src)) {
      thumbBuildingRef.current.add(m.id);
      const img = new Image();
      img.onload = () => {
        const s = 48 / Math.max(img.width, img.height, 1);
        const w = Math.max(1, Math.round(img.width * s)), h = Math.max(1, Math.round(img.height * s));
        const c = document.createElement("canvas"); c.width = w; c.height = h;
        c.getContext("2d").drawImage(img, 0, 0, w, h);
        setImgThumbs((t) => ({ ...t, [m.id]: c.toDataURL("image/jpeg", 0.7) }));
      };
      img.onerror = () => { thumbBuildingRef.current.delete(m.id); };
      img.src = m.src;
    }
    return null;
  }
  // Provenance one-liner for the panel row's title tooltip (Kevin: not shown
  // prominently). Degrades: drops the author when none is declared.
  function imageProvenance(m) {
    const verb = m.source === "upload" ? "Uploaded" : "Captured from";
    // src_sheet_id is the ORIGIN sheet; sheet_id is wherever the image lives NOW
    // and is rewritten on a cross-sheet place, so after a move reading sheet_id
    // here would misreport where it was captured. Fall back to sheet_id for
    // uploads (no src_sheet_id) and legacy records captured before this field.
    const where = m.source === "upload" ? "" : ` ${sheetBaseLabel(m.src_sheet_id || m.sheet_id)}`;
    const when = m.created_at ? ` · ${String(m.created_at).slice(0, 10)}` : "";
    const who = m.author ? ` · ${m.author}` : "";
    return `${verb}${where}${when}${who}`;
  }

  // Upload: decode a raster file (EXIF-oriented), downscale to 1600px longest side,
  // ALWAYS re-encode through a canvas (pixels only — SSRF/script-safe; guarantees a
  // PNG/JPEG data URL), and drop it centered in the current view of the focus sheet.
  async function addImageFromFile(file) {
    // don't trust accept="image/*": accept ONLY PNG/JPEG — matching the UI copy,
    // the docs, and pickEmbedFormat (the marked-set gate), and keeping the decode
    // surface small. By MIME OR by extension, because some platforms/drag-drop hand
    // over an empty file.type for a good PNG/JPEG (the StampPanel import checks the
    // extension for the same reason). Everything else — webp/gif/bmp, and SVG — is
    // refused here (uploads are still re-encoded to PNG/JPEG regardless).
    const name = file?.name || "";
    const isPngJpeg = !!file && (/^image\/(png|jpeg)$/.test(file.type) || /\.(png|jpe?g)$/i.test(name));
    if (!isPngJpeg) {
      setCommitMsg(uiText("Pick a PNG or JPEG image.")); return;
    }
    // cheap pre-decode gate: bail on a huge FILE before createImageBitmap allocates
    // anything (a small-file / huge-dims pixel bomb is caught by the area guard below).
    if (file.size > MARKUP_UPLOAD_MAX_BYTES) { setCommitMsg(uiText(`That image file is too large (max ${Math.round(MARKUP_UPLOAD_MAX_BYTES / (1024 * 1024))} MB).`)); return; }
    try {
      // sniff intrinsic dimensions via an <img> FIRST — reading naturalWidth/Height
      // only needs the header, so a pixel bomb (small file, enormous declared dims)
      // is refused BEFORE createImageBitmap forces a full-size RGBA decode that could
      // OOM the tab. createImageBitmap then only runs on an already-bounded image.
      const url = URL.createObjectURL(file);
      try {
        const dims = await new Promise((res, rej) => {
          const im = new Image();
          im.onload = () => res({ w: im.naturalWidth, h: im.naturalHeight });
          im.onerror = () => rej(new Error("decode"));
          im.src = url;
        });
        if (dims.w * dims.h > MARKUP_DECODE_MAX_AREA) { setCommitMsg(uiText("That image is too large (too many pixels).")); return; }
      } finally { URL.revokeObjectURL(url); }
      const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
      // defense-in-depth: the oriented bitmap's own area, in case the sniff and the
      // decoder disagree (a markup-appropriate cap, NOT the 241M render-canvas cap).
      if (bmp.width * bmp.height > MARKUP_DECODE_MAX_AREA) { bmp.close?.(); setCommitMsg(uiText("That image is too large (too many pixels).")); return; }
      const f = Math.min(1, MARKUP_IMG_MAX / Math.max(bmp.width, bmp.height));
      const bw = Math.max(1, Math.round(bmp.width * f)), bh = Math.max(1, Math.round(bmp.height * f));
      const canvas = document.createElement("canvas");
      canvas.width = bw; canvas.height = bh;
      canvas.getContext("2d").drawImage(bmp, 0, 0, bw, bh);
      bmp.close?.();
      const isJpeg = file.type === "image/jpeg";
      const src = canvas.toDataURL(isJpeg ? "image/jpeg" : "image/png", isJpeg ? 0.85 : undefined);
      const aspect = aspectFromDims(bw, bh);
      // center of the current view, normalized to the focus panel (falls back to
      // the panel center if the view geometry isn't available)
      const cl01 = (v) => Math.min(1, Math.max(0, v));
      let at = [0.5, 0.5];
      const r = containerRef.current?.getBoundingClientRect();
      if (r) {
        const c = toImage(r.left + r.width / 2, r.top + r.height / 2);
        at = [cl01((c[0] - focusPanel.xOffset) / focusPanel.img.w), cl01(c[1] / focusPanel.img.h)];
      }
      addImageMarkup({ at, w: 0.2, aspect, src, source: "upload", name: (file?.name || "").replace(/\.[^.]+$/, "") }, focusPanel.key);
    } catch { setCommitMsg(uiText("Couldn't read that image.")); }
  }

  // Approved rows → conditions. Category drives hatch/waste, the palette the color (rowToSeed);
  // product spec (mfr/style/color/size) rides a plain `spec` field — NOT custom
  // columns (would hijack a user column and pollute its grouping vocabulary) and
  // NOT materials[] (those are coverage buy-list items, no coverage rate here).
  // Existing codes and possible older flat spellings are held by the same
  // rules as the dialog; existing condition IDs and shapes stay untouched.
  function createFromSchedule(selected) {
    const existing = new Set(conditions.map((c) => normalizeTag(c.finish_tag)));
    const made = [];
    let idx = conditions.length;
    for (const row of newScheduleRows(selected, existing)) {
      const seed = rowToSeed(row, idx++, PALETTE);
      const hasSpec = Object.values(seed.spec).some(Boolean);
      made.push({
        id: uid("cnd"), created_at: nowIso(), finish_tag: seed.finish_tag, color: seed.color, fill: seed.color,
        hatch: seed.hatch, multiplier: 1, waste_pct: seed.waste_pct, materials: [],
        ...(hasSpec ? { spec: seed.spec } : {}),
      });
    }
    setImportRead(null);
    if (!made.length) { setCommitMsg(uiText("Those finishes already exist or need review against an existing condition.")); return; }
    setConditions((cs) => [...cs, ...made]);
    activateCondition(made[0].id, { reassign: false });
    setCommitMsg(uiText(`Created ${made.length} condition${made.length === 1 ? "" : "s"} from the schedule.`));
  }
  // every condition-editor save lands here — a bare updated_at is the whole
  // provenance story for conditions (no origin machinery; they're all manual)
  // By-id core + active-based convenience: one save chokepoint. Voice combo
  // intents ("cpt one waste seven") patch a condition activated in the SAME
  // handler, before re-render — the active-based form would hit the old active.
  const updateCondById = (id, patch) => setConditions((cs) => cs.map((c) => (c.id === id ? { ...c, ...patch, updated_at: nowIso() } : c)));
  const updateCond = (patch) => updateCondById(activeCond, patch);
  // The project's markups are copied from Company setup the first time its
  // estimate opens, then belong to the project: changing the defaults later
  // never re-prices a bid already worked up.
  const openEstimate = () => {
    if (!estimateSettings) setEstimateSettings(sanitizeEstimateSettings(loadEstimatingDefaults()));
    setShowEstimate(true);
  };

  // delete a condition entirely (and its takeoffs); pick a new active one
  function deleteCondition(id) {
    const c = condById[id];
    if (!c) return;
    const owned = shapes.filter((s) => s.condition_id === id);
    if (owned.length && !window.confirm(uiText(`Delete ${c.finish_tag} and its ${owned.length} takeoff${owned.length === 1 ? "" : "s"}? This can't be undone.`))) return;
    // Lineage first, removal second: deleting a family parent must not orphan its twins. The
    // eldest survivor is promoted to root (its rows are already materialized — propagate-on-write
    // guarantees that) and the rest re-point at it, origin_ids remapped.
    const next = promoteOnDelete(conditions, new Set([id])).filter((x) => x.id !== id);
    // cascade delete of the condition's OWNED shapes — counted centrally by the
    // command, but record:false keeps it off the undo stack: the confirm just
    // said "can't be undone", and ⌘Z restoring shapes without their condition
    // would resurrect orphans
    if (owned.length) dispatchShape({ type: "delete", ids: owned.map((s) => s.id), reason: "condition-delete" }, { record: false });
    setConditions(next);
    // Annotations are NOT owned by the condition the way shapes are — a cloud
    // saying "verify substrate here" outlives the takeoff line it was drawn
    // against. Clear the dangling pointer and keep the markup, same rule
    // deleteRfi follows: leave no orphan link, but never delete someone's note
    // as a side effect of deleting a quantity.
    setMarkups((ms) => ms.map((m) => (m.condition_id === id ? { ...m, condition_id: "" } : m)));
    unpinFromPalette(id);   // a deleted condition can't stay pinned in the palette
    if (activeCond === id) setActiveCond(next[0]?.id || "");
    // no bulk-selection pruning needed here: the panel derives liveness from
    // the conditions prop (liveChecked = conditions ∩ checked), so a deleted
    // id left in its checked set is inert by construction
    setCommitMsg(uiText(`Deleted ${c.finish_tag}${owned.length ? ` and ${owned.length} takeoff${owned.length === 1 ? "" : "s"}` : ""}.`));
  }

  // custom columns: project-scoped vocabulary editing + per-condition assignment.
  // Snapshot-compare asymmetry, accepted: the diff (COND_FIELDS quantities) is
  // blind to attrs/definition changes, yet Load restores them — an assignments-
  // only change diffs as "unchanged". Known, not a bug.
  const assignAttr = (colId, v) => {
    // hydrate sanitizes attrs (sanitizeConditionAttrs), so spreading is safe;
    // an absent attrs spreads to {}
    const attrs = { ...aCond?.attrs };
    if (v) attrs[colId] = v; else delete attrs[colId];   // Unassigned = key absent, never ""
    updateCond({ attrs });
  };
  const addColumn = () => setConditionColumns((cols) => [...cols, { id: uid("col"), name: "", values: [] }]);
  const renameColumn = (colId, name) => setConditionColumns((cols) => cols.map((cc) => (cc.id === colId ? { ...cc, name } : cc)));   // id stays — assignments follow automatically
  const addColumnValue = (colId, v) => setConditionColumns((cols) => cols.map((cc) => (cc.id === colId && !cc.values.includes(v) ? { ...cc, values: [...cc.values, v] } : cc)));
  const removeColumnValue = (colId, v) => setConditionColumns((cols) => cols.map((cc) => (cc.id === colId ? { ...cc, values: cc.values.filter((x) => x !== v) } : cc)));   // assigned conditions keep the string — selects show "(removed)"
  const renameColumnVal = (colId, oldV) => {
    const newV = (window.prompt(uiText("Rename value:"), oldV) || "").trim();
    if (!newV || newV === oldV) return;
    // rename into an existing value = merge (values are unique — they key the chips and the select options)
    setConditionColumns((cols) => cols.map((cc) => (cc.id === colId ? { ...cc, values: cc.values.includes(newV) ? cc.values.filter((x) => x !== oldV) : cc.values.map((x) => (x === oldV ? newV : x)) } : cc)));
    setConditions((cs) => renameColumnValue(cs, colId, oldV, newV));   // assignments follow the vocabulary
  };
  const deleteColumn = (colId) => {
    const cc = conditionColumns.find((c) => c.id === colId);
    if (!window.confirm(uiText(`Delete column "${columnLabel(cc)}" for the whole project? Conditions keep their values but they're no longer shown or exported.`))) return;
    setConditionColumns((cols) => cols.filter((c) => c.id !== colId));   // orphaned attrs[colId] stay behind — harmless, nothing iterates raw attrs
  };

  // shape-label vocabulary (#110): a flat project-level list; each shape carries
  // at most one, on shape.label. Mirrors the column-value family above.
  const addLabel = (v) => setShapeLabels((ls) => (ls.includes(v) ? ls : [...ls, v]));
  const removeLabel = (v) => setShapeLabels((ls) => ls.filter((x) => x !== v));   // labeled shapes keep the string — it falls into an ad-hoc report group, nothing disappears from totals
  const renameLabel = (oldV) => {
    const newV = (window.prompt(uiText("Rename label:"), oldV) || "").trim();
    if (!newV || newV === oldV) return;
    // rename into an existing value = merge (labels are unique — they key the chips and the report's group headers)
    setShapeLabels((ls) => (ls.includes(newV) ? ls.filter((x) => x !== oldV) : ls.map((x) => (x === oldV ? newV : x))));
    setShapes((sh) => renameShapeLabel(sh, oldV, newV));   // assignments follow the vocabulary
  };

  // ── the family seam (lib/variants.ts) ─────────────────────────────────────
  // Every material write on a condition that belongs to a family goes through one of these, so
  // inheritance can never be half-applied. Two directions, and they are opposites:
  //   editing a FAMILY PARENT's row → the same patch lands on every twin still following it
  //   editing a TWIN's row          → that row goes local and stops following, for good
  const isFamilyParent = (cs, id) => cs.some((c) => c.variant_of === id);
  // supporting-materials editing (operates on the active condition)
  const addMaterial = () => setConditions((cs) => {
    const row = { id: uid("mat"), name: "", per: 0, basis: "area", unit: "", round: true };
    const next = cs.map((c) => (c.id === activeCond
      ? { ...c, materials: [...(c.materials || []), row], updated_at: nowIso() } : c));
    // a row added to the family reaches every area; a row added ON a twin is that twin's own
    // (minted with no origin_id, so nothing upstream ever touches it)
    return isFamilyParent(cs, activeCond) ? propagateRowAdd(next, activeCond, row, uid) : next;
  });
  // a saved assembly (lib/assemblies.js) → new rows on the active condition, through the same
  // family seam as one added row; items the condition already names are skipped
  const applyAssembly = (assembly) => setConditions((cs) => {
    const cur = cs.find((c) => c.id === activeCond);
    const { rows } = assemblyRows(assembly, uid, cur?.materials);
    if (!cur || !rows.length) return cs;
    let next = cs.map((c) => (c.id === activeCond ? { ...c, materials: [...(c.materials || []), ...rows], updated_at: nowIso() } : c));
    if (isFamilyParent(cs, activeCond)) for (const row of rows) next = propagateRowAdd(next, activeCond, row, uid);
    return next;
  });
  const updateMaterial = (mid, patch) => setConditions((cs) => {
    const cur = cs.find((c) => c.id === activeCond);
    // NAME edits re-classify a geometry-less line's kind
    const next = cs.map((c) => (c.id === activeCond ? {
      ...c, updated_at: nowIso(),
      materials: (c.materials || []).map((m) => (m.id === mid ? matEditPatch(m, patch) : m)),
    } : c));
    if (cur?.variant_of) return next.map((c) => (c.id === activeCond ? markRowLocal(c, mid) : c));
    if (!isFamilyParent(cs, activeCond)) return next;
    const row = (next.find((c) => c.id === activeCond)?.materials || []).find((m) => m.id === mid);
    return row ? propagateRowPatch(next, activeCond, mid, row) : next;
  });
  // Removing a row: on a twin it leaves a tombstone (so the panel can show it, and so a later
  // family edit can't bring it back); on a parent it clears the twins' following copies but
  // never a row a twin has taken over.
  const removeMaterial = (mid) => setConditions((cs) => {
    const cur = cs.find((c) => c.id === activeCond);
    if (cur?.variant_of) return cs.map((c) => (c.id === activeCond ? { ...dropRowLocal(c, mid), updated_at: nowIso() } : c));
    const next = cs.map((c) => (c.id === activeCond
      ? { ...c, materials: (c.materials || []).filter((m) => m.id !== mid), updated_at: nowIso() } : c));
    return isFamilyParent(cs, activeCond) ? propagateRowRemove(next, activeCond, mid) : next;
  });
  // The per-row undo of an override: this row follows the family again.
  const followFamilyRow = (mid) => setConditions((cs) => {
    const row = (cs.find((c) => c.id === activeCond)?.materials || []).find((m) => m.id === mid);
    return row?.origin_id ? followFamily(cs, activeCond, row.origin_id, uid) : cs;
  });
  // A tombstoned row has no row left to carry the id, so the panel restores it by origin.
  const restoreDroppedRow = (originId) => setConditions((cs) => followFamily(cs, activeCond, originId, uid));
  // Twin the active condition: same finish somewhere else, its own materials, still following
  // this one. The label is REQUIRED and becomes the tag suffix — every export and every MCP tool
  // resolves a condition by tag, so two conditions sharing one make the second unreachable and
  // collapse on a takeoff re-import.
  const duplicateCondition = (id, label) => {
    const src = conditions.find((c) => c.id === id);
    const lab = String(label || "").trim();
    if (!src || !lab) return null;
    const tag = variantTag(src.finish_tag, lab);
    if (conditions.some((c) => normalizeTag(c.finish_tag) === normalizeTag(tag))) {
      setCommitMsg(uiText(`A condition is already called ${tag} — pick another label.`));
      return null;
    }
    const { twin, parentPatch } = mintTwin(src, {
      label: lab, tag, mintId: uid, nowIso,
      // keep the family's colour, advance only the hatch: variants of one finish should read as
      // related on the sheet, not as unrelated scopes
      nextHatch: HATCHES[1 + ((conditions.length + 1) % (HATCHES.length - 1))].id,
    });
    agentStateRef.current = { ...agentStateRef.current, conditions: [...agentStateRef.current.conditions, twin] };
    setConditions((cs) => [...cs.map((c) => (c.id === src.id && parentPatch ? { ...c, ...parentPatch } : c)), twin]);
    activateCondition(twin.id, { reassign: false });
    setCommitMsg(uiText(`Added ${twin.finish_tag} — its materials follow ${src.finish_tag} until you change them here.`));
    return twin;
  };
  // Cut a twin loose: every following row freezes where it stands. It KEEPS its family_id, so it
  // still groups and subtotals with its siblings — only the inheritance ends.
  const splitCondition = (id) => {
    const c = conditions.find((x) => x.id === id);
    if (!c?.variant_of) return;
    const par = conditions.find((x) => x.id === c.variant_of);
    const n = (c.materials || []).filter((r) => r.inherited).length;
    if (!window.confirm(uiText(`Split ${c.finish_tag} out of its family?\n\n${n} row${n === 1 ? "" : "s"} freeze at ${n === 1 ? "its" : "their"} current values, and edits to ${par?.finish_tag || "the original"} stop reaching it.\nIt keeps its name and still subtotals with the family.`))) return;
    setConditions((cs) => splitFromFamily(cs, id));
    setCommitMsg(uiText(`${c.finish_tag} no longer follows ${par?.finish_tag || "its family"}.`));
  };
  // Height/Thickness are LIVE parameters: changing them re-flows
  // every dependent shape on this condition — wall SF tracks the tile height.
  const setCondParam = (field, raw) => {
    const v = raw === "" ? null : Math.max(0, parseFloat(raw) || 0);
    updateCond({ [field]: v });
    setShapes((ss) => ss.map((s) => {
      // height: existing walls KEEP their drawn height (the condition H only
      // seeds new traces — Michael: 4-ft wainscot stays 4 ft when the next
      // wall goes full height). Thickness, rise and drop (#441) re-flow
      // linears live: they are the condition's defaults for its runs, and a
      // run that carries its own rise/drop keeps it (computeShapeMetrics).
      if (s.condition_id !== activeCond) return s;
      if (!((field === "thickness_in" || field === "rise_ft" || field === "drop_ft") && s.measure_role === "linear")) return s;
      const sp = panelByKey(s.sheet_id);
      const u = uppFor(s.sheet_id) || 0;
      return { ...s, computed: computeShapeMetrics(s, sp.img, u, { ...condById[s.condition_id], [field]: v }) };
    }));
  };
  // "Undo last shape" (toolbar/⌫) is NOT ⌘Z: it stays what it always was — a
  // DELETE of the newest shape on the focused sheets (a decision, so it still
  // counts toward the deletion tally, now via the command's central tally).
  // It records on the undo stack like any delete, so ⌘Z can resurrect it.
  function undoLast() {
    const mine = shapes.filter((x) => panelKeySet.has(x.sheet_id));
    if (!mine.length) return;
    dispatchShape({ type: "delete", ids: [mine[mine.length - 1].id], reason: "undo-last" });
  }

  const condById = Object.fromEntries(conditions.map((c) => [c.id, c]));
  const aCond = condById[activeCond];
  // resolve pinned ids to live conditions for the top-bar palette (a stale id
  // renders nothing — the persisted list is pruned on save/delete, this is the
  // render-time guard)
  const paletteConds = palette.map((id) => condById[id]).filter(Boolean);
  const activeColor = aCond?.color || "#c96442";
  // Pattern id encodes the appearance so a hatch/color change yields a NEW paint
  // server — otherwise browsers keep painting the cached old pattern (the "it
  // reverted" bug). Shapes and <defs> use the same id. `prefix` namespaces a
  // second <defs> block (the split-screen reference pane's read-only mirror,
  // "ref-") so its pattern ids can never collide with the primary's — a
  // collision would make url(#…) resolution document-order-dependent and
  // corrupt one pane's fills. The default keeps every existing call site
  // (this file's own <defs>/shapeFill) byte-identical.
  const patId = (c, prefix = "") => `hx-${prefix}${c.id}-${c.hatch || "solid"}-${String(c.color).slice(1)}-${String(c.fill || "n").slice(1)}${darkMode ? "-d" : ""}`;
  // Fill for a committed shape — delegates to the shared glyph module (also
  // used read-only by the reference pane) so the two panes' fill rules can't
  // drift apart.
  const shapeFill = (cond) => glyphFill(cond, { scale: tf.scale, darkMode, patId });
  // The in-progress ring/rect fill, per the theme's draft.fillMode: "condition"
  // wears the active condition's own fill (drafting — today's look), "tint" a
  // wash of the theme accent, "none" a hollow draft. Defined here (not with the
  // early helpers) because it reads shapeFill(aCond) — both defined just above.
  const draftFill = DS.draft.fillMode === "condition" ? shapeFill(aCond)
    : DS.draft.fillMode === "tint" ? rgbaFromHex(DS.accent, DS.draft.tintAlpha ?? 0.08)
      : "none";
  // When the "outline area while drawing" preference is on, the ring tools draw
  // as an OPEN outline (no fill, not auto-closed) while in progress — they still
  // commit CLOSED on Enter/dbl-click (commitPoly is untouched). Off ⇒ today's
  // closed+filled polygon, byte-identical. surface/linear are unaffected — they
  // already render open and are excluded here.
  const ringOutline = draftOutline && (tool === "area" || tool === "deduct" || tool === "zone");
  // the drawn boundary — flattenArcRing is the identity on an all-straight trace
  const mm = closedMetrics(curveIdx.length ? flattenArcRing(poly, curveIdx, !bowOpen) : poly);
  // the live readout prices the IN-PROGRESS poly with its own panel's scale
  const liveUpp = poly.length ? uppFor(panelAt(poly[0][0]).key) : uppFor(focusPanel.key);
  const liveArea = liveUpp ? mm.area * liveUpp * liveUpp : null;
  const livePerim = liveUpp ? mm.perim * liveUpp : null;
  // A zone trace with points on more than one panel (side-by-side group mode,
  // a gap click routing to the neighboring panel): finishShape normalizes
  // every point against the FIRST point's panel, so a second-panel point
  // would land at nx > 1 — outside that panel's own [0..1] space — and the
  // overlay would still draw the dashed region exactly where traced,
  // visually enclosing rooms on the second sheet that shapesInZone (filtered
  // to a single sheet_id) can never count. Reject it outright — mirrors the
  // check tool's checkCross guard, the same hazard on a 2-point span.
  const zoneTraceCross = tool === "zone" && poly.length >= 1 && poly.some((p) => panelAt(p[0]).key !== panelAt(poly[0][0]).key);
  const condMult = aCond?.multiplier || 1;
  // HUD + Takeoffs panel are sheet-scoped ("this sheet"): they total the
  // VISIBLE shapes through the same conditionTotals rules the Report uses —
  // one source of role math, two scopes. Memoized: visRowById is a prop of the
  // memoized panel, so its identity must only change when the totals can.
  const visRows = useMemo(() => conditionTotals(conditions, visibleShapes, seamCtx), [conditions, visibleShapes, seamCtx]);
  const visRowById = useMemo(() => new Map(visRows.map((r) => [r.id, r])), [visRows]);
  // Whole-project per-condition totals — the number the bid is built on. The
  // panel's rows lead with the visible-sheet slice (what you're looking at);
  // this map feeds the dim Σ suffix whenever the project holds MORE than the
  // open sheets show, so a condition whose takeoffs live on closed sheets
  // reads "Σ 412 SF" instead of a dead "—" (the whole-project number used to
  // exist only in the Report/exports). Same conditionTotals rules, no filter.
  const projRows = useMemo(() => conditionTotals(conditions, shapes, seamCtx), [conditions, shapes, seamCtx]);
  const projRowById = useMemo(() => new Map(projRows.map((r) => [r.id, r])), [projRows]);
  // the Premium top bar's running $ — the same engine as the Estimate panel, on
  // the project's markups (or the Company setup defaults until the estimate opens)
  const estTotal = useMemo(() => {
    if (!workspaceLayout) return 0;
    try { return priceEstimate({ rows: projRows, conditions, settings: estimateSettings || loadEstimatingDefaults() }).total; } catch { return 0; }
  }, [workspaceLayout, projRows, conditions, estimateSettings]);
  // {{qty}} in a note (#474) — the linked condition's measured quantity,
  // whole project, in the display unit system. Resolved at draw time only.
  const noteQtyLabels = useMemo(() => qtyLabels(projRows, units), [projRows, units]);
  // ── load-time quantity heal (#137) ─────────────────────────────────────────
  // A shape can ARRIVE without the numbers its role requires (an import that
  // carried geometry only). Such a shape draws fine but reads as 0 SF in
  // every summer and silently zeroes its condition's totals. Heal once per
  // load: recompute from the SAME deterministic dims the render pipeline uses
  // (pdf.js viewport at RENDER_SCALE — page metadata only, no raster, so
  // shapes on CLOSED sheets heal too), and only where the sheet's scale is
  // known — no scale, no honest number; those stay unpriced rather than
  // guessed. Commits like the rescale repair (replace + reset — not an edit,
  // no undo entry); the next autosave banks it. The seq guard kills an
  // in-flight heal the moment shapes/scales change — the rerun starts over
  // against the fresh state (a loaded doc is reused, so the redo is cheap),
  // and once nothing needsMetrics this is a pure no-op. Its sheets may be in
  // no tab: one lease per file across that file's pages.
  const healSeqRef = useRef(0);
  useEffect(() => {
    if (status !== "ready") return;
    const missing = shapes.filter((s) => needsMetrics(s) && uppFor(s.sheet_id));
    if (!missing.length) return;
    const seq = ++healSeqRef.current;
    (async () => {
      const dimsBy = new Map();
      const keysBy = new Map();
      for (const key of new Set(missing.map((s) => s.sheet_id))) {
        const { file } = parseSheetKey(key);
        keysBy.set(file, [...(keysBy.get(file) ?? []), key]);
      }
      for (const [file, keys] of keysBy) {
        try {
          await docCache.withDoc(file, async (pdf) => {
            for (const key of keys) {
              try {
                const pageObj = await pdf.getPage(Math.min(Math.max(1, parseSheetKey(key).page), pdf.numPages || 1));
                const vp = pageObj.getViewport({ scale: RENDER_SCALE });
                dimsBy.set(key, { w: Math.ceil(vp.width), h: Math.ceil(vp.height) });
              } catch { /* an unreadable page — its shapes stay unpriced */ }
            }
          });
        } catch { /* orphaned sheet (source gone) — its shapes stay unpriced */ }
      }
      if (seq !== healSeqRef.current) return;   // stale — a newer load/edit owns the heal now
      const healed = new Map(missing
        .filter((s) => dimsBy.has(s.sheet_id))
        .map((s) => [s.id, computeShapeMetrics(s, dimsBy.get(s.sheet_id), uppFor(s.sheet_id) || 0, condById[s.condition_id])]));
      if (!healed.size) return;
      dispatchShape({ type: "replace", shapes: shapes.map((s) => (healed.has(s.id) ? { ...s, computed: healed.get(s.id) } : s)) }, { reset: true });
      setCommitMsg(uiText(`Repriced ${healed.size} takeoff${healed.size === 1 ? "" : "s"} that loaded without quantities.`));
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- reruns on load/shape/scale change; docCache/uppFor/condById read from the same render
  }, [status, shapes, scales, conditions]);
  // Zone check: the SAME conditionTotals rules on the shapes whose center point
  // sits inside the traced zone (lib/zone.js) — third scope of the one role math.
  const zoneShapes = useMemo(() => (zoneCheck ? shapesInZone(shapes, zoneCheck) : null), [shapes, zoneCheck]);
  const zoneRows = useMemo(
    () => (zoneShapes ? conditionTotals(conditions, zoneShapes, seamCtx).filter((r) => r.shape_count > 0) : null),
    [conditions, zoneShapes, seamCtx]
  );
  const zoneIds = useMemo(() => (zoneShapes ? new Set(zoneShapes.map((sh) => sh.id)) : null), [zoneShapes]);
  const condRow = visRowById.get(activeCond);
  const condTotal = condRow?.floor_sf || 0;
  const lfTotal = condRow?.lf || 0;
  const countTotal = condRow?.ea || 0;
  const wallTotal = condRow?.wall_sf || 0;
  const borderTotal = condRow?.border_sf || 0;
  // display-only derived metric: floor-area perimeters × the condition height
  const condH = Number(aCond?.height_ft) || 0; // the live-readout JSX below still reads this
  const vertTotal = verticalWallSf(visibleShapes, activeCond, aCond?.height_ft, condMult);
  // the tally under the total: every linear run and wall of the active
  // condition on the visible sheets, in draw order (lib/measurementBreakdown)
  const tally = useMemo(() => measurementBreakdown(visibleShapes, activeCond, aCond), [visibleShapes, activeCond, aCond]);
  const num = (v, d = 1) => v.toLocaleString(undefined, { maximumFractionDigits: d });
  // unit-system display edge: internal math is always feet (lib/units.ts)
  const fa = (sf, d = 1) => `${num(areaVal(sf, units), d)} ${areaUnit(units)}`;
  const fl = (lf, d = 1) => `${num(lenVal(lf, units), d)} ${lenUnit(units)}`;
  const fv = (cf) => `${num(volVal(cf, units))} ${volUnit(units)}`;
  // L × W of a footprint: the smallest rectangle around the ring, read as a
  // drawing dimension (ft-in, or m) — a user asked for the sides, not just the
  // area. Exact for a rectangular room; the enclosing box for an L-shape.
  const fdims = (pxPts, upp) => {
    const r = upp && pxPts.length >= 2 ? minAreaRect(pxPts) : null;
    return r ? `${fmtCheckLen(r.w * upp, units)} × ${fmtCheckLen(r.h * upp, units)}` : null;
  };
  const dimsLine = (d, h) => d ? (
    <div style={{ fontSize: 12.5, color: "var(--ink-secondary)", marginTop: 2 }} title={uiText("Smallest rectangle around the shape — length × width, and the condition's H")}>
      {uiText(d)}{uiText(h > 0 ? ` × ${fmtCheckLen(h, units)}` : "")} <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>L × W{uiText(h > 0 ? " × H" : "")}</span>
    </div>
  ) : null;
  const faSY = (sf) => (units === "metric" ? fa(sf) : `${num(sf)} SF · ${num(sf / 9)} SY`);
  const stdValue = unitsPerPx ? (STANDARD_SCALES.find((s) => Math.abs(s.upp - unitsPerPx) < 1e-9)?.label || "") : "";
  // Check tool: measured span at the current scale vs what the drawing says
  const checkPanel = check.length ? panelAt(check[0][0]) : null;
  const checkUpp = checkPanel ? uppFor(checkPanel.key) : null;
  const checkCross = check.length === 2 && panelAt(check[1][0]).key !== checkPanel.key;
  const checkPx = check.length === 2 && !checkCross ? Math.hypot(check[1][0] - check[0][0], check[1][1] - check[0][1]) : 0;
  const checkFeet = checkUpp && checkPx ? checkPx * checkUpp : null;
  const checkStatedFeet = parseLenInput(checkStated, units);
  const checkErrPct = checkFeet && checkStatedFeet > 0 ? ((checkFeet - checkStatedFeet) / checkStatedFeet) * 100 : null;

  // Matches what the Markups tab actually renders post-Captures-split: the
  // per-sheet non-image list (panel-filtered) plus the GLOBAL Captures list
  // (every image markup, any sheet) — NOT the old panelKeySet-only count,
  // which double-missed (never counted an other-sheet capture) and
  // over-counted (still counted a THIS-sheet image, which no longer shows in
  // the per-sheet body it was counted against).
  const markupCount = markups.filter((m) => panelKeySet.has(m.sheet_id) && m.type !== "image").length + filterCaptures(markups, "").length;
  const selShape = selectedId ? visibleShapes.find((s) => s.id === selectedId) : null;
  // the input types in DISPLAY units (metres in metric); height_ft is stored feet
  const setShapeHeight = (raw) => {
    const v = Math.max(0, heightInputToFeet(parseFloat(raw) || 0, units));
    setShapes((ss) => ss.map((s) => {
      if (s.id !== selectedId) return s;
      const next = { ...s, height_ft: v, height_override: true };
      return { ...next, computed: recomputeShape(next) };
    }));
  };
  // a ceiling area's own height AFF (a soffit) — display only (the 3D view); no quantity reads it
  const setShapeCeiling = (raw) => {
    const v = raw === "" ? null : Math.max(0, heightInputToFeet(parseFloat(raw) || 0, units));
    setShapes((ss) => ss.map((s) => (s.id !== selectedId ? s : v ? { ...s, ceiling_ft: v } : (({ ceiling_ft: _drop, ...rest }) => rest)(s))));
  };
  const clearShapeHeight = () => {
    setShapeHDraft(null);
    setShapes((ss) => ss.map((s) => {
      if (s.id !== selectedId) return s;
      const next = { ...s, height_ft: Number(condById[s.condition_id]?.height_ft) || 0, height_override: false };
      return { ...next, computed: recomputeShape(next) };
    }));
  };
  // #441 — rise / drop for THIS run only. A value on the shape overrides the
  // condition's default for that field outright (0 included: "no drop here"
  // is a fact); ↺ deletes both so the condition's defaults apply again.
  const setShapeVertical = (field, raw) => {
    const v = Math.max(0, heightInputToFeet(parseFloat(raw) || 0, units));
    setShapes((ss) => ss.map((s) => {
      if (s.id !== selectedId) return s;
      const next = { ...s, [field]: v };
      return { ...next, computed: recomputeShape(next) };
    }));
  };
  const clearShapeVertical = () => {
    setShapeVertDraft({ rise_ft: null, drop_ft: null });
    setShapes((ss) => ss.map((s) => {
      if (s.id !== selectedId) return s;
      const { rise_ft, drop_ft, ...rest } = s;
      return { ...rest, computed: recomputeShape(rest) };
    }));
  };
  const finishOk = !bowOpen && (((tool === "area" || tool === "deduct") && poly.length >= 3) || (tool === "zone" && poly.length >= 3 && !zoneTraceCross) || ((tool === "linear" || tool === "surface") && poly.length >= 2));

  // ── Layers panel (#85 phase 2) wiring ──────────────────────────────────────
  // Open sheets that actually carry a PDF layer table. Empty for the common
  // flattened export — the rail button and the panel then render nothing at
  // all (zero chrome; the fallback is invisible, not a degraded mode).
  const layerEntries = groupKeys
    .map((k) => ({ key: k, label: tabLabel(k), layers: sheetLayers[k] || [], overrides: layerOverrides[k] || {} }))
    .filter((e) => e.layers.length);
  // Override mutations funnel here: the ref is the engine's source of truth
  // (rolesForSheet reads it inside click paths), state mirrors it for render/
  // persistence, and the sheet's lazy mask drops so the NEXT flood rebuilds
  // with the new roles. Existing staged proposals keep their traced rings —
  // they're under review, and re-flooding an estimator's edit would be rude.
  const setLayerOverride = (key, id, state) => {
    const prev = layerOverridesRef.current;
    const cur = { ...(prev[key] || {}) };
    if (state) cur[id] = state; else delete cur[id];
    const next = { ...prev };
    if (Object.keys(cur).length) next[key] = cur; else delete next[key];
    layerOverridesRef.current = next;
    maskCacheRef.current.delete(key);
    setLayerOverrides(next);
  };
  const resetLayerOverrides = (key) => {
    const next = { ...layerOverridesRef.current };
    delete next[key];
    layerOverridesRef.current = next;
    maskCacheRef.current.delete(key);
    setLayerOverrides(next);
  };

  // panel-toggle for the right-edge rail — square like the zoom cluster, count as a
  // tiny mono line under the icon. Lives on the canvas, costs the toolbar zero rows.
  const panelBtn = (onClick, iconName, label, isOn, count) => (
    <button onClick={onClick} title={uiText(label)} aria-label={uiText(label)} aria-pressed={!!isOn}
      style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 2, width: 34, minHeight: 34, padding: "5px 0 4px", border: `1px solid ${isOn ? "var(--ink)" : "var(--ink-faint)"}`, background: isOn ? "var(--ink)" : "var(--paper-bright)", color: isOn ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontWeight: 600, lineHeight: 1 }}>
      <Icon name={iconName} size={15} />{count ? <span style={{ fontFamily: "var(--f-mono)", fontSize: 9.5 }}>{uiText(count)}</span> : null}
    </button>
  );
  const vRule = <span style={{ width: 1, alignSelf: "stretch", background: "var(--ink-faint)", margin: "0 3px" }} />;

  // The panel's condition-list VIEW (search / natural sort / grouping / the
  // ⌘/⇧ multi-select) lives in components/TakeoffsPanel.jsx.

  // one activation path — the panel row, the compact strip, the 1–9 hotkeys,
  // +condition, and Library Apply all funnel here so the reassign-in-Select
  // and clear-multi-select semantics can never drift between surfaces. Only
  // surfaces with a VISIBLE reassign affordance (the panel row and the strip
  // button — both show the "reassign selected shape" hint once a shape is
  // selected) actually reassign; { reassign: false } is for keyboard/
  // programmatic activations (hotkeys, +condition, Library Apply) that offer
  // no such affordance — a digit press or an Apply click must never silently
  // move a selected shape's quantities. EVERY activation surface, reassigning
  // or not, dismisses a live bulk selection.
  const activateCondition = (id, { reassign = true } = {}) => {
    if (reassign && tool === "select" && selectedId) reassignSelected(id);
    setActiveCond(id);
    panelSelectionRef.current?.();   // plain activation dismisses a live bulk selection (panel view state)
  };
  // The label analogue (#111): with a shape selected in Select mode this re-labels
  // it (mirroring activateCondition's reassign-on-activate); otherwise it just sets
  // the active label for subsequent traces. value "" / null = No label / clear.
  const activateLabel = (value) => {
    if (tool === "select" && selectedId) reassignSelectedLabel(value);
    setActiveLabel(value);
  };

  // ── top-bar quick-access palette (pinned conditions) ──────────────────────
  // A palette chip is a shortcut, not a new activation path: single-click routes
  // through activateCondition (same reassign/clear-selection semantics as the
  // strip and panel row); double-click opens the docked Takeoffs panel on that
  // condition — the "don't open the sidebar unless double-clicked" contract.
  const pinToPalette = (id) => {
    if (palette.includes(id)) return;   // already pinned — silent no-op (dropping a chip back on the band)
    if (palette.length >= PALETTE_MAX) { setCommitMsg(uiText(`Palette is full (${PALETTE_MAX}) — unpin one first.`)); return; }
    setPalette((p) => (p.includes(id) || p.length >= PALETTE_MAX ? p : [...p, id]));
  };
  const unpinFromPalette = (id) => setPalette((p) => p.filter((x) => x !== id));
  // togglePin: the panel row's pushpin — pin if absent (respecting the cap),
  // unpin if already pinned. movePalette: drag one chip onto another to reorder
  // it to the target index (splice out, splice back in), which also renumbers
  // the 1–9 hotkeys since they follow palette order.
  // New work is never born invisible (#440): a shape that lands on a hidden
  // condition — drawn, swept, pasted, or accepted from an agent — reveals it.
  // Keyed on ids, not length, so a delete+add in one command still counts.
  const seenShapeIdsRef = useRef(null);
  useEffect(() => {
    const seen = seenShapeIdsRef.current;
    seenShapeIdsRef.current = new Set(shapes.map((s) => s.id));
    if (!seen || !hiddenConds.size) return;
    // …and so does reassigning the SELECTED shape onto one (same id, new
    // condition) — it must not vanish out from under the cursor
    const born = shapes.filter((s) => (!seen.has(s.id) || s.id === selectedId) && hiddenConds.has(s.condition_id));
    if (born.length) setHiddenConds((h) => born.reduce((acc, s) => revealed(acc, s.condition_id), h));
  }, [shapes]); // eslint-disable-line react-hooks/exhaustive-deps
  // Eye on a condition row (#440): click flips it, ⌥-click isolates it, a null
  // id shows everything. A selection that just went invisible is dropped — you
  // can't edit or delete what you can't see.
  const toggleCondHidden = (id, isolate = false) => {
    const next = nextHidden(hiddenConds, id, conditions.map((c) => c.id), { isolate });
    setHiddenConds(next);
    if (selectedId) {
      const sel = shapes.find((s) => s.id === selectedId);
      if (sel && next.has(sel.condition_id)) setSelectedId(null);
    }
  };
  const togglePin = (id) => setPalette((p) => (p.includes(id) ? p.filter((x) => x !== id) : (p.length >= PALETTE_MAX ? p : [...p, id])));
  const movePalette = (id, toIndex) => setPalette((p) => {
    const from = p.indexOf(id);
    if (from < 0 || toIndex < 0 || toIndex >= p.length || from === toIndex) return p;
    const next = p.slice();
    next.splice(from, 1);
    next.splice(toIndex, 0, id);
    return next;
  });
  const openConditionInPanel = (id) => {
    if (workspaceLayout && !fullTableOpen) setCondDockOpen(true);   // Premium layout: the Conditions dock is the panel
    else setPanelPrefs((p) => (p.collapsed ? { ...p, collapsed: false } : p));   // reveal the docked panel; no-op if already open
    activateCondition(id);   // highlight the row (reassigns a selected shape iff Select is armed, like every activation surface)
    // scroll the docked row into view AFTER the uncollapse paints — two rAFs so
    // the panel has mounted its list (the row carries data-cond-id)
    // CSS.escape the id — hydrate accepts hand-edited/older payloads, so an id
    // with quotes/brackets must not break the attribute selector
    requestAnimationFrame(() => requestAnimationFrame(() => document.querySelector(`[data-cond-id="${CSS.escape(id)}"]`)?.scrollIntoView({ block: "nearest" })));
  };

  // Bulk mutations — the multi-selection is TakeoffsPanel view state; every
  // callback takes the LIVE id set the panel computed (conditions ∩ checked),
  // so counts and names here can never claim rows the list already lost.
  const bulkWasteConditions = (ids, v) => {
    setConditions((cs) => cs.map((c) => (ids.has(c.id) ? { ...c, waste_pct: v } : c)));
    setCommitMsg(uiText(`Waste set to ${v}% on ${ids.size} condition${ids.size === 1 ? "" : "s"}.`));
  };
  const bulkColorConditions = (ids, color) => setConditions((cs) => cs.map((c) => (ids.has(c.id) ? { ...c, color } : c)));
  // returns whether the delete went through — the panel clears its selection only then
  const bulkDeleteConditions = (ids) => {
    const live = conditions.filter((c) => ids.has(c.id));
    if (!live.length) return false;
    const dead = shapes.filter((s) => ids.has(s.condition_id));
    const owned = dead.length;
    // name what dies while the list still reads at a glance (≤5); count beyond
    const what = live.length <= 5 ? live.map((c) => c.finish_tag).join(", ") : `${live.length} conditions`;
    if (!window.confirm(uiText(`Delete ${what}${owned ? ` and their ${owned} takeoff${owned === 1 ? "" : "s"}` : ""}? This can't be undone.`))) return false;
    setConditions((cs) => promoteOnDelete(cs, ids).filter((c) => !ids.has(c.id)));   // lineage repaired first
    // same cascade rule as deleteCondition: counted centrally, off the stack
    if (owned) dispatchShape({ type: "delete", ids: dead.map((s) => s.id), reason: "condition-delete" }, { record: false });
    setPalette((p) => p.filter((id) => !ids.has(id)));   // deleted conditions can't stay pinned
    if (ids.has(activeCond)) setActiveCond(conditions.find((c) => !ids.has(c.id))?.id || "");
    setCommitMsg(formatMessage("Deleted conditions: {0}. Deleted takeoffs: {1}.", [live.length, owned]));
    return true;
  };

  // ── condition template library ops (browser-global; store meta key) ───────
  const persistTemplates = (next) => {
    templatesRef.current = next; setTemplates(next);
    store.saveTemplates(next).catch((e) => setCommitMsg(uiText(`Couldn't save the library: ${e.message || e}`)));
  };
  const saveActiveAsTemplate = () => {
    if (!aCond) return;
    const tpl = conditionToTemplate(aCond);
    const at = templates.findIndex((t) => t.finish_tag === tpl.finish_tag);
    if (at >= 0 && !window.confirm(uiText(`A “${tpl.finish_tag}” template is already in the library — replace it?`))) return;
    persistTemplates(at >= 0 ? templates.map((t, i) => (i === at ? tpl : t)) : [...templates, tpl]);
    setCommitMsg(uiText(`Saved ${tpl.finish_tag} to the library.`));
  };
  const applyTemplate = (t) => {
    const c = instantiateTemplate(t);
    setConditions((cs) => [...cs, c]);
    // reassign:false — Library Apply has no visual reassign affordance, but it
    // still dismisses a live bulk selection like every other activation surface
    activateCondition(c.id, { reassign: false });
    // the panel switches itself back to the Takeoffs tab (its Apply handler)
    setCommitMsg(uiText(`Added ${c.finish_tag} from the library.`));
  };
  // idx addresses the template BY POSITION (the panel's plain templates.map
  // index — it doesn't filter/sort). The focus-refresh above now skips the
  // setState when the loaded library is unchanged, which closes off the
  // common way idx would go stale mid-session; a same-length edit landing
  // from another tab in the sub-second window between render and click can
  // still retarget these by position — accepted residual risk, not fully
  // closed. Guard the deref so a stale idx (list shrank out from under us)
  // reports rather than throwing.
  const renameTemplate = (idx) => {
    const t = templates[idx];
    if (!t) { setCommitMsg(uiText("The library changed in another tab — try again.")); return; }
    const tag = (window.prompt(uiText("Template tag:"), t.finish_tag) || "").trim();
    if (!tag || tag === t.finish_tag) return;
    persistTemplates(templates.map((x, i) => (i === idx ? { ...x, finish_tag: tag } : x)));
  };
  const deleteTemplate = (idx) => {
    const t = templates[idx];
    if (!t) { setCommitMsg(uiText("The library changed in another tab — try again.")); return; }
    if (!window.confirm(uiText(`Remove the ${t.finish_tag} template from the library? Existing conditions are unaffected.`))) return;
    persistTemplates(templates.filter((_, i) => i !== idx));
  };

  // ── material library ops (#47: copy-on-attach with a live link) ───────────
  // Conditions always own fully materialized material lines; lib_id is an
  // ADDITIVE link. Nothing here can affect totals, exports, or old snapshots
  // unless the user explicitly pushes an update.
  // memoized: both derivations feed the memoized TakeoffsPanel as props, so
  // they must hold identity across canvas-only renders (tf mirror, crosshair)
  const matLibById = useMemo(() => Object.fromEntries(matLib.map((m) => [m.id, m])), [matLib]);
  const persistMatLib = (next) => {
    setMatLib(next);
    store.saveMaterialLibrary(next).catch((e) => setCommitMsg(uiText(`Couldn't save the material library: ${e.message || e}`)));
  };
  // libFields / matFieldOverridden / the push+revert patch builders live in
  // lib/materials.js (pure, tested): they carry kind and the grout tile
  // geometry through every library copy, deep-copying grout at each point.
  const attachLibMaterial = (libId) => {
    const lm = matLibById[libId];
    if (!lm || !aCond) return;
    updateCond({ materials: [...(aCond.materials || []), { id: uid("mat"), ...libFields(lm), lib_id: lm.id }] });
  };
  const promoteMaterial = (m) => {
    if (!m.name) { setCommitMsg(uiText("Name the material before saving it to the library.")); return; }
    const entry = { id: uid("lib"), ...libFields(m) };
    persistMatLib([...matLib, entry]);
    updateMaterial(m.id, { lib_id: entry.id });
    setCommitMsg(uiText(`Saved ${m.name} to the material library.`));
  };
  const revertMatField = (m, f) => {
    const lm = matLibById[m.lib_id];
    if (lm) updateMaterial(m.id, libRevertPatch(m, lm, f));   // grout-derived per/note revert together with the geometry
  };
  const updateLibMaterial = (id, patch) => persistMatLib(matLib.map((x) => (x.id === id ? libEntryPatch(x, patch) : x)));   // hand-editing per/note detaches a grout entry's geometry
  // one pass per conditions change, not per library row — the Materials tab reads this per row
  const linkedCountById = useMemo(() => {
    const by = {};
    for (const c of conditions) for (const m of c.materials || []) if (m.lib_id) by[m.lib_id] = (by[m.lib_id] || 0) + 1;
    return by;
  }, [conditions]);
  const linkedCount = (libId) => linkedCountById[libId] || 0;
  const pushLibUpdate = (libId) => {
    const lm = matLibById[libId];
    if (!lm) return;
    const n = linkedCount(libId);
    if (!n) { setCommitMsg(uiText("No condition lines link this material yet.")); return; }
    if (!window.confirm(uiText(`Update ${n} linked line${n === 1 ? "" : "s"} across conditions to the library values? Overrides on those lines are replaced.`))) return;
    setConditions((cs) => cs.map((c) => ({ ...c, materials: (c.materials || []).map((m) => (m.lib_id === libId ? libPushPatch(m, lm) : m)) })));
    setCommitMsg(uiText(`Updated ${n} linked line${n === 1 ? "" : "s"} from the library.`));
  };
  const deleteLibMaterial = (libId) => {
    const lm = matLibById[libId];
    const n = linkedCount(libId);
    if (!window.confirm(uiText(`Remove ${lm?.name || "this material"} from the library?${n ? (n === 1 ? " 1 linked line keeps its values — only the link is removed." : ` ${n} linked lines keep their values — only the links are removed.`) : ""}`))) return;
    persistMatLib(matLib.filter((x) => x.id !== libId));
    if (n) setConditions((cs) => cs.map((c) => ({ ...c, materials: (c.materials || []).map((m) => { if (m.lib_id !== libId) return m; const { lib_id: _l, ...rest } = m; return rest; }) })));
    // condition templates carry lib_id too (so applying re-links to a live
    // entry) — detach them here as well, or a deleted entry would leave
    // dangling links inside saved templates
    if (templates.some((t) => (t.materials || []).some((m) => m.lib_id === libId))) {
      persistTemplates(templates.map((t) => ({ ...t, materials: (t.materials || []).map((m) => { if (m.lib_id !== libId) return m; const { lib_id: _l, ...rest } = m; return rest; }) })));
    }
  };
  const addLibMaterial = () => persistMatLib([...matLib, { id: uid("lib"), name: "", unit: "", per: 0, basis: "area", round: true, note: uiText("") }]);

  // ── TakeoffsPanel wiring ───────────────────────────────────────────────────
  // The docked panel is memoized (React.memo) so canvas-only renders — the
  // ~11Hz tf mirror during pan/zoom, crosshair/status churn — skip its whole
  // subtree. That only works if its props hold identity, and the handlers
  // above close over fresh state every render; so the panel gets STABLE
  // forwarders (minted once) that read the current handler through this ref
  // at call time. Add a handler here and it's automatically stable.
  const panelHandlersRef = useRef(null);
  panelHandlersRef.current = {
    onActivate: activateCondition, onLocate: locateCondition,
    onAddCondition: addCondition, onDeleteCondition: deleteCondition,
    onUpdateCond: updateCond, onSetCondParam: setCondParam, onAssignAttr: assignAttr,
    onAddMaterial: addMaterial, onUpdateMaterial: updateMaterial, onRemoveMaterial: removeMaterial, onApplyAssembly: applyAssembly,
    onDuplicateCondition: duplicateCondition, onSplitCondition: splitCondition,
    onDeriveTransitions: deriveTransitionsOnto,   // returns its result synchronously — the panel renders the withheld report from it
    onLocateTransition: locateSheetPoint,
    onFollowFamilyRow: followFamilyRow, onRestoreDroppedRow: restoreDroppedRow,
    onBulkWaste: bulkWasteConditions, onBulkColor: bulkColorConditions, onBulkDelete: bulkDeleteConditions,
    onSaveTemplate: saveActiveAsTemplate, onApplyTemplate: applyTemplate,
    onRenameTemplate: renameTemplate, onDeleteTemplate: deleteTemplate,
    onAddColumn: addColumn, onRenameColumn: renameColumn, onDeleteColumn: deleteColumn,
    onAddColumnValue: addColumnValue, onRemoveColumnValue: removeColumnValue, onRenameColumnValue: renameColumnVal,
    onAddLabel: addLabel, onRenameLabel: renameLabel, onRemoveLabel: removeLabel,
    onAttachLibMaterial: attachLibMaterial, onPromoteMaterial: promoteMaterial, onRevertMatField: revertMatField,
    onUpdateLibMaterial: updateLibMaterial, onPushLibUpdate: pushLibUpdate,
    onDeleteLibMaterial: deleteLibMaterial, onAddLibMaterial: addLibMaterial,
    matFieldOverridden,   // pure helper, not an event handler — the forwarder returns its result
    onToggleCollapse: () => (workspaceLayout ? setFullTableOpen((v) => !v) : toggleTakeoffs()), onTogglePin: togglePin, onToggleHidden: toggleCondHidden,
    // these three are ALREADY stable on their own (setState identity, and
    // holdPanelGesture is a useCallback with an empty dep array) — routed
    // through the registry anyway so the memo contract has exactly ONE
    // convention to audit, not "stable via the registry, except these three"
    onPanelPrefs: setPanelPrefs, onSetActive: setActiveCond, onHoldGesture: holdPanelGesture,
  };
  const [panelHandlers] = useState(() => {
    const stable = {};
    for (const k of Object.keys(panelHandlersRef.current)) stable[k] = (...a) => panelHandlersRef.current[k](...a);
    return stable;
  });

  function commitAnnotationBatch(next) {
    const patch = markupPatch(markups, next);
    if (!patch.ids.length) return;
    const st = recordCommand(undoStackRef.current, { family: "markup", patch });
    undoStackRef.current = st.undo; redoStackRef.current = st.redo;
    setMarkups(next);
  }
  const annotations = useAnnotationWorkbench({
    tool, setTool, panels, tf: tfRef, zoom: tf.scale, toImage, spaceRef,
    markups, selectedId: selectedMarkupId, setSelectedId: setSelectedMarkupId, activeCondition: activeCond,
    commit: commitAnnotationBatch, message: setCommitMsg, ready: status === "ready",
    storageKey: "opentakeoff_annotation_favorites_v1", visible: showMarkups,
    compact: workspaceLayout, onMenuDepth,
    keysHeld: () => !!ocrReadRef.current?.ocr,   // its Delete/Esc/⌘Z wait out a schedule box's on-device read, like the canvas's own keys
    legacyTools: { highlighter: "highlighter", cloud: "cloud", callout: "callout" },
    resetDraft: () => { leaveCanvas(); setMarkupDraft(null); },
    readText: key => withSheetPage(key, async page => {
      if (!page) throw new Error("This sheet has no native PDF text available. Use Freehand for a scan or composite.");
      const content = await page.getTextContent();
      return nativeTextRuns(content, page.getViewport({ scale: RENDER_SCALE }).transform);
    }),
    findSymbols: (key, rect) => {
      const segments = vectorSegsRef.current.get(key);
      if (!segments?.length) throw new Error("No vector symbols are available on this sheet. Scans need a manual cloud or note.");
      return sweepSymbols(segments, rect);
    },
  });

  const referencePins = markups.filter(m => m.type === "image" && (m.reference_only || m.id === pinSelectedId));
  const pinButton = <PinButton armed={tool === "pin"} disabled={status !== "ready"}
    onCapture={() => { setTool(tool === "pin" ? "select" : "pin"); setImageAnchor(null); setCommitMsg(tool === "pin" ? "Pin cancelled." : "Pin — click two corners around any part of the sheet."); }}
    count={referencePins.length} onShow={() => setPinsOpen(v => !v)} />;
  const pinWindow = pinsOpen && <ReferencePins pins={referencePins} selectedId={pinSelectedId}
    onSelect={setPinSelectedId} onClose={() => setPinsOpen(false)} onSource={traceSource}
    onRename={(mid, text) => updateMarkup(mid, { text })} />;

  // ── two-deck toolbar (issue #61) ───────────────────────────────────────────
  // drafting-style group caption floated above a deck-2 cluster
  const cluster = (cap, children, style) => (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 7, position: "relative", paddingTop: 2, ...style }}>
      <span style={{ position: "absolute", top: -13, left: 1, fontFamily: "var(--f-mono)", fontSize: 8, fontWeight: 700, letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--ink-muted)", whiteSpace: "nowrap", maxWidth: 200, overflow: "hidden", textOverflow: "ellipsis" }}>{tr(cap)}</span>
      {uiText(children)}
    </span>
  );
  // MODE segmented control — shared border, ink-filled active (cobalt stays
  // reserved for the armed DRAW face so only one control ever claims it)
  // rail tile — a machined tool face for the left rail: 36px, keycap corner,
  // filled cobalt (+ HUD glow) when armed. Tooltip = label · shortcut.
  const railTile = (id, iconName, label, shortcut, onArm, opts = {}) => {
    const armed = opts.armed ?? (tool === id);
    return (
      <button key={id} type="button" onClick={onArm || (() => setTool(id))}
        title={uiText(shortcut ? keyText(uiText(`${tr(label)} · ${shortcut}`)) : tr(label))} aria-label={tr(label)} aria-pressed={armed}
        style={{ position: "relative", width: language === "ru" ? "calc(var(--rail-w) - 2 * var(--sp-2))" : "var(--ctl-l)", height: language === "ru" ? 48 : "var(--ctl-l)", flexShrink: 0, display: "flex", flexDirection: language === "ru" ? "column" : "row", gap: 3, alignItems: "center", justifyContent: "center", border: "1px solid transparent", borderRadius: "var(--r-1)", background: armed ? (opts.tint || "var(--cobalt)") : "transparent", color: armed ? "var(--accent-contrast)" : (opts.tint || "var(--ink)"), boxShadow: armed ? "var(--glow)" : "none", cursor: "pointer", lineHeight: 1 }}>
        <Icon name={iconName} size={17} />
        {language === "ru" && <span className="ot-tool-name">{toolFaceLabel(id)}</span>}
        {shortcut && <span aria-hidden="true" style={{ position: "absolute", bottom: 1, right: 3, fontFamily: "var(--f-mono)", fontSize: 8, color: armed ? "var(--accent-contrast)" : "var(--ink-muted)", opacity: armed ? 0.75 : 1 }}>{uiText(keyText(uiText(shortcut)))}</span>}
      </button>
    );
  };
  const railLabel = (text) => dockBottom
    ? (text === "SEL" ? null : <span key={`sep-${text}`} aria-hidden="true" style={{ width: 1, height: 22, background: "var(--ink-faint)", margin: "0 var(--sp-1)", flexShrink: 0 }} />)
    : (
    <span style={{ fontFamily: "var(--f-mono)", fontSize: "var(--fs-2xs)", letterSpacing: ".1em", color: "var(--ink-muted)", userSelect: "none", margin: "var(--sp-2) 0 2px" }}>{tr(text)}</span>
  );

  // deck-1 sheet-nav chip — ONE home for "which sheet am I on": pages, files,
  // group/ungroup and the gallery all live in its dropdown. Ungroup/Regroup
  // are sheet-set operations, so they move in here instead of appearing
  // mid-row and shifting everything after them.
  // assigned floor/level rides the sheet chip + page entries (sheet key: page 1 is the bare file name)
  const levelOfPage = (n) => sheetLevels[n > 1 ? `${active}#${n}` : active] || "";
  const soloStitch = sheetGroup.length === 1 && isStitchKey(sheetGroup[0]) ? stitchById[sheetGroup[0]] : null;
  const sheetChipLabel = sheetGroup.length
    ? (soloStitch ? `Stitched — ${soloStitch.name}` : `${sheetGroup.length} sheets side-by-side`)
    : `${levelOfPage(page) ? `${levelOfPage(page)} · ` : ""}${pageLabels[page] || (pageCount > 1 ? `Sheet ${page}` : active)}${pageCount > 1 ? ` · ${page}/${pageCount}` : ""}`;
  const sheetMenuItems = [];
  if (!sheetGroup.length && pageCount > 1) {
    sheetMenuItems.push({ section: tr("Sheets in this set") });
    for (let n = 1; n <= pageCount; n++) sheetMenuItems.push({ id: `pg-${n}`, label: uiText(`${levelOfPage(n) ? `${levelOfPage(n)} · ` : ""}${pageLabels[n] || `Sheet ${n}`}`), shortcut: `${n}/${pageCount}`, active: n === page, onSelect: () => setPage(n) });
  }
  if (!sheetGroup.length && sheets.length > 1) {
    sheetMenuItems.push({ section: tr("Files") });
    for (const s of sheets) sheetMenuItems.push({ id: `f-${s.name}`, label: s.name, active: s.name === active, onSelect: () => { setActive(s.name); setPage(1); } });
  }
  if (sheetMenuItems.length && (sheetGroup.length || lastGroup.length >= 2)) sheetMenuItems.push("divider");
  if (sheetGroup.length) sheetMenuItems.push(soloStitch
    ? { id: "ungroup", label: tr("Leave stitch — back to one sheet"), title: uiText("Back to a single sheet (the stitch's first member) — the stitch keeps its takeoffs and reopens from the gallery or its tab"), onSelect: ungroup }
    : { id: "ungroup", label: tr("Ungroup — back to one sheet"), title: uiText("Back to one sheet — you land on the sheet you were last working; every sheet keeps its takeoffs and markups"), onSelect: ungroup });
  if (!sheetGroup.length && lastGroup.length >= 2) sheetMenuItems.push({ id: "regroup", label: uiText(`Regroup (${lastGroup.length})`), title: uiText(`Side-by-side again with the same ${lastGroup.length} sheets — each keeps its own scale, takeoffs and markups`), onSelect: regroup });
  // "Reference ▸ Split Vertical/Horizontal" (Task 7) — the discoverable,
  // keyboard/menu-driven fallback for the drag-a-tab-to-split gesture (Task
  // 4), for whoever doesn't discover or can't perform the drag. Only offered
  // pre-split: dragging is ALSO edge-disabled once a split exists (see
  // primaryViewport's onDragOver/onDrop above), and re-running this would
  // silently discard the current reference SET, not add to it — the one way
  // to add a second sheet to an existing reference is still the drop-onto-
  // the-reference-pane gesture (ReferencePane.jsx's onDropSheet); this menu
  // only ever MINTS a new split. The candidate sheet defaults to the
  // most-recently-viewed OPEN tab that isn't already on screen in the
  // primary (tabMruRef, front-loaded on every sheetKey change above),
  // falling back to the first open tab that qualifies; excludes every
  // member of `groupKeys` (not just the focused sheetKey) so a side-by-side
  // group never offers to reference a sheet it's already showing.
  // Task 8: also withheld on a device canSplit disables (no override here —
  // that's for RESTORING an already-open split, not minting a new one on a
  // device that can't usefully show it).
  const referenceCandidate = splitView || !deviceCanSplit ? null : (
    tabMruRef.current.find((k) => openTabs.includes(k) && !groupKeys.includes(k))
    ?? openTabs.find((k) => !groupKeys.includes(k))
    ?? null
  );
  if (referenceCandidate) {
    sheetMenuItems.push({
      id: "ref-split-v", label: tr("Reference ▸ Split Vertical"),
      title: uiText(`Open a read-only reference pane beside this one, framing ${tabLabel(referenceCandidate)}`),
      onSelect: () => { if (refuseIfOverCap(1)) return; setSplitView({ orientation: "v", ratio: 0.5, refKey: referenceCandidate, refSet: [referenceCandidate] }); },
    });
    sheetMenuItems.push({
      id: "ref-split-h", label: tr("Reference ▸ Split Horizontal"),
      title: uiText(`Open a read-only reference pane below this one, framing ${tabLabel(referenceCandidate)}`),
      onSelect: () => { if (refuseIfOverCap(1)) return; setSplitView({ orientation: "h", ratio: 0.5, refKey: referenceCandidate, refSet: [referenceCandidate] }); },
    });
  }
  // "Restore split" (Task 8): a splitView PERSISTS in state even when the
  // device can't currently mount its reference pane (narrow viewport /
  // low-memory — see splitMounted above); this is the escape hatch for a
  // user who wants it anyway, e.g. a phone user who's fine with a cramped
  // pane, or a false-positive low-memory read. Disappears the moment
  // deviceCanSplit becomes true on its own (viewport widened) — nothing left
  // to override at that point.
  if (splitView && !deviceCanSplit && !splitOverride) {
    sheetMenuItems.push({
      id: "restore-split", label: tr("Restore split"),
      title: isNarrow
        ? "This split is hidden because the window is too narrow to show two panes usefully — restoring it may feel cramped."
        : "This split is hidden because this device may not have enough memory for two rendered sheets at once — restoring it may be slow.",
      onSelect: () => setSplitOverride(true),
    });
  }
  if (sheetMenuItems.length) sheetMenuItems.push("divider");
  sheetMenuItems.push({ id: "gallery", icon: "sheets", label: tr("Open gallery…"), shortcut: "G", onSelect: () => setView("gallery") });
  sheetMenuItems.push({
    id: "export-takeoff", icon: "document", label: tr("Export takeoff…"),
    title: uiText("Save this whole takeoff to a JSON file on your computer — every shape, condition, scale, markup and RFI, in the app's own format. Import takeoff reads it back as an editable takeoff (the plan PDF isn't in the file: open it first, then import)."),
    onSelect: exportTakeoffFile,
  });
  sheetMenuItems.push({
    id: "import-takeoff", icon: "document", label: tr("Import takeoff…"),
    title: uiText("Load a takeoff JSON — the app's own export or an agent session's export_takeoff. Machine shapes land dashed in their condition colors for your review; on merge, your calibration, conditions, and workspace win."),
    onSelect: () => importInputRef.current?.click(),
  });
  sheetMenuItems.push({
    id: "export-project", icon: "document", label: tr("Export project archive…"),
    title: uiText("Save the WHOLE job as one portable .otk file — every plan PDF plus the full takeoff. Open it on any machine (drop it like a plan, or Add plans), archive it, or hand it to another estimator; unlike Export takeoff, the plans travel inside."),
    onSelect: exportProjectArchive,
  });
  sheetMenuItems.push({ section: "Page tools" });
  sheetMenuItems.push({
    id: "rotate-page-cw", icon: "redo", label: "Rotate page 90° clockwise",
    title: "Rotate current page 90° clockwise — every takeoff and markup stays locked to the drawing",
    shortcut: "]",
    disabled: !active,
    onSelect: () => rotateCurrentSheet(90),
  });
  sheetMenuItems.push({
    id: "rotate-page-180", icon: "redo", label: "Rotate page 180°",
    title: "Rotate current page 180°",
    disabled: !active,
    onSelect: () => rotateCurrentSheet(180),
  });
  sheetMenuItems.push({
    id: "rotate-page-ccw", icon: "undo", label: "Rotate page 270° clockwise",
    title: "Rotate current page 270° clockwise (90° counter-clockwise)",
    shortcut: "[",
    disabled: !active,
    onSelect: () => rotateCurrentSheet(270),
  });
  sheetMenuItems.push({
    id: "delete-page", icon: "cross", label: "Delete current page…",
    title: "Delete this page from the document — asks before removing takeoffs, and undo restores them",
    disabled: !active || pageCount <= 1,
    onSelect: () => deleteCurrentSheet(),
  });
  sheetMenuItems.push({
    id: "extract-pages", icon: "document", label: "Extract pages from set…",
    title: "Extract a range of pages into a new PDF, carrying takeoffs along",
    disabled: !active,
    onSelect: () => extractPageRange(),
  });
  sheetMenuItems.push({
    id: "merge-docs", icon: "sheets", label: "Merge PDF sets…",
    title: "Combine multiple open PDF files into one set, remapping all takeoffs",
    disabled: sheets.length < 2,
    onSelect: mergePdfSets,
  });
  sheetMenuItems.push({
    id: "insert-pages", icon: "document", label: "Insert pages from PDF…",
    title: "Insert pages from another PDF file into the active document",
    disabled: !active,
    onSelect: insertPagesFromPdf,
  });
  sheetMenuItems.push({
    id: "export-edited-pdf", icon: "document", label: "Export edited PDF…",
    title: "Export the modified PDF with all rotations, reordering and page edits applied",
    disabled: !active,
    onSelect: exportEditedPdf,
  });
  sheetMenuItems.push({ section: tr("Profile — your templates, stamps & report setup") });
  sheetMenuItems.push({
    id: "company-setup", icon: "document", label: tr("Company setup…"),
    title: uiText("Your company on proposals — trade name, logo, phone, email, license — plus default overhead, profit and sales tax and your proposal inclusions, exclusions and terms. Saved on this device; Export profile carries it."),
    onSelect: () => setCompanySetupOpen(true),
  });
  sheetMenuItems.push({
    id: "export-profile", icon: "document", label: tr("Export profile…"),
    title: uiText("Save your working environment — condition templates, material library, stamps, report templates/theme/columns, company setup — as one portable .otprofile. Import it on another machine or hand a company setup to another estimator; project takeoffs are never in it."),
    onSelect: exportProfileFile,
  });
  sheetMenuItems.push({
    id: "import-profile", icon: "document", label: tr("Import profile…"),
    title: uiText("Replace your working environment with a .otprofile (you can also drop the file on the canvas). Your current setup downloads as a backup first — importing that backup restores it. Project takeoffs are untouched."),
    onSelect: () => profileInputRef.current?.click(),
  });
  sheetMenuItems.push({
    id: "reset-profile", icon: "undo", label: tr("Reset profile to defaults"),
    title: uiText("Back to a stock OpenTakeoff setup — empty template/material libraries, the default stamps, no report customization. Your company setup is kept. Your current setup downloads as a backup first; project takeoffs are untouched."),
    onSelect: resetProfile,
  });

  // deck-2 scale chip — the four scale controls collapsed to one status face:
  // red dashed = unset ("you can't trace yet"), green = set, warning = the
  // plan notes a different scale than the one you picked
  const scaleDet = detectedScales[focusPanel.key];
  const scaleMismatch = !!(unitsPerPx && stdValue && scaleDet && Math.abs(scaleDet.upp - unitsPerPx) > 1e-9);
  // scale gate: an agent-set scale no human has confirmed wears the warning
  // face until it's confirmed (menu row below) or replaced by a human act
  const scaleNeedsConfirm = !!unitsPerPx && scaleUnconfirmed[focusPanel.key] === false;
  const shownScale = stdValue ? scaleRatioLabel(stdValue, units === "metric" ? "ru" : "en") : calibratedScaleLabel(unitsPerPx, RENDER_SCALE, units);
  const scaleFace = !unitsPerPx ? tr("Set scale…") : scaleNeedsConfirm ? `⚠ ${shownScale || tr("custom")} — confirm` : `${scaleMismatch ? "≠" : "✓"} ${shownScale || tr("custom")}`;
  const scaleFaceStyle = !unitsPerPx
    ? { border: "1px dashed var(--c-danger)", color: "var(--c-danger)" }
    : scaleMismatch || scaleNeedsConfirm
      ? { border: "1px solid var(--c-warning)", color: "var(--c-warning)" }
      : { border: "1px solid var(--c-positive)", color: "var(--c-positive)" };
  const scaleTitle = scaleNeedsConfirm
    ? `An agent set this sheet's scale — no person has confirmed it. Check it against a printed dimension (K), then confirm from this menu; quantities stand on this number.`
    : scaleMismatch
      ? `You set ${stdValue}, but the plan notes ${scaleDet.label} on ${labelFor(focusPanel)} — double-check before tracing.`
      : `Set the scale for ${labelFor(focusPanel)} — remembered per sheet${groupKeys.length > 1 ? " (targets the sheet you last clicked)" : ""}`;
  const scaleItems = [];
  if (scaleNeedsConfirm) {
    scaleItems.push({
      id: "confirm-scale", icon: "check", tint: "var(--c-warning)",
      label: tr("Confirm agent-set scale"),
      title: `This scale arrived from an agent takeoff and no person has verified it. Best practice: Check a dimension (K) against a printed dimension string first — a wrong scale poisons every quantity on the sheet.`,
      onSelect: () => confirmScale(focusPanel.key),
    });
    scaleItems.push("divider");
  }
  // one-step revert after a rescale that changed committed quantities on this
  // sheet — the oops-hatch for a mistyped recalibrate (ephemeral, one slot)
  if (prevScale && prevScale.key === focusPanel.key && scales[focusPanel.key] !== prevScale.upp) {
    const wasLabel = STANDARD_SCALES.find((x) => Math.abs(x.upp - prevScale.upp) < 1e-9)?.label
      || (prevScale.source === "calibrated" ? "calibrated" : tr("custom"));
    scaleItems.push({
      id: "revert-scale", icon: "undo",
      label: uiText(`Revert scale (was ${wasLabel})`),
      title: uiText(`Put ${labelFor(focusPanel)} back on the scale the last rescale replaced and re-price its takeoffs. One step, kept only until the sheet view changes — reverting is itself revertible.`),
      onSelect: revertScale,
    });
    scaleItems.push("divider");
  }
  if (scaleDet) {
    scaleItems.push({ section: tr("From the plan") });
    scaleItems.push({
      id: "use-detected", icon: "target", tint: "var(--c-positive)",
      label: uiText(`Plan says ${scaleDet.label}${scaleDet.multi ? " ±" : ""} — use it`),
      title: uiText(`The plan notes ${scaleDet.label} on ${labelFor(focusPanel)}${scaleDet.multi ? " — this sheet shows several scales (details are often larger); confirm against a known dimension" : ""}. Hover previews a calibrated guide bar on the sheet so you can sanity-check it.`),
      onSelect: () => { rescaleSheet(focusPanel.key, scaleDet.upp); setScaleSources((s) => ({ ...s, [focusPanel.key]: "detected" })); showScaleGuide(focusPanel.key, scaleDet.upp, scaleDet.label); },
      // hover previews the guide bar behind the open menu — only while the
      // sheet is still UNSCALED (upstream's gate: on a scaled sheet the bar
      // would advertise a scale the sheet is not using, on the very affordance
      // whose job is sanity-checking bar length). The preview dies on hover-out
      // AND on menu close however it happens (onScaleMenuDepth below) — an
      // ACCEPTED bar (onSelect) is not a preview and rides out its 8 s.
      onHover: (on) => { if (on) { if (!scales[focusPanel.key]) showScaleGuide(focusPanel.key, scaleDet.upp, scaleDet.label, true); } else clearPreviewGuide(); },
    });
  }
  const detectedScaleItems = scaleItems.splice(0);
  for (const group of scaleGroups(STANDARD_SCALES, language)) {
    if (language === "ru" && group.title === "Imperial scales (feet and inches)") {
      scaleItems.push({ id: "toggle-imperial", label: uiText(group.title), checked: showImperialScales, stayOpen: true, onSelect: () => setShowImperialScales((value) => !value) });
      if (!showImperialScales) continue;
    } else scaleItems.push({ section: uiText(group.title) });
    for (const entry of group.scales) scaleItems.push({ id: entry.label, label: entry.label,
      active: stdValue === entry.label,
      onSelect: () => { rescaleSheet(focusPanel.key, entry.upp); setScaleSources((sc) => ({ ...sc, [focusPanel.key]: "standard" })); showScaleGuide(focusPanel.key, entry.upp, entry.label); } });
  }
  if (detectedScaleItems.length) scaleItems.push("divider", ...detectedScaleItems);
  scaleItems.push("divider");
  scaleItems.push({ id: "calibrate", icon: "calibrate", label: tr("Calibrate two points…"), title: tr("Calibrate — click two points of a known dimension"), active: tool === "calibrate", onSelect: () => setTool("calibrate") });
  scaleItems.push({ id: "check", icon: "check", label: tr("Check a dimension…"), shortcut: "K", title: uiText("Check a dimension (K) — click both ends of a printed dimension string; compares the measured length against what the drawing says"), active: tool === "check", onSelect: () => setTool("check") });
  scaleItems.push({ note: tr("Remembered per sheet.") });

  // One-Click fill sensitivity — lives in the render menu now, so arming
  // One-Click never reshapes the toolbar. Detents at Strict / Balanced /
  // Aggressive; the slider still tunes 0–100% freely, snapping to a notch when
  // released near one. Detents come from oneclick's canonical presets so UI
  // and flood math can't drift if a preset is ever retuned.

  // Draft menu — ONE dropdown on the toolbar (between 45° and the scale) for the
  // drafting conventions: the drawing style, "Outline area while drawing", and
  // the ╱ Straight / ⌒ Curve bend (#284). They lived in the ⋯ menu and the
  // readout before 2026-09-12; one face keeps the row compact while every
  // convention is one click from the sheet. The face is the active style's
  // swatch; the bend rows are live only while a curvable tool is armed and
  // stay open on click so a mode can be flipped and watched against the draft.
  // (DrawStylePicker, the ⋯-menu row form, is no longer mounted; its StylePreview is.)
  const curvable = CURVABLE.has(tool);
  const activeDrawStyle = DRAW_STYLES[drawStyleId] || DRAW_STYLES[DRAW_STYLE_IDS[0]];
  const draftMenu = (
    <ToolMenu
      title={uiText(`Draft — drawing style (${activeDrawStyle.label}), outline while drawing, straight or curve`)}
      onOpenChange={onMenuDepth}
      faceStyle={{ padding: "4px 6px" }}
      face={<><StylePreview t={activeDrawStyle} w={26} h={16} />{workspaceLayout && <span>{tr("Draft")}</span>}</>}
      items={[
        { section: tr("Drawing style") },
        ...DRAW_STYLE_IDS.map((id) => {
          const t = DRAW_STYLES[id];
          const on = id === drawStyleId;
          return {
            id: `ds-${id}`, custom: (
              <button type="button" aria-pressed={on} data-ds={id} onClick={() => setDrawStyle(id)}
                style={{ display: "flex", alignItems: "center", gap: 10, width: "100%", padding: "7px 12px", border: "none", textAlign: "left", cursor: "pointer", background: on ? "var(--tint-select)" : "transparent", color: "var(--ink)", fontFamily: "var(--f-body)", fontSize: 13, fontWeight: on ? 600 : 400 }}
                onMouseEnter={(e) => { if (!on) e.currentTarget.style.background = "var(--paper-shadow)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = on ? "var(--tint-select)" : "transparent"; }}>
                <StylePreview t={t} />
              <span style={{ flex: 1 }}>{uiText(t.label)}</span>
                <span style={{ display: "inline-flex", width: 14, justifyContent: "center", color: "var(--cobalt)", visibility: on ? "visible" : "hidden" }} aria-hidden="true">✓</span>
              </button>
            )
          };
        }),
        "divider",
        {
          id: "draftoutline", checked: draftOutline, stayOpen: true, icon: "area", label: tr("Outline area while drawing"), onSelect: () => setDraftOutline(!draftOutline),
          title: uiText("Draw Area / Deduct / Zone as an open outline (no fill) while tracing — it still commits closed on Enter or double-click.")
        },
        "divider",
        { section: tr("Bend") },
        {
          id: "straight", checked: !curveMode, stayOpen: true, disabled: !curvable, label: tr("Straight"), onSelect: () => setCurveMode(false),
          title: tr("Straight places corners.")
        },
        {
          id: "curve", checked: curveMode, stayOpen: true, disabled: !curvable, icon: "curve", label: tr("Curve"), shortcut: "Q", onSelect: () => setCurveMode(true),
          title: tr("Curve takes two clicks — one anywhere ON the bow, then its far end — and lays the unique circle through those and the vertex you were on, so it sits on a radius wall instead of near it. Q flips it once a trace is going; ⌥-click places the OTHER kind for one point.")
        },
        { note: curvable ? "Switch as often as you like inside one measurement." : "Arm Area, Line, Cut Out or Surface Area to bend a trace." },
      ]}
    />
  );

  const workspaceShapeCounts = new Map();
  if (workspaceLayout) for (const shape of shapes) workspaceShapeCounts.set(shape.sheet_id, (workspaceShapeCounts.get(shape.sheet_id) || 0) + 1);
  const treeCurrent = (focusKey && groupKeys.includes(focusKey)) ? focusKey : sheetKey;
  const countKnown = useCallback((f) => !!knownPages[f] || f === active, [knownPages, active]);
  const ocrHold = useCallback(() => !!ocrReadRef.current?.ocr, []);
  const workspaceSheets = (workspaceLayout ? sheets : []).flatMap((sheet) => Array.from({ length: knownPages[sheet.name] || (sheet.name === active ? pageCount : 1) }, (_, i) => {
    const key = i ? `${sheet.name}#${i + 1}` : sheet.name;
    return { key, label: tabLabel(key), file: sheet.name, count: workspaceShapeCounts.get(key) || 0, level: sheetLevels[key] || "" };
  }));
  const workspaceDockHandle = (dock, label) => workspaceLayout && <DockHandle dock={dock} label={label} locked={workspaceArrangement.locked} onDrag={setWorkspaceDragging} onMove={workspacePrefs.move} />;
  const workspaceActions = [
    ...measureTools.filter((t) => t.id !== "oneclick" || oneClickEnabled()).concat(cutTools).map((t) => ({ id: `tool-${t.id}`, label: t.label, shortcut: t.shortcut, group: tr("Measuring tools"), run: () => { setView("canvas"); setTool(t.id); } })),
    { id: "select", label: tr("Select and edit a measurement"), group: tr("Tools"), shortcut: "V", run: () => setTool("select") },
    { id: "zone", label: tr("Zone check — what's inside a traced region"), group: tr("Tools"), run: () => { setView("canvas"); setTool("zone"); } },
    { id: "textcopy", label: tr("Copy text — box a region, its text goes on the clipboard"), group: tr("Tools"), run: () => { setView("canvas"); if (tool !== "textcopy") armCopyText(); } },
    { id: "undo", label: tr("Undo"), group: tr("Edit"), shortcut: "⌘Z", run: () => poly.length ? dropLastPoint() : undoShapeCommand() },
    { id: "redo", label: tr("Redo"), group: tr("Edit"), shortcut: "⇧⌘Z", run: redoShapeCommand },
    { id: "finish", label: tr("Finish shape"), group: tr("Edit"), shortcut: "↵", disabled: !finishOk, run: finishShape },
    { id: "copy", label: tr("Copy selected"), group: tr("Edit"), shortcut: "⌘C", disabled: !selectedId, run: copySelected },
    { id: "paste", label: tr("Paste"), group: tr("Edit"), shortcut: "⌘V", disabled: !clipRef.current.length, run: () => pasteClipboard() },
    { id: "report", label: tr("Open report"), group: tr("Workspace"), run: () => setShowReport(true) },
    { id: "estimate", label: tr("Estimate — price the takeoff"), group: tr("Workspace"), run: openEstimate },
    { id: "company-setup", label: tr("Company setup — logo, markups, proposal terms"), group: tr("Workspace"), run: () => setCompanySetupOpen(true) },
    { id: "tour", label: tr("Guided first takeoff — learn it on the sample plan"), group: tr("Help"), run: startTour },
    { id: "guide", label: tr("How OpenTakeoff works — shortcuts and the five-minute path"), group: tr("Help"), shortcut: "?", run: () => setGuideOpen(true) },
    { id: "connect-ai", label: tr("Connect your AI — Claude, Codex, Cursor"), group: tr("Help"), run: () => setConnectOpen(true) },
    { id: "work", label: tr("Open work and review"), group: tr("Workspace"), run: () => setAgentOpen(true) },
    { id: "layout", label: tr("Arrange and save your layout"), group: tr("Workspace"), run: () => setWorkspaceLayoutOpen(true) },
    { id: "fit", label: tr("Fit sheet to view"), group: tr("View"), disabled: !stage.w, run: () => fitToView(stage.w, stage.h) },
    { id: "focus", label: tr("Focus mode"), group: tr("View"), shortcut: "F", run: toggleFocusMode },
    { id: "theme", label: workspaceArrangement.look === "light" ? tr("Backlit graphite") : tr("Studio light"), group: tr("Appearance"), run: () => workspacePrefs.update({ look: workspaceArrangement.look === "light" ? "graphite" : "light" }) },
    { id: "addcondition", label: tr("Add condition"), group: tr("Conditions"), run: addCondition },
    ...scaleItems.filter((item) => item.onSelect).map((item) => ({ ...item, id: `scale-${item.id}`, group: tr("Scale"), run: item.onSelect })),
    ...sheetMenuItems.filter((item) => item.onSelect).map((item) => ({ ...item, id: `file-${item.id}`, group: tr("Plans and files"), run: item.onSelect })),
    ...workspaceSheets.map((sheet) => ({ id: `sheet-${sheet.key}`, label: sheet.label, group: sheet.file, run: () => openSheets([sheet.key], false) })),
  ];

  // ?hatchqa — density-tuning wall: every pattern at three scales in two palette
  // colors, real components, dark-aware. Unreachable from the UI; kept for retunes.
  // Added 2026-07-07 (d02032a) and lost, not removed, in the fork merge 1317d07
  // (PR #26, 2026-07-13) — FEATURES.md has advertised it the whole time.
  if (new URLSearchParams(window.location.search).has("hatchqa")) {
    const qaColors = [PALETTE[0], PALETTE[2]];
    return (
      <div style={{ padding: 20, background: darkMode ? "#14120e" : "var(--paper-bright)", minHeight: "100vh", overflow: "auto" }}>
        <button onClick={() => setDarkMode((v) => !v)} style={{ marginBottom: 14, padding: "4px 12px", border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", cursor: "pointer", fontSize: 12 }}>{uiText("☾ toggle dark")}</button>
        {HATCHES.map((h) => (
          <div key={h.id} style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 10 }}>
            <span style={{ width: 120, fontFamily: "var(--f-mono)", fontSize: 10, textTransform: "uppercase", letterSpacing: ".08em", color: darkMode ? "#c9c2b2" : "var(--ink-muted)" }}>{uiText(h.label)}</span>
            {qaColors.map((col) => (
              <svg key={col} width={392} height={64} style={{ border: "1px solid var(--ink-faint)", background: darkMode ? "#1c1914" : "#fff" }}>
                <defs>
                  <HatchPattern id={`qa-${h.id}-${col.slice(1)}`} type={h.id} line={col} fill={col} dark={darkMode} />
                </defs>
                {[[0.5, 0], [1, 132], [3, 264]].map(([sc, x]) => (
                  <g key={sc} transform={`translate(${x},0) scale(${sc})`}>
                    <rect width={128 / sc} height={64 / sc} fill={`url(#qa-${h.id}-${col.slice(1)})`} />
                  </g>
                ))}
              </svg>
            ))}
          </div>
        ))}
      </div>
    );
  }

  // This div always lives inside SplitLayout's primary pane (a plain block,
  // not a flex container — SplitLayout itself is the flex item that claims
  // the row's space), and its only content is position:absolute (out of
  // flow), so without an explicit height it would collapse to 0. width/
  // height:100% make it self-sizing off its parent's box (percent-flex or
  // full-bleed, whichever SplitLayout gave that pane).
  const primaryViewport = (
    <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden" }}
      onDragOver={(e) => {
        // Filter on the tab MIME so this never fires for a dragged condition
        // chip (CONDITION_DND_MIME) or an OS file drag (dataTransfer.files) —
        // both must fall through untouched to their own handlers (the
        // quick-access palette's onDrop, and the app-shell's file-drop
        // onDrop — `handleFiles(e.dataTransfer?.files)` on the top-level
        // .app-shell div — neither of which this element sits between).
        if (![...e.dataTransfer.types].includes(SHEET_TAB_DND_MIME)) return;
        e.preventDefault(); e.stopPropagation();
        e.dataTransfer.dropEffect = "copy"; // negotiate the cursor — a bare preventDefault() without this leaves the browser showing "no-drop" over a valid target
        const r = e.currentTarget.getBoundingClientRect();
        // Task 8: edges are ALSO disabled (center-join-only) when the
        // device can't split — same rule the menu's referenceCandidate
        // uses, so the drag gesture and its menu fallback never disagree
        // about whether split creation is currently offered.
        setDragZone(dropZoneAt({ w: r.width, h: r.height }, e.clientX - r.left, e.clientY - r.top, { edgesDisabled: !!splitView || !deviceCanSplit }));
      }}
      onDragLeave={(e) => {
        if (![...e.dataTransfer.types].includes(SHEET_TAB_DND_MIME)) return;
        // dragenter/dragleave fire at every child boundary too (the stage's
        // canvases, the panel rail buttons) — only clear when the pointer
        // actually left this wrapper, not when it crossed onto a descendant,
        // or the overlay would strobe on every pixel of internal movement.
        if (e.relatedTarget && e.currentTarget.contains(e.relatedTarget)) return;
        setDragZone(null);
      }}
      onDrop={(e) => {
        if (![...e.dataTransfer.types].includes(SHEET_TAB_DND_MIME)) return;
        e.preventDefault(); e.stopPropagation();
        const droppedKey = e.dataTransfer.getData(SHEET_TAB_DND_MIME);
        setDragZone(null);
        if (!droppedKey) return;
        // recompute the zone from THIS event's own coordinates rather than
        // trusting the dragZone state from the last dragover render — the
        // drop must honor where the pointer actually released, not lag a
        // render behind it.
        const r = e.currentTarget.getBoundingClientRect();
        const zone = dropZoneAt({ w: r.width, h: r.height }, e.clientX - r.left, e.clientY - r.top, { edgesDisabled: !!splitView || !deviceCanSplit });
        if (zone === "center") { toggleInGroup(droppedKey); return; } // join primary group (existing behavior)
        const orientation = zoneToOrientation(zone); // "v" | "h"
        if (refuseIfOverCap(1)) return; // Task 8: refuse rather than silently drop when this would exceed the total-sheet budget
        // dropped sheet frames the reference pane; primary keeps its content
        setSplitView({ orientation, ratio: 0.5, refKey: droppedKey, refSet: [droppedKey] });
      }}>
      <div ref={containerRef} onPointerDownCapture={annotations.onPointerDownCapture} onPointerMoveCapture={annotations.onPointerMoveCapture} onPointerUpCapture={annotations.onPointerUpCapture} onPointerCancelCapture={annotations.onPointerCancelCapture} onDoubleClickCapture={annotations.onDoubleClickCapture} onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp} onPointerLeave={leaveCanvas} onContextMenu={(e) => e.preventDefault()}
        onDoubleClick={(e) => { if (tool === "oneclick") { if (proposal?.regions.length) createProposal(); } else if (tool === "area" || tool === "deduct" || tool === "linear" || tool === "surface" || tool === "zone") finishShape(); else if (tool === "select") editMarkupAt(e); }}
        style={{ position: "absolute", inset: 0, background: darkMode ? "#0b0e14" : "var(--paper-cream)", cursor: tool === "annotation" ? "crosshair" : tool === "select" ? "default" : "none", touchAction: "none" }}>
        {/* aim crosshair (draw modes): the OS cursor is hidden on the canvas — the
              crosshair IS the cursor. Two crisp full-page hairlines riding the
              EFFECTIVE point (angle-locked / endpoint-snapped), the SPLINE STAR at
              the crossing, and a small readout chip in the house style. The 45°
              lock reads as a quiet state change (hairlines brighten, star swells
              cobalt, rubber band thickens) — no extra chrome on the sheet. All
              positioned imperatively in moveCrosshair. */}
        {DS.crosshair !== "none" && (<>
          <div ref={crossVRef} style={{ position: "absolute", top: 0, bottom: 0, width: 1.5, background: DS._hairline, boxShadow: DS._hairlineLock.boxShadowBase, pointerEvents: "none", display: "none", zIndex: 5 }} />
          <div ref={crossHRef} style={{ position: "absolute", left: 0, right: 0, height: 1.5, background: DS._hairline, boxShadow: DS._hairlineLock.boxShadowBase, pointerEvents: "none", display: "none", zIndex: 5 }} />
        </>)}
        <div ref={aimMarkRef} style={{ position: "absolute", left: 0, top: 0, width: 0, height: 0, pointerEvents: "none", display: "none", zIndex: 6, willChange: "transform" }}>
          {/* the aim mark at the crossing — the theme's cursor glyph; it swells
                and glows while the 45° lock holds (drafting: the house star) */}
          <svg width={22} height={22} viewBox="0 0 22 22" style={{ position: "absolute", left: -11, top: -11, transition: "transform 120ms ease, filter 120ms ease", filter: "drop-shadow(0 1px 2px rgba(14,26,46,.3))" }}>
            {DS.aimMark === "ring"
              ? <circle cx={11} cy={11} r={6.5} fill="none" stroke={DS.aimMarkColor} strokeWidth={1.6} />
              : <path d={markerPath(DS.aimMark, 11, 11, DS.aimMark === "star" ? 8.5 : 6)} fill={DS.aimMarkColor} stroke="#fff" strokeWidth={1.4} />}
          </svg>
        </div>
        <div ref={aimChipRef} style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none", display: "none", zIndex: 6, padding: "2px 8px", background: DS.chip.bg, border: `1px solid ${DS.chip.border}`, boxShadow: "var(--shadow-1)", fontFamily: DS.chip.font === "mono" ? "var(--f-mono)" : "var(--f-body)", fontSize: 10.5, fontWeight: 600, color: DS.chip.fg, whiteSpace: "nowrap", willChange: "transform" }} />
        {/* hover readout — what takeoff is under the cursor (DOM-direct) */}
        <div ref={hoverRef} style={{ position: "absolute", display: "none", pointerEvents: "none", zIndex: 8, background: "var(--paper-bright)", border: "1px solid var(--ink)", boxShadow: "var(--shadow-1)", padding: "4px 8px", fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink)", whiteSpace: "nowrap" }} />
        {/* edge-insert ghost — the "+" that rides the selected shape's edge under
              the cursor; pressing there inserts a vertex at that exact spot */}
        <div ref={insGhostRef} style={{ position: "absolute", display: "none", pointerEvents: "none", zIndex: 8, width: 16, height: 16, alignItems: "center", justifyContent: "center", borderRadius: "50%", background: "#1f3fc7", border: "1.5px solid #fff", boxShadow: "var(--shadow-1)", color: "#fff", fontFamily: "var(--f-mono)", fontSize: 12, lineHeight: 1 }}>+</div>
        {/* inline on-canvas text editor — a screen-space overlay pinned to its anchor
              (pan/zoom is frozen while open). Enter commits, Esc cancels, blur commits;
              all on the input's OWN handlers so the global keydown (which returns early
              for INPUT) never interferes. cursor:text overrides the stage's cursor:none. */}
        {editor && (
          <input name="inline-editor" autoComplete="off" ref={editorInputRef} autoFocus defaultValue={editor.value}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); finishEditor(true); } else if (e.key === "Escape") { e.preventDefault(); finishEditor(false); } }}
            onBlur={() => finishEditor(true)}
              placeholder={uiText("Type, Enter to place · Esc cancels")}
            style={{ position: "absolute", left: editor.left, top: editor.top, zIndex: 9, minWidth: 160, padding: "3px 6px", font: "13px var(--f-body, sans-serif)", color: "var(--ink)", background: "var(--paper-bright)", border: "1px solid var(--cobalt)", boxShadow: "0 2px 10px rgba(0,0,0,.18)", borderRadius: 0, cursor: "text", outline: "none" }} />
        )}
        {/* No permanent will-change here: the stage is compositor-promoted only
              for the duration of a gesture (promoteStage / syncTilePanels demote).
              A permanent promotion froze the layer's raster scale and pixelated
              every drawn boundary after a zoom-in. */}
        <div ref={stageRef} style={{ position: "absolute", transformOrigin: "0 0", width: stage.w || undefined, height: stage.h || undefined }}>
          {/* base layer — a small, bounded coarse pyramid placeholder CSS-stretched
                to the panel's full logical footprint (see tileCompositor.ts's
                paintBase); the backing store is NOT sheet-sized, only its CSS box is,
                which is what keeps this a bounded canvas regardless of sheet size */}
          {drawPanels.filter((d) => !d.clip).map((d) => (
            <canvas key={d.drawKey} ref={(el) => { if (el) panelCanvasRefs.current.set(d.drawKey, el); else panelCanvasRefs.current.delete(d.drawKey); }}
              style={{ position: "absolute", left: d.x, top: d.y, width: d.w || undefined, height: d.h || undefined, boxShadow: "0 2px 20px rgba(0,0,0,.18)" }} />
          ))}
          {/* detail layer — one PER SOURCE, a crop of the visible region + margin
                composited from cached tiles at the current zoom (see the detail-view
                effect); group mode no longer shares a single global detail canvas */}
          {drawPanels.filter((d) => !d.clip).map((d) => (
            <canvas key={`detail-${d.drawKey}`} ref={(el) => { if (el) detailCanvasRefs.current.set(d.drawKey, el); else detailCanvasRefs.current.delete(d.drawKey); }}
              style={{ position: "absolute", left: 0, top: 0, display: "none", pointerEvents: "none" }} />
          ))}
          {/* stitch members (#161): base + detail together inside a seam-clip
                wrapper — the div does ALL clipping (overflow:hidden at the member's
                visible box), so the neighbor's margin/border strip near the match
                line can't overpaint the plan. The shadow rides the wrapper: the
                composite reads as one sheet of paper, not N taped panels. */}
          {drawPanels.filter((d) => d.clip).map((d) => (
            <div key={`wrap-${d.drawKey}`} style={{ position: "absolute", left: d.clip.x, top: d.clip.y, width: d.clip.w, height: d.clip.h, overflow: "hidden", boxShadow: "0 2px 20px rgba(0,0,0,.18)" }}>
              <canvas ref={(el) => { if (el) panelCanvasRefs.current.set(d.drawKey, el); else panelCanvasRefs.current.delete(d.drawKey); }}
                style={{ position: "absolute", left: d.x - d.clip.x, top: d.y - d.clip.y, width: d.w || undefined, height: d.h || undefined }} />
              <canvas ref={(el) => { if (el) detailCanvasRefs.current.set(d.drawKey, el); else detailCanvasRefs.current.delete(d.drawKey); }}
                style={{ position: "absolute", left: 0, top: 0, display: "none", pointerEvents: "none" }} />
            </div>
          ))}
          <svg width={stage.w} height={stage.h} viewBox={`0 0 ${stage.w} ${stage.h}`} style={{ position: "absolute", top: 0, left: 0, overflow: "visible", pointerEvents: "none" }}>
            <defs>
              {conditions.map((c) => <HatchPattern key={patId(c)} id={patId(c)} type={c.hatch || "solid"} line={c.color} fill={c.fill} dark={darkMode} />)}
            </defs>
            {/* committed shapes + markups, one group per panel in its local frame */}
            {panels.map((p) => {
              const pShapes = stackedShapes.filter((s) => s.sheet_id === p.key);
              const dn = (vn) => vn.map(([x, y]) => [x * p.img.w, y * p.img.h]);
              const label = labelFor(p);
              return (
                <g key={p.key} transform={`translate(${p.xOffset},0)`} style={{ opacity: rotatingKey === p.key ? 0 : 1, transition: "opacity 120ms ease" }}>
                  {panels.length > 1 && <text x={0} y={-26} fontSize={64} fontWeight={700} fill={darkMode ? "#9a917f" : "#6b6256"}>{uiText(label)}</text>}
                  {/* Fill/stroke logic for one shape lives in shapeGlyphs.jsx,
                        shared byte-for-byte with the reference pane's read-only
                        mirror (ReferencePane.jsx) — see that module for the full
                        measure_role switch. `sel`/`DS.selection` only matter when
                        `sel` is true, which never happens on the reference side. */}
                    {uiText(pShapes.map((s) => renderShapeGlyph(s, {
                    dn, cond: condById[s.condition_id], sel: s.id === selectedId,
                    z: tf.scale, darkMode, selection: DS.selection, patId,
                    })))}
                  {/* vertex handles for the selected shape (drag to reshape) */}
                  {selectedId && (() => {
                    const sel = pShapes.find((s) => s.id === selectedId);
                    if (!sel || sel.measure_role === "count") return null;
                    const qs = dn(sel.verts_norm);
                    const closed = sel.measure_role !== "linear" && sel.measure_role !== "surface_area";
                    const s = tf.scale;
                    const grip = darkMode ? "#0b0e14" : "#faf6ea";
                    const edges = closed ? qs.length : qs.length - 1;
                    return (
                      <g>
                        {/* edge grips — drag moves the whole line; Shift-click inserts a point */}
                        {Array.from({ length: edges }, (_, i) => {
                          const a = qs[i], b = qs[(i + 1) % qs.length];
                          const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
                          const ang = Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI;
                          const ew = 14 / s, eh = 6 / s;
                            return <rect key={tr("m") + i} x={mx - ew / 2} y={my - eh / 2} width={ew} height={eh} rx={eh / 2}
                            transform={`rotate(${ang} ${mx} ${my})`} fill={grip} stroke={DS.selection.color} strokeWidth={1.6 / s} />;
                        })}
                        {/* corner handles — click selects (Delete removes just that point), drag moves.
                              The theme's handle glyph (drafting: paper-filled diamond); a "hollow" theme
                              draws the mark unfilled, the selection color as its outline. */}
                        {qs.map(([x, y], i) => {
                          const isSel = selVert === i;
                          const sz = (isSel ? 6.5 : 5.5) / s;
                          const hollow = DS.selection.handleFill === "hollow";
                          return <g key={"h" + i}>
                            {isSel && <circle cx={x} cy={y} r={9 / s} fill="none" stroke={DS.selection.color} strokeWidth={1.2 / s} opacity={0.5} />}
                            <path d={markerPath(DS.selection.handleShape, x, y, sz)}
                              fill={hollow ? "none" : (isSel ? grip : DS.selection.color)} stroke={hollow ? DS.selection.color : (isSel ? DS.selection.color : "#fff")} strokeWidth={(isSel ? 2 : 1.4) / s} />
                          </g>;
                        })}
                      </g>
                    );
                  })()}
                  {/* markup layer — clouds / callouts / text notes / dimensions / arrows /
                        highlights / bubbles / captured images / vector stamps on this panel.
                        The ink itself lives in markupGlyphs.jsx, shared byte-for-byte with the
                        reference pane's read-only mirror; the paint order and the per-panel
                        scope come from lib/markupPaint.ts, shared the same way. Highlights draw
                        FIRST (behind) so their translucent fill never dims the linework above. A
                        selected markup wears a CONTRASTING halo (white outer ring + cobalt
                        inner) — `selected` is the only thing this side adds. Layer hides via
                        showMarkups. */}
                    {uiText(showMarkups && paintOrderedMarkups(visibleMarkups.filter((m) => m.sheet_id === p.key)).map((m0) =>
                    renderMarkupGlyph(m0, {
                      img: p.img, z: tf.scale, darkMode, condById, rfis, noteQtyLabels, sheetBaseLabel,
                      selected: m0.id === selectedMarkupId, premiumInk: annotations.render,
                      })))}
                  {/* approval seals — ink over pencil (lib/approvals.js): the
                        estimator's APPROVED ring, the agent's AGENT diamond. Its
                        own layer above markups and NOT gated on showMarkups — a
                        seal is the record of review, so it never hides with the
                        annotations. Sizes are sheet-normalized (the bubble
                        convention) so seals print proportionally; inks are token
                        literals via approvalInk (SVG attrs don't resolve CSS vars). */}
                  {approvals.filter((a) => a.sheet_id === p.key).map((a) => {
                    const cx = a.at[0] * p.img.w, cy = a.at[1] * p.img.h;
                    const rad = APPROVAL_R * p.img.w;
                    const ink = approvalInk(a.actor, darkMode);
                    const backing = darkMode ? "rgba(12,15,20,.72)" : "rgba(255,255,255,.72)";
                    if (a.actor === "agent") {
                      const dia = (k) => `M${cx},${cy - rad * k} L${cx + rad * k},${cy} L${cx},${cy + rad * k} L${cx - rad * k},${cy} Z`;
                      return (
                        <g key={a.id} style={{ pointerEvents: "none" }}>
                          <path d={dia(1)} fill={backing} stroke={ink} strokeWidth={rad * 0.07} strokeLinejoin="round" />
                          <path d={dia(0.72)} fill="none" stroke={ink} strokeWidth={rad * 0.035} strokeLinejoin="round" />
                            <text x={cx} y={cy} fill={ink} fontSize={rad * 0.3} fontWeight="700" letterSpacing={rad * 0.02} textAnchor="middle" dominantBaseline="central">{uiText("AGENT")}</text>
                        </g>
                      );
                    }
                    return (
                      <g key={a.id} style={{ pointerEvents: "none" }}>
                        <circle cx={cx} cy={cy} r={rad} fill={backing} stroke={ink} strokeWidth={rad * 0.07} />
                        <circle cx={cx} cy={cy} r={rad * 0.78} fill="none" stroke={ink} strokeWidth={rad * 0.035} />
                          <text x={cx} y={cy} fill={ink} fontSize={rad * 0.26} fontWeight="700" letterSpacing={rad * 0.03} textAnchor="middle" dominantBaseline="central">{uiText("APPROVED")}</text>
                      </g>
                    );
                  })}
                  {/* zone check — transparent dashed region + a cobalt trace on every counted shape */}
                  {zoneCheck && zoneCheck.key === p.key && (
                    <g style={{ pointerEvents: "none" }}>
                      <polygon points={zoneCheck.pts.map(([nx, ny]) => `${nx * p.img.w},${ny * p.img.h}`).join(" ")}
                        fill="rgba(31,63,199,.06)" stroke="#1f3fc7" strokeWidth={2 / tf.scale}
                        strokeDasharray={`${7 / tf.scale} ${5 / tf.scale}`} />
                      {zoneIds && pShapes.filter((sh) => zoneIds.has(sh.id)).map((sh) => {
                        const vs = sh.verts_norm || [];
                        if (vs.length < 2) {
                          return <circle key={"zc" + sh.id} cx={(vs[0]?.[0] || 0) * p.img.w} cy={(vs[0]?.[1] || 0) * p.img.h}
                            r={7 / tf.scale} fill="none" stroke="#1f3fc7" strokeOpacity={0.45} strokeWidth={2.5 / tf.scale} />;
                        }
                        // Closed roles (floor_area/deduct) get a <polygon> like the
                        // main shape renderer — a <polyline> never draws the
                        // closing edge back to the first vertex, so a 4-vertex
                        // room's glow was missing 25% of its outline. linear/
                        // surface_area are genuinely open runs, so they keep
                        // <polyline>, also matching the main renderer.
                        const closed = sh.measure_role !== "linear" && sh.measure_role !== "surface_area";
                        const pts = vs.map(([nx, ny]) => `${nx * p.img.w},${ny * p.img.h}`).join(" ");
                        return closed
                          ? <polygon key={"zc" + sh.id} points={pts} fill="none" stroke="#1f3fc7" strokeOpacity={0.45} strokeWidth={3.5 / tf.scale} strokeLinejoin="round" />
                          : <polyline key={"zc" + sh.id} points={pts} fill="none" stroke="#1f3fc7" strokeOpacity={0.45} strokeWidth={3.5 / tf.scale} strokeLinejoin="round" />;
                      })}
                    </g>
                  )}
                  {/* One-Click proposal preview — dashed cobalt selection, red dashed carve.
                        Handles (corner diamonds + edge grips) rise on the hovered/selected
                        region: drag a corner, drag an edge to move the whole line, Shift-click
                        an edge to add a point, select a corner + Delete to remove it. */}
                  {proposal && proposal.key === p.key && proposal.regions.map((r, i) => {
                    const col = r.kind === "neg" ? "#b03a26" : "#1f3fc7";
                    const s = tf.scale;
                    const grip = darkMode ? "#0b0e14" : "#faf6ea";
                    const show = i === ocHover || (ocSel && ocSel.ri === i);
                    return (
                      <g key={"oc" + i}>
                        <path d={[r.poly, ...(r.holes || [])].map((ring) => `M${ring.map((q) => q.join(",")).join("L")}Z`).join(" ")} fillRule="evenodd"
                          fill={r.kind === "neg" ? "rgba(176,58,38,.18)" : "rgba(31,63,199,.10)"}
                          stroke={col} strokeWidth={2.5 / s} strokeDasharray={`${7 / s} ${4 / s}`} />
                        <path d={starPath(r.seed[0], r.seed[1], 5 / s)} fill={col} stroke="#fff" strokeWidth={1 / s} />
                        {show && r.poly.map((a, k) => {
                          const b = r.poly[(k + 1) % r.poly.length];
                          const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
                          const ang = Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI;
                          const w = 14 / s, h = 6 / s;
                          return <rect key={"e" + k} x={mx - w / 2} y={my - h / 2} width={w} height={h} rx={h / 2}
                            transform={`rotate(${ang} ${mx} ${my})`} fill={grip} stroke={col} strokeWidth={1.6 / s} />;
                        })}
                        {show && r.poly.map(([x, y], k) => {
                          const isSel = ocSel && ocSel.ri === i && ocSel.vi === k;
                          const sz = (isSel ? 6.5 : 5.5) / s;
                          return <g key={"v" + k}>
                            {isSel && <circle cx={x} cy={y} r={9 / s} fill="none" stroke={col} strokeWidth={1.2 / s} opacity={0.5} />}
                            <path d={`M${x},${y - sz} L${x + sz},${y} L${x},${y + sz} L${x - sz},${y} Z`}
                              fill={isSel ? grip : col} stroke={isSel ? col : "#fff"} strokeWidth={(isSel ? 2 : 1.4) / s} />
                          </g>;
                        })}
                      </g>
                    );
                  })}
                  {/* Agent proposals — DASHED pencil pending the accept gate. A
                        finer dash than one-click's selection so the two proposal
                        kinds read apart; the seed star marks the flood seed. The
                        native SVG <title> is the evidence tooltip. Click-to-accept
                        only under the non-drawing tools (select/pan) so a live
                        trace over a proposal is never swallowed; the panel rows
                        and ⏎ accept regardless of tool. */}
                  {agentProposals.filter((ap) => ap.sheet_id === p.key).map((ap) => {
                    const s = tf.scale;
                    const pts = ap.verts_norm.map(([x, y]) => [x * p.img.w, y * p.img.h]);
                    const ded = ap.measure_role === "deduct";
                    const col = ded ? "#b03a26" : "#1f3fc7";
                    const clickable = tool === "select";
                    const ev = ap.evidence || {};
                    const evBits = [
                      ev.schedule_row_tag ? `schedule ${ev.schedule_row_tag}` : "",
                      ev.matched_text && ev.matched_text !== ev.schedule_row_tag ? `matched "${ev.matched_text}"` : "",
                      Array.isArray(ev.seed_norm) ? "seeded by one-click" : "",
                    ].filter(Boolean).join(", ");
                    return (
                      <g key={ap.id} style={{ pointerEvents: clickable ? "auto" : "none", cursor: clickable ? "pointer" : undefined }}
                        onPointerDown={(e) => { if (clickable) e.stopPropagation(); }}
                        onClick={(e) => { if (clickable) { e.stopPropagation(); acceptAgentProposal(ap.id); } }}>
                          <title>{uiText(`Agent proposal — ${condById[ap.condition_id]?.finish_tag || "?"}${ded ? " (deduct)" : ""}, ${fa(ap.area_sf)}. ${evBits ? `Evidence: ${evBits}. ` : ""}Click to accept (⏎ accepts all visible); reject from the Agent panel.`)}</title>
                        <path d={[pts, ...(ap.verts_norm_holes || []).map((h) => h.map(([x, y]) => [x * p.img.w, y * p.img.h]))].map((ring) => `M${ring.map((q) => q.join(",")).join("L")}Z`).join(" ")} fillRule="evenodd"
                          fill={ded ? "rgba(176,58,38,.10)" : "rgba(31,63,199,.07)"}
                          stroke={col} strokeOpacity={0.9} strokeWidth={2 / s}
                          strokeDasharray={`${3.5 / s} ${3.5 / s}`} strokeLinejoin="round" />
                        {Array.isArray(ap.seed_norm) && (
                          <path d={starPath(ap.seed_norm[0] * p.img.w, ap.seed_norm[1] * p.img.h, 4.5 / s)}
                            fill={col} fillOpacity={0.85} stroke="#fff" strokeWidth={1 / s} />
                        )}
                      </g>
                    );
                  })}
                  {/* staged rule-propagation candidates (#88): dashed danger
                        pencil until Apply — the same review-before-ink contract
                        as agent proposals. Non-interactive on the canvas; the
                        banner owns Apply/Cancel (ONE decision for the batch,
                        matching the one-command undo). */}
                  {ruleStage && ruleStage.candidates.filter((c) => c.sheet_id === p.key).map((c, i) => {
                    const s = tf.scale;
                    const pts = c.verts_norm.map(([x, y]) => [x * p.img.w, y * p.img.h]);
                    return (
                      <g key={`rulecand-${i}`} style={{ pointerEvents: "none" }}>
                          <title>{uiText(`Rule candidate — −${fa(c.area_sf)} deduct. ${ruleStage.rule.label}.`)}</title>
                        <polygon points={pts.map((q) => q.join(",")).join(" ")}
                          fill="rgba(176,58,38,.10)" stroke="#b03a26" strokeOpacity={0.9}
                          strokeWidth={2 / s} strokeDasharray={`${3.5 / s} ${3.5 / s}`} strokeLinejoin="round" />
                      </g>
                    );
                  })}
                  {/* Roll-goods cut overlay (#136) — every figured cut drawn to
                        scale over its room in the MATERIAL-TRUE color (carpet tan,
                        vinyl/rubber grey — the engine's own palette, so cuts never
                        mimic a condition's takeoff look), numbered in cutting
                        order, dashed when the room seams across lanes. Inert
                        drawing until edit mode; then each cut owns its pointer
                        events — body slides along the lane, the two end handles
                        pull the run ends, double-click resets to the figured
                        layout. Adjacent cuts overlapping IS the seam (physical
                        pieces carry the seam allowance). */}
                  {rollShow && (rollCutsByPanel.get(p.key) || []).map((ct) => {
                    const s = tf.scale;
                    const col = rollColorForType(ct.material);
                    const runY = ct.laneAxis === "x";     // strips run along screen y; lanes tile across x
                    const hs = 5 / s;
                    const showNum = ct.w * s > 16 && ct.h * s > 16;
                    const strokeCol = ct.overRoll ? "#b03a26" : col;
                    return (
                      <g key={"roll" + ct.id}
                        style={{ pointerEvents: rollEdit ? "auto" : "none", cursor: rollEdit ? "grab" : undefined }}
                        onPointerDown={(e) => beginRollCut(e, ct, "body")}
                        onPointerMove={moveRollCut} onPointerUp={endRollCut} onPointerCancel={endRollCut}
                        onDoubleClick={() => rollEdit && resetRollCut(ct)}>
                          <title>{uiText(`Cut ${ct.num} — ${condById[ct.condId]?.finish_tag || "?"}: ${fmtCheckLen(ct.lenFt, units)} × ${fmtCheckLen(ct.widthFt, units)}${ct.multi ? ` · lane ${ct.laneIndex + 1}/${ct.laneCount}` : ""}${ct.overRoll ? " · LONGER THAN ONE ROLL — needs a cross-seam" : ""}${rollEdit ? " · drag to slide, pull the square handles to resize, double-click to reset" : ""}`)}</title>
                        <rect x={ct.x} y={ct.y} width={ct.w} height={ct.h}
                          fill={col + "38"} stroke={strokeCol}
                          strokeWidth={(ct.overRoll ? 2.6 : 1.8) / s}
                          strokeDasharray={ct.multi ? `${6 / s} ${4 / s}` : undefined} />
                        {showNum && (
                          <g style={{ pointerEvents: "none" }}>
                            <circle cx={ct.x + 11 / s} cy={ct.y + 11 / s} r={7.5 / s} fill={strokeCol} stroke="#fff" strokeWidth={1 / s} />
                              <text x={ct.x + 11 / s} y={ct.y + 14.4 / s} fontSize={10 / s} fontWeight={700} fill="#fff" textAnchor="middle" fontFamily="var(--f-mono,monospace)">{uiText(ct.num)}</text>
                          </g>
                        )}
                        {rollEdit && (
                          <>
                            <rect x={runY ? ct.x + ct.w / 2 - hs : ct.x - hs} y={runY ? ct.y - hs : ct.y + ct.h / 2 - hs}
                              width={hs * 2} height={hs * 2} fill="#fff" stroke={strokeCol} strokeWidth={1.4 / s}
                              style={{ cursor: runY ? "ns-resize" : "ew-resize" }}
                              onPointerDown={(e) => beginRollCut(e, ct, "start")} />
                            <rect x={runY ? ct.x + ct.w / 2 - hs : ct.x + ct.w - hs} y={runY ? ct.y + ct.h - hs : ct.y + ct.h / 2 - hs}
                              width={hs * 2} height={hs * 2} fill="#fff" stroke={strokeCol} strokeWidth={1.4 / s}
                              style={{ cursor: runY ? "ns-resize" : "ew-resize" }}
                              onPointerDown={(e) => beginRollCut(e, ct, "end")} />
                          </>
                        )}
                      </g>
                    );
                  })}
                  {/* Source-trace flash (◎, wired by slice 3) — a transient highlight
                        drawn in the SOURCE panel's own <g>, so it inherits xOffset like
                        every other overlay here. `key={sourceFlash.token}` is load-bearing:
                        a CSS keyframes animation only (re)starts on mount, so without a
                        key tied to the token a repeat trace of the SAME region would find
                        the <rect> already mounted and silently no-op the pulse — no JS
                        tick, per the plan's no-live-tick rule. The guard on `rect` shape
                        matches the try-wrap the export side uses: a malformed value from a
                        future caller must not take the canvas down. */}
                  {sourceFlash && sourceFlash.sheet_id === p.key
                    && Array.isArray(sourceFlash.rect) && sourceFlash.rect.length === 2 && (() => {
                      const [[fnx0, fny0], [fnx1, fny1]] = sourceFlash.rect;
                      const fx0 = Math.min(fnx0, fnx1) * p.img.w, fy0 = Math.min(fny0, fny1) * p.img.h;
                      const fx1 = Math.max(fnx0, fnx1) * p.img.w, fy1 = Math.max(fny0, fny1) * p.img.h;
                      return (
                        <rect key={sourceFlash.token}
                          x={fx0} y={fy0} width={fx1 - fx0} height={fy1 - fy0}
                          fill="rgba(31,63,199,.14)" stroke="#1f3fc7" strokeWidth={3 / tf.scale}
                          style={{ pointerEvents: "none", animation: "sourceFlashPulse .85s ease-in-out 3 forwards" }} />
                      );
                    })()}
                </g>
              );
            })}
            {/* IN-PROGRESS work draws in the INSTRUMENT color — the house cobalt pencil
                  (deduct keeps its danger red). Committed shapes wear the condition's own
                  color; the draft never mimics anyone's takeoff look. Solid, no dashes. */}
            {DS.casing && <line ref={rubberCasingRef} data-draft="casing" stroke={DS.casing.color} strokeWidth={DS.casing.width / tf.scale} strokeOpacity={DS.rubber.opacity} strokeLinecap="round" style={{ display: "none" }} />}
            <line ref={rubberRef} stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.rubber.width / tf.scale} strokeOpacity={DS.rubber.opacity} strokeDasharray={drawDashFor(DS.rubber.dash, tf.scale)} strokeLinecap="round" style={{ display: "none" }} />
            <path ref={arcRef} fill="none" stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.draft.lineWidth / tf.scale} strokeLinecap="round" style={{ display: "none" }} />
            {/* rect/marquee preview shares one ref across four tools, so its paint
                  is a 3-way branch: deduct-rect (AND ring deduct) = danger red;
                  schedule = a NEUTRAL selection gesture, left cobalt + condition
                  fill; rect & symbol marquees are measure tools, themed via DS. */}
            {(() => {
              const rectDeduct = tool === "deduct" || tool === "deduct-rect";
              const rectNeutral = tool === "schedule" || tool === "textcopy";   // selection gestures, not measurement — never themed
              return <rect ref={rectRef}
                fill={rectDeduct ? "rgba(176,58,38,.22)" : rectNeutral ? shapeFill(aCond) : draftFill}
                stroke={rectDeduct ? "#b03a26" : rectNeutral ? "#1f3fc7" : DS.accent}
                strokeWidth={(rectNeutral ? 2 : DS.draft.width) / tf.scale} style={{ display: "none" }} />;
            })()}
            <path ref={cloudRef} fill="rgba(37,99,235,.06)" stroke="#1f3fc7" strokeWidth={2 / tf.scale} strokeDasharray={`${5 / tf.scale} ${4 / tf.scale}`} style={{ display: "none" }} />
            <rect ref={highlightRef} fill="rgba(196,122,16,.18)" stroke="#c47a10" strokeWidth={2 / tf.scale} style={{ display: "none" }} />
            <line ref={dimRef} stroke="#1f3fc7" strokeWidth={2 / tf.scale} strokeDasharray={`${5 / tf.scale} ${4 / tf.scale}`} style={{ display: "none" }} />
            <path ref={hlPathRef} style={{ display: "none" }} />
            {/* Symbol sweep review overlay (#264) — the same glyph language the
                  MCP renders ship: seed = violet double ring, question = orange
                  ?-circle, accepted/committed-to-be = the condition color. */}
            {/* Symbol sweep review overlay (#264) — the same glyph language the
                  MCP renders ship: seed = violet double ring, question = orange
                  ?-circle, accepted/committed-to-be = the condition color. */}
              {sweep && (() => {
                const pp = panels.find((x) => x.key === sweep.key);
                if (!pp) return null;
                const ox = pp.xOffset;
                const k = 1 / tf.scale;
                // translucent like the highlighter — the estimator's own rule:
                // review glyphs must never obstruct the ink they sit on
                const X = (at, color, w) => (
                  <g stroke={color} strokeWidth={w * k} strokeOpacity={0.6}>
                    <line x1={at[0] + ox - 8 * k} y1={at[1] - 8 * k} x2={at[0] + ox + 8 * k} y2={at[1] + 8 * k} />
                    <line x1={at[0] + ox - 8 * k} y1={at[1] + 8 * k} x2={at[0] + ox + 8 * k} y2={at[1] - 8 * k} />
                  </g>
                );
                return (
                  <g pointerEvents="none">
                    <circle cx={sweep.seed.center[0] + ox} cy={sweep.seed.center[1]} r={15 * k} fill="none" stroke={DS.symbol.seed} strokeWidth={2 * k} strokeOpacity={0.65} />
                    <circle cx={sweep.seed.center[0] + ox} cy={sweep.seed.center[1]} r={9 * k} fill="none" stroke={DS.symbol.seed} strokeWidth={2 * k} strokeOpacity={0.65} />
                    {sweep.matches.map((m, i) => {
                      const offTag = sweep.excludedTags.includes((m.label && m.label.label) || "\u2205");
                      return <g key={`m${i}`} opacity={offTag ? 0.22 : 1}>{uiText(X(m.at, activeColor, 2.4))}</g>;
                    })}
                    {sweep.questions.map((q, i) => {
                      if (q.state === "dismissed") return null;
                      if (q.state === "accepted") return <g key={`q${i}`}>{uiText(X(q.at, activeColor, 2.4))}</g>;
                      return (
                        <g key={`q${i}`}>
                          <circle cx={q.at[0] + ox} cy={q.at[1]} r={13 * k} fill="none" stroke={DS.symbol.question} strokeWidth={(i === sweep.qIndex ? 3.4 : 2.2) * k} strokeOpacity={i === sweep.qIndex ? 0.85 : 0.6} />
                          <text x={q.at[0] + ox} y={q.at[1] + 5 * k} textAnchor="middle" fill={DS.symbol.question} fillOpacity={0.85} fontSize={14 * k} fontWeight="700" fontFamily="JetBrains Mono, monospace">?</text>
                        </g>
                      );
                    })}
                  </g>
                );
              })()}
              {/* Doors suite overlay: each door's own swing and leaf, coloured by
                  hardware set; dashed = needs an answer; the schedule's rows boxed
                  in the same colours on the schedule sheet. Screen-constant widths. */}
              {doorSuiteOn && panels.map((p) => {
                const k = 1 / tf.scale;
                const out = [];
                const rd = doorReadsEff[p.key];
                if (rd?.status === "done") {
                  const marks = p.key === doorKey && doorView ? doorView.openings : null;
                  rd.doors.forEach((d, i) => {
                    if (rd.hidden?.[i]) return;   // a second find of an opening already drawn
                    const o = marks ? marks[i] : null;
                    const color = o?.row ? doorSetColor(o.row.hwSet, doorSetOrder) : DOOR_NEUTRAL;
                    const asked = rd.withheld[i] || (doorView && p.key === doorKey && doorView.questions.some((q) => q.door === i && !doorAnswers[q.id]));
                    const faded = o?.leftOut && !rd.withheld[i];
                    const sel = (doorSel && doorSel.key === p.key && doorSel.i === i) || (!!o?.mark && o.mark === doorHover);
                    const paths = d.leaves.map((l, j) => {
                      const h = l.hinge, t = l.tip, r = l.radiusPt, sw = (l.sweepDeg || 90) * Math.PI / 180;
                      const a0 = Math.atan2(t[1] - h[1], t[0] - h[0]);
                      const ends = [1, -1].map((sg) => [h[0] + r * Math.cos(a0 + sg * sw), h[1] + r * Math.sin(a0 + sg * sw)]);
                      const inBox = (q) => q[0] >= d.box[0] - r * 0.15 && q[0] <= d.box[2] + r * 0.15 && q[1] >= d.box[1] - r * 0.15 && q[1] <= d.box[3] + r * 0.15;
                      const sg = inBox(ends[0]) || !inBox(ends[1]) ? 0 : 1;
                      const e = ends[sg];
                      const H = doorToImg(rd, p, h), T = doorToImg(rd, p, t), E = doorToImg(rd, p, e);
                      const R = Math.hypot(T[0] - H[0], T[1] - H[1]);
                      // sweep direction survives the page rotation: decide it in image space
                      const cross = (T[0] - H[0]) * (E[1] - H[1]) - (T[1] - H[1]) * (E[0] - H[0]);
                      return <path key={j} d={`M${H[0] + p.xOffset},${H[1]} L${T[0] + p.xOffset},${T[1]} A${R},${R} 0 0 ${cross > 0 ? 1 : 0} ${E[0] + p.xOffset},${E[1]}`} />;
                    });
                    // the opening itself: the jamb-to-jamb line across the wall
                    const [ja, jb] = openingLine(d).map((q) => doorToImg(rd, p, q));
                    paths.push(<path key="jamb" d={`M${ja[0] + p.xOffset},${ja[1]} L${jb[0] + p.xOffset},${jb[1]}`} />);
                    // a door the detector added with no swing to trace (a cased opening, a slider): its box, dotted
                    if (d.added && !d.leaves.length) {
                      const q = [[d.box[0], d.box[1]], [d.box[2], d.box[1]], [d.box[2], d.box[3]], [d.box[0], d.box[3]]].map((v) => doorToImg(rd, p, v));
                      paths.push(<path key="box" strokeDasharray={`${2 * k} ${4 * k}`} d={`M${q.map((v) => `${v[0] + p.xOffset},${v[1]}`).join(" L")} Z`} />);
                    }
                    const c = doorCenter(d);
                    const C = doorToImg(rd, p, [c.x, c.y]);
                    const rPx = Math.abs(doorToImg(rd, p, [c.x + c.r, c.y])[0] - C[0]) + Math.abs(doorToImg(rd, p, [c.x + c.r, c.y])[1] - C[1]);
                    out.push(
                      <g key={`door-${p.key}-${i}`} opacity={faded ? 0.3 : 1}>
                        <g fill="none" stroke={color} strokeWidth={(sel ? 4 : 2.6) * k} strokeOpacity={0.9} strokeDasharray={asked ? `${6 * k} ${4 * k}` : undefined} strokeLinecap="round">{paths}</g>
                        <circle cx={C[0] + p.xOffset} cy={C[1]} r={Math.max(rPx * 0.75, 10 * k)} fill="transparent" stroke="none" style={{ pointerEvents: "all", cursor: "pointer" }}
                          onPointerDown={(e) => { e.stopPropagation(); }} onClick={(e) => { e.stopPropagation(); setDoorSel({ key: p.key, i }); }}>
                          <title>{o?.mark ? `Door ${o.mark}` : d.added ? `${DOOR_KIND_LABEL[d.added.kind] || "Door"} found by the door detector, no number` : "Door with no number"}</title>
                        </circle>
                        {o?.mark && rPx * tf.scale > 16 && (
                          <text x={C[0] + p.xOffset} y={C[1] - rPx * 0.9} textAnchor="middle" fontSize={11 * k} fontWeight={700} fontFamily="JetBrains Mono, monospace"
                            fill={color} stroke={darkMode ? "#0b0e14" : "#ffffff"} strokeWidth={3 * k} paintOrder="stroke" style={{ pointerEvents: "none" }}>{o.mark}</text>
                        )}
                      </g>,
                    );
                  });
                }
                if (doorDocs?.schedule && doorDocs.schedule.key === p.key) out.push(<g key="drows">{doorRowBoxes(p.img, tf.scale, p.xOffset)}</g>);
                return out.length ? <g key={`doors-${p.key}`}>{out}</g> : null;
              })}
              {/* casing under-stroke (Site Glass): a JSX twin BEHIND each draft
                  stroke, tracing the SAME geometry (arc-flattened where a bow is
                  set). Width ownership is DUAL like the rubber core — this twin
                  declares width from the ~11 Hz tf mirror (heals wheel-zoom with a
                  stationary pointer). Surface is un-themed, so no casing there.
                  The polygon's strokeDasharray MUST mirror the accent polygon's
                  four lines below — same expression, same dash, so a dashed
                  zone accent never rides a solid casing ribbon. */}
            {DS.casing && poly.length >= 2 && tool !== "surface" && (tool === "linear"
              ? <polyline data-draft="casing" points={(curveIdx.length ? flattenArcRing(poly, curveIdx, false) : poly).map((p) => p.join(",")).join(" ")} fill="none" stroke={DS.casing.color} strokeWidth={DS.casing.width / tf.scale} strokeLinecap="round" strokeLinejoin="round" />
              : ringOutline
                ? <polyline data-draft="casing" points={(curveIdx.length ? flattenArcRing(poly, curveIdx, false) : poly).map((p) => p.join(",")).join(" ")} fill="none" stroke={DS.casing.color} strokeWidth={DS.casing.width / tf.scale} strokeDasharray={tool === "zone" ? `${7 / tf.scale} ${5 / tf.scale}` : drawDashFor(DS.draft.dash, tf.scale)} strokeLinecap="round" strokeLinejoin="round" />
                : <polygon data-draft="casing" points={(curveIdx.length ? flattenArcRing(poly, curveIdx, tool !== "zone" && !bowOpen) : poly).map((p) => p.join(",")).join(" ")} fill="none" stroke={DS.casing.color} strokeWidth={DS.casing.width / tf.scale} strokeDasharray={tool === "zone" ? `${7 / tf.scale} ${5 / tf.scale}` : drawDashFor(DS.draft.dash, tf.scale)} strokeLinejoin="round" />)}
            {poly.length >= 2 && (tool === "linear" || tool === "surface"
              ? <polyline points={(curveIdx.length ? flattenArcRing(poly, curveIdx, false) : poly).map((p) => p.join(",")).join(" ")} fill="none" stroke={tool === "surface" ? activeColor : DS.accent} strokeWidth={(tool === "surface" ? 3.5 : DS.draft.lineWidth) / tf.scale} strokeDasharray={tool === "surface" ? `${10 / tf.scale} ${3 / tf.scale} ${2 / tf.scale} ${3 / tf.scale}` : drawDashFor(DS.draft.dash, tf.scale)} strokeLinecap="round" strokeLinejoin="round" />
              : ringOutline
                ? <polyline points={(curveIdx.length ? flattenArcRing(poly, curveIdx, false) : poly).map((p) => p.join(",")).join(" ")} fill="none" stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.draft.width / tf.scale} strokeDasharray={tool === "zone" ? `${7 / tf.scale} ${5 / tf.scale}` : drawDashFor(DS.draft.dash, tf.scale)} strokeLinecap="round" strokeLinejoin="round" />
                : <polygon points={(curveIdx.length ? flattenArcRing(poly, curveIdx, tool !== "zone" && !bowOpen) : poly).map((p) => p.join(",")).join(" ")} fill={poly.length >= 3 ? (tool === "deduct" ? "rgba(176,58,38,.22)" : tool === "zone" ? rgbaFromHex(DS.accent, 0.06) : draftFill) : "none"} stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.draft.width / tf.scale} strokeDasharray={tool === "zone" ? `${7 / tf.scale} ${5 / tf.scale}` : drawDashFor(DS.draft.dash, tf.scale)} />)}
            {/* outline mode: dotted ghost of the on-commit closing edge (last vertex → first), so the loop is visible without a fill. */}
            {ringOutline && poly.length >= 3 && !bowOpen && (
              <line x1={poly[poly.length - 1][0]} y1={poly[poly.length - 1][1]} x2={poly[0][0]} y2={poly[0][1]}
                stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.draft.width / tf.scale}
                strokeLinecap="round" strokeDasharray={`${1 / tf.scale} ${5 / tf.scale}`} />
            )}
            {/* Bold the most recent segment so you see where you just clicked.
                  A closed arc bolds AS the arc — a straight chord drawn across
                  the bow would read as the boundary and it isn't one. Nothing
                  bolds while a bow is still open; the live preview is the
                  segment then. */}
            {poly.length >= 2 && !bowOpen && DS.lastSegWidth != null && (
              polyCurve[poly.length - 2] && poly.length >= 3
                ? <>
                  {DS.casing && tool !== "surface" && <path data-draft="casing" d={arcPathD(poly[poly.length - 3], poly[poly.length - 2], poly[poly.length - 1])} fill="none"
                    stroke={DS.casing.color} strokeWidth={DS.casing.width / tf.scale} strokeLinecap="round" />}
                  <path d={arcPathD(poly[poly.length - 3], poly[poly.length - 2], poly[poly.length - 1])} fill="none"
                    stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.lastSegWidth / tf.scale} strokeLinecap="round" />
                </>
                : <>
                  {DS.casing && tool !== "surface" && <line data-draft="casing" x1={poly[poly.length - 2][0]} y1={poly[poly.length - 2][1]} x2={poly[poly.length - 1][0]} y2={poly[poly.length - 1][1]}
                    stroke={DS.casing.color} strokeWidth={DS.casing.width / tf.scale} strokeLinecap="round" />}
                  <line x1={poly[poly.length - 2][0]} y1={poly[poly.length - 2][1]} x2={poly[poly.length - 1][0]} y2={poly[poly.length - 1][1]}
                    stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.lastSegWidth / tf.scale} strokeLinecap="round" />
                </>
            )}
            {/* close preview — the ring tools' ghost cursor→first edge (theme-
                  gated; positioned by moveCrosshair). Width AND dash dual-owned with
                  the mover: both declared here from the tf mirror, both re-written
                  there from tfRef — always the same scale read, both cadences. */}
            {DS.closePreview && (tool === "area" || tool === "deduct" || tool === "zone") && poly.length >= 2 && (
              <line ref={closeRef} data-draft="close-preview" stroke={draftStroke(tool, draftInvalid, DS)} strokeWidth={DS.closePreview.width / tf.scale} strokeDasharray={drawDashFor(DS.closePreview.dash, tf.scale)} strokeLinecap="round" style={{ display: "none" }} />
            )}
            {poly.map((p, i) => {
              const isLast = i === poly.length - 1;
              // Preserve the affordance: a CURVE point reads as a round handle,
              // a corner as the theme's vertex glyph (drafting: the house star).
              // Only the CORNER shape is themed — curve points stay circles so
              // the ⌥-curve gesture is always legible, whatever the theme.
              // casing backing (Site Glass): the same glyph fattened in the
              // casing color, so each vertex carries a sheet-contrast halo. When
              // off (every other style), the bare element is returned EXACTLY as
              // before — no wrapper — so Drafting Table is byte-identical.
              const cased = DS.vertex.casing && DS.casing;
              if (polyCurve[i]) {
                const dot = <circle key={i} cx={p[0]} cy={p[1]} r={(isLast ? 4.5 : 3.4) / tf.scale}
                  fill={isLast ? "#fff" : DS.accent} stroke={DS.accent} strokeWidth={(isLast ? 2 : 1.4) / tf.scale} />;
                if (!cased) return dot;
                return (
                  <g key={i}>
                    <circle data-draft="casing" cx={p[0]} cy={p[1]} r={((isLast ? 4.5 : 3.4) + 1.5) / tf.scale} fill={DS.casing.color} stroke={DS.casing.color} strokeWidth={1 / tf.scale} />
                    <circle cx={p[0]} cy={p[1]} r={(isLast ? 4.5 : 3.4) / tf.scale}
                      fill={isLast ? "#fff" : DS.accent} stroke={DS.accent} strokeWidth={(isLast ? 2 : 1.4) / tf.scale} />
                  </g>
                );
              }
              const d = markerPath(DS.vertex.shape, p[0], p[1], (isLast ? DS.vertex.lastR : DS.vertex.r) / tf.scale);
              if (!d) return null;   // "none" — this theme places no corner marks
              if (!cased) return <path key={i} d={d}
                fill={isLast ? "#fff" : DS.accent} stroke={DS.accent} strokeWidth={(isLast ? 2 : 1) / tf.scale} />;
              return (
                <g key={i}>
                  <path data-draft="casing" d={d} fill={DS.casing.color} stroke={DS.casing.color} strokeWidth={3 / tf.scale} />
                  <path d={d} fill={isLast ? "#fff" : DS.accent} stroke={DS.accent} strokeWidth={(isLast ? 2 : 1) / tf.scale} />
                </g>
              );
            })}
            {/* edge labels (Precision "all" / Site Glass "last2"): placed-edge
                  midpoints priced with the draft's own sheet scale, in the check
                  tool's white-halo idiom. Surface keeps its own readout; a segment
                  touching a curve control is skipped — its chord would float off
                  the flattened arc and misstate the length. */}
            {DS.edgeLabels && tool !== "surface" && poly.length >= 2 && liveUpp ? (() => {
              const z = tf.scale;
              const start = DS.edgeLabels === "last2" ? Math.max(0, poly.length - 3) : 0;
              const kids = [];
              for (let i = start; i < poly.length - 1; i++) {
                if (polyCurve[i] || polyCurve[i + 1]) continue;   // arc segment — chord label would misstate
                const a = poly[i], b = poly[i + 1];
                kids.push(
                  <text key={i} data-draft="edge-label" x={(a[0] + b[0]) / 2} y={(a[1] + b[1]) / 2 - 6 / z} fontSize={10.5 / z} fontWeight={600}
                    fill={DS.accent} textAnchor="middle" stroke="#fff" strokeWidth={3 / z} paintOrder="stroke">
                      {uiText(fmtCheckLen(Math.hypot(b[0] - a[0], b[1] - a[1]) * liveUpp, units))}
                  </text>
                );
              }
                return <g>{uiText(kids)}</g>;
            })() : null}
            {calib.length === 2 && <line x1={calib[0][0]} y1={calib[0][1]} x2={calib[1][0]} y2={calib[1][1]} stroke={DS.accent} strokeWidth={2 / tf.scale} />}
            {calib.map((p, i) => <path key={i} d={starPath(p[0], p[1], 3.5 / tf.scale)} fill={DS.accent} />)}
            {alignPt && <path d={starPath(alignPt[0], alignPt[1], 4.5 / tf.scale)} fill={DS.accent} stroke="#fff" strokeWidth={1 / tf.scale} />}
            {/* check tool — dashed so it never reads as calibrate's solid line */}
            {tool === "check" && check.length === 2 && !checkCross && (
              <>
                <line x1={check[0][0]} y1={check[0][1]} x2={check[1][0]} y2={check[1][1]} stroke={DS.accent} strokeWidth={2 / tf.scale} strokeDasharray={`${6 / tf.scale} ${4 / tf.scale}`} />
                {checkFeet != null && (
                  <text x={(check[0][0] + check[1][0]) / 2} y={(check[0][1] + check[1][1]) / 2 - 8 / tf.scale}
                    fontSize={12.5 / tf.scale} fontWeight={700} fill={DS.accent} textAnchor="middle"
                      stroke="#fff" strokeWidth={3 / tf.scale} paintOrder="stroke">{uiText(fmtCheckLen(checkFeet, units))}</text>
                )}
              </>
            )}
            {tool === "check" && check.map((p, i) => <path key={"ck" + i} d={starPath(p[0], p[1], 3.5 / tf.scale)} fill={DS.accent} />)}
            {/* scale-acceptance guide — an ephemeral calibrated ruler so a 2×-off
                  scale is visually obvious against known elements (a door is ~3′) */}
            {SHOW_SCALE_GUIDE && scaleGuide && panelKeySet.has(scaleGuide.key) && (() => {
              const [gx, gy] = scaleGuide.at;
              const z = tf.scale;
              const unitPx = scaleGuide.px / (units === "metric" ? scaleGuide.feet * M_PER_FT : scaleGuide.feet); // one ft (or 1 m) in px
              const step = unitPx * z >= 6 ? 1 : unitPx * z * 5 >= 6 ? 5 : 0;
              const nUnits = units === "metric" ? Math.round(scaleGuide.feet * M_PER_FT) : scaleGuide.feet;
              const ticks = step ? Array.from({ length: Math.floor(nUnits / step) + 1 }, (_, i) => i * step) : [0, nUnits];
              // "at 1/8″ = 1′-0″" reads right for a scale string; a source word ("calibrated", "custom") reads better parenthesized
              const scaleTxt = /[=:]/.test(scaleGuide.label) ? `at ${scaleGuide.label}` : `(${scaleGuide.label})`;
              const lbl = units === "metric" ? `${nUnits} m ${scaleTxt}` : `${scaleGuide.feet}′ ${scaleTxt}`;
              const cap = units === "metric" ? "a door is about 0.9 m — if this bar looks wildly off, the scale is wrong" : "a door opening is about 3′ — if this bar looks wildly off, the scale is wrong";
              return (
                <g style={{ pointerEvents: "none" }}>
                  <line x1={gx} y1={gy} x2={gx + scaleGuide.px} y2={gy} stroke="#fff" strokeWidth={7 / z} strokeLinecap="round" />
                  <line x1={gx} y1={gy} x2={gx + scaleGuide.px} y2={gy} stroke="#1f3fc7" strokeWidth={3 / z} />
                  {ticks.map((u) => (
                    <line key={u} x1={gx + u * unitPx} y1={gy - (u % 5 === 0 ? 8 : 5) / z} x2={gx + u * unitPx} y2={gy}
                      stroke="#1f3fc7" strokeWidth={(u % 5 === 0 ? 2 : 1.2) / z} />
                  ))}
                  <text x={gx + scaleGuide.px / 2} y={gy - 14 / z} fontSize={13 / z} fontWeight={700} fill="#1f3fc7"
                      textAnchor="middle" stroke="#fff" strokeWidth={3.5 / z} paintOrder="stroke">{uiText(lbl)}</text>
                  <text x={gx + scaleGuide.px / 2} y={gy + 16 / z} fontSize={10.5 / z} fill="#5b544a"
                      textAnchor="middle" stroke="#fff" strokeWidth={3 / z} paintOrder="stroke">{uiText(cap)}</text>
                </g>
              );
            })()}
            {/* snap-to-vector indicator (star) */}
            <path ref={snapMarkRef} fill="#1f6b4a" stroke="#fff" strokeWidth={1 / tf.scale} style={{ display: "none" }} />
            {/* markup draft marker (first click of cloud/callout) */}
            {markupDraft && <path d={starPath(markupDraft[0], markupDraft[1], 5 / tf.scale)} fill="#1f3fc7" />}
            {uiText(annotations.layer)}
          </svg>
        </div>

        {status !== "ready" && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--ink-muted)", fontSize: 15 }}>
              {uiText(status === "loading" && "Loading sheets…")}
              {uiText(status === "rendering" && "Rendering sheet…")}
              {uiText(status === "empty" && "No PDFs yet — click “Open PDF” or drag a plan onto the canvas.")}
              {status === "error" && <span style={{ color: "var(--c-danger)" }}>{uiText("Error: ")}{uiText(err)}</span>}
          </div>
        )}

        {/* corner cluster — fit + sheet-invert only. Zoom buttons are gone:
              wheel-notch/pinch zoom toward the cursor already owns zooming
              (precision-instrument rule: no control that duplicates a gesture).
              Left presses stop here (the container's onPointerDown
              setPointerCapture()s every left press, which retargets pointerup
              so the composed click never reaches these buttons); right/middle/
              Space presses still bubble so a pan can start on top, and dblclick
              is stopped so rapid clicks can't finishShape() */}
          <div data-view-controls onPointerDown={(e) => { if (e.button === 0 && !spaceRef.current) e.stopPropagation(); }} onDoubleClick={(e) => e.stopPropagation()}
            style={dockBottom
              ? { position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", display: "flex", flexDirection: "column", gap: 2, padding: 4, border: "1px solid var(--ink-faint)", borderRadius: 10, background: "var(--paper-cream)", boxShadow: "var(--shadow-2)", zIndex: 24 }
              : { position: "absolute", left: 14, bottom: 14, display: "flex", flexDirection: "column", gap: 6 }}>
            {(() => {
              // Premium's view group: zoom in / out about the canvas centre, fit, focus, and the
              // open source's sheet invert. The wheel and pinch still zoom toward the cursor.
              const face = (on) => dockBottom
                ? { width: 32, height: 32, borderRadius: 7, border: "1px solid transparent", background: on ? "var(--cobalt)" : "transparent", color: on ? "var(--accent-contrast)" : "var(--ink)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }
                : { width: 34, height: 34, borderRadius: 0, border: `1px solid ${on ? "var(--cobalt)" : "var(--ink-faint)"}`, background: on ? "var(--cobalt)" : "var(--paper-bright)", color: on ? "var(--accent-contrast)" : "var(--ink)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12 };
              const zoomStep = (f) => {
                const el = containerRef.current;
                if (!el) return;
                promoteStage();                                    // same opening as a wheel gesture
                gestureUntilRef.current = performance.now() + GESTURE_MS;
                const r = el.getBoundingClientRect();
                zoomAround(r.width / 2, r.height / 2, f);           // about the visible canvas centre
              };
              return (<>
                {dockBottom && <button onClick={() => zoomStep(1.25)} title={tr("Zoom in")} aria-label={tr("Zoom in")} style={face(false)}><Icon name="zoomIn" size={16} /></button>}
                {dockBottom && <button onClick={() => zoomStep(0.8)} title={tr("Zoom out")} aria-label={tr("Zoom out")} style={face(false)}><Icon name="zoomOut" size={16} /></button>}
                <button onClick={() => stage.w && fitToView(stage.w, stage.h)} title={tr("Fit sheet to view")} aria-label={tr("Fit sheet to view")} style={{ ...face(false), ...(!dockBottom && language === "ru" ? { width: "auto", minWidth: 114, padding: "0 8px", whiteSpace: "nowrap" } : {}) }}>{dockBottom ? <Icon name="fit" size={16} /> : (language === "ru" ? "Лист целиком" : "fit")}</button>
                <button onClick={() => toggleFocusMode()} title={uiText(focusMode ? "Focus off — show all chrome (F)" : "Focus — trade chrome for canvas height (F)")} aria-label={tr("Focus mode")} aria-pressed={focusMode} style={face(focusMode)}>{dockBottom ? <Icon name="focus" size={16} /> : "⛶"}</button>
                <button name="view-3d" onClick={open3d} title="3D — this sheet's takeoff stood up: floors, base, transitions, wall runs, stairs. Read-only." aria-label="3D view" aria-pressed={!!show3d} style={{ ...face(!!show3d), fontSize: 11, fontWeight: 700 }}>3D</button>
                <button onClick={() => setDarkMode((d) => !d)} title={uiText(darkMode ? "Sheet back to positive print" : "Invert sheet — negative print (affects marked-set export)")} aria-label={tr("Invert sheet")} aria-pressed={darkMode} style={face(darkMode)}>{dockBottom ? <Icon name="invert" size={16} /> : (darkMode ? "☀" : "☾")}</button>
              </>);
            })()}
          </div>
          {show3d && uppFor(show3d.sheetId) > 0 && (
            <Lazy3D shapes={shapes} conditions={conditions} sheetId={show3d.sheetId}
              sheet={{ widthPx: show3d.dims.w, heightPx: show3d.dims.h, upp: uppFor(show3d.sheetId) }}
              sheetLabel={tabLabel(show3d.sheetId)} projectName={projectName}
              scaleLabel={STANDARD_SCALES.find((x) => Math.abs(x.upp - uppFor(show3d.sheetId)) < 1e-9)?.label || ""}
              planSkin={planSkin3d?.sheetId === show3d.sheetId ? planSkin3d : null} hiddenConds={viewHidden}
              initialSelectedId={selectedId}
              onSelectShape={(sid) => { if (shapes.some((x) => x.id === sid)) selectShape(sid); }}
              onFail={(msg) => setCommitMsg(`The 3D view could not load (${msg}) — reload the page.`)}
              levelSheets={openTabs.filter((k) => !isStitchKey(k)).map((k) => ({ id: k, label: tabLabel(k) }))}
              upperSheetId={upperSheet3d} upperSkin={upperSkin3d?.sheetId === upperSheet3d ? upperSkin3d : null} onPickUpperSheet={setUpperSheet3d}
              onClose={() => { setShow3d(null); setUpperSheet3d(null); }} />
          )}

        {/* Read page text (#471) and Read picture text (#489) — beside the
              corner cluster, above the status bar (and above the rule banner
              while one shows): one row per scan or hybrid on screen (named in
              a group), and a
              Cancel row for a read still running on a sheet that left the
              screen. Same press handling as the cluster. */}
        <div onPointerDown={(e) => { if (e.button === 0 && !spaceRef.current) e.stopPropagation(); }} onDoubleClick={(e) => e.stopPropagation()}
          style={{ ...readControlPlacement({ bannerHeight: ruleBannerH }), zIndex: Z.canvasUi, maxWidth: `calc(100% - ${READ_CONTROL_LEFT + CANVAS_EDGE}px)` }}>
          <PageReadControl
            rows={[
              ...panels.filter((p) => !isStitchKey(p.key)).map((p) => ({
                key: p.key,
                label: labelFor(p),
                view: pageReadView({ textless: readableByKey[p.key] === undefined ? undefined : readableByKey[p.key] !== null, avail: ocrAvail, status: pageReader.status(p.key) }),
                what: readableByKey[p.key] === "picture" ? "picture" : "page",
              })),
              ...backgroundRows(pageReader.active(), groupKeys, tabLabel).map((r) => ({ ...r, background: true })),
            ]}
            onRead={(key) => { readSheet(key); }}
            onReadAgain={(key) => { readSheet(key, { force: true }); }}
            onCancel={(key) => pageReader.cancel(key)}
            onRetry={() => { ocrAvailability().catch(() => { }); }} />
        </div>
      </div>

      {/* correction-rule banner (#88): offer after a qualifying Cut Out, then
            the staged batch's Apply/Cancel. Floats alone bottom-center (the
            transient commitMsg text lives in the status bar now); Dismiss/
            Cancel are always one click — a rule is never applied silently. */}
      {(ruleOffer || ruleStage) && (
        <div ref={ruleBannerRef} style={{ position: "absolute", left: "50%", bottom: dockBottom ? 70 : 14, transform: "translateX(-50%)", zIndex: Z.canvasUi, display: "flex", flexDirection: "column-reverse", alignItems: "center", gap: 8, maxWidth: "82%", pointerEvents: "none" }}>
        {(ruleOffer || ruleStage) && (
          <div style={{ pointerEvents: "auto", display: "flex", alignItems: "center", gap: 10, padding: "8px 14px", background: "var(--paper-bright)", border: "1.5px dashed var(--c-danger)", boxShadow: "var(--shadow-1)", fontSize: 12.5, color: "var(--ink)", maxWidth: "100%" }}>
            {ruleOffer ? (<>
              <span>{uiText("Make this a rule for all ")}<b>{uiText(ruleOffer.tag)}</b> {uiText("rooms? Excludes enclosed regions under ")}<b>{uiText(ruleOffer.seed.max_area_sf)} {uiText("SF")}</b>.</span>
              <button onClick={previewRule}
                style={{ padding: "4px 12px", background: "var(--paper-bright)", border: "1.5px solid var(--cobalt)", color: "var(--cobalt)", fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" }}>
                {uiText("Preview")}</button>
              <button onClick={() => setRuleOffer(null)}
                style={{ padding: "4px 12px", background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", color: "var(--ink-muted)", fontSize: 12, cursor: "pointer" }}>
                {uiText("Dismiss")}</button>
            </>) : (<>
              <span><b>{uiText(ruleStage.candidates.length)}</b> {uiText("matching region")}{uiText(ruleStage.candidates.length === 1 ? "" : "s")} {uiText("staged as dashed deducts — ")}{uiText(ruleStage.rule.label)}.</span>
              <button onClick={applyStagedRule}
                style={{ padding: "4px 12px", background: "var(--paper-bright)", border: "1.5px solid var(--cobalt)", color: "var(--cobalt)", fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" }}>
                {uiText("Apply ")}{uiText(ruleStage.candidates.length)}</button>
              <button onClick={() => setRuleStage(null)}
                style={{ padding: "4px 12px", background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", color: "var(--ink-muted)", fontSize: 12, cursor: "pointer" }}>
                {uiText("Cancel")}</button>
            </>)}
          </div>
        )}
        </div>
      )}
      {/* top-center stack: accept pill + dictation chip share one flex column
            so simultaneous voice + pending proposals can never overlap. */}
      {(voiceChip || pendingCommitted.length > 0) && (
        <div style={{ position: "absolute", left: "50%", top: 12, transform: "translateX(-50%)", zIndex: Z.canvasUi, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, pointerEvents: "none" }}>
          {/* accept pill — visible while committed-but-unreviewed shapes (an
            imported MCP takeoff) are on the visible sheets; they render dashed
            pencil until accepted. One click, one undo entry. */}
          {/* proposals (#365): one pill per BATCH. A forty-room detect run the
            agent proposed under one label is one Accept and one Reject, not
            forty; un-batched pending shapes keep the original pill. */}
          {pendingGroups.map((g) => {
            const n = g.ids.length;
          const label = g.proposal ? g.proposal.label : formatMessage("Proposed measurements: {0}", [n]);
            const key = g.proposal ? g.proposal.id : "_loose";
            return (
              <div key={key} data-proposal-pill={key} style={{ pointerEvents: "auto", display: "flex", alignItems: "stretch", background: "var(--paper-bright)", border: "1.5px dashed var(--cobalt)", boxShadow: "var(--shadow-1)", fontSize: 12.5, fontWeight: 600, color: "var(--cobalt)" }}>
                <button onClick={() => acceptProposalGroup(g)}
                title={uiText(g.proposal
                    ? `Proposal “${g.proposal.label}”${g.proposal.rationale ? ` — ${g.proposal.rationale}` : ""}. ${n} shape${n === 1 ? "" : "s"} render${n === 1 ? "s" : ""} dashed pending your review. Accept makes the whole batch ink in one step (⌘Z undoes).`
                  : `${n} machine-proposed shape${n === 1 ? "" : "s"} render${n === 1 ? "s" : ""} dashed pending your review. Accept makes them ink (⌘Z undoes); to reject one, select it and press Delete.`)}
                  style={{ padding: "6px 12px", border: "none", background: "transparent", color: "inherit", font: "inherit", cursor: "pointer" }}>
                {uiText("Accept ")}{g.proposal ? <>“{label}” <span style={{ fontWeight: 500, color: "var(--ink-muted)" }}>· {uiText(n)}</span></> : label}
                </button>
                <button onClick={() => rejectProposalGroup(g)}
                title={uiText(`Reject ${g.proposal ? `“${g.proposal.label}”` : "these shapes"} — removes ${n === 1 ? "the pending shape" : `all ${n} pending shapes`} (⌘Z restores).`)}
                aria-label={uiText("Reject proposal")}
                  style={{ padding: "6px 9px", border: "none", borderLeft: "1px dashed var(--cobalt)", background: "transparent", color: "var(--c-danger)", font: "inherit", cursor: "pointer" }}>✕</button>
              </div>
            );
          })}
          {/* live dictation chip (RFC #59 recognizer): top-center, fixed — NOT
            cursor-following, the cursor is busy aiming for deixis. Shows the
            hold state, decode state, and a brief flash of the heard transcript
            (the receipt); outcomes land in the commitMsg bar like every command. */}
          {voiceChip && (
            <div style={{ padding: "5px 12px", background: "var(--surface-pop)", border: `1px solid ${voiceChip.tone === "live" || voiceChip.tone === "offer" ? "var(--cobalt)" : "var(--ink-faint)"}`, boxShadow: "var(--shadow-1)", fontFamily: "var(--f-mono)", fontSize: 11.5, color: "var(--ink)", display: "flex", alignItems: "center", gap: 7, whiteSpace: "nowrap" }}>
              {voiceChip.tone === "live" && <span className="pip" />}
            {uiText(voiceChip.text)}
            </div>
          )}
        </div>
      )}

      {/* live readout — top-right, at right:56 so it clears the panel rail's
            column entirely (right:14, 34px wide — same clearance the zone panel
            uses) instead of the old magic maxHeight tuned to the rail's height. */}
      <div data-quantity-readout style={{
        display: (workspaceLayout && !workspaceArrangement.readout) || (tool === "select" && agentOpen) ? "none" : undefined, position: "absolute", ...(isNarrow
          // phones: a bottom strip — the top-right box plus the panel rail was
          // covering the entire screen. bottom:64 clears the bottom-center toast.
          ? { left: 10, right: 10, bottom: 64, maxHeight: "36%", padding: "8px 12px" }
          : { right: RAIL_CLEAR, top: CANVAS_EDGE, minWidth: 200, maxWidth: 260, maxHeight: `calc(100% - ${2 * CANVAS_EDGE}px)`, padding: "12px 16px" }),
        background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", borderRadius: 0, overflowY: "auto", boxShadow: "var(--shadow-pop)", fontVariantNumeric: "tabular-nums", zIndex: Z.canvasUi
      }}>
        <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5, opacity: 0.55, marginBottom: 6, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{uiText(tool === "zone" ? "Zone check" : (aCond?.finish_tag || "No condition"))}</div>
        {tool === "oneclick" && proposal?.regions.length ? (() => {
          const pos = proposal.regions.filter((r) => r.kind === "pos");
          const neg = proposal.regions.filter((r) => r.kind === "neg");
          const sf = pos.reduce((n, r) => n + r.area_sf, 0) - neg.reduce((n, r) => n + r.area_sf, 0);
          return (
            <>
                <div style={{ fontSize: 22, fontWeight: 700, color: "var(--cobalt)" }}>{uiText(num(areaVal(sf, units)))} <span style={{ fontSize: 13, fontWeight: 600 }}>{uiText(areaUnit(units))} {uiText("selected")}</span></div>
                <div style={{ fontSize: 12.5, color: "var(--ink-secondary)", marginTop: 2 }}>{uiText(pos.length)} {uiText("space")}{uiText(pos.length === 1 ? "" : "s")}{uiText(neg.length ? ` − ${neg.length} cutout${neg.length === 1 ? "" : "s"}` : "")}{uiText(units === "metric" ? "" : ` · ${num(sf / 9)} SY`)}</div>
                <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 4 }}>{uiText(ocSel ? "drag to move · Delete drops this point · Esc deselects" : "hover a fill to edit: drag a corner or edge · shift-click an edge adds a point")}</div>
                <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 2 }}>{uiText("click adds a space · ⌥-click carves a cutout · ⏎ Create · ⌫ undo · Esc cancel")}</div>
              {proposal.regions.some((r) => r.rt) && (
                  <div style={{ fontSize: 11.5, color: "var(--c-warning)", marginTop: 4 }}>{uiText("Traced from scan pixels — verify edges before Create.")}</div>
              )}
            </>
          );
        })() : tool === "surface" && poly.length >= 2 && liveUpp ? (
          (() => {
            const liveLF = openLen(curveIdx.length ? flattenArcRing(poly, curveIdx, false) : poly) * liveUpp;
            return condH > 0 ? (
              <>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "var(--ink)" }}>{uiText(num(areaVal(liveLF * condH, units)))} <span style={{ fontSize: 13, fontWeight: 600 }}>{uiText(areaUnit(units))} {uiText("wall")}</span></div>
                  <div style={{ fontSize: 12.5, color: "var(--ink-secondary)", marginTop: 2 }}>{uiText(fl(liveLF))} × {uiText(num(heightVal(condH, units), 2))} {uiText(heightUnit(units))}</div>
              </>
              ) : <div style={{ fontSize: 12.5, color: "var(--c-danger)" }}>{uiText("Set a height for ")}{uiText(aCond?.finish_tag || "this condition")} {uiText("— H in the condition editor")}</div>;
          })()
        ) : tool === "zone" && poly.length >= 1 ? (
          zoneTraceCross ? (
              <span style={{ color: "var(--c-danger)", fontSize: 12.5 }}>{uiText("Zone on one sheet — that point landed on a different sheet. Finish is disabled; Esc or Undo last point to fix it.")}</span>
          ) : (
            <>
                {liveArea != null && poly.length >= 3 && <div style={{ fontSize: 22, fontWeight: 700, color: "var(--cobalt)" }}>{uiText(num(areaVal(liveArea, units)))} <span style={{ fontSize: 13, fontWeight: 600 }}>{uiText(areaUnit(units))} {uiText("in zone")}</span></div>}
                <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 4 }}>{uiText("⏎, double-click, or the Finish button closes the zone and lists everything inside · Esc cancels")}</div>
            </>
          )
        ) : liveArea != null && poly.length >= 3 ? (
          <>
              <div style={{ fontSize: 22, fontWeight: 700, color: tool === "deduct" ? "var(--c-danger)" : "var(--ink)" }}>{uiText(tool === "deduct" ? "−" : "")}{uiText(num(areaVal(liveArea, units)))} <span style={{ fontSize: 13, fontWeight: 600 }}>{uiText(areaUnit(units))}</span></div>
              <div style={{ fontSize: 12.5, color: "var(--ink-secondary)", marginTop: 2 }}>{uiText(units === "metric" ? `${fl(livePerim)} perim` : `${num(liveArea / 9)} SY  ·  ${num(livePerim)} LF perim`)}</div>
              {uiText(dimsLine(fdims(curveIdx.length ? flattenArcRing(poly, curveIdx, !bowOpen) : poly, liveUpp), condH))}
              {condH > 0 && <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 2 }}>@H {uiText(num(heightVal(condH, units), 2))}{uiText(units === "metric" ? " m" : "′")}: {uiText(fa(livePerim * condH))} {uiText("vert · ")}{uiText(fv(liveArea * condH))}</div>}
              {CURVABLE.has(tool) && <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 4 }}>{uiText(bowOpen ? "Bow set — click the far END of the arc" : curveMode && poly.length ? "Click a point ON the bow, then its far end" : curveIdx.length ? `${curveIdx.length} arc${curveIdx.length === 1 ? "" : "s"} — each one a true circle through 3 points` : "Q or Draft ▾ Curve draws an arc · ⌥-click flips one point")}</div>}
          </>
        ) : selShape ? (
          // #283 — a FINISHED takeoff reads the same as it did mid-trace.
          // The perimeter is already computed and stored on every closed
          // shape (shapeMetrics); before this it simply had nowhere to be
          // read, so an estimator who wanted the footprint's LF traced the
          // ring a second time with the linear tool.
          (() => {
            const c = selShape.computed || {};
            const a = c.area_sf || 0, lf = c.perimeter_lf || 0;
            const shTag = condById[selShape.condition_id]?.finish_tag || "—";
            const big = (txt, unit, col) => (
                <div style={{ fontSize: 22, fontWeight: 700, color: col || "var(--ink)" }}>{uiText(txt)} <span style={{ fontSize: 13, fontWeight: 600 }}>{uiText(unit)}</span></div>
            );
              const sub = (txt) => <div style={{ fontSize: 12.5, color: "var(--ink-secondary)", marginTop: 2 }}>{uiText(txt)}</div>;
              const foot = <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 4 }}>{uiText(shTag)} {uiText("· selected")}{uiText(selShape.origin === "agent" ? " · agent" : "")}</div>;
              if (selShape.measure_role === "count") return <>{uiText(big(num(c.count || 1, 0), "EA"))}{uiText(foot)}</>;
            if (selShape.measure_role === "linear") {
              // #441 — a run with vertical legs reads as its parts: plan + ↑rise + ↓drop = total
              const vert = Number(c.vertical_lf) || 0;
              const { rise, drop } = vert > 0 ? linearVerticalFt(selShape, condById[selShape.condition_id]) : { rise: 0, drop: 0 };
              const legs = [`${fl(Number(c.plan_lf) || 0)} plan`, rise > 0 ? `↑ ${fl(rise)}` : "", drop > 0 ? `↓ ${fl(drop)}` : ""].filter(Boolean).join(" + ");
                return <>{uiText(big(num(lenVal(lf, units)), lenUnit(units)))}{uiText(vert > 0 ? sub(legs) : null)}{uiText(a > 0 ? sub(`${fa(a)} border`) : null)}{uiText(foot)}</>;
            }
            if (selShape.measure_role === "surface_area") {
              const h = selShape.height_override === true
                ? Number(selShape.height_ft) || 0
                : Number(selShape.height_ft) || Number(condById[selShape.condition_id]?.height_ft) || 0;
                return <>{uiText(big(num(areaVal(a, units)), `${areaUnit(units)} wall`))}{uiText(sub(`${fl(lf)} × ${num(heightVal(h, units), 2)}${units === "metric" ? " m" : " ft"}`))}{uiText(foot)}</>;
            }
            const ded = selShape.measure_role === "deduct";
            const shSp = panelByKey(selShape.sheet_id), shUpp = uppFor(selShape.sheet_id) || 0;
            const shPx = shSp?.img?.w ? (selShape.verts_norm || []).map(([nx, ny]) => [nx * shSp.img.w, ny * shSp.img.h]) : [];
            const shH = Number(condById[selShape.condition_id]?.height_ft) || 0;
            return (
              <>
                  {uiText(big(`${ded ? "−" : ""}${num(areaVal(a, units))}`, areaUnit(units), ded ? "var(--c-danger)" : undefined))}
                  {uiText(sub(units === "metric" ? `${fl(lf)} perim` : `${num(a / 9)} SY  ·  ${num(lf)} LF perim`))}
                  {uiText(dimsLine(fdims(shPx, shUpp), shH))}
                  {shH > 0 && <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 2 }}>@H {uiText(num(heightVal(shH, units), 2))}{uiText(units === "metric" ? " m" : "′")}: {uiText(fa(lf * shH))} {uiText("vert · ")}{uiText(fv(a * shH))}</div>}
                  {uiText(foot)}
              </>
            );
          })()
        ) : (
            <div style={{ fontSize: 12.5, opacity: 0.6 }}>{uiText(!unitsPerPx ? tr("Set scale first") : tool === "zone" ? "Trace a region (an apartment, a wing) — ⏎ closes it and lists every condition inside" : !activeCond ? tr("Pick a condition") : tool === "oneclick" ? tr("Click inside a room — it selects itself") : tool === "surface" ? tr("Trace the wall run") : tr("Click to trace an area"))}</div>
        )}
        {selShape?.measure_role === "surface_area" && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 8 }} title={uiText("Height for THIS wall only — full-height tile here, 4-ft wainscot there, same condition. ↺ returns to the condition height.")}>
            <Icon name="height" size={12} />
              <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>{uiText("this wall")}</span>
            <input name="shape-height-ft" type="number" min="0" step={heightStep(units)} value={shapeHDraft ?? dimInputStr(selShape.height_ft, units, "height")}
              onChange={(e) => { setShapeHDraft(e.target.value); setShapeHeight(e.target.value); }}
              onBlur={() => { if (shapeHDraft != null) setShapeHeight(shapeHDraft); setShapeHDraft(null); }}
              style={{ width: 56, padding: "2px 5px", border: "1px solid var(--ink-faint)", fontSize: 12 }} />
              <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>{uiText(heightUnit(units))} → {uiText(fa(selShape.computed?.area_sf || 0))}</span>
            {condH > 0 && Number(selShape.height_ft) !== condH && (
                <button onClick={clearShapeHeight} title={uiText("Set this wall to the condition height")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--ink-muted)", padding: 0 }}>↺</button>
            )}
          </div>
        )}
        {selShape && (selShape.measure_role || "floor_area") === "floor_area" && isCeilingCondition(condById[selShape.condition_id]) && (
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 8 }} title="Ceiling height for THIS area only (a soffit or bulkhead) — where it sits in the 3D view. Blank = the condition's Ceiling AFF.">
            <Icon name="height" size={12} />
            <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>ceiling AFF</span>
            <input name="shape-ceiling-ft" type="number" min="0" step={heightStep(units)} value={selShape.ceiling_ft != null ? dimInputStr(selShape.ceiling_ft, units, "height") : ""}
              placeholder={condById[selShape.condition_id]?.ceiling_ft ? dimInputStr(condById[selShape.condition_id].ceiling_ft, units, "height") : "9"}
              onChange={(e) => setShapeCeiling(e.target.value)}
              style={{ width: 56, padding: "2px 5px", border: "1px solid var(--ink-faint)", fontSize: 12 }} />
            <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>{heightUnit(units)}</span>
          </div>
        )}
        {selShape?.measure_role === "linear" && (() => {
          // #441 — vertical legs for THIS run: the fields shown are what the
          // run resolves to (its own override, else the condition default).
          const shCond = condById[selShape.condition_id];
          const own = selShape.rise_ft != null || selShape.drop_ft != null;
          const { rise, drop } = linearVerticalFt(selShape, shCond);
          const vInput = (field, val, label, glyph) => (
              <label style={{ display: "flex", alignItems: "center", gap: 3 }} title={uiText(`${label} (${heightUnit(units)}) for THIS run only — the vertical leg added to its plan length. Blank the field or press ↺ to use the condition's default.`)}>
                <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>{uiText(glyph)} {uiText(label)}</span>
              <input name={`shape-${field}`} type="number" min="0" step={heightStep(units)} value={shapeVertDraft[field] ?? dimInputStr(val, units, "height")}
                onChange={(e) => { setShapeVertDraft((d) => ({ ...d, [field]: e.target.value })); setShapeVertical(field, e.target.value); }}
                onBlur={() => { if (shapeVertDraft[field] != null) setShapeVertical(field, shapeVertDraft[field]); setShapeVertDraft((d) => ({ ...d, [field]: null })); }}
                style={{ width: 52, padding: "2px 5px", border: "1px solid var(--ink-faint)", fontSize: 12 }} />
            </label>
          );
          return (
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>{uiText("this run")}</span>
                {uiText(vInput("rise_ft", rise, "rise", "↑"))}
                {uiText(vInput("drop_ft", drop, "drop", "↓"))}
                <span style={{ fontSize: 11, color: "var(--ink-muted)" }}>{uiText(heightUnit(units))} → {uiText(fl(selShape.computed?.perimeter_lf || 0))}</span>
                {own && <button onClick={clearShapeVertical} title={uiText("Use the condition's rise and drop for this run")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--ink-muted)", padding: 0 }}>↺</button>}
            </div>
          );
        })()}
        <div style={{ height: 1, background: "var(--divider-soft)", margin: "8px 0" }} />
          <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 0.4, opacity: 0.5 }}>{finishLabel(aCond?.finish_tag || "—")} {uiText("total (")}{uiText(condRow?.shape_count || 0)}{uiText(condMult > 1 ? ` ×${condMult}` : "")})</div>
          {condTotal !== 0 && <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{uiText(num(areaVal(condTotal, units)))} <span style={{ fontSize: 12, fontWeight: 600 }}>{uiText(areaUnit(units))}</span> {units === "imperial" && <span style={{ fontSize: 12, fontWeight: 500, color: "var(--ink-secondary)" }}>· {uiText(num(condTotal / 9))} {uiText("SY")}</span>}</div>}
          {wallTotal > 0 && <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{uiText(num(areaVal(wallTotal, units)))} <span style={{ fontSize: 12, fontWeight: 600 }}>{uiText(areaUnit(units))} {uiText("wall")}</span></div>}
          {borderTotal > 0 && <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{uiText(num(areaVal(borderTotal, units)))} <span style={{ fontSize: 12, fontWeight: 600 }}>{uiText(areaUnit(units))} {uiText("border")}</span></div>}
          {lfTotal > 0 && <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{uiText(num(lenVal(lfTotal, units)))} <span style={{ fontSize: 12, fontWeight: 600 }}>{uiText(lenUnit(units))}</span></div>}
          {countTotal > 0 && <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2 }}>{uiText(num(countTotal, 0))} <span style={{ fontSize: 12, fontWeight: 600 }}>{uiText("EA")}</span></div>}
          {vertTotal > 0 && <div style={{ fontSize: 11.5, color: "var(--ink-muted)", marginTop: 2 }} title={uiText("Display only — floor-area perimeters × this condition's height (not committed)")}>{uiText(fa(vertTotal))} {uiText("vert (perim × H)")}</div>}
        {condTotal === 0 && lfTotal === 0 && countTotal === 0 && wallTotal === 0 && borderTotal === 0 && <div style={{ fontSize: 12.5, color: "var(--ink-muted)", marginTop: 2 }}>—</div>}
        {tally.length > 0 && (
          <>
              <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 0.4, opacity: 0.5, marginTop: 8 }}>{uiText("Measurements")}</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11.5, lineHeight: 1.5, marginTop: 2 }}>
              {tally.map((r) => (
                <div key={r.id} style={{ display: "flex", gap: 6, whiteSpace: "nowrap" }}>
                    <span style={{ opacity: 0.45 }}>{uiText(String(r.n).padStart(2, "0"))}</span>
                  <span>
                      {uiText(fl(r.lf))}
                    {r.role === "wall"
                        ? <> × {uiText(num(heightVal(r.h, units), 2))} {uiText(heightUnit(units))} = {uiText(fa(r.sf))}</>
                      : r.vert > 0
                          ? <span style={{ color: "var(--ink-muted)" }}> = {uiText(fl(r.plan))} {uiText("plan + ")}{uiText(fl(r.vert))} {uiText("vert")}</span>
                          : <span style={{ color: "var(--ink-muted)" }}> {uiText("linear")}</span>}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}
          <div style={{ fontSize: 10.5, opacity: 0.45, marginTop: 6 }}>{uiText(visibleShapes.length)} {uiText("shapes on ")}{uiText(groupKeys.length > 1 ? `${groupKeys.length} sheets` : "sheet")} {uiText("· zoom ")}{uiText((tf.scale * 100).toFixed(0))}%</div>
      </div>

      {/* zone check results — ephemeral, clears with the tool/outline. Docked at
            right:56 so it never covers the panel rail (right:14, 34px wide), and
            anchored to the BOTTOM (not top:14 like the original) so it stacks
            vertically with the live readout instead of sitting on top of it —
            the live readout (right:14, top:14, zIndex 6) shows the SAME zone's
            live "SF in zone" figure for the NEXT trace while this panel is open,
            and a top:14 placement here covered all but a ~42px sliver of it. */}
      {/* Copy text receipt (#471) — in the canvas, bottom-right below the live
            readout like the zone panel, moved left of the Sweep panel while a
            sweep is live (lib/copyText receiptPlacement) */}
      {copyReceipt && (
        <CopyTextReceipt receipt={copyReceipt} placement={receiptPlacement({ sweepOpen: !!sweep, zoneOpen: !!zoneRows, narrow: isNarrow })}
          onClose={() => setCopyReceipt(null)}
          onCopyPage={(key) => copyTextFrom(key, null, "page")}
          onCopied={() => setCopyReceipt((r) => (r ? { ...r, failed: false } : r))} />
      )}
      {zoneRows && (
        <div style={{ position: "absolute", right: RAIL_CLEAR, bottom: CANVAS_EDGE, width: ZONE_PANEL_W, maxHeight: `calc(100% - ${2 * CANVAS_EDGE}px)`, overflowY: "auto", background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", borderRadius: 0, boxShadow: "0 6px 22px rgba(0,0,0,.16)", zIndex: 7, fontSize: 12.5, fontVariantNumeric: "tabular-nums" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", borderBottom: "1px solid var(--ink-faint)" }}>
              <b style={{ fontSize: 12.5 }}>{uiText("Zone check")}</b>
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 9.5, color: "var(--ink-muted)" }}>{uiText("nothing saved")}</span>
            <button onClick={resetZone} style={{ marginLeft: "auto", border: "none", background: "none", cursor: "pointer", fontSize: 15, lineHeight: 1, color: "var(--ink)" }}>×</button>
          </div>
          {zoneRows.length === 0 && (
              <div style={{ padding: "10px 12px", color: "var(--ink-muted)", fontSize: 11.5 }}>{uiText("No takeoffs inside this zone on this sheet.")}</div>
          )}
          {zoneRows.map((zr) => {
            const parts = [];
            if (zr.floor_sf) parts.push(fa(zr.floor_sf));
            if (zr.wall_sf) parts.push(`${fa(zr.wall_sf)} wall`);
            if (zr.border_sf) parts.push(`${fa(zr.border_sf)} border`);
            if (zr.lf) parts.push(fl(zr.lf));
            if (zr.ea) parts.push(`${num(zr.ea, 0)} EA`);
            const open = zoneExpand === zr.id;
            return (
              <div key={zr.id} style={{ padding: "8px 12px", borderBottom: "1px solid var(--ink-faint)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <span style={{ borderRadius: 4, overflow: "hidden", lineHeight: 0, flexShrink: 0 }}><HatchSwatch type={zr.hatch || "solid"} line={zr.color} fill={zr.fill} /></span>
                    <b style={{ fontFamily: "var(--f-mono)", fontSize: 11.5 }}>{finishLabel(zr.finish_tag || "—")}</b>
                    {zr.multiplier > 1 && <span style={{ color: "var(--ink-muted)", fontSize: 11 }}>×{uiText(zr.multiplier)}</span>}
                    <span style={{ marginLeft: "auto", fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink)" }}>{uiText(parts.join(" · ") || "—")}</span>
                </div>
                {zr.materials.length > 0 && (
                  <button onClick={() => setZoneExpand(open ? null : zr.id)}
                    style={{ marginTop: 4, padding: 0, border: "none", background: "none", cursor: "pointer", fontSize: 10.5, color: "var(--ink-muted)" }}>
                      {uiText(open ? "▾" : "▸")} {uiText("materials · ")}{uiText(zr.materials.length)}
                  </button>
                )}
                {open && zr.materials.map((m, i) => (
                  <div key={i} style={{ display: "flex", gap: 8, marginTop: 3, marginLeft: 12, fontSize: 11, color: "var(--ink-secondary)" }}>
                      <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{uiText(m.name)}</span>
                      <span style={{ fontFamily: "var(--f-mono)" }}>{uiText(num(m.qty))} {uiText(m.unit)}</span>
                  </div>
                ))}
              </div>
            );
          })}
          <div style={{ padding: "7px 12px", fontSize: 10, color: "var(--ink-muted)" }}>
              {uiText("Shapes counted by their center point · same sheet only · counted shapes glow cobalt.")}{zoneRows.some((r) => (r.multiplier || 1) > 1) && <> {uiText("Rows marked ×N already have the condition's multiplier applied — the same convention as the Report's Groups section, not its base-quantity by-sheet rows.")}</>}
            {/* A deduct classifies by its OWN center, independent of its positive
                  area's center (same rule the Report's by-sheet "negative slices"
                  note already documents for a cross-sheet split) — a zone edge
                  can split a deduct from the shape it cuts, producing a negative
                  row here. Flag it rather than guess a pairing: the deduct/positive
                  link is never stored, only inferred by overlap, and geometric
                  containment pairing would guess wrong for nested/overlapping
                  positives. */}
              {zoneRows.some((r) => r.total_sf < 0 || r.floor_sf < 0) && <> {uiText("A negative row means a deduct here counted but its positive area's center fell outside the zone (or vice-versa) — the zone edge split a deduct from its shape.")}</>}
          </div>
        </div>
      )}

      {/* panel rail — markup/takeoffs toggles on the right edge (zoom-cluster
            style). Moved out of the toolbar so it never wraps a third row. The
            takeoffs toggle mirrors the DOCKED panel's collapsed pref — the rail
            rides the canvas edge, so it stays visible either way. */}
      <div data-panel-rail style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", display: workspaceLayout && !focusMode ? "none" : "flex", flexDirection: "column", gap: 6, zIndex: 8 }}>
          {uiText(panelBtn(() => setLeftTab((t) => (t === "markup" ? null : "markup")), "document", tr("Markup list — existing clouds, callouts, and notes"), leftTab === "markup", markupCount))}
          {uiText(panelBtn(() => setLeftTab((t) => (t === "stamp" ? null : "stamp")), "stamp", tr("Stamps — reusable annotations dropped click-to-place"), leftTab === "stamp", stampLib.stamps.length))}
          {uiText(panelBtn(() => setLeftTab((t) => (t === "rfi" ? null : "rfi")), "rfi", tr("RFI register — raise, track, and export Requests For Information"), leftTab === "rfi", rfis.length))}
          {uiText((!workspaceLayout || focusMode) && panelBtn(toggleTakeoffs, "takeoffs", "Takeoffs — conditions + running totals", takeoffsOpen, visibleShapes.length))}
          {uiText((!workspaceLayout || focusMode) && panelBtn(() => setAgentOpen((o) => !o), "target", "Work and review — measurements and agent proposals", agentOpen, agentProposals.length))}
          {uiText(rollByCond.size > 0 && panelBtn(() => setRollPanelOpen((o) => !o), "roll", "Roll goods — the cut diagram, cutting order, and figured order footage", rollPanelOpen, rollByCond.size))}
          {uiText(layerEntries.length > 0 && panelBtn(() => setLayersOpen((o) => !o), "layers", "PDF layers — what this drawing's own layer table states each ink is; set what One-Click treats as wall and what it ignores", layersOpen, layerEntries.reduce((n, e) => n + e.layers.length, 0)))}
          {uiText(panelBtn(() => setShowRevisions(true), "revisions", tr("Revisions — save the takeoff at each bid revision, compare what moved"), showRevisions))}
      </div>

        {workspaceLayout && !focusMode && view === "canvas" && !showReport && <CanvasSideTabs
          conditionsOpen={condDockOpen && !fullTableOpen} conditionCount={conditions.length}
          onConditions={() => { if (fullTableOpen) { setFullTableOpen(false); setCondDockOpen(true); } else setCondDockOpen((v) => !v); }}
          assistantOpen={assistantOpen} onAssistant={() => (assistantOpen ? setAssistantOpen(false) : openAssistant())} working={agentRunning} />}
        <DropZoneOverlay zone={dragZone} />
       </div>
  );
  return (
    // .app-shell: the print stylesheet collapses this 100vh flex column while the report is open
    <div
      className={`app-shell${workspaceLayout ? " workspace-calm premium-workspace" : ""}${workspaceLayout && !focusMode ? " pc-on" : ""}`}
      data-workspace-look={workspaceLayout ? workspaceArrangement.look : undefined}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => { e.preventDefault(); handleFiles(e.dataTransfer?.files); }}
      style={{ position: "relative", display: "flex", flexDirection: "column", height: "100vh", "--workspace-glow-strength": workspaceArrangement.backlight / 100 }}>
      {uiText(pinWindow)}
      {/* file inputs — always mounted (drag-drop and the ⋯ import path need
          the refs even while focus mode hides the bar) */}
      <input name="sheet-file" ref={fileInputRef} type="file" accept=".pdf,application/pdf,image/*,.zip,application/zip,application/x-zip-compressed,.otk" multiple style={{ display: "none" }}
        onChange={(e) => { handleFiles(e.target.files); e.target.value = ""; }} />
      <input name="profile-import" ref={profileInputRef} type="file" accept=".otprofile,application/json" style={{ display: "none" }}
        onChange={(e) => { importProfileFile(e.target.files?.[0]); e.target.value = ""; }} />
      <input name="takeoff-import" ref={importInputRef} type="file" accept=".json,application/json" style={{ display: "none" }}
        onChange={(e) => { importTakeoffFile(e.target.files?.[0]); e.target.value = ""; }} />
      {/* THE top bar — one row (the two decks of issue #61 merged once the
          tool rail absorbed the draw menus). Project verbs left, work verbs
          center, Report + the ⋯ overflow (guide, appearance — chrome theme and
          drawing style —, schedule import, cloud moves) right. Cluster captions stay — they're the drafting
          language. The row never wraps; rarely-used controls live in ⋯ so
          nothing shifts position mid-work. Focus mode (F) hides the whole
          bar — the rail and status bar carry the essentials.
          Un-wrapped is not the same as unreachable, though: this row is
          ~1550px of fixed-width controls, so on a 1440-class laptop Report and
          the Action menu render past the right edge. The document can
          technically scroll to them, but the canvas claims wheel and trackpad
          gestures for zoom/pan, so that scroll never arrives and the app reads
          as "Export is unclickable". The row therefore SCROLLS itself; its
          menus open position:fixed off the trigger rect (ToolMenu) so this
          overflow cannot clip them. */}
      {!focusMode && workspaceLayout && <PremiumRail running={agentRunning} onMenuDepth={onMenuDepth}
        onSearch={() => setWorkspaceSearchOpen(true)}
        onSheets={() => setWorkspaceNavigationOpen((v) => !v)} sheetsOpen={workspaceNavigationOpen}
        onOpenPlans={() => fileInputRef.current?.click()}
        onCollapse={toggleFocusMode} onLayout={() => setWorkspaceLayoutOpen(true)}
        helpItems={[
          { id: "tour", label: tr("Guided first takeoff"), onSelect: startTour },
          { id: "guide", label: tr("How OpenTakeoff works"), shortcut: "?", onSelect: () => setGuideOpen(true) },
          ...(CONFENGE_LOCAL_ONLY ? [] : [
            { id: "assistant", label: tr("Assistant — talk to your own AI here"), onSelect: openAssistant },
            { id: "connect-ai", label: tr("Connect your AI"), onSelect: () => setConnectOpen(true) },
          ]),
        ]} />}
      {!focusMode && workspaceLayout && (() => {
        const kept = shapes.filter((sh) => sh.origin?.reviewed !== false).length;
        const pendingN = shapes.filter((sh) => sh.origin?.reviewed === false).length;
        const moreItems = [
          { section: tr("Plans") },
          { id: "open-plans", icon: "plus", label: tr("Open plans…"), onSelect: () => fileInputRef.current?.click() },
          // the sheet switcher already lists pages and files; keep the set operations and file moves
          ...sheetMenuItems.filter((it) => it !== "divider" && !/^(pg|f)-/.test(it.id || "") && (!it.section || it.section.startsWith("Profile"))),
          "divider",
          { section: tr("Panels") },
          { id: "work", icon: "target", label: tr("Work and review"), checked: agentOpen, onSelect: () => setAgentOpen((v) => !v) },
          { id: "full-takeoffs", icon: "takeoffs", label: tr("Takeoffs table — library, materials, columns"), checked: fullTableOpen, onSelect: () => setFullTableOpen((v) => !v) },
          { id: "markups", icon: "document", label: tr("Markup list") + `${markupCount ? ` (${markupCount})` : ""}`, checked: leftTab === "markup", onSelect: () => setLeftTab((t) => (t === "markup" ? null : "markup")) },
          { id: "stamps", icon: "stamp", label: tr("Stamps"), checked: leftTab === "stamp", onSelect: () => setLeftTab((t) => (t === "stamp" ? null : "stamp")) },
          { id: "rfis", icon: "rfi", label: tr("RFI register") + `${rfis.length ? ` (${rfis.length})` : ""}`, checked: leftTab === "rfi", onSelect: () => setLeftTab((t) => (t === "rfi" ? null : "rfi")) },
          ...(rollByCond.size > 0 ? [{ id: "roll", icon: "roll", label: tr("Roll goods"), checked: rollPanelOpen, onSelect: () => setRollPanelOpen((o) => !o) }] : []),
          ...(layerEntries.length > 0 ? [{ id: "layers", icon: "layers", label: tr("PDF layers"), checked: layersOpen, onSelect: () => setLayersOpen((o) => !o) }] : []),
          { id: "revisions", icon: "revisions", label: tr("Revisions"), onSelect: () => setShowRevisions(true) },
          { id: "estimate", label: tr("Estimate"), onSelect: openEstimate },
          { id: "report", icon: "document", label: tr("Report"), onSelect: () => setShowReport(true) },
          "divider",
          { section: tr("Drawing") },
          ...(panels.length === 1 && isStitchKey(panels[0].key) ? [{ id: "stitch-align", icon: "calibrate", label: tr("Align match line"), active: tool === "stitch-align", onSelect: () => setTool((t) => (t === "stitch-align" ? "select" : "stitch-align")) }] : []),
          { id: "snap", label: tr("Snap to plan lines"), checked: snapOn, stayOpen: true, onSelect: () => setSnapOn((v) => !v) },
          { id: "angle", label: tr("45° / 90° guides"), checked: angleOn, stayOpen: true, onSelect: () => setAngleOn((v) => !v) },
          { id: "zone", icon: "zone", label: tr("Zone check"), active: tool === "zone", onSelect: () => setTool((t) => (t === "zone" ? "select" : "zone")) },
          { id: "schedule", icon: "rectTool", label: tr("Import from schedule"), active: tool === "schedule", onSelect: () => { setScheduleAnchor(null); setTool((t) => (t === "schedule" ? "select" : "schedule")); } },
          { id: "units", label: tr(units === "metric" ? "Units: metric (switch to ft)" : "Units: feet (switch to metric)"), onSelect: () => setUnits((u) => (u === "metric" ? "imperial" : "metric")) },
          "divider",
          { section: tr("Workspace") },
          { id: "layout", icon: "sliders", label: tr("Layout…"), onSelect: () => setWorkspaceLayoutOpen(true) },
          { id: "focus", icon: "focus", label: tr("Focus mode"), shortcut: "F", onSelect: toggleFocusMode },
          { id: "controls", label: tr(workspaceControlsOpen ? "Hide classic toolbar" : "Classic toolbar"), checked: workspaceControlsOpen, onSelect: () => setWorkspaceControlsOpen((v) => !v) },
          { id: "classic", label: tr("Classic layout"), onSelect: () => workspacePrefs.setEnabled(false) },
          ...(cloudMode ? [{ id: "closeproj", label: tr("Close project"), onSelect: closeProject }] : []),
        ];
        return <PremiumTopBar
          title={projectName || active}
          subtitle={uiText(pendingN ? `${pendingN} to review · ${kept} kept` : kept ? `${kept} shape${kept === 1 ? "" : "s"} kept` : "Nothing kept yet")}
          onBack={() => setView("gallery")} onGallery={() => setView("gallery")}
          sheets={workspaceSheets} current={treeCurrent} onSheet={(key) => openSheets([key], false)} onMenuDepth={onMenuDepth}
          scaleMenu={<ToolMenu title={scaleTitle} onOpenChange={onScaleMenuDepth} face={<span data-tour="scale" style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><Icon name="scaleRule" size={16} />{uiText(scaleFace)}</span>} faceStyle={{ fontFamily: "var(--f-body)", fontSize: 13.5, fontWeight: 500, ...scaleFaceStyle }} menuStyle={{ minWidth: 250 }} items={scaleItems} />}
          action={finishOk && <button type="button" className="cd-btn" style={{ flex: "0 0 auto", marginLeft: 6 }} onClick={finishShape}>{tr("Finish")} ({poly.length})</button>}
          onList={() => setShowReport(true)} total={estTotal} onEstimate={openEstimate}
          moreItems={moreItems}
          onBell={() => setAgentOpen((v) => !v)} pending={pendingN} languageControl={<LanguageSwitcher />} />;
      })()}
      {workspaceLayout && !workspaceArrangement.readout && selShape?.measure_role === "surface_area" && <div className="calm-property-editor"><label>{tr("Selected wall height")} <input aria-label={tr("Selected wall height")} type="number" min="0" step={heightStep(units)} value={shapeHDraft ?? dimInputStr(selShape.height_ft, units, "height")} onChange={(e) => { setShapeHDraft(e.target.value); setShapeHeight(e.target.value); }} onBlur={() => { if (shapeHDraft != null) setShapeHeight(shapeHDraft); setShapeHDraft(null); }} /></label><span>{uiText(heightUnit(units))} → {uiText(fa(selShape.computed?.area_sf || 0))}</span><button type="button" onClick={clearShapeHeight}>{tr("Use condition height")}</button></div>}
      {workspaceLayout && !workspaceArrangement.readout && selShape && (selShape.measure_role || "floor_area") === "floor_area" && isCeilingCondition(condById[selShape.condition_id]) && <div className="calm-property-editor"><label>Selected ceiling AFF <input name="shape-ceiling-ft" aria-label="Selected ceiling height" type="number" min="0" step={heightStep(units)} value={selShape.ceiling_ft != null ? dimInputStr(selShape.ceiling_ft, units, "height") : ""} placeholder={condById[selShape.condition_id]?.ceiling_ft ? dimInputStr(condById[selShape.condition_id].ceiling_ft, units, "height") : "condition"} onChange={(e) => setShapeCeiling(e.target.value)} /></label><span>{heightUnit(units)} · 3D only (a soffit) · blank = the condition</span></div>}
      {!focusMode && workspaceLayout && workspaceDetailsOpen && aCond && <div className="calm-property-editor"><strong>{finishLabel(aCond.finish_tag)}</strong><ConditionAppearanceEditor cond={aCond} onUpdateCond={updateCond} onSetCondParam={setCondParam} onAssignAttr={assignAttr} conditionColumns={conditionColumns} layout="row" units={units} /><button type="button" onClick={() => setWorkspaceDetailsOpen(false)}>{tr("Close properties")}</button></div>}
      {workspaceLayout && <><WorkspaceCommandMenu open={workspaceSearchOpen} onClose={() => setWorkspaceSearchOpen(false)} actions={workspaceActions} onOpenChange={onMenuDepth} /><WorkspaceLayoutDialog open={workspaceLayoutOpen} onClose={() => setWorkspaceLayoutOpen(false)} prefs={workspacePrefs} onOpenChange={onMenuDepth} /></>}
      {!focusMode && (!workspaceLayout || workspaceControlsOpen) && (
        <div data-topbar style={{ display: "flex", gap: 7, alignItems: "center", padding: "0 14px 6px", borderBottom: "1px solid var(--ink-faint)", background: "var(--paper-bright)", whiteSpace: "nowrap" }}>
          {/* The working controls scroll as one region when the window is
            narrower than the row (1440-class laptops); Report, ⋯, presence and
            account sit OUTSIDE that region so they are on screen at every
            width — the row's contract (#61: nothing wraps or shifts) holds,
            and nothing important is ever past the right edge. paddingTop 16
            keeps the cluster captions (top:-13) inside the scroll box. */}
        <div data-topbar-scroll style={{ display: "flex", gap: 7, alignItems: "center", flex: "1 1 0", minWidth: 0, padding: "16px 0 0", overflowX: "auto", overflowY: "hidden", scrollbarWidth: "thin", overscrollBehaviorX: "contain" }}>
        <strong style={{ display: "inline-flex", alignItems: "center", whiteSpace: "nowrap" }} title={tr("OpenTakeoff")}><OtLockup size={15} />{agentRunning && <ScanStar size={13} reach={1.6} working style={{ color: "var(--cobalt)", marginLeft: 8 }} title={tr("The agent is working")} />}</strong>
        <button type="button" onClick={() => fileInputRef.current?.click()} title={tr("Open plans — PDF, image, or a .zip plan set (or just drag them onto the canvas)")}
          style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", border: "1px solid var(--ink)", background: "var(--ink)", color: "var(--paper-bright)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}>
          <Icon name="plus" size={14} />{tr("Open")}</button>
        <button type="button" onClick={() => setView("gallery")}
          title={uiText(`Plan set — the visual gallery; open one or several sheets (G)${sheetGroup.length ? ` · ${sheetGroup.length} side-by-side now` : ""}`)}
          style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", border: `1px solid ${sheetGroup.length ? "var(--cobalt)" : "var(--ink-faint)"}`, background: sheetGroup.length ? "var(--cobalt)" : "transparent", color: sheetGroup.length ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}>
          <Icon name="sheets" size={15} />{tr("Sheets")}
        </button>
        {uiText(pinButton)}
            {sheets.length > 0 && (
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
            <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={!!sheetGroup.length || page <= 1} title={tr("Previous sheet")}
                  style={{ padding: "5px 8px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", cursor: "pointer", opacity: (!!sheetGroup.length || page <= 1) ? 0.4 : 1 }}><Icon name="chevronLeft" size={12} /></button>
                <ToolMenu
              title={uiText("Sheet — the sheets in this set, files, grouping, and the gallery")}
                  onOpenChange={onMenuDepth}
              face={<span style={{ display: "inline-block", maxWidth: 220, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{uiText(sheetChipLabel)}</span>}
                  faceStyle={{ fontFamily: "var(--f-mono)", fontSize: 12, fontWeight: 400, padding: "6px 8px" }}
                  menuStyle={{ minWidth: 260, maxHeight: "min(480px, 60vh)", overflowY: "auto" }}
                  items={sheetMenuItems}
                />
            <button type="button" onClick={() => setPage((p) => Math.min(pageCount, p + 1))} disabled={!!sheetGroup.length || page >= pageCount} title={tr("Next sheet")}
                  style={{ padding: "5px 8px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", cursor: "pointer", opacity: (!!sheetGroup.length || page >= pageCount) ? 0.4 : 1 }}><Icon name="chevronRight" size={12} /></button>
              </span>
            )}
        {uiText(vRule)}
        {cluster(tr("Edit"), <>
              <ToolMenu
            title={tr("Edit takeoffs")}
                onOpenChange={onMenuDepth}
            face={<span>{tr("Edit")}</span>}
                items={[
              { id: "copy", icon: "copy", label: tr("Copy"), shortcut: "⌘C", disabled: !selectedId, onSelect: copySelected },
              { id: "paste", icon: "paste", label: tr("Paste"), shortcut: "⌘V", disabled: !clipRef.current.length, onSelect: () => pasteClipboard() },
              { id: "dup", icon: "duplicate", label: tr("Duplicate"), shortcut: "⌘D", disabled: !selectedId, onSelect: duplicateSelected },
                  "divider",
              { id: "flipH", label: tr("Flip Horizontal"), disabled: !selectedId, onSelect: () => flipSelected("h") },
              { id: "flipV", label: tr("Flip Vertical"), disabled: !selectedId, onSelect: () => flipSelected("v") },
              { id: "tidy", label: tr("Tidy shape"), disabled: !selectedId, onSelect: tidySelected },
                  "divider",
              { id: "finish", icon: "check", label: uiText(`${tr("Finish shape")}${poly.length ? ` (${poly.length})` : ""}`), shortcut: "↵", disabled: !finishOk, onSelect: finishShape },
              { id: "undopt", icon: "undo", label: tr("Undo last point"), shortcut: "⌘Z", disabled: !poly.length, onSelect: dropLastPoint },
              { id: "undoshape", icon: "undo", label: tr("Undo last shape"), disabled: !visibleShapes.length, onSelect: undoLast },
              { id: "redo", label: tr("Redo"), shortcut: "⇧⌘Z", onSelect: redoShapeCommand },
                  "divider",
              { id: "del", icon: "close", label: tr("Delete selected"), shortcut: "⌫", disabled: !selectedId, tint: "var(--c-danger)", onSelect: deleteSelected },
                ]}
              />
            </>)}
        {uiText(vRule)}
        {cluster(tr("Aids"), <>
              {panels.length === 1 && isStitchKey(panels[0].key) && (
                <button onClick={() => setTool((t) => (t === "stitch-align" ? "select" : "stitch-align"))}
              title={uiText("Align the match line — click a point near the joint, then the SAME point where the other sheet draws it; that sheet slides so the two coincide. Do this before tracing (a stitch with takeoffs on it won't re-align).")}
                  style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", border: `1px solid ${tool === "stitch-align" ? "var(--cobalt)" : "var(--ink-faint)"}`, background: tool === "stitch-align" ? "var(--cobalt)" : "transparent", color: tool === "stitch-align" ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}>
              <Icon name="calibrate" size={15} />{tr("Align")}
                </button>
              )}
              <button onClick={() => setTool((t) => (t === "zone" ? "select" : "zone"))}
            title={tr("Zone check — trace a region (an apartment, a wing) to read every condition's quantities inside it, materials included. Nothing is saved; the outline clears when you leave the tool.")}
                style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", border: `1px solid ${tool === "zone" ? "var(--cobalt)" : "var(--ink-faint)"}`, background: tool === "zone" ? "var(--cobalt)" : "transparent", color: tool === "zone" ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}>
            <Icon name="zone" size={15} />{tr("Zone")}
              </button>
          <button onClick={() => setSnapOn((v) => !v)} title={tr("Snap to plan lines/corners (beta)")}
                style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", border: `1px solid ${snapOn ? "var(--c-positive)" : "var(--ink-faint)"}`, background: snapOn ? "var(--c-positive)" : "transparent", color: snapOn ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}>
            <Icon name="snap" size={15} />{tr("Snap")}
              </button>
          <button onClick={() => setAngleOn((v) => !v)} title={tr("45°/90° angle guides — the next segment locks to the 45° family as you draw (hold ⇧ to force the lock at any angle)")}
                style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", border: `1px solid ${angleOn ? "var(--cobalt)" : "var(--ink-faint)"}`, background: angleOn ? "var(--cobalt)" : "transparent", color: angleOn ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}>
                <Icon name="angle" size={15} />45°
              </button>
            </>)}
        {uiText(vRule)}
            {/* Drafting conventions — how a trace looks and where it bends, one
            dropdown. Style and Outline came up from the ⋯ menu, Straight/Curve
            over from the readout (2026-09-12): a convention you set before
            tracing belongs beside the aids, one click from the sheet. */}
        {uiText(cluster(tr("Draft"), draftMenu))}
            {/* The caption always shows the ACTIVE label (+ the cobalt highlight keyed
            on it) so what a new trace will get is never hidden — even in Select
            mode, where the dropdown VALUE instead shows the selected shape's label
            so changing it reliably re-labels that shape (a value-always-active
            select couldn't reassign to the already-active label — onChange wouldn't fire). */}
            {shapeLabels.length > 0 && cluster(
          tool === "select" && selectedId ? `Label · ${activeLabel || "none"} → shape` : (activeLabel ? `Label · ${activeLabel}` : tr("Label")),
              <select
                value={tool === "select" && selectedId ? shapeLabelValue(shapes.find((s) => s.id === selectedId)) : (activeLabel || "")}
                onChange={(e) => activateLabel(e.target.value || null)}
            title={uiText("Phase/area label. The caption shows the ACTIVE label (what new takeoffs get). With a shape selected (Select tool), the dropdown shows and re-labels that shape. Manage the list in the Columns tab.")}
                style={{ fontFamily: "var(--f-mono)", fontSize: 11.5, padding: "5px 6px", border: `1px solid ${activeLabel ? "var(--cobalt)" : "var(--ink-faint)"}`, background: activeLabel ? "var(--cobalt)" : "transparent", color: activeLabel ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", maxWidth: 150 }}>
            <option value="">{tr("No label")}</option>
            {shapeLabels.map((v) => <option key={v} value={v}>{uiText(v)}</option>)}
              </select>
            )}
            {/* Typed voice command (RFC #59 slice 2): the same grammar push-to-talk
            will feed — a keyboard command line meanwhile, and the accessibility
            path. Focus suppresses canvas shortcuts via the existing INPUT guards.
            Deixis: focus marks the utterance's start — "this room" then needs an
            aim placed AFTER it (park the pointer on the room, type, Enter). */}
        {commandBoxEnabled() && cluster(tr("Command"),
              <input
                type="text"
            placeholder={uiText("cpt 1 · waste 7 · this room")}
            title={uiText('Command line (RFC #59): a condition tag ("CPT-1", "carpet one", "tile 2 waste 5"), "waste 7", "label Phase 1", "clear label", "author <your name>" (new marks sign it — the report can group by author), or "note …" — Enter runs it through the same actions the buttons use. End with "this room" / "here" while the pointer rests on a room to trace and commit it there ("carpet one, this room"). Push-to-talk dictation will feed this box.')}
                onFocus={() => { voiceAimMarkRef.current = aimSeqRef.current; }}
                onKeyDown={(e) => {
                  if (e.key !== "Enter") return;
                  const v = e.currentTarget.value.trim();
                  if (!v) return;
                  const el = e.currentTarget;   // capture: currentTarget nulls after dispatch, and deixis outcomes can resolve async (raster)
                  // router confirm (RFC #59 slice 5): the rejected text is still in
                  // the box (only success clears it) — a second ⏎ on the SAME text
                  // confirms the pending offer instead of re-rejecting in a loop
                  if (pendingAgentOfferRef.current && v === pendingAgentOfferRef.current.transcript) {
                    agentOfferFnsRef.current.confirm();
                    el.value = "";
                    return;
                  }
                  Promise.resolve(onVoiceCommand(v)).then((ok) => { if (ok) el.value = ""; });
                }}
                style={{ fontFamily: "var(--f-mono)", fontSize: 11.5, padding: "5px 6px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", width: 150 }}
              />
            )}
            {/* Push-to-talk (RFC #59 recognizer): hold the button (or M) to dictate
            into the same grammar the Command box runs. Hidden entirely where
            capture is unsupported — graceful feature-absence, never broken. */}
        {commandBoxEnabled() && captureSupported() && cluster(tr("Voice"),
              <button
            title={uiText('Hold to talk (or hold M anywhere on the canvas): speak a command — "carpet one, waste seven", "label phase two", "note …", or end with "this room" to trace at the cursor. Release to run; Esc discards. Audio is processed on-device and never leaves the browser.')}
                onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); voiceHoldRef.current = true; voiceFnsRef.current.start(); }}
                onPointerUp={() => { if (voiceHoldRef.current) { voiceHoldRef.current = false; voiceFnsRef.current.end(true); } }}
                onPointerCancel={() => { if (voiceHoldRef.current) { voiceHoldRef.current = false; voiceFnsRef.current.end(false); } }}
                style={{ padding: "5px 10px", border: `1px solid ${voiceChip?.tone === "live" ? "var(--cobalt)" : "var(--ink-faint)"}`, background: voiceChip?.tone === "live" ? "var(--cobalt)" : "transparent", color: voiceChip?.tone === "live" ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontFamily: "var(--f-mono)", fontSize: 11, fontWeight: 700, lineHeight: 1 }}>
            {uiText(voiceChip?.tone === "live" ? "● talking" : "talk · M")}
              </button>
            )}
            <div style={{ flex: 1 }} />
            {cluster("Action",
              <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "flex-end", gap: 6, minWidth: 150 }}>
            {markupDraft && (tool === "cloud" || tool === "callout" || tool === "highlight" || tool === "dimension") && <span style={{ fontSize: 11, color: "var(--cobalt)" }}>{uiText("click the ")}{uiText(tool === "callout" ? "label spot" : tool === "dimension" ? "other end" : "opposite corner")}…</span>}
                {finishOk && (
              <button onClick={finishShape} title={uiText("Finish shape (↵ or double-click)")} style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 12px", border: "none", background: "var(--c-positive)", color: "var(--paper-bright)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}><Icon name="check" size={14} />{uiText("Finish (")}{uiText(poly.length)})</button>
                )}
                {proposal?.regions.length > 0 && (
              <button onClick={createProposal} title={uiText("Create the selected takeoff(s) (↵). ⌫ removes the last click; Esc discards the selection.")} style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 12px", border: "none", background: "var(--c-positive)", color: "var(--paper-bright)", cursor: "pointer", fontWeight: 600, fontSize: 12.5, lineHeight: 1 }}><Icon name="check" size={14} />{uiText("Create (")}{uiText(proposal.regions.length)})</button>
                )}
              </span>
            )}
            <div style={{ flex: 1 }} />
          </div>
          <span data-topbar-pinned style={{ display: "inline-flex", alignItems: "center", gap: 7, flexShrink: 0, paddingTop: 16 }}>
        {!workspaceLayout && <LanguageSwitcher />}
        {cluster(`${tr("Scale")} — ${labelFor(focusPanel)}`,
              <>
                <button onClick={() => setUnits((u) => (u === "metric" ? "imperial" : "metric"))}
              title={uiText(units === "metric" ? "Metric display (m² / m) — click for imperial. Calibrate in meters; 1:50-style scales in the list. Display only — stored takeoffs never change." : "Imperial display (SF / LF) — click for metric (m² / m, calibrate in meters, 1:50-style scales). Display only — stored takeoffs never change.")}
                  style={{ padding: "6px 10px", border: `1px solid ${units === "metric" ? "var(--cobalt)" : "var(--ink-faint)"}`, background: units === "metric" ? "var(--cobalt)" : "transparent", color: units === "metric" ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", fontWeight: 700, fontFamily: "var(--f-mono)", fontSize: 11, lineHeight: 1 }}>
              {uiText(units === "metric" ? tr("m") : tr("ft"))}
                </button>
                <ToolMenu
              title={uiText(scaleTitle)}
                  onOpenChange={onScaleMenuDepth}
              face={<span data-tour="scale">{uiText(scaleFace)}</span>}
                  faceStyle={{ fontFamily: "var(--f-mono)", fontSize: 11.5, ...scaleFaceStyle }}
              menuStyle={{ minWidth: 290, maxHeight: "min(600px, 70vh)", overflowY: "auto" }}
                  items={scaleItems}
                />
              </>
            )}
            <button type="button" ref={workspaceLayout ? undefined : workButtonRef} aria-expanded={agentOpen} onClick={() => setAgentOpen((v) => !v)}
          title={uiText("Work and review — measurements, provenance, and agent proposals")}
              style={{ minHeight: "var(--ctl-m)", padding: "var(--sp-1) var(--sp-3)", border: "1px solid var(--cobalt)", background: agentOpen ? "var(--cobalt)" : "transparent", color: agentOpen ? "var(--accent-contrast)" : "var(--cobalt)", cursor: "pointer", fontSize: "var(--fs-s)", fontWeight: 600 }}>
          <ScanStar size={12} working={agentRunning} style={{ marginRight: 6, marginTop: -2 }} />{tr("Work")}{uiText(agentRunning ? " · Working" : shapes.some((s) => s.origin?.reviewed === false) ? ` · ${shapes.filter((s) => s.origin?.reviewed === false).length}` : "")}
            </button>
        <button onClick={openEstimate} disabled={!conditions.length} title={uiText("Price the takeoff — material and labor per unit, markups, Excel.")}
          style={{ padding: "8px 14px", border: "1px solid var(--ink)", background: "transparent", color: conditions.length ? "var(--ink)" : "var(--text-faint)", cursor: conditions.length ? "pointer" : "default", fontWeight: 700, fontFamily: "var(--f-mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase" }}>{tr("Estimate")}</button>
        <button data-tour="report" onClick={() => setShowReport(true)} disabled={!conditions.length} title={uiText("Open the takeoff report — per-condition breakdown with waste, plus CSV / JSON export.")}
          style={{ padding: "8px 14px", border: "none", background: conditions.length ? "var(--ink)" : "var(--text-faint)", color: "var(--paper-bright)", cursor: conditions.length ? "pointer" : "default", fontWeight: 700, fontFamily: "var(--f-mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase" }}>{tr("Report")}</button>
            {/* ⋯ overflow — rarely-used project controls, so the row never wraps
            and nothing shifts position mid-work (issue #61's contract). */}
            <ToolMenu
          title={tr("More — guide, appearance, schedule import, project moves")}
              onOpenChange={onMenuDepth}
              face={<span style={{ fontWeight: 700, letterSpacing: "0.08em" }}>⋯</span>}
              items={[
                { id: "workspace-preview", label: workspaceLayout ? "Classic layout" : "Premium layout — compact controls", onSelect: () => workspacePrefs.setEnabled(!workspaceLayout) },
                { id: "guide", label: tr("How OpenTakeoff works"), shortcut: "?", onSelect: () => setGuideOpen(true) },
                { id: "tour", label: tr("Guided first takeoff"), onSelect: startTour },
                { id: "assistant", label: tr("Assistant — talk to your own AI here"), onSelect: openAssistant },
                { id: "connect-ai", label: tr("Connect your AI"), onSelect: () => setConnectOpen(true) },
                { id: "theme", label: theme === "dark" ? "Light chrome" : "Dark chrome", onSelect: toggleTheme },
                "divider",
            { id: "schedule", icon: "rectTool", label: tr("Import from schedule"), active: tool === "schedule", onSelect: () => { setScheduleAnchor(null); setTool((t) => (t === "schedule" ? "select" : "schedule")); } },
                ...(cloudMode ? [
                  "divider",
              { id: "closeproj", label: tr("Close project"), onSelect: closeProject },
              ...(browseProjects ? [{ id: "projects", label: tr("Team projects"), onSelect: browseProjects }] : []),
                ] : []),
                ...(!cloudMode && googleUser && isGoogleConfigured() && projectHomeFolderId() ? [
                  "divider",
              { id: "browse", label: tr("Browse team projects"), onSelect: () => navigate("/projects") },
                ] : []),
              ]}
            />
            <PresenceChip bridge={store.syncBridge} />
        <AccountChip note={cloudMode ? tr("Synced to Google Drive") : tr("Local workspace")} onOpenChange={onMenuDepth} />
          </span>
        </div>
      )}

      {/* quick-access condition palette — its own slim band under the toolbar
          (like the sheet-tabs / conditions-strip rows), not crammed into the
          already-wrapping top bar. A curated ≤9 pinned conditions for one-click
          activation without opening the panel: drag a condition here from the
          Takeoffs panel (or the strip) to pin it, or use a row's pushpin. Each
          chip carries its 1–9 hotkey badge (cobalt); single-click activates
          (reassigning a selected shape, like every activation surface),
          double-click opens the docked panel scrolled to that row, the pushpin
          unpins, and dragging one chip onto another reorders (which renumbers
          the hotkeys). Below the chips, the active condition's appearance editor
          — the same one the docked panel row renders — so line/fill/hatch/height
          are editable without opening the sidebar. Shown once there's a
          condition to pin, so the drop zone is discoverable. */}
      {!focusMode && (!workspaceLayout || workspaceArrangement.palette) && conditions.length > 0 && (
        <div
          onDragOver={(e) => { if (e.dataTransfer.types.includes(CONDITION_DND_MIME)) { e.preventDefault(); e.stopPropagation(); e.dataTransfer.dropEffect = "copy"; } }}
          onDrop={(e) => { if (!e.dataTransfer.types.includes(CONDITION_DND_MIME)) return; e.preventDefault(); e.stopPropagation(); const id = e.dataTransfer.getData(CONDITION_DND_MIME); if (id) pinToPalette(id); }}
          style={{ padding: "5px 14px", borderBottom: "1px solid var(--ink-faint)", background: "var(--paper-bright)" }}>
          <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
            <span title={uiText("Quick-access conditions — drag a condition here (or use a row's pushpin) to pin it, up to 9. Press 1–9 to activate by this order; click a chip to activate; double-click to open the panel.")}
              style={{ fontFamily: "var(--f-mono)", fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.14em", color: "var(--ink-muted)" }}>{tr("Conditions")}</span>
            {paletteConds.length === 0 ? (
              <span style={{ fontSize: 11.5, color: "var(--ink-muted)", fontStyle: "italic", padding: "3px 8px", border: "1px dashed var(--ink-faint)" }}>{uiText("drag conditions here (or pin a row) for 1-9 one-click access")}</span>
            ) : paletteConds.map((c) => {
              const on = c.id === activeCond;
              const reassign = tool === "select" && selectedId;
              const idx = palette.indexOf(c.id);   // palette position → the 1–9 hotkey number
              return (
                <span key={c.id} style={{ display: "inline-flex", alignItems: "center" }}
                  onDragOver={(e) => { if (e.dataTransfer.types.includes(CONDITION_DND_MIME)) { e.preventDefault(); e.stopPropagation(); e.dataTransfer.dropEffect = "move"; } }}
                  onDrop={(e) => { if (!e.dataTransfer.types.includes(CONDITION_DND_MIME)) return; e.preventDefault(); e.stopPropagation(); const dragId = e.dataTransfer.getData(CONDITION_DND_MIME); if (dragId) { if (palette.includes(dragId)) movePalette(dragId, idx); else pinToPalette(dragId); } }}>
                  <button type="button" draggable
                    onDragStart={(e) => { e.dataTransfer.setData(CONDITION_DND_MIME, c.id); e.dataTransfer.effectAllowed = "copyMove"; }}
                    onClick={() => activateCondition(c.id)}
                    onDoubleClick={() => openConditionInPanel(c.id)}
                    title={uiText(reassign ? `Reassign the selected takeoff to ${c.finish_tag} (double-click opens the panel)` : `${c.finish_tag} — press ${idx + 1} or click to activate, double-click to open in the panel, drag onto another chip to reorder`)}
                    style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "3px 8px 3px 5px", border: on ? `2px solid ${c.color}` : (reassign ? "1px dashed var(--cobalt)" : "1px solid var(--ink-faint)"), background: on ? "var(--surface-pop)" : "transparent", cursor: "pointer", fontWeight: on ? 700 : 500, fontSize: 12.5, lineHeight: 1 }}>
                    {idx < 9 && <span style={{ fontSize: 9, fontFamily: "var(--f-mono,monospace)", color: "var(--cobalt)", border: "1px solid var(--cobalt)", borderRadius: 3, padding: "0 3px" }}>{uiText(idx + 1)}</span>}
                    <span style={{ borderRadius: 4, overflow: "hidden", lineHeight: 0 }}><HatchSwatch type={c.hatch || "solid"} line={c.color} fill={c.fill} /></span><span title={finishLabel(c.finish_tag)}>{c.finish_tag}</span>
                  </button>
                  <button type="button" onClick={() => unpinFromPalette(c.id)} title={uiText(`Unpin ${c.finish_tag} from the palette`)}
                    style={{ border: "none", background: "none", cursor: "pointer", color: "var(--cobalt)", padding: "0 3px", lineHeight: 0, display: "inline-flex" }}>
                    <Icon name="pin" size={12} />
                  </button>
                </span>
              );
            })}
            {paletteConds.length >= PALETTE_MAX && (
              <span style={{ fontSize: 10.5, color: "var(--ink-muted)", fontStyle: "italic" }}>{uiText("full (")}{uiText(PALETTE_MAX)})</span>
            )}
            {/* add a condition without opening the (now-collapsed) sidebar */}
            <button type="button" onClick={addCondition} title={uiText("Add a new condition")}
              style={{ padding: "3px 9px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 12, color: "var(--ink-muted)" }}>{tr("+ condition")}</button>
          </div>
          {/* the active condition's appearance editor, restored to the top bar —
              same component the docked panel row renders (one source of truth) */}
          {aCond && (
            <div style={{ marginTop: 5, paddingTop: 5, borderTop: "1px solid var(--ink-faint)", display: "flex", alignItems: "center", flexWrap: "wrap", gap: "var(--sp-2)" }}>
              <button type="button" aria-expanded={conditionDetails} onClick={() => setConditionDetails((v) => !v)} style={{ border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink-secondary)", padding: "var(--sp-1) var(--sp-2)", fontSize: "var(--fs-s)", cursor: "pointer" }}>{uiText(conditionDetails ? "▾" : "▸")} {finishLabel(aCond.finish_tag)} {uiText("properties")}</button>
              {conditionDetails && <ConditionAppearanceEditor cond={aCond} onUpdateCond={updateCond} onSetCondParam={setCondParam} onAssignAttr={assignAttr} conditionColumns={conditionColumns} layout="row" units={units} />}
            </div>
          )}
        </div>
      )}

      {uiText(!focusMode && view === "canvas" && annotations.toolbar)}

      {/* open-sheet tabs — what you opened from the gallery; click to view,
          ⊞ to side-by-side, ✕ to close; the dropdown lists every open sheet */}
      {!focusMode && openTabs.length > 0 && !(workspaceLayout && openTabs.length <= 1 && !sheetGroup.length && !splitView) && (
        <div data-sheet-tabs style={{ display: "flex", gap: 5, alignItems: "center", padding: "5px 14px", flexWrap: openTabs.length > MANY_TABS ? "nowrap" : "wrap", borderBottom: "1px solid var(--ink-faint)", background: "var(--paper-bright)", minWidth: 0 }}>
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.14em", color: "var(--ink-muted)", flexShrink: 0 }}>{tr("Sheets")}</span>
          {openTabs.length > MANY_TABS && (
            <button type="button" onClick={() => scrollTabStrip(-1)} title={uiText("Scroll sheets left")} aria-label={uiText("Scroll sheets left")} style={{ flexShrink: 0, padding: "4px 5px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", cursor: "pointer", display: "inline-flex" }}><Icon name="chevronLeft" size={12} /></button>
          )}
          <div ref={tabStripRef} data-sheet-tab-strip style={{ display: "flex", gap: 5, alignItems: "center", flexWrap: openTabs.length > MANY_TABS ? "nowrap" : "wrap", overflowX: openTabs.length > MANY_TABS ? "auto" : "visible", minWidth: 0, flex: openTabs.length > MANY_TABS ? 1 : "0 1 auto", scrollbarWidth: "none", overscrollBehaviorX: "contain" }}>
            {openTabs.map((k) => {
              const inGroup = sheetGroup.includes(k);
              const on = sheetGroup.length ? inGroup : k === sheetKey;
              const lbl = tabLabel(k);
              return (
                <span key={k} data-sheet-tab={on ? "active" : "idle"} draggable={!isStitchKey(k)}
                  onMouseEnter={() => armSheetDrag(k)}
                  onDragStart={(e) => onSheetTabDragStart(k, e)}
                  // dragend fires exactly once per drag gesture regardless of how
                  // it ended (a real drop, an Escape-cancel, or releasing outside
                  // any valid target) — the one reliable place to guarantee the
                  // overlay never survives a cancelled drag (onDrop only clears
                  // dragZone on an actual drop).
                  onDragEnd={() => setDragZone(null)}
                title={uiText(!isStitchKey(k) ? "Drag this tab to a screen edge to split, or out of the app to export the marked sheet" : undefined)}
                  style={{ display: "inline-flex", alignItems: "center", gap: 5, flexShrink: 0, border: "1px solid var(--ink-faint)", borderBottom: on ? "2px solid var(--cobalt)" : "1px solid var(--ink-faint)", background: on ? "var(--paper-cream)" : "transparent", padding: "3px 6px 2px 9px", maxWidth: 190 }}>
                <button onClick={() => goToSheet(k)} title={uiText(k)} style={{ border: "none", background: "none", cursor: "pointer", fontWeight: on ? 700 : 500, fontSize: 11.5, color: "var(--ink)", fontFamily: "var(--f-mono)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 140, padding: 0 }}>{uiText(lbl)}</button>
                <button onClick={() => toggleInGroup(k)} title={uiText(inGroup ? "Remove from side-by-side" : "Side-by-side with the current sheet")} style={{ border: "none", background: "none", cursor: "pointer", color: inGroup ? "var(--cobalt)" : "var(--ink-faint)", padding: 0, display: "inline-flex" }}><Icon name="sideBySide" size={11} /></button>
                <button onClick={() => closeTab(k)} title={uiText("Close tab")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--ink-muted)", padding: 0, display: "inline-flex" }}><Icon name="close" size={10} /></button>
                </span>
              );
            })}
          </div>
          {openTabs.length > MANY_TABS && (
            <button type="button" onClick={() => scrollTabStrip(1)} title={uiText("Scroll sheets right")} aria-label={uiText("Scroll sheets right")} style={{ flexShrink: 0, padding: "4px 5px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", cursor: "pointer", display: "inline-flex" }}><Icon name="chevronRight" size={12} /></button>
          )}
          {openTabs.length > 1 && openTabs.length <= MANY_TABS && (
            <ToolMenu
              title={uiText("Jump to an open sheet")}
              onOpenChange={onMenuDepth}
              face={<span style={{ fontFamily: "var(--f-mono)", fontSize: 11 }}>{uiText(openTabs.length)} open</span>}
              items={openTabs.map((k) => ({ id: k, icon: "document", label: tabLabel(k), active: sheetGroup.length ? sheetGroup.includes(k) : k === sheetKey, onSelect: () => goToSheet(k) }))}
            />
          )}
        </div>
      )}

      {/* compact conditions strip — OPTIONAL small-project mode. The docked
          Takeoffs panel is the primary conditions surface; the strip renders
          the same state (activate/reassign, hotkey badges, + condition) for
          users who want max panel-collapse and one-click switching. Toggled
          from the panel header, persisted with the panel prefs. */}
      {!focusMode && !workspaceLayout && panelPrefs.strip && (
        <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "7px 14px", flexWrap: "wrap", borderBottom: "1px solid var(--ink-faint)", background: "var(--paper-bright)" }}>
          <span style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--ink-muted)" }}>{tr("Conditions")}</span>
          {conditions.map((c, i) => {
            const on = c.id === activeCond;
            // the 1–9 badge follows the same rule as the hotkeys: palette order
            // when curated, condition order (fallback) when nothing is pinned
            const pinnedPal = palette.length > 0;
            const hIdx = pinnedPal ? palette.indexOf(c.id) : i;
            const hot = hIdx >= 0 && hIdx < 9;
            return (
              <button key={c.id} draggable onDragStart={(e) => { e.dataTransfer.setData(CONDITION_DND_MIME, c.id); e.dataTransfer.effectAllowed = "copy"; }} onClick={() => activateCondition(c.id)} title={uiText(tool === "select" && selectedId ? "Reassign selected shape to this condition" : (hot ? `Press ${hIdx + 1} · drag to the palette to pin` : "Drag to the palette to pin"))} style={{ display: "flex", alignItems: "center", gap: 6, padding: "3px 10px 3px 4px", borderRadius: 0, border: on ? `2px solid ${c.color}` : (tool === "select" && selectedId ? "1px dashed var(--cobalt)" : "1px solid var(--ink-faint)"), background: on ? "var(--surface-pop)" : "transparent", cursor: "pointer", fontWeight: on ? 700 : 500, fontSize: 12.5 }}>
                {hot && <span style={{ fontSize: 9, fontFamily: "var(--f-mono,monospace)", color: pinnedPal ? "var(--cobalt)" : "var(--ink-muted)", border: `1px solid ${pinnedPal ? "var(--cobalt)" : "var(--ink-faint)"}`, borderRadius: 3, padding: "0 3px" }}>{uiText(hIdx + 1)}</span>}
                <span style={{ borderRadius: 4, overflow: "hidden", lineHeight: 0 }}><HatchSwatch type={c.hatch || "solid"} line={c.color} fill={c.fill} /></span><span title={finishLabel(c.finish_tag)}>{c.finish_tag}</span>
              </button>
            );
          })}
          <button onClick={addCondition} style={{ padding: "4px 10px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 12.5, color: "var(--ink-muted)" }}>{tr("+ condition")}</button>
        </div>
      )}

      {/* Copy text prompt (#471) — the calibrate/check prompt-bar idiom */}
      {tool === "textcopy" && (
        <div style={{ padding: "8px 14px", background: "var(--paper-bright)", borderBottom: "1px solid var(--hairline-warm)", fontSize: 14, display: "flex", alignItems: "center", gap: "var(--sp-3)" }}>
          <span>{uiText("Copy text: click two corners around the text (")}{uiText(textAnchor ? 1 : 0)}{uiText("/2). Rotated runs are left out and counted.")}</span>
          <button type="button" className="btn-ghost" onClick={() => copyTextFrom(focusPanel.key, null, "page")}>{uiText("Copy page text")}</button>
        </div>
      )}

      {/* calibration prompt */}
      {tool === "calibrate" && (
        <div style={{ padding: "8px 14px", background: "var(--paper-bright)", borderBottom: "1px solid var(--hairline-warm)", fontSize: 14 }}>
          {calib.length < 2 ? <span>{uiText("Custom scale: click two points along a known dimension (")}{uiText(calib.length)}{uiText("/2). Tip: use the longest dimension. (Or just pick a standard scale above.)")}</span> : (
            <span>{uiText("Real length:")}{uiText(" ")}
              <input name="calibration-length" type="number" step="any" inputMode="decimal" aria-label={tr("Real length:")} value={pendingLen} onChange={(e) => setPendingLen(e.target.value)} onKeyDown={(e) => e.key === "Enter" && applyCalibration()} placeholder={uiText(units === "metric" ? "meters" : "feet")} autoFocus style={{ width: 90, padding: 5, borderRadius: 0, border: "1px solid var(--ink-faint)" }} /> {uiText(units === "metric" ? tr("m") : tr("ft"))}
              <button onClick={applyCalibration} style={{ marginLeft: 8, padding: "5px 12px", borderRadius: 0, border: "none", background: "var(--ink)", color: "var(--paper-bright)", cursor: "pointer" }}>{uiText("Apply")}</button>
              <button onClick={() => setCalib([])} style={{ marginLeft: 6, padding: "5px 10px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer" }}>{uiText("Reset")}</button>
            </span>
          )}
        </div>
      )}

      {/* check-a-dimension prompt — read-only twin of calibrate: measure a printed
          dimension at the current scale, compare with what the drawing says */}
      {tool === "check" && (
        <div style={{ padding: "8px 14px", background: "var(--paper-bright)", borderBottom: "1px solid var(--hairline-warm)", fontSize: 14 }}>
          {check.length < 2 ? (
            <span>{uiText("Check a dimension: click both ends of a printed dimension (")}{uiText(check.length)}{uiText("/2). The measured length shows here — compare it with what the drawing says.")}</span>
          ) : checkCross ? (
            <span style={{ color: "var(--c-danger)" }}>{uiText("Check on one sheet — those two clicks landed on different sheets. ")}<button onClick={() => { setCheck([]); setCheckStated(""); }} style={{ marginLeft: 6, padding: "5px 10px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer" }}>{uiText("Reset")}</button></span>
          ) : !checkUpp ? (
            <span style={{ color: "var(--c-danger)" }}>{uiText("No scale set for ")}{uiText(labelFor(checkPanel))} {uiText("— pick a standard scale or calibrate first, then check it here.")}</span>
          ) : checkPx <= 0 ? (
            <span style={{ color: "var(--c-danger)" }}>{uiText("Those two clicks landed on the same point — click the two ")}<b>{uiText("ends")}</b> {uiText("of a printed dimension.")}</span>
          ) : (
            <span>
              {uiText("measures ")}<b style={{ fontFamily: "var(--f-mono)" }}>{uiText(fmtCheckLen(checkFeet, units))}</b> {uiText("at ")}{uiText(stdValue || "custom scale")} {uiText("· drawing says")}{uiText(" ")}
              <input name="check-stated-length" value={checkStated} onChange={(e) => setCheckStated(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") e.currentTarget.blur(); }} placeholder={uiText(units === "metric" ? "meters" : `feet (12'6, 6" ok)`)} autoFocus style={{ width: 100, padding: 5, borderRadius: 0, border: "1px solid var(--ink-faint)" }} /> {uiText(units === "metric" ? tr("m") : tr("ft"))}
              {checkErrPct != null && (() => {
                // checkVerdict grades the ROUNDED value the chip displays (and
                // normalizes -0), so color and number can never contradict —
                // see units.ts for the ≤1/≤5 tie-break rationale
                const v = checkVerdict(checkErrPct);
                const pct = `${v.shown >= 0 ? "+" : ""}${v.shown.toFixed(1)}%`;
                return (
                  <b style={{ marginLeft: 8, color: v.grade === "match" ? "var(--c-positive)" : v.grade === "close" ? "var(--c-warning)" : "var(--c-danger)" }}>
                    {uiText(v.grade === "match" ? `matches — scale checks out (${pct})`
                      : v.grade === "close" ? `off by ${pct} — re-check or recalibrate`
                      : `off by ${pct} — wrong scale; recalibrate`)}
                  </b>
                );
              })()}
              {checkStatedFeet > 0 && (
                <button onClick={recalibrateFromCheck} style={{ marginLeft: 8, padding: "5px 12px", borderRadius: 0, border: "none", background: "var(--ink)", color: "var(--paper-bright)", cursor: "pointer" }}>{uiText("Recalibrate to this")}</button>
              )}
              <button onClick={() => { setCheck([]); setCheckStated(""); }} style={{ marginLeft: 6, padding: "5px 10px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer" }}>{uiText("Reset")}</button>
            </span>
          )}
        </div>
      )}

      {/* canvas + issue desk */}
      <div data-canvas-workspace style={{ flex: 1, display: "flex", overflow: "hidden", minHeight: 0, position: "relative" /* anchors the narrow-screen panel overlay */ }}>
        {workspaceLayout && <><WorkspaceNavigator open={!focusMode && workspaceNavigationOpen} items={workspaceSheets} current={treeCurrent} namer={namer} countKnown={countKnown} hold={ocrHold} onSelect={(key) => openSheets([key], false)} onClose={() => setWorkspaceNavigationOpen(false)} onGallery={() => { setView("gallery"); setWorkspaceNavigationOpen(false); }} dockSide={workspaceArrangement.sheets} width={workspaceArrangement.sheetWidth} dockHandle={workspaceDockHandle("sheets", tr("Sheets"))} onReorderPages={(f, fromP, toP) => reorderDocumentPages(f, fromP, toP)} onRotatePage={(k, a) => rotateCurrentSheet(a, k)} onDeletePage={(k) => deleteCurrentSheet(k)} /><DockTargets dragging={workspaceDragging} /></>}
        {/* tool rail — machined faces grouped by MCP module (the concept shell).
           Individual tiles replace deck 2's Measure/Cut Out menus; Markup keeps
           its variety flyout on one tile (five markup kinds don't earn five
           faces). Lives in the canvas row so docked panels + canvas reflow
           beside it; survives focus mode — it IS the tool access. */}
       {view === "canvas" && dockBottom && (() => {
         // Premium's dock: the five everyday tools and Cut, then ⋯ for everything else, then history
         const toggleLeft = (id) => setLeftTab((t) => (t === id ? null : id));
         const trayGroups = [
           [tr("Measure"), [
             ...(oneClickEnabled() ? [{ id: "oneclick", icon: "oneClick", label: tr("One-click area — click inside a room"), short: tr("One-click"), shortcut: "O", active: tool === "oneclick", onSelect: () => setTool("oneclick") }] : []),
             { id: "surface", icon: "surface", label: tr("Surface (wall) area"), short: tr("Wall area"), shortcut: "S", active: tool === "surface", onSelect: () => setTool("surface") },
             { id: "deduct-rect", icon: "deductRect", label: tr("Rectangle cutout"), short: tr("Rect cutout"), shortcut: "⇧D", active: tool === "deduct-rect", onSelect: () => setTool("deduct-rect") },
           ]],
           [tr("Check & find"), [
             { id: "zone", icon: "zone", label: tr("Zone check — trace a region to read every condition's quantities inside it. Nothing is saved."), short: tr("Zone check"), active: tool === "zone", onSelect: () => setTool((t) => (t === "zone" ? "select" : "zone")) },
             { id: "symbol", icon: "symbol", label: tr("Symbol sweep — box one example; every match is counted"), short: tr("Symbol sweep"), shortcut: "Y", active: tool === "symbol", onSelect: () => setTool("symbol") },
             { id: "textcopy", icon: "copyText", label: tr("Copy text — click two corners around a note or schedule"), short: tr("Copy text"), active: tool === "textcopy", onSelect: armCopyText },
           ]],
           [tr("Mark up"), [
             ...annotations.items.map((it) => ({ ...it, short: { "annot-sweep": "Mark all", "annot-selection": "Select notes", "annot-cloud": "Cloud" }[it.id] })),
             ...MARKUP_TOOLS.filter((t) => !["highlighter", "cloud", "callout"].includes(t.id)).map((t) => ({ id: t.id, icon: t.icon, label: t.label, short: { text: "Text", highlight: "Box", dimension: "Dimension", image: "Image" }[t.id], shortcut: t.shortcut, active: tool === t.id, onSelect: () => { setTool(t.id); setMarkupDraft(null); } })),
             { id: "approve", icon: "approve", label: tr("Approval stamp — your sign-off that a takeoff was checked. Human-only."), short: tr("Approve"), active: tool === "approve", onSelect: () => setTool((t) => (t === "approve" ? "select" : "approve")) },
             { id: "markup-list", icon: "document", label: tr("Markup list — existing clouds, callouts, and notes"), short: tr("Markup list"), count: markupCount, active: leftTab === "markup", onSelect: () => toggleLeft("markup") },
             { id: "stamps", icon: "stamp", label: tr("Stamps — reusable annotations dropped click-to-place"), short: tr("Stamp library"), count: stampLib.stamps.length, active: leftTab === "stamp", onSelect: () => toggleLeft("stamp") },
             { id: "rfis", icon: "rfi", label: tr("RFI register — raise, track, and export Requests For Information"), short: tr("Issues"), count: rfis.length, active: leftTab === "rfi", onSelect: () => toggleLeft("rfi") },
           ]],
           [tr("Scale"), [
             { id: "calibrate", icon: "calibrate", label: tr("Calibrate — click two points of a known dimension"), short: tr("Calibrate"), active: tool === "calibrate", onSelect: () => setTool("calibrate") },
           ]],
           [tr("Aids"), [
             { id: "snap", icon: "snap", label: tr("Snap to plan lines and corners (beta)"), short: tr("Snap"), active: snapOn, stayOpen: true, onSelect: () => setSnapOn((v) => !v) },
             { id: "angle", icon: "angle", label: tr("45° / 90° angle guides — ⇧ locks"), short: tr("45° / 90°"), active: angleOn, stayOpen: true, onSelect: () => setAngleOn((v) => !v) },
           ]],
         ];
         const trayArmed = trayGroups.some(([, items]) => items.some((it) => it.active && !["snap", "angle", "markup-list", "stamps", "rfis"].includes(it.id)));
         const sep = (k) => <span key={k} aria-hidden="true" style={{ width: 1, height: 24, background: "var(--ink-faint)", margin: "0 5px", flexShrink: 0 }} />;
         return (
           <div ref={dockWrapRef} data-dock-wrap onPointerDown={(e) => e.stopPropagation()}
             style={{ position: "absolute", left: 0, right: 0, bottom: 14, marginInline: "auto", width: "max-content", maxWidth: "calc(100% - 28px)", zIndex: 25 }}>
             {trayOpen && <ToolTray groups={trayGroups} onPicked={() => setTrayOpen(false)} />}
             {tool === "highlighter" && (
               <div style={{ position: "absolute", left: 0, bottom: "calc(100% + 10px)", zIndex: Z.popover, background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", boxShadow: "var(--shadow-pop)", padding: "8px 10px", display: "flex", gap: 6 }} title={tr("Ink")}>
                 {HL_INKS.map((c) => <button key={c} onClick={() => setHlStyle((st) => ({ ...st, color: c }))} aria-label={uiText(`Ink ${c}`)} style={{ width: 16, height: 16, padding: 0, background: c, border: hlStyle.color === c ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer" }} />)}
               </div>
             )}
             <nav data-tool-rail data-dock-side="bottom" role="toolbar" aria-label={tr("Tools")}
               style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: 3, padding: "6px 8px", border: "1px solid var(--ink-faint)", borderRadius: 12, background: "var(--paper-cream)", boxShadow: "var(--shadow-2)", overflowX: "auto" }}>
               {railTile("select", "select", "Select — pick a takeoff, drag points; drag open canvas to pan", "V")}
               {sep("s1")}
               {railTile("area", "area", "Area", "A")}
               {railTile("rect", "rectTool", "Rectangle", "R")}
               {railTile("linear", "linear", "Linear", "L")}
               {railTile("count", "count", "Count", "C")}
               {railTile("cut", "scissors", "Cut — polygon cutout (D); click again for a rectangle cutout (⇧D)", "D",
                 () => setTool((t) => (t === "deduct" ? "deduct-rect" : "deduct")), { armed: tool === "deduct" || tool === "deduct-rect", tint: tool === "deduct" || tool === "deduct-rect" ? "var(--c-danger)" : undefined })}
               {sep("s2")}
               <button type="button" onClick={() => setTrayOpen((v) => !v)} aria-expanded={trayOpen} aria-controls="ot-tool-tray" aria-label={tr("More tools")}
                 title={tr("More tools — measure, check & find, mark up, scale and aids")}
                 style={{ position: "relative", width: "var(--ctl-l)", height: "var(--ctl-l)", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: "var(--r-1)", cursor: "pointer",
                   border: `1px solid ${trayOpen || trayArmed ? "color-mix(in srgb, var(--cobalt) 45%, transparent)" : "transparent"}`, background: trayOpen ? "var(--tint-select)" : "transparent", color: trayOpen || trayArmed ? "var(--cobalt)" : "var(--ink)" }}>
                 <Icon name="more" size={18} />
               </button>
               {sep("s3")}
               {railTile("dock-undo", "undo", "Undo", "⌘Z", () => (poly.length ? dropLastPoint() : undoShapeCommand()), { armed: false })}
               {railTile("dock-redo", "redo", "Redo", "⇧⌘Z", () => redoShapeCommand(), { armed: false })}
             </nav>
           </div>
         );
       })()}
       {view === "canvas" && !dockBottom && (
       <nav data-tool-rail data-dock-side={workspaceLayout ? workspaceArrangement.tools : undefined} role="toolbar" aria-label={tr("Tools")}
         onPointerDown={dockBottom ? (e) => e.stopPropagation() : undefined}
         style={dockBottom
           ? { position: "absolute", left: 0, right: 0, bottom: 14, marginInline: "auto", width: "max-content", zIndex: 25, display: "flex", flexDirection: "row", alignItems: "center", gap: 2, padding: "4px 6px", border: "1px solid var(--ink-faint)", borderRadius: 10, background: "var(--paper-cream)", boxShadow: "var(--shadow-2)", maxWidth: "calc(100% - 28px)", overflowX: "auto", overflowY: "visible" }
           : { order: workspaceLayout ? workspaceArrangement.tools === "right" ? 30 : -30 : undefined, width: "var(--rail-w)", flexShrink: 0, display: "flex", flexDirection: "column", alignItems: "center", gap: "var(--sp-1)", paddingTop: "var(--sp-2)", borderRight: "1px solid var(--ink-faint)", background: "var(--paper-bright)", overflowY: "auto", overflowX: "visible" }}>
         {!dockBottom && workspaceDockHandle("tools", "Tools")}
         {railLabel("SEL")}
         {railTile("select", "select", "Select — pick a takeoff, drag points; drag open canvas to pan", "V")}
         {railLabel("MEAS")}
         {MEASURE_TOOLS.filter((t) => t.id !== "oneclick" || oneClickEnabled()).map((t) => railTile(t.id, t.icon, t.label, t.shortcut))}
         {railLabel("CUT")}
         {CUT_TOOLS.map((t) => railTile(t.id, t.icon, t.label, t.shortcut, null, { tint: "var(--c-danger)" }))}
         {railLabel("MARK")}
         <span ref={(el) => { if (el) markTileTopRef.current = el.getBoundingClientRect().top; }} style={{ position: "relative", display: "inline-flex" }}>
           <ToolMenu
             title={tr("Create annotation — cloud, callout, text, highlight, or dimension")}
             active={MARKUP_IDS.includes(tool)}
             onOpenChange={onMenuDepth}
             flyout={dockBottom ? "up" : "right"}
             face={<span className="ot-rail-annotation"><Icon name="markup" size={17} />{language === "ru" && !dockBottom && <span>Пометки</span>}</span>}
             items={[
               { section: tr("Markup — notes on the plan, never measured") },
               ...markupTools.map((t) => ({ id: t.id, icon: t.icon, label: t.label, shortcut: t.shortcut, active: tool === t.id, onSelect: () => { setTool(t.id); setMarkupDraft(null); } })),
             ]}
           />
           {/* highlighter style popover — fixed beside the rail while armed
               (fixed, not absolute: the rail's scroll box would clip it) */}
           {tool === "highlighter" && (
             <div style={{ position: dockBottom ? "absolute" : "fixed", ...(dockBottom ? { left: 0, bottom: "calc(100% + 10px)" } : { left: "calc(var(--rail-w) + 8px)", top: markTileTopRef.current || 200 }), zIndex: Z.popover, background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", borderRadius: 0, boxShadow: "var(--shadow-pop)", padding: "8px 10px", display: "flex", flexDirection: "column", gap: 7 }}>
               <div style={{ display: "flex", gap: 6 }} title={uiText("Ink")}>
                 {HL_INKS.map((c) => (
                   <button key={c} onClick={() => setHlStyle((st) => ({ ...st, color: c }))}
                     style={{ width: 16, height: 16, padding: 0, background: c, border: hlStyle.color === c ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer" }} />
                 ))}
               </div>
               <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                 {HL_SIZES.map(([lbl, px]) => (
                   <button key={lbl} onClick={() => setHlStyle((st) => ({ ...st, size: px }))} title={uiText(`${lbl === "F" ? "Fine" : lbl === "M" ? "Medium" : "Broad"} tip`)}
                     style={{ width: 22, height: 20, padding: 0, fontFamily: "var(--f-mono)", fontSize: 10, cursor: "pointer", border: hlStyle.size === px ? "1px solid var(--ink)" : "1px solid var(--ink-faint)", background: hlStyle.size === px ? "var(--ink)" : "transparent", color: hlStyle.size === px ? "var(--paper-bright)" : "var(--ink)" }}>{uiText(lbl)}</button>
                 ))}
                 <span style={{ width: 1, alignSelf: "stretch", background: "var(--ink-faint)" }} />
                 {[["chisel", "M4 16 L14 6 L18 10 L8 20 Z"], ["round", "M5 17 Q12 3 19 13"]].map(([tip, d]) => (
                   <button key={tip} onClick={() => setHlStyle((st) => ({ ...st, tip }))} title={uiText(`${tip} tip`)}
                     style={{ width: 24, height: 20, padding: 1, cursor: "pointer", border: hlStyle.tip === tip ? "1px solid var(--ink)" : "1px solid var(--ink-faint)", background: "transparent" }}>
                     <svg viewBox="0 0 24 24" width="18" height="14">{tip === "chisel"
                       ? <path d={d} fill="currentColor" stroke="none" />
                       : <path d={d} fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />}</svg>
                   </button>
                 ))}
               </div>
             </div>
           )}
         </span>
         {/* Approval stamp — ink over pencil. Human-only by design: this tile
             is the ONLY way an estimator seal is minted (no MCP tool, no agent
             path), so the mark means a person looked. */}
         {railTile("approve", "approve", "Approval stamp — the estimator's ink. Click a committed takeoff to approve it, or empty plan to approve the sheet; click a seal to lift it. ⌘Z undoes. Human-only.", null,
           () => setTool((t) => (t === "approve" ? "select" : "approve")), { tint: tool === "approve" ? "var(--c-positive)" : undefined, armed: tool === "approve" })}
         {railLabel("READ")}
         {railTile("textcopy", "copyText", "Copy text — click two corners around a note or schedule; its text goes on your clipboard", null, armCopyText)}
         {railLabel("CAL")}
         {railTile("calibrate", "calibrate", "Calibrate — click two points of a known dimension", null)}
         {dockBottom && railLabel("HIST")}
         {dockBottom && railTile("dock-undo", "undo", "Undo", "⌘Z", () => (poly.length ? dropLastPoint() : undoShapeCommand()), { armed: false })}
         {dockBottom && railTile("dock-redo", "redo", "Redo", "⇧⌘Z", () => redoShapeCommand(), { armed: false })}
       </nav>
       )}
       {/* docked LEFT panel — one of Markups/Stamps/RFIs at a time. Reflows the
           canvas (a flex sibling), mirroring the docked Takeoffs panel on the right. */}
        {leftTab && (
          <div style={{ width: 360, flexShrink: 0, display: "flex", flexDirection: "column", borderRight: "1px solid var(--ink-faint)", background: "var(--paper-bright)", overflow: "hidden", minHeight: 0 }}>
            {/* tab strip */}
            <div style={{ display: "flex", alignItems: "stretch", background: "var(--cobalt)", color: "var(--accent-contrast)" }}>
             {[{ id: "markup", label: uiText("Markups"), n: markupCount }, { id: "stamp", label: uiText("Stamps"), n: stampLib.stamps.length }, { id: "rfi", label: uiText("RFIs"), n: rfis.length }].map((t) => (
               <button key={t.id} onClick={() => setLeftTab(t.id)} title={uiText(t.label)}
                  style={{ flex: 1, padding: "9px 6px", border: "none", borderBottom: leftTab === t.id ? "2px solid var(--accent-contrast)" : "2px solid transparent", background: leftTab === t.id ? "rgba(255,255,255,.18)" : "transparent", color: "var(--accent-contrast)", cursor: "pointer", fontWeight: leftTab === t.id ? 700 : 500, fontSize: 12 }}>
                 {uiText(t.label)}{uiText(t.n ? ` · ${t.n}` : "")}
                </button>
              ))}
             <button onClick={() => setLeftTab(null)} title={uiText("Close panel")} style={{ padding: "0 12px", border: "none", background: "transparent", color: "var(--accent-contrast)", fontSize: 16, cursor: "pointer" }}>×</button>
            </div>
            {/* body of the active tab */}
            <div style={{ flex: 1, overflow: "auto", minHeight: 0 }}>
              {leftTab === "markup" && (
                <div>
                  {/* layer show/hide — hides the on-canvas markup layer AND its hit-testing
                     (can't select/delete/fly-to an invisible markup); orthogonal to the
                     marked-set export, which still includes markups. */}
                  <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", padding: "6px 10px", borderBottom: "1px solid var(--ink-faint)" }}>
                    <button
                      onClick={() => { const nv = !showMarkups; setShowMarkups(nv); if (!nv) setSelectedMarkupId(null); }}
                     title={uiText(showMarkups ? "Hide the markup layer on the canvas" : "Show the markup layer on the canvas")}
                      style={{ background: "transparent", border: "1px solid var(--ink-faint)", color: "var(--ink)", fontSize: 11, cursor: "pointer", padding: "2px 7px" }}>
                     {uiText(showMarkups ? "Hide layer" : "Show layer")}
                    </button>
                  </div>
                  <div style={{ padding: "8px 10px", color: "var(--ink-muted)" }}>
                   {uiText("Open ")}<b>{uiText("Create annotation")}</b> {uiText("in the drawing toolbar to choose a cloud, highlight, callout, text note, or dimension, then click the plan to annotate it. ")}<b>{uiText("🖼 Image")}</b> {uiText("marquees a region (two clicks) — or use ")}<b>{uiText("Upload image…")}</b> {uiText("in Captures below.")}</div>
                  {markups.filter((m) => panelKeySet.has(m.sheet_id) && m.type !== "image").length === 0 && (
                    <div style={{ padding: "4px 12px 14px", color: "var(--ink-muted)" }}>
                     {uiText("No markups ")}{uiText(groupKeys.length > 1 ? "on these sheets" : "on this sheet")} {uiText("yet.")}<div style={{ marginTop: 4, fontSize: 11 }}>{uiText("Images now live in ")}<b>{uiText("Captures")}</b> {uiText("below.")}</div>
                    </div>
                  )}
                  {markups.filter((m) => panelKeySet.has(m.sheet_id) && m.type !== "image").map((m) => (
                    <div key={m.id} style={{ padding: "10px 12px", borderTop: "1px solid var(--ink-faint)", background: selectedMarkupId === m.id ? "var(--surface-pop)" : "transparent" }}>
                      {/* the header line selects + flies to the markup (parity with the RFI
                         register's onFlyTo) — the inner controls stopPropagation so only the
                         label area triggers it, never edit/delete. */}
                     <div onClick={() => flyToMarkup(m)} title={uiText("Select and center this markup")} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
                       <span style={{ fontSize: 10, fontWeight: 700, color: "var(--cobalt)", textTransform: "uppercase" }}>{uiText(m.type)}</span>
                        {/* inline edit — the panel's fallback for the canvas overlay, since a
                           markup here may be off-screen or on another sheet (no click point).
                           Enter/blur commit, Esc cancels; INPUT is guarded from the global keys. */}
                        {panelEditId === m.id ? (
                          <input name="markup-text" autoComplete="off" autoFocus defaultValue={m.text || ""}
                            onClick={(e) => e.stopPropagation()}
                            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); updateMarkup(m.id, { text: e.currentTarget.value.trim() }); setPanelEditId(null); } else if (e.key === "Escape") { e.preventDefault(); e.currentTarget.value = m.text || ""; setPanelEditId(null); } }}
                            onBlur={(e) => { updateMarkup(m.id, { text: e.currentTarget.value.trim() }); setPanelEditId(null); }}
                            style={{ flex: 1, minWidth: 0, fontSize: 12.5, padding: "1px 4px", border: "1px solid var(--cobalt)", borderRadius: 0, outline: "none" }} />
                        ) : (
                          (() => {
                            // shown resolved ({{qty}} → "5 EA", #474); the edit box keeps the template
                            const rm = resolveMarkup(m, noteQtyLabels);
                            const warn = rm.unresolved.length > 0;
                           return <span title={uiText(warn ? `Can't fill ${rm.unresolved.join(", ")}: link this note to a condition that has a quantity` : (rm.m !== m ? m.text : undefined))} style={{ flex: 1, color: warn ? "var(--c-danger)" : "var(--ink)" }}>{m.type === "svg" ? <em style={{ color: "var(--ink-muted)" }}>{uiText("(vector symbol)")}</em> : ([m.type === "dimension" && Number(m.len_ft) > 0 ? dimLabel(m.len_ft) : "", rm.m.text].filter(Boolean).join(" · ") || <em style={{ color: "var(--ink-muted)" }}>{uiText("(no text)")}</em>)}</span>;
                          })()
                        )}
                       {m.type !== "svg" && <button onClick={(e) => { e.stopPropagation(); setPanelEditId((id) => (id === m.id ? null : m.id)); }} title={uiText("Edit text")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--ink-muted)" }}>✎</button>}
                       <button onClick={(e) => { e.stopPropagation(); deleteMarkup(m.id); }} title={uiText("Delete markup")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--c-danger)" }}>🗑</button>
                      </div>
                      {/* appearance — per-markup color (reuse PALETTE) + line style; both
                         additive: unset color falls back to the cobalt(linked)/amber default,
                         unset style to solid. The RFI ⬢/number badge stays cobalt regardless. */}
                      <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 7, flexWrap: "wrap" }}>
                       <span style={{ fontSize: 10.5, color: "var(--ink-muted)", marginRight: 2 }}>{uiText("Color")}</span>
                       <button title={uiText("Auto (linkage color)")} onClick={() => updateMarkup(m.id, { color: "" })} style={{ width: 26, height: 15, borderRadius: 4, background: "var(--paper-bright)", border: !m.color ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer", fontSize: 8.5, lineHeight: "11px", color: "var(--ink-muted)" }}>{uiText("auto")}</button>
                       {PALETTE.map((c) => <button key={c} title={uiText(c)} onClick={() => updateMarkup(m.id, { color: c })} style={{ width: 15, height: 15, borderRadius: 4, background: c, border: m.color === c ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer" }} />)}
                       <select name="markup-line-style" value={m.line_style || "solid"} onChange={(e) => updateMarkup(m.id, { line_style: e.target.value })} title={uiText("Line style")} style={{ marginLeft: 4, fontSize: 11, border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", padding: "1px 3px" }}>
                         {LINE_STYLE_IDS.map((id) => <option key={id} value={id}>{uiText(LINE_STYLES[id].label)}</option>)}
                        </select>
                        {/* line weight — a multiplier over the element's base stroke width (default
                           ×1, clamped 0.5–3); additive, absent = ×1 so legacy markups are unchanged */}
                       <span style={{ fontSize: 10.5, color: "var(--ink-muted)", marginLeft: 4 }}>{uiText("Weight")}</span>
                       <select name="markup-weight" value={String(snapWeight(m.weight))} onChange={(e) => updateMarkup(m.id, { weight: Number(e.target.value) })} title={uiText("Line weight (× base)")} style={{ fontSize: 11, border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", padding: "1px 3px" }}>
                         {WEIGHT_STEPS.map((wv) => <option key={wv} value={wv}>{uiText(wv)}×</option>)}
                        </select>
                        {/* revision-delta △n — clouds only; blank clears it (no delta drawn) */}
                        {m.type === "cloud" && (
                          <>
                           <span style={{ fontSize: 10.5, color: "var(--ink-muted)", marginLeft: 4 }} title={uiText("Revision-delta number (△) drawn at a cloud corner")}>{uiText("Rev △")}</span>
                           <input name="markup-rev" type="number" min="0" step="1" value={Number.isFinite(m.rev) ? m.rev : ""} placeholder={uiText("—")}
                              onChange={(e) => { const raw = e.target.value; updateMarkup(m.id, { rev: raw === "" ? undefined : Math.max(0, Math.floor(Number(raw) || 0)) }); }}
                             title={uiText("Revision number for the △ delta (blank = none)")}
                              style={{ width: 40, fontSize: 11, border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", padding: "1px 3px" }} />
                          </>
                        )}
                      </div>
                      {/* Condition link — which scope this annotation is ABOUT.
                         Same one-to-many shape as the RFI link below it. */}
                      {(() => {
                        const lc = m.condition_id ? condById[m.condition_id] : null;
                        const ctrl = { padding: "2px 7px", border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 11 };
                        return (
                          <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 7, flexWrap: "wrap" }}>
                            {lc ? (
                              <>
                               <span title={uiText(`Annotation is about ${lc.finish_tag}`)}
                                  style={{ display: "inline-flex", alignItems: "center", gap: 5, fontFamily: "var(--f-mono)", fontSize: 11, fontWeight: 700 }}>
                                  <span style={{ width: 9, height: 9, background: lc.color, border: "1px solid var(--ink-faint)" }} />
                                 {finishLabel(lc.finish_tag)}
                                </span>
                               <button onClick={() => { setActiveCond(lc.id); }} style={{ ...ctrl, color: "var(--cobalt)" }} title={uiText("Make this the active condition")}>{uiText("Select")}</button>
                               <button onClick={() => unlinkCondition(m)} style={{ ...ctrl, color: "var(--ink-muted)" }} title={uiText("Detach this annotation from its condition")}>{uiText("Detach")}</button>
                              </>
                            ) : conditions.length > 0 && (
                              <select name="link-condition" value="" onChange={(e) => { if (e.target.value) linkCondition(m, e.target.value); }}
                               title={uiText("Attach this annotation to a condition")} style={{ ...ctrl, background: "var(--paper-bright)", maxWidth: 170 }}>
                               <option value="">{uiText("Attach to condition…")}</option>
                               {conditions.map((c) => <option key={c.id} value={c.id}>{finishLabel(c.finish_tag)}</option>)}
                              </select>
                            )}
                          </div>
                        );
                      })()}
                      {/* RFI controls — raise a fresh RFI, link an existing one, or unlink */}
                      {(() => {
                        const linked = m.rfi_id ? rfis.find((r) => r.id === m.rfi_id) : null;
                        const ctrl = { padding: "2px 7px", border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 11 };
                        return (
                          <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 7, flexWrap: "wrap" }}>
                            {linked ? (
                              <>
                               <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, fontWeight: 700, color: "var(--cobalt)" }}>⬢ {uiText(String(linked.number ?? ""))}</span>
                               <button onClick={() => { setLeftTab("rfi"); }} style={{ ...ctrl, color: "var(--cobalt)" }} title={uiText("Open the RFI register")}>{uiText("Open")}</button>
                               <button onClick={() => unlinkRfi(m)} style={{ ...ctrl, color: "var(--ink-muted)" }} title={uiText("Unlink this markup from its RFI")}>{uiText("Unlink")}</button>
                              </>
                            ) : (
                              <>
                               <button onClick={() => raiseRfi(m)} style={{ ...ctrl, color: "var(--cobalt)", fontWeight: 600 }} title={uiText("Create a new RFI from this markup")}>{uiText("Raise RFI")}</button>
                                {rfis.length > 0 && (
                                  <select name="link-rfi" value="" onChange={(e) => { if (e.target.value) linkRfi(m, e.target.value); }}
                                   title={uiText("Link this markup to an existing RFI")} style={{ ...ctrl, background: "var(--paper-bright)", maxWidth: 150 }}>
                                   <option value="">{uiText("Link existing…")}</option>
                                   {rfis.map((r) => <option key={r.id} value={r.id}>{uiText(r.number)}{uiText(r.subject ? ` · ${r.subject}` : "")}</option>)}
                                  </select>
                                )}
                              </>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  ))}
                  {/* Captures — a GLOBAL image-markup library, every sheet, NOT
                     filtered to the panels open right now (unlike the per-sheet
                     list above): that global-ness is the whole point of the
                     feature — find, re-place, trace, or caption any capture
                     regardless of which sheet is open. Uploads live here too
                     (no source fields, so ◎ and the caption toggle are hidden
                     — see isTraceable). */}
                  <div style={{ borderTop: "2px solid var(--ink-faint)" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 10px", borderBottom: "1px solid var(--ink-faint)", gap: 8 }}>
                     <span style={{ fontSize: 10.5, fontWeight: 700, color: "var(--ink-muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{uiText("Captures")}</span>
                      {/* hidden input reused by the Upload button — re-encoded through addImageFromFile */}
                      <input name="markup-image-file" ref={imageInputRef} type="file" accept="image/*" style={{ display: "none" }}
                        onChange={(e) => { const f = e.target.files?.[0]; if (f) addImageFromFile(f); e.target.value = ""; }} />
                      <button
                        onClick={() => imageInputRef.current?.click()}
                       title={uiText("Upload a raster image (PNG or JPEG) as a floating annotation on the current sheet")}
                        style={{ background: "transparent", border: "1px solid var(--ink-faint)", color: "var(--ink)", fontSize: 11, cursor: "pointer", padding: "2px 7px" }}>
                       {uiText("Upload image…")}</button>
                    </div>
                    {/* always-on name search — mirrors the condQuery idiom
                       (TakeoffsPanel ~:718/763/1054-1056) */}
                    <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 10px", borderBottom: "1px solid var(--ink-faint)" }}>
                     <input name="capture-filter" value={captureQuery} onChange={(e) => setCaptureQuery(e.target.value)} placeholder={uiText("filter captures…")}
                        style={{ flex: 1, minWidth: 0, padding: "4px 8px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 }} />
                     {captureQuery && <button onClick={() => setCaptureQuery("")} title={uiText("Clear the filter")} style={{ border: "none", background: "none", color: "var(--ink-muted)", cursor: "pointer", fontSize: 13, padding: 0 }}>×</button>}
                    </div>
                    {(() => {
                      // one pass over `markups` for the image subset; the query
                      // then narrows THAT (small) list instead of re-scanning
                      // every markup a second time — filterCaptures's own
                      // type==="image" filter is a no-op on an already-image-only input.
                      const allCaptures = filterCaptures(markups, "");
                      const captures = filterCaptures(allCaptures, captureQuery);
                      if (allCaptures.length === 0) {
                       return <div style={{ padding: "4px 12px 14px", color: "var(--ink-muted)" }}>{uiText("No captures yet. Marquee a region with 🖼 or use Upload image… above.")}</div>;
                      }
                      if (captures.length === 0) {
                       return <div style={{ padding: "4px 12px 14px", color: "var(--ink-muted)" }}>{uiText("No captures match “")}{uiText(captureQuery)}”.</div>;
                      }
                      return captures.map((m) => {
                        // Captures-only gate for ◎ + the caption toggle — legacy
                        // pre-slice-1 images and uploads both lack src_sheet_id.
                        const traceable = isTraceable(m);
                        return (
                          <div key={m.id} style={{ padding: "10px 12px", borderTop: "1px solid var(--ink-faint)", background: selectedMarkupId === m.id ? "var(--surface-pop)" : "transparent" }}>
                            {/* header line — thumb, name(✎), sheet badge, age,
                               Place, ◎ trace, caption toggle, delete. Mirrors the
                               per-sheet row's click-to-fly / stopPropagation
                               pattern above. */}
                           <div onClick={() => { if (m.reference_only) { setPinSelectedId(m.id); setPinsOpen(true); } else flyToMarkup(m); }} title={uiText(imageProvenance(m))} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", flexWrap: "wrap" }}>
                              {(() => {
                                const th = ensureThumb(m);
                                return <span style={{ flex: "0 0 auto", width: 30, height: 30, border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
                                 {th ? <img src={th} alt={uiText("")} style={{ maxWidth: "100%", maxHeight: "100%", display: "block" }} /> : <span style={{ fontSize: 14 }}>🖼</span>}
                                </span>;
                              })()}
                              {panelEditId === m.id ? (
                                <input name="capture-text" autoComplete="off" autoFocus defaultValue={m.text || ""}
                                  onClick={(e) => e.stopPropagation()}
                                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); updateMarkup(m.id, { text: e.currentTarget.value.trim() }); setPanelEditId(null); } else if (e.key === "Escape") { e.preventDefault(); e.currentTarget.value = m.text || ""; setPanelEditId(null); } }}
                                  onBlur={(e) => { updateMarkup(m.id, { text: e.currentTarget.value.trim() }); setPanelEditId(null); }}
                                  style={{ flex: 1, minWidth: 0, fontSize: 12.5, padding: "1px 4px", border: "1px solid var(--cobalt)", borderRadius: 0, outline: "none" }} />
                              ) : (
                               <span style={{ flex: "0 1 auto", minWidth: 0, color: "var(--ink)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.text || <em style={{ color: "var(--ink-muted)" }}>{uiText("(no name)")}</em>}</span>
                              )}
                             <button onClick={(e) => { e.stopPropagation(); setPanelEditId((id) => (id === m.id ? null : m.id)); }} title={uiText("Edit name")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--ink-muted)" }}>✎</button>
                              <span style={{ color: "var(--ink-faint)" }}>·</span>
                             <span title={uiText(`Currently on ${sheetBaseLabel(m.sheet_id)}`)} style={{ fontSize: 10.5, color: "var(--ink-muted)", padding: "1px 6px", border: "1px solid var(--ink-faint)", borderRadius: 4, background: "var(--paper-cream)", whiteSpace: "nowrap" }}>{uiText(sheetBaseLabel(m.sheet_id))}</span>
                              {/* legacy/imported captures can predate created_at (see
                                 imageProvenance's own guard on the same field) — a
                                 blank relativeAge must not leave a dangling "·" */}
                              {(() => {
                                const age = relativeAge(m.created_at, Date.now());
                                return age ? (
                                  <>
                                    <span style={{ color: "var(--ink-faint)" }}>·</span>
                                   <span style={{ fontSize: 10.5, color: "var(--ink-muted)", whiteSpace: "nowrap" }} title={uiText(absoluteUtc(m.created_at))}>{uiText(age)}</span>
                                  </>
                                ) : null;
                              })()}
                             <button onClick={(e) => { e.stopPropagation(); setPinSelectedId(m.id); setPinsOpen(true); }} title={uiText("Keep this capture beside your takeoff while changing sheets")}>{uiText("Pin")}</button>
                             {!m.reference_only && (<button onClick={(e) => { e.stopPropagation(); beginPlace(m); }} title={uiText(panelKeySet.has(m.sheet_id) ? "Reposition: centers the view on the image, then it follows the cursor — click the sheet to drop it" : "Place this image on the current sheet — it follows the cursor until you click to drop it")} style={{ border: "1px solid var(--ink-faint)", background: placingImageId === m.id ? "var(--cobalt)" : "transparent", color: placingImageId === m.id ? "#fff" : "var(--cobalt)", cursor: "pointer", fontSize: 11, padding: "1px 7px" }}>{uiText("Place")}</button>)}

                              {traceable && (
                               <button onClick={(e) => { e.stopPropagation(); traceSource(m); }} title={uiText("Jump to the source sheet and flash the captured region")} style={{ border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--cobalt)", cursor: "pointer", fontSize: 11, padding: "1px 7px", whiteSpace: "nowrap" }}>
                                 {uiText(traceLabel(m.src_sheet_id, m.sheet_id, sheetBaseLabel(m.src_sheet_id)))}
                                </button>
                              )}
                              {traceable && (
                                <button onClick={(e) => { e.stopPropagation(); updateMarkup(m.id, { source_label: !m.source_label }); }}
                                 title={uiText("Show/Hide the source caption on the image")}
                                  style={{ padding: "2px 7px", border: `1px solid ${m.source_label ? "var(--cobalt)" : "var(--ink-faint)"}`, background: m.source_label ? "var(--cobalt)" : "transparent", color: m.source_label ? "var(--paper-bright)" : "var(--ink-muted)", cursor: "pointer", fontSize: 10.5, fontFamily: "var(--f-mono)", lineHeight: 1.4 }}>
                                 {uiText("caption")}</button>
                              )}
                             <button onClick={(e) => { e.stopPropagation(); deleteMarkup(m.id); }} title={uiText("Delete capture")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--c-danger)" }}>🗑</button>
                            </div>
                            {/* Condition link — identical block to the per-sheet row's
                               (8211–8235 pre-slice-4); keys off `m` and works for any
                               markup type, captures included. */}
                            {(() => {
                              const lc = m.condition_id ? condById[m.condition_id] : null;
                              const ctrl = { padding: "2px 7px", border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 11 };
                              return (
                                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 7, flexWrap: "wrap" }}>
                                  {lc ? (
                                    <>
                                     <span title={uiText(`Annotation is about ${lc.finish_tag}`)}
                                        style={{ display: "inline-flex", alignItems: "center", gap: 5, fontFamily: "var(--f-mono)", fontSize: 11, fontWeight: 700 }}>
                                        <span style={{ width: 9, height: 9, background: lc.color, border: "1px solid var(--ink-faint)" }} />
                                       {finishLabel(lc.finish_tag)}
                                      </span>
                                     <button onClick={() => { setActiveCond(lc.id); }} style={{ ...ctrl, color: "var(--cobalt)" }} title={uiText("Make this the active condition")}>{uiText("Select")}</button>
                                     <button onClick={() => unlinkCondition(m)} style={{ ...ctrl, color: "var(--ink-muted)" }} title={uiText("Detach this annotation from its condition")}>{uiText("Detach")}</button>
                                    </>
                                  ) : conditions.length > 0 && (
                                    <select name="link-condition" value="" onChange={(e) => { if (e.target.value) linkCondition(m, e.target.value); }}
                                     title={uiText("Attach this annotation to a condition")} style={{ ...ctrl, background: "var(--paper-bright)", maxWidth: 170 }}>
                                     <option value="">{uiText("Attach to condition…")}</option>
                                     {conditions.map((c) => <option key={c.id} value={c.id}>{finishLabel(c.finish_tag)}</option>)}
                                    </select>
                                  )}
                                </div>
                              );
                            })()}
                            {/* RFI controls — identical block to the per-sheet row's
                               (8237–8262 pre-slice-4). */}
                            {(() => {
                              const linked = m.rfi_id ? rfis.find((r) => r.id === m.rfi_id) : null;
                              const ctrl = { padding: "2px 7px", border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 11 };
                              return (
                                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 7, flexWrap: "wrap" }}>
                                  {linked ? (
                                    <>
                                     <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, fontWeight: 700, color: "var(--cobalt)" }}>⬢ {uiText(String(linked.number ?? ""))}</span>
                                     <button onClick={() => { setLeftTab("rfi"); }} style={{ ...ctrl, color: "var(--cobalt)" }} title={uiText("Open the RFI register")}>{uiText("Open")}</button>
                                     <button onClick={() => unlinkRfi(m)} style={{ ...ctrl, color: "var(--ink-muted)" }} title={uiText("Unlink this markup from its RFI")}>{uiText("Unlink")}</button>
                                    </>
                                  ) : (
                                    <>
                                     <button onClick={() => raiseRfi(m)} style={{ ...ctrl, color: "var(--cobalt)", fontWeight: 600 }} title={uiText("Create a new RFI from this markup")}>{uiText("Raise RFI")}</button>
                                      {rfis.length > 0 && (
                                        <select name="link-rfi" value="" onChange={(e) => { if (e.target.value) linkRfi(m, e.target.value); }}
                                         title={uiText("Link this markup to an existing RFI")} style={{ ...ctrl, background: "var(--paper-bright)", maxWidth: 150 }}>
                                         <option value="">{uiText("Link existing…")}</option>
                                         {rfis.map((r) => <option key={r.id} value={r.id}>{uiText(r.number)}{uiText(r.subject ? ` · ${r.subject}` : "")}</option>)}
                                        </select>
                                      )}
                                    </>
                                  )}
                                </div>
                              );
                            })()}
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
              )}
              {leftTab === "stamp" && (
                <StampPanel
                  docked
                  library={stampLib} armedStamp={armedStamp}
                  selectedMarkup={selectedMarkupId ? markups.find((m) => m.id === selectedMarkupId) : null}
                  onArm={armStamp} onSaveSelected={saveMarkupAsStamp} onDelete={deleteStamp} onRename={renameStamp}
                  onExport={exportStamps} onImport={importStamps} onImportSvg={importSvgStamp} onClose={() => setLeftTab(null)}
                />
              )}
              {leftTab === "rfi" && (
                <RfiPanel
                  docked
                  rfis={rfis} markups={markups}
                  onUpdateRfi={updateRfi} onDeleteRfi={deleteRfi} onFlyTo={flyToMarkup}
                  sheetLabel={(k) => tabLabel(k)} onClose={() => setLeftTab(null)}
                />
              )}
            </div>
          </div>
        )}
        {/* ALWAYS mounted — reference={null} is how "no split" renders (see
           SplitLayout.jsx). This is what keeps primaryViewport's element type
           and tree position stable across every split toggle, so the primary
           canvas subtree never unmounts/remounts on enter/exit/flip/drag. */}
       <SplitLayout
         orientation={splitView?.orientation ?? "v"}
         ratio={splitView?.ratio ?? 1}
         onRatioChange={(r) => {
           // hold the gesture window open for every drag tick, same idiom as
           // wheel-zoom/panel-resize — the detail-tile resync effect depends
           // on splitView (ratio changes its identity every tick) and would
           // otherwise re-fire paintDetail worker requests on every pointermove;
           // this defers the real resync to one shot on drag settle.
           gestureUntilRef.current = performance.now() + GESTURE_MS;
           setSplitView((s) => s && { ...s, ratio: r });
         }}
         onFlip={() => setSplitView((s) => s && { ...s, orientation: s.orientation === "v" ? "h" : "v" })}
         onCollapse={() => setSplitView(null)}
         primary={primaryViewport}
         // Task 8: a persisted/live splitView that the device can't (or isn't
         // overridden to) mount still renders the primary pane single —
         // `reference` going null is what SplitLayout treats as "no split"
         // (see its header comment); `splitView` itself stays in state
         // untouched (the "Restore split" menu item above flips
         // splitOverride, not this).
         reference={splitView && splitMounted ? (
           <ReferencePane refKey={effectiveRefKey} panelImg={refPanelImg} paintBase={paintReferenceBase} paintDetail={paintReferenceDetail} epoch={refEpoch}
             shapes={refStackedShapes} conditions={conditions} condById={condById} darkMode={darkMode} patId={patId}
             markups={refMarkups} rfis={rfis} noteQtyLabels={noteQtyLabels} sheetBaseLabel={sheetBaseLabel}
             refSet={refSet} activeKey={rawRefKey} tabLabel={tabLabel} onSelectRef={selectRefTab} onRemoveRef={removeRefTab} onDropSheet={dropOntoReference}
             overlay={doorSuiteOn && doorSchedKey && effectiveRefKey === doorSchedKey ? (img, sc) => doorRowBoxes(img, sc) : null}
             focus={doorCompareOn ? doorRefFocus : null} />
         ) : null}
       />
        {/* Work and review panel — DOCKED right-rail sibling (reflows the canvas
            like the Takeoffs panel). Its Agent tab is the chat window
            (components/AgentChat): a connect state until the BYO-AI seam is
            configured; otherwise the conversation, every tool step, and the
            per-proposal accept/reject desk. */}
        <WorkspacePanel dockSide={workspaceLayout ? workspaceArrangement.work : undefined} width={workspaceLayout ? workspaceArrangement.workWidth : undefined} dockHandle={workspaceDockHandle("work", "Work")} open={agentOpen} shapes={shapes} conditions={condById} selectedId={selectedId}
          sheetLabel={tabLabel} fmtArea={(sf) => fa(sf, 2)} fmtLength={(lf) => fl(lf, 2)}
          scales={scales} scaleUnconfirmed={scaleUnconfirmed} running={agentRunning}
          proposalCount={agentProposals.length} onLocate={locateWork}
          onReview={(id) => dispatchShape({ type: "review", ids: [id] })}
          onClose={() => { setAgentOpen(false); workButtonRef.current?.focus(); }} onReport={() => setShowReport(true)}>
          <AgentChat
            configured={isAiConfigured()}
            modelLabel={aiConfig().model}
            running={agentRunning}
            turns={agentChat.turns}
            proposals={agentProposals}
            condById={condById}
            sheetLabel={(k) => tabLabel(k)}
            fmtArea={(sf) => fa(sf)}
            onSend={runAgent}
            onStop={stopAgent}
            onAccept={acceptAgentProposal}
            onReject={rejectAgentProposal}
            onAcceptAll={acceptAllVisibleAgentProposals}
            onRejectAll={rejectAllAgentProposals}
            onOpenSettings={() => setShowAiSettings(true)}
            onOpenConnect={() => setConnectOpen(true)}
            onClear={agentChat.clear}
          />
        </WorkspacePanel>

        {/* Roll panel (#136) — DOCKED right-rail sibling like the Agent panel:
            per-condition cut diagrams (to scale, numbered), drag-to-reorder with
            the engine re-pack, the overlay/edit toggles, and the figured order
            lines. A pure view — layout state lives on the shapes (rollcut). */}
        {rollPanelOpen && (
          <RollPanel
            layouts={[...rollByCond.entries()].map(([condId, ri]) => {
              const c = condById[condId];
              return { condId, tag: c?.finish_tag || "?", color: c?.color, fill: c?.fill, hatch: c?.hatch, multiplier: c?.multiplier || 1, ri };
            })}
            show={rollShow} onShow={setRollShow}
            edit={rollEdit} onEdit={setRollEdit}
            onReorder={onReorderRollCuts} onResetOrder={onResetRollOrder}
            onClose={() => setRollPanelOpen(false)}
          />
        )}

        {/* Layers panel (#85 phase 2) — DOCKED right-rail sibling like the Roll
            panel: the sheet's PDF layer table (names + stated roles) with the
            per-layer Auto/Wall/Off controls feeding One-Click's role
            short-circuit. Its rail button renders only when an open sheet
            actually carries layers, so a flattened export costs zero chrome. */}
        {layersOpen && layerEntries.length > 0 && (
          <LayerPanel
            entries={layerEntries}
            onOverride={setLayerOverride}
            onReset={resetLayerOverrides}
            onClose={() => setLayersOpen(false)}
          />
        )}

        {/* Takeoffs panel — DOCKED in the layout row (reflows the canvas, not an
            overlay): every condition with its running totals, plus the Library,
            Materials, and Columns tabs. Extracted to components/TakeoffsPanel.jsx and
            ALWAYS mounted (it renders null while collapsed) so its view state —
            tab, filter, multi-select — survives a collapse/expand round-trip
            exactly as it did as canvas state. Collapse/expand keeps the current
            transform — the stage is anchored top-left, so a re-fit would be a
            jarring jump. */}
      {/* ── Doors suite panel — DOCKED in the layout row while the trade is Doors
              (takes the Conditions dock's place, so the canvas and the reference
              pane reflow around it instead of sitting under it) ── */}
        {doorSuiteOn && (() => {
          const rd = doorKey ? doorReads[doorKey] : null;
          const reading = !rd || rd.status === "reading";
          const found = doorKey ? doorFound[doorKey] : null;
          const detect = {
            on: doorDetectOn, gpu: doorDetect.gpu, cached: doorDetect.cached, load: doorDetect.load, progress: doorDetect.progress, error: doorDetect.error,
            sheet: doorDetectOn && found ? found : null, canRun: !!(rd?.status === "done" && rd.doors.length),
          };
          const docsBusy = !doorDocs || doorDocs.status === "reading";
          const status = rd?.status === "failed" ? { busy: true, text: `Couldn't read this sheet's doors: ${rd.error}` }
            : reading ? { busy: true, text: "Reading the doors on this sheet…" }
            : docsBusy ? { busy: false, docsBusy: true, note: "Reading the door schedule and the hardware spec in the loaded files…" }
            : { busy: false, note: !doorDocs.schedule ? "No door schedule found in the loaded files: doors are counted from the plan alone." : !doorDocs.sets.length ? "No spec section 08 71 00 loaded: hardware sets come from the schedule. Drop the project manual PDF in to add their items." : null };
          return (
            <DoorsSuitePanel
              sheetLabel={doorKey ? sheetBaseLabel(doorKey) : "this sheet"} status={status} view={doorView}
              schedule={doorDocs?.schedule ? { ...doorDocs.schedule, label: sheetBaseLabel(doorDocs.schedule.key) } : null}
              sets={doorDocs?.sets || []} setOrder={doorSetOrder} answers={doorAnswers}
              sel={doorSel && doorSel.key === doorKey ? doorSel.i : null}
              coach={doorCoach} onDismissCoach={() => { setDoorCoach(false); try { localStorage.setItem("opentakeoff_doors_coach", "seen"); } catch { /* private mode */ } }}
              tab={doorTab} onTab={(t) => { setDoorTab(t); setDoorSel(null); }}
              onAnswer={answerDoor} onUndo={undoDoor}
              onSelect={(i) => { setDoorSel(i == null ? null : { key: doorKey, i }); if (i == null) setDoorTab("doors"); }}
              onShowDoor={(i) => showDoor(i)} onShowRow={showScheduleRow} onShowElevation={showElevation}
              onShowSet={(m) => { const o = doorView?.openings.find((x) => x.mark === m); if (o) showDoor(o.door); else showScheduleRow(m); }}
              onAdd={addDoorsToEstimate} added={!!doorAnswers[`added:${doorKey}`]}
              compareOn={doorCompareOn} canCompare={!!doorSchedKey} onCompare={toggleDoorCompare}
              selMark={doorSelMark} hoverMark={doorHover} onHoverRow={setDoorHover} onPickRow={pickDoorRow}
              placed={doorPlaced} checks={doorAnswers} onCheck={setDoorCheck} onNote={setDoorNote}
              detect={detect} onToggleDetect={toggleDoorDetect}
              onRetryDetect={() => { setDoorDetect((d) => ({ ...d, load: "idle", error: null })); if (doorKey) setDoorFound((prev) => { if (prev[doorKey]?.status !== "failed") return prev; const n = { ...prev }; delete n[doorKey]; return n; }); }}
              onClose={() => pickViewTrade(ALL_TRADES)}
            />
          );
        })()}
        {!doorSuiteOn && workspaceLayout && !focusMode && (
          <ConditionsDock
            open={condDockOpen && !fullTableOpen} onClose={() => setCondDockOpen(false)}
            sheetLabel={(() => { const l = tabLabel(treeCurrent || sheetKey); const m = /^\s*([A-Z]{1,3}-?\d{1,4}(?:\.\d{1,3})?[A-Z]?)\b/i.exec(l); return m ? m[1] : l; })()}
            conditions={conditions} activeCond={activeCond} hiddenConds={hiddenConds} tradeHidden={tradeHidden} palette={palette}
            viewTrade={viewTrade} allTrades={ALL_TRADES}
            tradeLabel={viewTrade !== ALL_TRADES ? (suiteById(viewTrade)?.label || "This trade") : (suiteById(conditionTrade(aCond || {}))?.label || "This trade")}
            onTradeThis={() => pickViewTrade(viewTrade !== ALL_TRADES ? viewTrade : (conditionTrade(aCond || {}) || ALL_TRADES))}
            onTradeAll={() => pickViewTrade(ALL_TRADES)}
            rowById={projRowById} units={units} conditionColumns={conditionColumns} rollByCond={rollByCond}
            matLib={matLib} matLibById={matLibById}
            onActivate={panelHandlers.onActivate} onAddCondition={panelHandlers.onAddCondition} onDeleteCondition={panelHandlers.onDeleteCondition}
            onDuplicateCondition={panelHandlers.onDuplicateCondition} onUpdateCond={panelHandlers.onUpdateCond} onSetCondParam={panelHandlers.onSetCondParam} onAssignAttr={panelHandlers.onAssignAttr}
            onToggleHidden={panelHandlers.onToggleHidden} onTogglePin={panelHandlers.onTogglePin} onApplyAssembly={panelHandlers.onApplyAssembly}
            onAddMaterial={panelHandlers.onAddMaterial} onUpdateMaterial={panelHandlers.onUpdateMaterial} onRemoveMaterial={panelHandlers.onRemoveMaterial}
            matFieldOverridden={panelHandlers.matFieldOverridden} onRevertMatField={panelHandlers.onRevertMatField}
            onAttachLibMaterial={panelHandlers.onAttachLibMaterial} onPromoteMaterial={panelHandlers.onPromoteMaterial}
            onFollowFamilyRow={panelHandlers.onFollowFamilyRow} onRestoreDroppedRow={panelHandlers.onRestoreDroppedRow}
          />
        )}
        <TakeoffsPanel
          dockSide={workspaceLayout ? workspaceArrangement.takeoffs : undefined} layoutLocked={workspaceLayout && workspaceArrangement.locked} dockHandle={workspaceDockHandle("takeoffs", "Takeoffs")}
          open={workspaceLayout ? fullTableOpen : takeoffsOpen}
          width={panelW}
          overlay={isNarrow}
          multiSheet={groupKeys.length > 1}
          units={units}
          conditions={conditions}
          conditionEditProposals={conditionEditProposals} onAcceptConditionEdit={acceptConditionEdit} onRejectConditionEdit={rejectConditionEdit}
          collisionsByCond={scopeByCond} onLookAtCollision={lookAtCollision}
          revisionFlaggedByCond={revisionFlaggedByCond}
          activeCond={activeCond}
          visRowById={visRowById} projRowById={projRowById}
          conditionColumns={conditionColumns}
          shapeLabels={shapeLabels}
          templates={templates}
          palette={palette}
          hiddenConds={hiddenConds}
          tradeHidden={tradeHidden} viewTradeLabel={viewTrade !== ALL_TRADES ? suiteById(viewTrade)?.label : null} onShowAllTrades={() => setViewTrade(ALL_TRADES)}
          rollByCond={rollByCond}
          transitionSources={transitionSources}
          matLib={matLib}
          matLibById={matLibById}
          linkedCountById={linkedCountById}
          panelPrefs={panelPrefs}
          reassigning={tool === "select" && !!selectedId}
          epoch={panelEpoch}
          clearSelectionRef={panelSelectionRef}
          {...panelHandlers}
        />
      </div>

      {/* Unified plan navigator — one surface for the plan-set gallery AND the
          Drive folder browser. Presents as a modal over the dimmed canvas when a
          sheet is open behind it, or full-screen (onboarding) when nothing is. */}
      {(view === "gallery" || view === "picker") && (
        <PlanNavigator
          nameGen={namerGen} onSheetText={offerSheetText}
          onStartTour={() => { startTour(); loadSampleForTour(); }}
          onConnect={CONFENGE_LOCAL_ONLY ? undefined : () => setConnectOpen(true)}
          canClose={openTabs.length > 0}
          onExit={() => setView("canvas")}
          initialMode={view === "picker" ? "browse" : "plan"}
          cloudMode={cloudMode}
          sheets={sheets} withDoc={docCache.withDoc} withLoadedDoc={docCache.withLoadedDoc} scales={scales} detectedScales={detectedScales} scaleUnconfirmed={scaleUnconfirmed}
          shapes={shapes} labels={galleryLabels}
          onLabel={(k, lbl) => setGalleryLabels((m) => (m[k] === lbl ? m : { ...m, [k]: lbl }))}
          onDetect={(k, det) => setDetectedScales((d) => (d[k]?.label === det.label ? d : { ...d, [k]: det }))}
          thumbCacheRef={thumbCacheRef} busyRef={statusRef}
          planIndexRef={planIndexRef} subscribeIndex={indexSignal.subscribe} onIndexed={onIndexed} pageHeld={pageHeld} docLoaded={docCache.loaded}
          ocr={ocrApi}
          openTabs={openTabs} onOpen={openSheets}
          stitches={stitches} onStitch={createStitch} onOpenStitch={openStitch} onDeleteStitch={deleteStitch}
          onAddFiles={handleFiles}
          levels={sheetLevels}
          onAssignLevel={(keys, label) => setSheetLevels((m) => {
            const next = { ...m };
            for (const k of keys) { if (label) next[k] = label; else delete next[k]; }
            return next;
          })}
          onClosePdf={closePdf}
          onCloseMany={closePdfs}
          onClearWorkspace={cloudMode ? undefined : clearWorkspace}
          knownPages={knownPages} onPages={rememberPages}
          onRemoveFromProject={cloudMode ? removeFromProject : undefined}
          onCloseProject={cloudMode ? closeProject : undefined}
          onBrowseProjects={cloudMode ? browseProjects : undefined}
          listFolder={cloudMode ? pickerListFolder : undefined}
          addSheets={pickerAddSheets}
          onAdded={async () => { await refreshSheets(); setStatus("ready"); }}
        />
      )}

      {materialImport && <div style={{position:'fixed',inset:0,zIndex:1000,background:'var(--scrim)',display:'grid',placeItems:'center'}} onKeyDown={e => {e.stopPropagation(); if(e.key === 'Escape') finishMaterialImport(false);}}>
        <div role="dialog" aria-modal="true" aria-label={uiText('Import units')} style={{background:'var(--paper-bright)',color:'var(--ink)',padding:24,width:'min(460px,90vw)',border:'1px solid var(--ink-faint)'}}>
          <h3>{uiText('Import units')}</h3>
          <MaterialUnitSelector value={materialImport.unit} onChange={unit => setMaterialImport(p => ({...p,unit}))} />
          <p style={{fontSize:12,lineHeight:1.6}}>{uiText('Liquid volumes and unit prices are converted; purchase rounding follows the original package size.')}</p>
          <div style={{display:'flex',gap:12,justifyContent:'flex-end'}}><button className="btn-ghost" onClick={() => finishMaterialImport(false)}>{uiText('Cancel')}</button><button autoFocus className="btn-primary" onClick={() => finishMaterialImport(true)}>{uiText('Import')}</button></div>
        </div>
      </div>}
      {importRead && (
        <ImportSchedulePanel
          rows={importRead.rows} skipped={importRead.skipped}
          planSet={importPlanSet}
          subscribeIndex={indexSignal.subscribe} labelOf={tabLabel}
          existing={new Set(conditions.map((c) => normalizeTag(c.finish_tag)))}
          palette={PALETTE} startIndex={conditions.length}
          onCreate={createFromSchedule}
          onClose={() => setImportRead(null)}
        />
      )}

      {loadError && (
        <div style={{ position: "absolute", top: 12, left: "50%", transform: "translateX(-50%)", zIndex: 60, display: "flex", alignItems: "center", gap: 12, maxWidth: 640, padding: "10px 14px", background: "var(--paper-bright)", border: "1px solid var(--c-danger)", boxShadow: "var(--shadow-2)", fontSize: 12.5, color: "var(--ink)" }}>
          <span>
            <strong style={{ color: "var(--c-danger)" }}>{uiText("Couldn't load this project's saved takeoff")}</strong> ({uiText(loadError)}{uiText("). Autosave is paused so nothing overwrites your saved work — reload the tab to retry.")}</span>
          <button onClick={() => window.location.reload()} style={{ whiteSpace: "nowrap", padding: "6px 12px", border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", cursor: "pointer", fontSize: 12 }}>{uiText("Reload")}</button>
        </div>
      )}

      {showReport && (
        <ReportPanel
          projectName={projectName} onProjectName={setProjectName}
          clientInfo={clientInfo} onClientInfo={setClientInfo} units={units}
          onOpenCompanySetup={() => setCompanySetupOpen(true)} companyRev={companyRev} onEstimate={openEstimate}
          conditions={conditions} shapes={shapes} markups={markups} rfis={rfis}
          conditionEditProposals={conditionEditProposals}
          conditionColumns={conditionColumns} shapeLabels={shapeLabels}
          scaleInfo={Object.entries(scales).map(([sheet_id, units_per_px]) => ({ sheet_id, units_per_px, scale_source: scaleSources[sheet_id] || "unknown", scale_confirmed: scaleUnconfirmed[sheet_id] !== false }))}
          rollByCond={rollByCond}
          provenanceCounters={provCounters}
          sheetLabel={(k) => tabLabel(k)}
          sheetDims={(k) => panelByKey(k)?.img}
          onMarkedSet={exportMarkedSet} markedSetDark={darkMode}
          onClose={() => setShowReport(false)}
        />
      )}

      {showEstimate && estimateSettings && (
        <EstimatePanel
          projectName={projectName} clientInfo={clientInfo}
          conditions={conditions} shapes={shapes} rollByCond={rollByCond}
          settings={estimateSettings} onSettings={(next) => setEstimateSettings(sanitizeEstimateSettings(next))}
          onUpdateCondition={updateCondById}
          onClientInfo={setClientInfo}
          bidProposal={bidProposal} onBidProposal={(next) => setBidProposal(sanitizeBidProposal(next))}
          onOpenCompanySetup={() => setCompanySetupOpen(true)} companyRev={companyRev}
          onClose={() => setShowEstimate(false)}
        />
      )}

      {showRevisions && (
        <RevisionsPanel
          current={buildPayload()}
          units={units}
          onRestore={restoreSavedPayload}
          onClose={() => setShowRevisions(false)}
        />
      )}

      {/* status bar — the 28px instrument strip, the grid shell's bottom row.
          Mono, tabular, tick-ruled top edge. The verb column keeps tool/agent
          activity legible at all times; the coords span updates via direct DOM
          from onPointerMove (never React state per mousemove); transient
          commitMsg text lives here now (the old floating pill is gone — the
          rule banner still floats, it has buttons). Print: the report-only
          visibility rules already hide this. */}
      {/* ── Symbol sweep review panel (#264) — floats while a sweep is live ── */}
      {sweep && view === "canvas" && (() => {
        const seedTag = sweep.seed.label?.label || null;
        const mLine = sweepLabelLine(sweep.matches, seedTag);
        const openQ = sweep.questions.filter((q) => q.state === "open").length;
        const accQ = sweep.questions.filter((q) => q.state === "accepted").length;
        // per-tag groups (#308 → commit-by-label): the drawing names the
        // matches; a tag the estimator unticks is excluded from the commit —
        // the sibling-fixture answer in one click, sweep_schedule_row's
        // excluded-by-tag discipline brought to the canvas.
        const tagKeyOf = (m) => (m.label && m.label.label) || "\u2205";
        const tagGroups = [];
        for (const m of sweep.matches) {
          const k = tagKeyOf(m);
          const g = tagGroups.find((x) => x.tag === k);
          if (g) g.n += 1; else tagGroups.push({ tag: k, n: 1 });
        }
        tagGroups.sort((a, b) => b.n - a.n);
        const offSet = new Set(sweep.excludedTags);
        const matchN = sweep.matches.filter((m) => !offSet.has(tagKeyOf(m))).length;
        const commitN = (sweep.includeSeed ? 1 : 0) + matchN + accQ;
        const unlabeled = (seedTag || sweep.matches.some((m) => m.label)) ? sweep.matches.filter((m) => !m.label).length : 0;
        return (
          <div style={{ position: "fixed", right: FLOAT_GAP, top: `calc(var(--topbar-h) + ${FLOAT_GAP}px)`, width: SWEEP_PANEL_W, zIndex: Z.popover, background: "var(--paper-cream)", border: "1px solid var(--ink-faint)", boxShadow: "var(--shadow-pop)", display: "flex", flexDirection: "column", fontSize: "var(--fs-m)" }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8, padding: "10px 12px", borderBottom: "1px solid var(--ink-faint)" }}>
              <span className="field-label">{uiText("SYMBOL SWEEP")}</span>
              <span style={{ flex: 1 }} />
              {sweep.complete
                ? <span style={{ fontFamily: "var(--f-mono)", fontSize: "var(--fs-2xs)", letterSpacing: ".1em", color: "var(--c-positive)", border: "1px solid var(--c-positive)", padding: "2px 6px" }}>{uiText("COMPLETE")}</span>
                : <span style={{ fontFamily: "var(--f-mono)", fontSize: "var(--fs-2xs)", letterSpacing: ".1em", color: "#fff", background: "var(--c-warning)", padding: "3px 6px" }}>{uiText("FLOOR — NOT A TOTAL")}</span>}
            </div>
            {sweep.seed.segments <= 3 && (
              <div style={{ padding: "8px 12px", background: "var(--tint-select)", color: "var(--ink)", fontSize: "var(--fs-s)", lineHeight: 1.45 }}>
                {uiText("The seed is only ")}{uiText(sweep.seed.segments)} {uiText("segment(s) — likely a FRAGMENT, and fragments match everywhere (every square corner reads as one). Marquee the whole symbol.")}</div>
            )}
            {!sweep.complete && (
              <div style={{ padding: "8px 12px", background: "var(--c-warning)", color: "#fff", fontSize: "var(--fs-s)", lineHeight: 1.45 }}>
                {uiText(sweep.dropped)} {uiText("placement(s) were never scored — tighten the marquee around more distinctive linework before trusting this as a total.")}</div>
            )}
            <div style={{ padding: "10px 12px", display: "flex", flexDirection: "column", gap: 8 }}>
              <div><b style={{ fontFamily: "var(--f-display)", fontSize: "var(--fs-xl)" }}>{uiText(matchN)}</b> {uiText("of ")}{uiText(sweep.matches.length)} {uiText("matched will commit")}{mLine && tagGroups.length <= 1 ? <span style={{ color: "var(--ink-soft)" }}> — {uiText(mLine)}</span> : null}</div>
              {tagGroups.length > 1 && (
                <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                  <div className="field-label">{uiText("BY LABEL — UNTICK A TAG TO EXCLUDE IT")}</div>
                  {tagGroups.map((g) => {
                    const isSeedTag = seedTag && g.tag === seedTag;
                    const isOff = offSet.has(g.tag);
                    return (
                      <label key={g.tag} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "var(--fs-s)", cursor: "pointer", color: isOff ? "var(--text-faint)" : !isSeedTag && g.tag !== "\u2205" ? "var(--c-warning)" : "var(--ink)" }}>
                        <input type="checkbox" checked={!isOff}
                          onChange={() => setSweep((sw2) => ({ ...sw2, excludedTags: isOff ? sw2.excludedTags.filter((t) => t !== g.tag) : [...sw2.excludedTags, g.tag] }))} />
                        <span style={{ fontFamily: "var(--f-mono)", fontWeight: 600 }}>{uiText(g.tag === "\u2205" ? "no label" : g.tag)}</span>
                        <span>×{uiText(g.n)}</span>
                        {isSeedTag && <span style={{ fontSize: "var(--fs-2xs)", color: "var(--ink-muted)" }}>{uiText("seed's tag")}</span>}
                        {!isSeedTag && g.tag !== "\u2205" && !isOff && <span style={{ fontSize: "var(--fs-2xs)" }}>{uiText("different device?")}</span>}
                      </label>
                    );
                  })}
                </div>
              )}
              {unlabeled > 0 && tagGroups.length <= 1 && <div style={{ fontSize: "var(--fs-s)", color: "var(--c-warning)" }}>{uiText(unlabeled)} {uiText("match(es) carry no label while this family is labeled — look at those first.")}</div>}
              <div><b style={{ fontFamily: "var(--f-display)", fontSize: "var(--fs-xl)", color: openQ ? "var(--c-warning)" : "var(--ink)" }}>{uiText(sweep.questions.length)}</b> {uiText("question(s)")}{openQ ? <span style={{ color: "var(--ink-soft)" }}> {uiText("— ↵ accept · X dismiss · → next")}</span> : <span style={{ color: "var(--ink-soft)" }}> {uiText("— all answered")}</span>}</div>
              {sweep.questions.length > 0 && (
                <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 150, overflowY: "auto" }}>
                  {sweep.questions.map((q, i) => (
                    <button key={i} type="button" title="Show this spot on the sheet" onClick={() => { setSweep((s) => ({ ...s, qIndex: i })); centerOnSweepQuestion(sweep, i); }}
                      style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 8px", fontFamily: "var(--f-body)", fontSize: "var(--fs-s)", textAlign: "left", background: i === sweep.qIndex ? "var(--tint-select)" : "transparent", border: `1px solid ${i === sweep.qIndex ? "var(--c-warning)" : "var(--ink-faint)"}`, color: q.state === "dismissed" ? "var(--text-faint)" : "var(--ink)", textDecoration: q.state === "dismissed" ? "line-through" : "none", cursor: "pointer" }}>
                      <span style={{ fontFamily: "var(--f-mono)", fontWeight: 700, color: q.state === "accepted" ? "var(--c-positive)" : q.state === "dismissed" ? "var(--text-faint)" : DS.symbol.question }}>{uiText(q.state === "accepted" ? "✓" : q.state === "dismissed" ? "×" : "?")}</span>
                      <span>{uiText(Math.round(q.score * 100))}%{uiText(q.label ? ` · ${q.label.label}` : "")}{uiText(q.readings > 1 ? ` · read ${q.readings} ways` : "")}</span>
                    </button>
                  ))}
                </div>
              )}
              <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "var(--fs-s)", cursor: "pointer" }}>
                <input type="checkbox" checked={sweep.includeSeed} onChange={(e) => setSweep((s) => ({ ...s, includeSeed: e.target.checked }))} />
                <span>{uiText("Count the seed")}{seedTag ? <span> {uiText("— drawing says ")}<b style={{ fontFamily: "var(--f-mono)" }}>{uiText(seedTag)}</b></span> : null}</span>
              </label>
            </div>
            <div style={{ padding: "10px 12px", borderTop: "1px solid var(--ink-faint)", display: "flex", flexDirection: "column", gap: 6 }}>
              <button type="button" className="btn-primary" onClick={commitSweep} style={{ justifyContent: "center" }}>
                {uiText("Commit ")}{uiText(commitN)} {uiText("as ")}{uiText(condById[activeCond]?.finish_tag || "…")}
              </button>
              <button type="button" className="btn-ghost" onClick={() => setSweep(null)} style={{ justifyContent: "center" }}>{uiText("Discard (Esc)")}</button>
            </div>
          </div>
        );
      })()}
      <footer className="ink-panel ticks"
        style={{ height: "var(--status-h)", flex: "0 0 auto", display: "flex", alignItems: "center", gap: 12, padding: "0 14px", fontFamily: "var(--f-mono)", fontSize: "var(--fs-xs)", fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap", overflow: "hidden", userSelect: "none" }}>
        <span style={{ color: "var(--status-acc)", textShadow: "var(--glow)" }}>{uiText(TOOL_VERB[tool] || tool)}</span>
        <span style={{ opacity: 0.25 }} aria-hidden="true">|</span>
        <span ref={statusCoordRef} aria-hidden="true" style={{ minWidth: 150 }} />
        <span style={{ opacity: 0.25 }} aria-hidden="true">|</span>
        <span>{uiText(scaleFace)}</span>
        <span style={{ opacity: 0.25 }} aria-hidden="true">|</span>
        <label data-trade-picker="" style={{ display: "flex", alignItems: "center", gap: 6 }}
          title={tr("The trade this canvas shows: other trades' conditions and shapes hide (the Report, estimate and exports keep everything), and new conditions are booked to it. Yours only; saved in this browser.")}>
          <span style={{ opacity: 0.75 }}>{tr("Trade")}</span>
          <select aria-label={tr("Trade view")} value={viewTrade} onChange={(e) => pickViewTrade(e.target.value)}
            style={{ font: "inherit", color: "inherit", background: "transparent", border: "1px solid currentColor", borderRadius: 0, padding: "0 4px", cursor: "pointer" }}>
            <option value={ALL_TRADES}>{tr("All trades")} ({conditions.length})</option>
            {VISIBLE_TRADE_SUITES.map((t) => <option key={t.id} value={t.id}>{tr(t.label)} ({tradeCountMap[t.id] || 0})</option>)}
          </select>
        </label>
        {workspaceLayout && <>
          <label data-label-picker="" style={{ display: "flex", alignItems: "center", gap: 6 }}
            title={tr("Phase/area label: new takeoffs get it; with a shape selected (Select tool) it re-labels that shape. Manage the list in the Takeoffs table's Columns tab.")}>
            <span style={{ opacity: 0.75 }}>{tr("Label")}</span>
            <select aria-label={tr("Label")} value={tool === "select" && selectedId ? shapeLabelValue(shapes.find((sh) => sh.id === selectedId)) : (activeLabel || "")} onChange={(e) => activateLabel(e.target.value || null)}
              style={{ font: "inherit", color: "inherit", background: "transparent", border: "1px solid currentColor", borderRadius: 0, padding: "0 4px", cursor: "pointer" }}>
              <option value="">{tr("No label")}</option>
              {shapeLabels.map((v) => <option key={v} value={v}>{v}</option>)}
            </select>
          </label>
          <span data-status-draft="" style={{ display: "inline-flex" }}>{draftMenu}</span>
        </>}
        {commitMsg && (
          <span title={uiText(commitMsg)} style={{ marginLeft: 8, color: isDangerMsg(commitMsg) ? "var(--c-danger)" : "var(--c-positive)", overflow: "hidden", textOverflow: "ellipsis", minWidth: 0 }}>
            {uiText(commitMsg)}
          </span>
        )}
        {/* Import from schedule's on-device read: its own live line, never
            commitMsg (which ellipsizes), and hidden while the download notice
            is up (the notice owns Cancel and Esc then) */}
        <span data-import-read-status="" aria-live="polite" style={{ flexShrink: 0, display: "flex", alignItems: "center", gap: "var(--sp-2)" }}>
          {ocrRead && !ocrNotice && (<>
            <span>{uiText(ocrRead === "starting" ? OCR_STARTING_MESSAGE : ocrRead === "waiting" ? OCR_WAITING_MESSAGE : ocrReadingMessage(ocrReadProgress))}</span>
            <button type="button" className="btn-ghost" onClick={cancelImportRead} style={{ padding: "var(--sp-1) var(--sp-2)" }}>{uiText("Cancel")}</button>
          </>)}
        </span>
        <span style={{ marginLeft: "auto", display: "flex", gap: 12, opacity: 0.75 }} aria-live="polite">
          <span>{measurementCount(shapes.filter((s) => panelKeySet.has(s.sheet_id)).length, language)}</span>
          <span>{uiText(cloudMode ? "drive" : "local")}{uiText(saveState === "saving" ? " · saving…" : saveState === "saved" ? " · saved" : "")}</span>
        </span>
      </footer>
      {/* BYO-key AI settings — the single config surface for the ai.js seam
          (the Agent panel links here; closing re-renders, so `configured`
          re-reads immediately). */}
      {showAiSettings && <AiSettings onClose={() => setShowAiSettings(false)} />}
      {/* live counter (mock) — floating running totals, drag to park anywhere */}
      {!focusMode && (!workspaceLayout || workspaceArrangement.counter) && !agentOpen && !showReport && <LiveCounter rows={liveCounterRows} onActivate={(id) => activateCondition(id, { reassign: false })} />}
      {/* the manual, last in the tree so it sits above every panel and dock */}
      {guideOpen && <UserGuide onClose={() => setGuideOpen(false)} onTour={startTour} onConnect={() => { setGuideOpen(false); setConnectOpen(true); }} />}
      {connectOpen && <ConnectAI onClose={() => setConnectOpen(false)} />}
      <AssistantWindow open={assistantOpen} onOpen={openAssistant} onClose={() => setAssistantOpen(false)}
        launcher={view === "canvas" && !showReport && !focusMode && !workspaceLayout} onConnectHelp={() => setConnectOpen(true)} />
      {companySetupOpen && <CompanySetup onClose={() => setCompanySetupOpen(false)} onSaved={() => setCompanyRev((r) => r + 1)} />}
      {tour && view === "canvas" && !focusMode && !guideOpen && !connectOpen && (
        <FirstTakeoffTour done={tour.done} step={currentStep(tour.done)} sheetOpen={tourSheetOpen}
          sampleBusy={tourSampleBusy} onLoadSample={loadSampleForTour} result={tourResult}
          onClose={() => setTour(null)} onConnect={() => { setTour(null); setConnectOpen(true); }} />
      )}
      {/* on-device OCR's download notice (#471): modal over everything, the
          gallery and the guide included. Keys stop here so the canvas's
          window shortcuts (Delete, ⌘Z, letters) don't act behind it, and a
          press on the scrim doesn't move focus out of the notice. */}
      {ocrNotice && (
        <div onKeyDown={(e) => e.stopPropagation()} onMouseDown={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
          style={{ position: "fixed", inset: 0, zIndex: Z.modal, background: "var(--scrim)", display: "flex", alignItems: "center", justifyContent: "center", padding: "var(--sp-4)" }}>
          <OcrDownloadNotice downloadBytes={ocrNotice.downloadBytes} progress={ocrNotice.progress} onDownload={ocrHost.download} onCancel={ocrHost.cancel} />
        </div>
      )}
    </div>
  );
}
