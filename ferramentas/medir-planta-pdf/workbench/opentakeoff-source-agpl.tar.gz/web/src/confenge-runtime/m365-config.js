export const M365_ENABLED_KEY = "confenge:cloud-disabled";
export const m365Config = () => null;
export const m365SyncConfigured = () => false;
export const m365Scope = () => "confenge-local";
