const disabled = async () => { throw new Error("Integrações em nuvem estão desativadas nesta versão local."); };
export const isGoogleConfigured = () => false;
export const onAuthChange = () => () => {};
export const getUser = () => null;
export const preloadGoogle = disabled;
export const signIn = disabled;
export const getAccessToken = disabled;
export const signOut = disabled;
