import React from "react";

const disabled = async () => { throw new Error("Integrações em nuvem estão desativadas nesta versão local."); };
export function GoogleAuthProvider({ children }) { return <>{children}</>; }
export function useGoogleAuth() { return { user: null, ready: true, signIn: disabled, signOut: disabled }; }
