export function createCloudStore() { throw new Error("Sincronização em nuvem está desativada nesta versão local."); }
export function buildLocalFirstStore() { throw new Error("Sincronização em nuvem está desativada nesta versão local."); }
