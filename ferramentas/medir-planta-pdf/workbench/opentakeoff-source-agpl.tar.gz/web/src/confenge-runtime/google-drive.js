export function createDrive() { throw new Error("Google Drive está desativado nesta versão local."); }
