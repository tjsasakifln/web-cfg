// Deliberately inert worker for removed ML/OCR/STT/door-detection features.
// The local measurement workflow neither starts it nor contacts a model host.
self.onmessage = () => {};
