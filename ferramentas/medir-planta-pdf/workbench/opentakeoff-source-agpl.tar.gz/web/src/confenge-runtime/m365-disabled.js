const disabled = () => { throw new Error("Microsoft 365 está desativado nesta versão local."); };
export const createMsalAuth = disabled;
export const buildM365Store = disabled;
export const createGraphDrive = disabled;
export class GraphAuthError extends Error {}
export const retryAfterMs = () => 1000;
