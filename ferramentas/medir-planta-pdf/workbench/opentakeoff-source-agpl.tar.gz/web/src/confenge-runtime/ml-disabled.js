const disabled = () => { throw new Error("Recursos de detecção por modelo estão desativados nesta versão local."); };
export const DEFAULT_ENGINE = "disabled";
export const createEngine = disabled;
export const createTransformersJsEngine = disabled;
export const TRANSFORMERS_MODEL_ID = "disabled";
