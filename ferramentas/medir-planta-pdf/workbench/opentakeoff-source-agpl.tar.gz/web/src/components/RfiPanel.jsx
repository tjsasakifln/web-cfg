import { localizeText as uiText, rfiStatusLabel } from "../lib/i18n/core.js";
// RfiPanel — the RFI register (Request For Information). A docked, project-global
// panel (unlike the sheet-scoped markup panel): every RFI with number, subject,
// status chip, and linked-markup count; filter by status; edit every field;
// close / void / delete; and fly to a linked markup on any sheet.
//
// State lives in the PARENT (TakeoffCanvas) — this view holds only local filter
// state. The status→response_date auto-stamp is the parent's job (onUpdateRfi),
// so the view never computes a date. Contract:
//   <RfiPanel rfis markups onUpdateRfi(id,patch) onDeleteRfi(id) onFlyTo(markup)
//             sheetLabel={tabLabel} onClose />
import React, { useMemo, useState } from "react";
import { Icon } from "../brand/icons.jsx";
import { ScanStar } from "../brand/marks.jsx";
import { RFI_STATUSES, rfiStatus, linkedMarkups, liveRfis, rfiPending } from "../lib/rfi.js";

const PRIORITIES = ["low", "normal", "high"];

export default function RfiPanel({ docked = false, rfis: rfisIn = [], markups = [], onUpdateRfi, onDeleteRfi, onFlyTo, sheetLabel, onClose }) {
  const [filter, setFilter] = useState("all"); // "all" | status id
  // a withdrawn RFI is a tombstone (its number stays reserved) and never lists
  const rfis = useMemo(() => liveRfis(rfisIn), [rfisIn]);
  const shown = useMemo(
    () => (filter === "all" ? rfis : rfis.filter((r) => rfiStatus(r.status).id === filter)),
    [rfis, filter],
  );

  const field = { width: "100%", padding: "4px 6px", border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", fontSize: 12, boxSizing: "border-box" };
  const lbl = { fontFamily: "var(--f-mono)", fontSize: 9, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-muted)", display: "block", marginBottom: 2 };
  const up = (r, patch) => onUpdateRfi && onUpdateRfi(r.id, patch);

  const chip = (id, label) => {
    const on = filter === id;
    return (
      <button key={id} onClick={() => setFilter(id)}
        style={{ padding: "2px 8px", border: `1px solid ${on ? "var(--cobalt)" : "var(--ink-faint)"}`, background: on ? "var(--cobalt)" : "transparent", color: on ? "var(--accent-contrast)" : "var(--ink)", cursor: "pointer", fontSize: 11 }}>
        {uiText(label)}
      </button>
    );
  };

  const outer = docked
    ? { display: "flex", flexDirection: "column", width: "100%", height: "100%", overflow: "auto", background: "var(--paper-bright)", fontSize: 12.5 }
    : { position: "absolute", left: 14, top: 14, width: 372, maxHeight: "calc(100% - 28px)", overflow: "auto", background: "var(--paper-bright)", border: "1px solid var(--cobalt)", boxShadow: "var(--shadow-pop)", zIndex: 9, fontSize: 12.5 };

  return (
    <div style={outer}>
      {!docked && (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "9px 12px", borderBottom: "1px solid var(--ink-faint)", background: "var(--cobalt)", color: "var(--accent-contrast)" }}>
          <strong style={{ display: "inline-flex", alignItems: "center", gap: 7 }}><Icon name="rfi" size={15} />{uiText("RFIs · ")}{uiText(rfis.length)}</strong>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "var(--accent-contrast)", fontSize: 16, cursor: "pointer" }}>×</button>
        </div>
      )}

      <div style={{ display: "flex", gap: 5, flexWrap: "wrap", padding: "8px 10px", borderBottom: "1px solid var(--ink-faint)" }}>
        {uiText(chip("all", `All ${rfis.length}`))}
        {RFI_STATUSES.map((s) => chip(s.id, `${rfiStatusLabel(s.id)} ${rfis.filter((r) => rfiStatus(r.status).id === s.id).length}`))}
      </div>

      {rfis.length === 0 && (
        <div style={{ padding: "14px 12px", color: "var(--ink-muted)" }}>
          {uiText("No RFIs yet — select a cloud, callout, or note in the markup panel and press ")}<b>{uiText("Raise RFI")}</b>.
        </div>
      )}
      {rfis.length > 0 && shown.length === 0 && (
        <div style={{ padding: "14px 12px", color: "var(--ink-muted)" }}>{uiText("No RFIs with this status.")}</div>
      )}

      {shown.map((r) => {
        const st = rfiStatus(r.status);
        const linked = linkedMarkups(r, markups);
        // agent-raised (MCP create_rfi): who asked is on the record, and the
        // question is PENDING — pencil — until the estimator accepts it here.
        // The same origin.reviewed flag every agent shape carries; Accept is
        // the only path that sets it, so nothing agent-raised sends unseen.
        const agent = r.origin?.actor === "agent";
        const pending = rfiPending(r);
        return (
          <div key={r.id} style={{ padding: "10px 12px", borderTop: "1px solid var(--ink-faint)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6 }}>
              <span style={{ fontFamily: "var(--f-mono)", fontWeight: 700, color: "var(--cobalt)" }}>{String(r.number ?? "")}</span>
              <span style={{ padding: "1px 7px", background: st.color, color: "#fff", fontSize: 10, fontWeight: 700, letterSpacing: "0.04em", textTransform: "uppercase" }}>{rfiStatusLabel(st.id)}</span>
              {agent && (
                <span title={uiText(pending ? "Raised by an agent over MCP — pending until you accept it" : "Raised by an agent over MCP — accepted")}
                  style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "1px 6px", border: "1px dashed var(--ink-muted)", color: "var(--ink-muted)", fontSize: 9.5, fontWeight: 700, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                  <ScanStar size={10} style={{ color: "var(--cobalt)" }} />{uiText("agent")}{uiText(pending ? " · pending" : "")}
                </span>
              )}
              {pending && (
                <button onClick={() => up(r, { origin: { ...r.origin, reviewed: true } })}
                  title={uiText("Accept this agent-raised RFI as your own question (turns it from pencil to ink)")}
                  style={{ padding: "1px 8px", border: "1px solid var(--cobalt)", background: "var(--cobalt)", color: "var(--accent-contrast)", cursor: "pointer", fontSize: 10, fontWeight: 700 }}>{uiText("Accept")}</button>
              )}
              <span style={{ flex: 1 }} />
              <span style={{ fontSize: 10.5, color: "var(--ink-muted)" }}>{uiText(linked.length)} {uiText("linked")}</span>
              <button onClick={() => { if (window.confirm(uiText(`Delete ${r.number}? Linked markups keep their annotation but lose the RFI link.`))) onDeleteRfi && onDeleteRfi(r.id); }}
                title={uiText("Delete this RFI (hard remove; clears links)")} style={{ border: "none", background: "none", cursor: "pointer", color: "var(--c-danger)" }}>🗑</button>
            </div>

            <label style={lbl}>{uiText("Subject")}</label>
            <input name="rfi-subject" value={r.subject || ""} onChange={(e) => up(r, { subject: e.target.value })} placeholder={uiText("Short subject")} style={{ ...field, marginBottom: 6 }} />

            <label style={lbl}>{uiText("Question")}</label>
            <textarea name="rfi-question" value={r.question || ""} onChange={(e) => up(r, { question: e.target.value })} rows={2} placeholder={uiText("What are you asking?")} style={{ ...field, marginBottom: 6, resize: "vertical" }} />

            <div style={{ display: "flex", gap: 6, marginBottom: 6 }}>
              <div style={{ flex: 1 }}>
                <label style={lbl}>{uiText("Status")}</label>
                <select name="rfi-status" value={st.id} onChange={(e) => up(r, { status: e.target.value })} style={field}>
                  {RFI_STATUSES.map((s) => <option key={s.id} value={s.id}>{rfiStatusLabel(s.id)}</option>)}
                </select>
              </div>
              <div style={{ flex: 1 }}>
                <label style={lbl}>{uiText("Priority")}</label>
                <select name="rfi-priority" value={r.priority || "normal"} onChange={(e) => up(r, { priority: e.target.value })} style={field}>
                  {PRIORITIES.map((p) => <option key={p} value={p}>{uiText(p)}</option>)}
                </select>
              </div>
            </div>

            <div style={{ display: "flex", gap: 6, marginBottom: 6 }}>
              <div style={{ flex: 1 }}>
                <label style={lbl}>{uiText("Ball in court")}</label>
                <input name="rfi-to" value={r.to || ""} onChange={(e) => up(r, { to: e.target.value })} placeholder={uiText("Architect / GC…")} style={field} />
              </div>
              <div style={{ flex: 1 }}>
                <label style={lbl}>{uiText("Opened")}</label>
                <input name="rfi-date" value={r.date || ""} onChange={(e) => up(r, { date: e.target.value })} placeholder={uiText("YYYY-MM-DD")} style={field} />
              </div>
            </div>

            <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 6 }}>
              <label style={{ display: "inline-flex", alignItems: "center", gap: 5, cursor: "pointer", fontSize: 11.5 }}>
                <input name="rfi-cost-impact" type="checkbox" checked={!!r.cost_impact} onChange={(e) => up(r, { cost_impact: e.target.checked })} />{uiText("cost impact")}</label>
              <label style={{ display: "inline-flex", alignItems: "center", gap: 5, cursor: "pointer", fontSize: 11.5 }}>
                <input name="rfi-schedule-impact" type="checkbox" checked={!!r.schedule_impact} onChange={(e) => up(r, { schedule_impact: e.target.checked })} />{uiText("schedule impact")}</label>
            </div>

            <label style={lbl}>{uiText("Response")}</label>
            <textarea name="rfi-response" value={r.response || ""} onChange={(e) => up(r, { response: e.target.value })} rows={2} placeholder={uiText("The answer, once received")} style={{ ...field, marginBottom: 6, resize: "vertical" }} />
            <label style={lbl}>{uiText("Response date")}</label>
            <input name="rfi-response-date" value={r.response_date || ""} onChange={(e) => up(r, { response_date: e.target.value })} placeholder={uiText("auto-stamps when set to Answered")} style={{ ...field, marginBottom: 6 }} />

            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
              <button onClick={() => up(r, { status: "closed" })} disabled={st.id === "closed"}
                style={{ padding: "3px 9px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", cursor: st.id === "closed" ? "default" : "pointer", fontSize: 11, opacity: st.id === "closed" ? 0.5 : 1 }}>{uiText("Close")}</button>
              <button onClick={() => up(r, { status: "void" })} disabled={st.id === "void"}
                style={{ padding: "3px 9px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: st.id === "void" ? "default" : "pointer", fontSize: 11, opacity: st.id === "void" ? 0.5 : 1 }}>{uiText("Void")}</button>
              <span style={{ flex: 1 }} />
              {linked.length === 0
                ? <span style={{ fontSize: 10.5, color: "var(--ink-muted)" }}>{uiText("no linked markups")}</span>
                : linked.map((m) => (
                  <button key={m.id} onClick={() => onFlyTo && onFlyTo(m)} title={uiText(`Fly to this ${m.type} on ${sheetLabel ? sheetLabel(m.sheet_id) : m.sheet_id}`)}
                    style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "3px 8px", border: "1px solid var(--cobalt)", background: "transparent", color: "var(--cobalt)", cursor: "pointer", fontSize: 11 }}>
                    <Icon name="target" size={11} />{sheetLabel ? sheetLabel(m.sheet_id) : m.sheet_id}
                  </button>
                ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
