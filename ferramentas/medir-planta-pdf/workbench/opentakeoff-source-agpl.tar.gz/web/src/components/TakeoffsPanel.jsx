import MaterialUnitSelector, { useMaterialUnit } from './MaterialUnitSelector.jsx';
import { liquidFactor } from '../lib/materialUnits.js';
import { formatMessage, finishLabel, getLanguage, localizeText as uiText } from "../lib/i18n/core.js";
import { useTranslation as useUiLocale } from "../lib/i18n/index.jsx";
// TakeoffsPanel — the docked conditions panel on the canvas's right edge
// (reflows the canvas, not an overlay): every condition with its running
// totals and inline properties, plus the template Library, material-library
// Materials (#47/#48), and custom Columns tabs. Extracted from TakeoffCanvas
// and memoized so canvas-only renders (the
// ~11Hz transform mirror during pan/zoom, crosshair churn) skip this whole
// subtree — every callback prop the canvas passes is identity-stable.
//
// View state lives HERE (active tab, filter, collapsed tag-family groups, the
// ⌘/⇧ multi-select, bulk-waste draft): search keystrokes and bulk inputs
// re-render only the panel. Three couplings reach back to the canvas:
//   · `epoch` — hydrate (mount load or snapshot Load) bumps it and an effect
//     clears filter/collapsed-groups/selection IN PLACE. An effect, not a
//     `key` remount: the active tab and resize width survive a snapshot load
//     exactly as they did when this state lived in the canvas.
//   · `clearSelectionRef` — the canvas owns activateCondition (panel rows, the
//     compact strip, and the 1–9 hotkeys all funnel through it); plain
//     activation dismisses a live bulk selection through this ref.
//   · bulk MUTATIONS stay in the canvas: onBulkWaste/onBulkColor/onBulkDelete
//     take the LIVE id set computed here. Liveness derives from the conditions
//     prop (`liveChecked`), so a checked id deleted elsewhere is inert by
//     construction — the canvas never needs to prune this selection.
//
// The panel stays MOUNTED while collapsed (open=false renders null), so all of
// that transient state survives a collapse/expand round-trip.

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { keyText } from "../lib/keys.ts";
import { Icon } from "../brand/icons.jsx";
import { attrValue, columnLabel } from "../lib/conditionColumns.js";
import { SPEC_FIELDS } from "../lib/reportColumns.js";
import { num } from "../lib/num.js";
import { areaVal, areaUnit, lenVal, lenUnit, heightUnit, heightInputToFeet, heightStep, thickUnit, thickInputToInches, thickStep, dimInputStr } from "../lib/units";
import { HATCHES, PALETTE, NO_FILL, HatchSwatch } from "./hatches.jsx";
import { LINE_STYLES, LINE_STYLE_IDS } from "../lib/lineStyles.js";
import { baseTagOf, localCount } from "../lib/variants.ts";
import { materialKind, MATERIAL_PRESETS, GROUT_DEFAULTS, groutDerivedFields, showsGroutCalc, showsGroutDeriveAffordance, isLinearGrout, baseGroutParams, baseCourses, groutRateStale, inFrac } from "../lib/coverage.js";
import { draftCommitValue, blurCommitValue, blurCommitNonNegative } from "../lib/draftInput.js";
import { itemRule, itemWastePct, coverageLabel } from "../lib/totals.js";
import { loadAssemblies, saveAssemblies, conditionToAssembly, ASSEMBLY_EVENT, ASSEMBLY_STORAGE_KEY } from "../lib/assemblies.js";
import { mintUuid } from "../lib/provenance.js";
import { ROLL_FLOORING_TYPES } from "../lib/rollgoods.js";
import { isCeilingCondition } from "../lib/ceilingKind.js";
import { hasRollSetup, mintRollSetup } from "../lib/rollTakeoff.js";
import { Z } from "../lib/ui.js";
import { ftIn } from "../lib/units";
import { describeConditionEdit } from "../lib/proposals.js";
import { TRADE_SUITES, suiteById, conditionTrade } from "../lib/tradeSuites.ts";

export const PANEL_MIN_W = 240;
export const PANEL_MAX_W = 560;
export const clampPanelW = (w) => Math.min(PANEL_MAX_W, Math.max(PANEL_MIN_W, w));

// drag-and-drop payload type carrying a condition id — a condition row here is
// a drag SOURCE, the top-bar quick-access palette (TakeoffCanvas) is the drop
// TARGET. Custom MIME so a condition drag never looks like a file drop.
export const CONDITION_DND_MIME = "application/x-opentakeoff-condition";

// tag family = the text before the dash (CPT-1 → CPT) — the grouping key for
// the panel's grouped view. VIEW-ONLY, like sort and search: the conditions
// array order is canonical (1–9 hotkeys are positional and the payload
// serializes it), so nothing here ever reorders the array itself.
// A condition minted as a TWIN carries an explicit family_id, which beats guessing from the
// tag: "SV-1 – Level 2" and "SV-1" are one family by construction, and the group is named for
// the base tag they share (lib/variants.ts). Everything else still groups by its tag prefix.
const tagFamily = (c) => {
  const t = typeof c === "string" ? c : c?.finish_tag;
  if (typeof c === "object" && c?.family_id) return baseTagOf(t).toUpperCase() || "—";
  return String(t || "").split("-")[0].trim().toUpperCase() || "—";
};
// one module-level collator — localeCompare builds a fresh collator per CALL
// (~56× slower, benchmarked), and natCompare runs n·log n per sorted view
const coll = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });
const natCompare = (a, b) => coll.compare(String(a), String(b));

// shared style atoms — these were re-declared at every call site (one even
// fresh per matLib row per render); hoisted so identical controls can't drift
const ip = { padding: "3px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 };
const btnAddFull = { width: "100%", padding: "6px 10px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 12 };
const btnClearX = { border: "none", background: "none", color: "var(--ink-muted)", cursor: "pointer", fontSize: 13, padding: 0 };

// Per-material-kind coverage presets (adhesive trowel notches, mortar trowels)
// and the grout-from-tile-geometry calculator live in lib/coverage.js —
// vendor-neutral, generic rates; always verify against the product data sheet.

// The fraction formatter (inFrac) and derivation-note builder moved to
// lib/coverage.js with the rest of the grout math so they're pure and tested.

// One grout tile-geometry input. Keeps the RAW string in local state while the
// field is being edited — clamping/coercing inside onChange made the joint
// field untypeable (every keystroke through "0." snapped to the 0.03125 min)
// and wiped the leading "0" of decimals in the tile fields. The commit/clamp
// decision rules live in lib/draftInput.js (pure, tested): typing commits only
// a fully valid in-range value; blur clamps an out-of-range value into range
// and abandons an empty/invalid draft, so the last good committed value
// redisplays.
function GroutParamInput({ name, value, title, min = 0, max, width = 52, override, onCommit }) {
  const [draft, setDraft] = useState(null);   // raw text mid-edit; null = mirror the committed value
  return (
    <input name={name} type="number" min={min || 0} max={max} step="any" title={uiText(title)}
      value={draft ?? (value > 0 ? String(value) : "")}
      onChange={(e) => { const t = e.target.value; setDraft(t); const v = draftCommitValue(t, min, max); if (v != null) onCommit(v); }}
      onBlur={() => {
        const v = blurCommitValue(draft, min, max);
        if (v != null) onCommit(v);
        setDraft(null);
      }}
      style={{ ...ip, width, ...(override ? { border: "1px solid var(--c-warning)" } : {}) }} />
  );
}

// Draft-buffered input for a condition's dimension params — wall height
// (stored `height_ft`) and material thickness (stored `thickness_in`). Both
// are internal-feet-contract fields, so this component owns the whole display
// edge: it SHOWS the value in the active unit system and commits back in the
// stored one (issue #115 — a metric user typing a 2.4 m wall used to get a
// 2.4 FOOT wall, silently, beside a readout that said m²).
//
// Draft-buffered for the same reason GroutParamInput is, plus one specific to
// converting: without it the field fights the typist, because every keystroke
// round-trips through a rounded conversion — typing "2.4" would redisplay as
// "2.438" mid-word. The raw text stays local while editing; the converted
// value still commits per keystroke, so thickness keeps re-flowing linear runs
// live the way it always has. Clearing commits "" (the param's null), which is
// distinct from an intentional 0.
function DimParamInput({ name, internal, units, kind, width, onCommit }) {
  const [draft, setDraft] = useState(null);   // raw text mid-edit; null = mirror the committed value
  const toInternal = (n) => (kind === "height" ? heightInputToFeet(n, units) : thickInputToInches(n, units));
  const commit = (text) => {
    if (text === "") return onCommit("");
    const n = parseFloat(text);
    if (Number.isFinite(n) && n >= 0) onCommit(toInternal(n));
  };
  return (
    <input name={name} type="number" min="0" step={kind === "height" ? heightStep(units) : thickStep(units)}
      placeholder={uiText(kind === "height" ? heightUnit(units) : thickUnit(units))}
      value={draft ?? dimInputStr(internal, units, kind)}
      onChange={(e) => { setDraft(e.target.value); commit(e.target.value); }}
      onBlur={() => { if (draft != null) commit(draft); setDraft(null); }}
      style={{ width, padding: "3px 5px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 }} />
  );
}

// Draft-buffered input for the Materials tab's name + per + note fields:
// keeps the raw text local while editing and commits ONLY on blur/Enter —
// every commit there flows through libEntryPatch, where a CHANGED per/note
// detaches a grout entry's tile geometry and a name edit re-classifies the
// entry's kind, so committing per keystroke destroyed the geometry (or the
// classification) on the transient values of a select-all-retype ("5" of
// "512") or a clear-and-retype, silently and with no undo. In number mode an
// empty/unparseable draft on blur is ABANDONED and the last good value
// redisplays (blurCommitNonNegative, the GroutParamInput/blurCommitValue
// philosophy) — clearing the per field must not commit 0 and take the
// geometry with it; an intentional 0 can still be typed as "0". Text drafts
// commit as-is (clearing a name/note is a legitimate edit).
function LibDraftInput({ name, value, number, placeholder, width, onCommitText }) {
  const [draft, setDraft] = useState(null);   // raw text mid-edit; null = mirror the committed value
  return (
    <input name={name} type={number ? "number" : "text"} min={number ? 0 : undefined} step={number ? "any" : undefined}
      value={draft ?? value}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        if (draft != null) {
          if (number) { const v = blurCommitNonNegative(draft); if (v != null) onCommitText(String(v)); }
          else onCommitText(draft);
        }
        setDraft(null);
      }}
      onKeyDown={(e) => { if (e.key === "Enter" && !e.nativeEvent.isComposing) e.currentTarget.blur(); }}
      placeholder={uiText(placeholder)} style={{ ...ip, width }} />
  );
}

// Coverage preset picker — shared by the condition-line editor and the
// Materials tab so a library "Adhesive" and an attached line offer the same
// notch/roller list. Renders nothing when the kind has no preset table.
function CoveragePresetSelect({ material: m, onPick }) {
  const presets = (m.basis || "area") === "area" ? MATERIAL_PRESETS[materialKind(m)] : undefined;
  if (!presets) return null;
  return (
    <select name="coverage-preset" value={presets.some((t) => t.label === m.note) ? m.note : ""}
      onChange={(e) => { const t = presets.find((x) => x.label === e.target.value); if (t) onPick({ note: t.label, per: t.per }); }}
      title={uiText("Coverage preset — trowel notch / spread rate. Generic industry-typical values; verify against the product data sheet.")}
      style={{ ...ip, background: "var(--paper-bright)" }}>
      <option value="">{uiText("preset…")}</option>
      {presets.map((t) => <option key={t.label} value={t.label}>{uiText(t.label)} · {uiText(t.per)} {uiText("SF/")}{uiText(m.unit || "unit")}</option>)}
    </select>
  );
}

// Editable supporting-materials rows for a condition (coverage-derived order qty).
export function MaterialsEditor({ materials, onAdd, onUpdate, onRemove, library, libById, overridden, onRevert, onAttach, onPromote,
    twin = false, parentTag = "", dropped = [], parentRows = [], onFollowFamilyRow, onRestoreDroppedRow,
    heightFt = 0 }) {
  const liquidUnit = useMaterialUnit();
  const metric = getLanguage() === "ru";
  // library link affordances (#47, all optional so the editor works standalone):
  // linked lines show ⛓; a field differing from its library entry tints amber
  // and grows a per-field ↺ revert; unlinked lines can be promoted to the library
  const OV = "1px solid var(--c-warning)";
  const rv = (m, f) => (
    <button onClick={() => onRevert(m, f)} title={uiText("Revert this field to the library value")}
      style={{ padding: "0 3px", border: "none", background: "transparent", color: "var(--c-warning)", cursor: "pointer", fontSize: 11, lineHeight: 1 }}>↺</button>
  );
  return (
    <>
      <div style={{margin:"8px 0"}}><MaterialUnitSelector /></div>
      {(materials || []).map((m) => {
        const lm = libById ? libById[m.lib_id] : null;
        const volumeFactor = liquidFactor(m.unit, liquidUnit);
        const basisFactor = metric ? (m.basis === 'count' ? 1 : m.basis === 'linear' || m.basis === 'seam_lf' ? 0.3048 : 0.09290304) : 1;
        const perFactor = basisFactor / (volumeFactor || 1);
        const ov = (f) => (lm && overridden ? overridden(m, lm, f) : false);
        // On a base (linear) line the piece's long dimension is the CONDITION's height,
        // so it is derived in, not stored on the row — and the calculator below renders
        // it read-only for the same reason.
        const g = baseGroutParams({ ...GROUT_DEFAULTS, ...(m.grout || {}) },
          isLinearGrout(m) ? heightFt : 0);
        // grout coverage derives from tile geometry — a param change re-derives
        // per + writes the derivation into the note so the Report shows its
        // work, but ONLY while the whole geometry is valid: an incomplete edit
        // (cleared field, zero) keeps the last good per + note instead of
        // silently committing a rate of 0 into the buy list and exports
        const setGrout = (patch) => {
          const grout = { ...g, ...patch };
          onUpdate(m.id, { grout, ...(groutDerivedFields(grout, m.basis, heightFt) || {}) });
        };
        // Displayed rate follows the metric / liquid-unit display: coverage rows
        // scale by perFactor, "each" rows (units per 1 basis) by its inverse.
        const perInput = (row) => {
          const f = itemRule(row) === "each" ? 1 / perFactor : perFactor;
          return <input name="material-per" type="number" min="0" step="any" value={row.per ? Number((row.per * f).toFixed(6)) : ""} onChange={(e) => onUpdate(row.id, { per: Math.max(0, parseFloat(e.target.value) || 0) / f })} placeholder={uiText("0")} style={{ ...ip, width: 66, ...(ov("per") ? { border: OV } : {}) }} />;
        };
        const gi = (key, title, extra) => (
          <GroutParamInput name={`grout-${key}`} value={g[key]} title={uiText(title)} override={ov("grout")}
            onCommit={(v) => setGrout({ [key]: v })} {...extra} />
        );
        return (
          <div key={m.id} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6, flexWrap: "wrap" }}>
            {/* family state: this row still follows the original, or it is this condition's own */}
            {twin && (
              <span title={uiText(m.inherited
                ? `Following ${parentTag || "the family"} — edit any field here and this row stops following (the others keep following)`
                : `This row is this condition's own${m.origin_id ? ` — it no longer follows ${parentTag || "the family"}` : ""}`)}
                style={{ fontSize: 10, lineHeight: 1, cursor: "default", padding: "2px 3px",
                  color: m.inherited ? "var(--ink-faint)" : "var(--cobalt)",
                  border: `1px solid ${m.inherited ? "var(--ink-faint)" : "var(--cobalt)"}` }}>{uiText(m.inherited ? "↳" : "✎")}</span>
            )}
            {twin && !m.inherited && m.origin_id && onFollowFamilyRow && (
              <button onClick={() => onFollowFamilyRow(m.id)} title={uiText(`Follow the family again — take this row's values back from ${parentTag || "the original"}`)}
                style={{ padding: "1px 4px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 10, lineHeight: 1.4 }}>{uiText("↺ follow")}</button>
            )}
            {lm && <span title={uiText(`Linked to “${lm.name}” in the material library — amber fields differ from the library values`)} style={{ color: "var(--ink-muted)", fontSize: 11, cursor: "default" }}>⛓</span>}
            <input name="material-name" value={m.name} onChange={(e) => onUpdate(m.id, { name: e.target.value })} placeholder={uiText("Material (e.g. Adhesive)")} style={{ ...ip, width: 160, ...(ov("name") ? { border: OV } : {}) }} />
            {ov("name") && rv(m, "name")}
            {/* quantity rule (lib/totals.js itemRule): "1 gal per 150 SF" (coverage) or "2 ea per 1 EA" (each — per piece) */}
            <select name="material-rule" value={itemRule(m)} onChange={(e) => onUpdate(m.id, { rule: e.target.value === "each" ? "each" : undefined })}
              title={uiText("Quantity rule — coverage: 1 unit per N measured (1 gal per 150 SF); each: N units per 1 measured (2 anchors per EA, 1 plate per piece)")}
              style={{ ...ip, background: "var(--paper-bright)" }}>
              <option value="coverage">{uiText("1 per N")}</option>
              <option value="each">{uiText("N per 1")}</option>
            </select>
            {itemRule(m) === "each" ? perInput(m) : <span style={{ color: "var(--ink-muted)" }}>1</span>}
            <input name="material-unit" readOnly={volumeFactor !== null} title={uiText('Liquid material units')} value={volumeFactor !== null ? uiText(liquidUnit) : m.unit} onChange={(e) => onUpdate(m.id, { unit: e.target.value })} placeholder={uiText("unit")} style={{ ...ip, width: 60, ...(ov("unit") ? { border: OV } : {}) }} />
            {ov("unit") && rv(m, "unit")}
            <span style={{ color: "var(--ink-muted)" }}>{uiText("per")}</span>
            {itemRule(m) === "each" ? <span style={{ color: "var(--ink-muted)" }}>1</span> : perInput(m)}
            {ov("per") && rv(m, "per")}
            <select name="material-basis" value={m.basis || "area"} onChange={(e) => onUpdate(m.id, { basis: e.target.value })} style={{ ...ip, background: "var(--paper-bright)", ...(ov("basis") ? { border: OV } : {}) }}>
              <option value="area">{metric ? 'пола, м²' : uiText('floor SF')}</option>
              <option value="linear">{metric ? 'длины, м' : uiText('linear LF')}</option>
              <option value="count">{uiText("each")}</option>
              <option value="seam_lf" title={uiText("Figured seam length from the roll layout — 0 until this condition carries a roll setup")}>{metric ? 'шва, м' : uiText('seam LF')}</option>
            </select>
            {ov("basis") && rv(m, "basis")}
            <label style={{ display: "inline-flex", alignItems: "center", gap: 4, color: ov("round") ? "var(--c-warning)" : "var(--ink-muted)" }} title={uiText("Round up to whole units (you buy whole buckets/bags)")}>
              <input name="material-round" type="checkbox" checked={m.round !== false} onChange={(e) => onUpdate(m.id, { round: e.target.checked })} />{uiText("Round to source packages")}
            </label>
            {ov("round") && rv(m, "round")}
            <label style={{ display: "inline-flex", alignItems: "center", gap: 3, color: "var(--ink-muted)" }} title={uiText("This item's own waste % — applied to its order quantity before the round-up (the condition's waste is separate)")}>
              +<input name="material-waste" type="number" min="0" step="any" value={itemWastePct(m) || ""} placeholder="0"
                onChange={(e) => { const w = Math.max(0, parseFloat(e.target.value) || 0); onUpdate(m.id, { waste_pct: w > 0 ? w : undefined }); }}
                style={{ ...ip, width: 44 }} />{uiText("% waste")}
            </label>
            <CoveragePresetSelect material={m} onPick={(patch) => onUpdate(m.id, patch)} />
            <input name="material-note" value={m.note || ""} onChange={(e) => onUpdate(m.id, { note: e.target.value })} placeholder={uiText("note (coats, trowel…)")} style={{ ...ip, width: 150, ...(ov("note") ? { border: OV } : {}) }} />
            {uiText(ov("note") && rv(m, "note"))}
            {!lm && onPromote && (
              <button onClick={() => onPromote(m)} title={uiText("Save this material to the library (this line becomes linked)")}
                style={{ padding: "2px 7px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>{uiText("→ lib")}</button>
            )}
            <button onClick={() => onRemove(m.id)} title={uiText("Remove this material")}
              style={{ padding: "2px 7px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 12 }}>✕</button>
            {/* the calculator renders ONLY when the line HAS geometry; a grout
                line without it keeps its rate untouched behind an explicit
                opt-in below — never a calculator backfilled with defaults */}
            {showsGroutCalc(m) && (
              <div style={{ flexBasis: "100%", display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", paddingLeft: 14, color: "var(--ink-muted)", fontSize: 12 }}>
                {isLinearGrout(m) ? (
                  <>
                    <span>{uiText("base")}</span>
                    {/* read-only: the height belongs to the CONDITION, and an editable copy
                        here would be a second owner of one number. No height = not figurable,
                        which says so rather than deriving off a default. */}
                    <span title={uiText("Base height — set on the condition, not here")}
                      style={{ fontFamily: "var(--f-mono, monospace)", padding: "2px 5px", border: "1px dashed var(--ink-faint)",
                        color: Number(heightFt) > 0 ? "var(--ink)" : "var(--c-warning)" }}>
                      {uiText(Number(heightFt) > 0 ? `${inFrac(Number(heightFt) * 12)}″ H` : "set height on condition")}
                    </span>
                    {/* piece height defaults to the base height (one course); a SHORTER one
                        is multi-course base, where the interior horizontal joints are real */}
                    <span>{uiText("· pc")}</span>
                    {uiText(gi("tileL", "Piece height (in) — defaults to the base height (one course). Enter a SHORTER piece for multi-course base (a 6″ band of 2×2 mosaic is three courses)", { width: 52 }))}
                    <span>×</span>
                    {uiText(gi("tileW", "Piece width (in) — for field-cut base, the parent tile dimension you did NOT rip"))}
                    {baseCourses(g, heightFt) > 1 && (
                      <span title={uiText("Courses of base — a fractional last course is a CUT (waste), not more grout")}>
                        ({uiText(Math.round(baseCourses(g, heightFt) * 100) / 100)} {uiText("crs)")}</span>
                    )}
                  </>
                ) : (
                  <>
                    <span>{uiText("tile")}</span>
                    {uiText(gi("tileL", "Tile length (in)"))}
                    <span>×</span>
                    {uiText(gi("tileW", "Tile width (in)"))}
                  </>
                )}
                <span>{uiText("× thick")}</span>
                {uiText(gi("tileT", "Tile thickness (in)"))}
                <span>{uiText("″ · joint")}</span>
                {uiText(gi("joint", "Joint width (in) — 1/32″ to 1/2″", { min: 0.03125, max: 0.5, width: 62 }))}
                <span>{uiText("″ · bag")}</span>
                {uiText(gi("bagLbs", "Bag size (lbs)"))}
                <span>{uiText("lb")}</span>
                {uiText(ov("grout") && rv(m, "grout"))}
                {groutRateStale(m, heightFt) && (
                  <button onClick={() => setGrout({})}
                    title={uiText(`This line's rate (${m.per} per LF-basis unit) is not what its geometry and this condition's base height derive. A rate figured for a different base height — from a library entry or a hand edit — does not follow the height here. Click to re-derive.`)}
                    style={{ padding: "1px 6px", borderRadius: 0, border: "1px solid var(--c-warning)", background: "transparent", color: "var(--c-warning)", cursor: "pointer", fontSize: 11 }}>
                    {uiText("⚠ rate ≠ geometry · re-derive")}</button>
                )}
              </div>
            )}
            {showsGroutDeriveAffordance(m) && (
              <div style={{ flexBasis: "100%", display: "flex", alignItems: "center", gap: 6, paddingLeft: 14 }}>
                <button onClick={() => setGrout({})}
                  title={uiText(isLinearGrout(m)
                    ? "Start the base-grout calculator with standard geometry (3/8″ thick @ 1/8″ joint, 25 lb bag) — the piece height comes from the condition. REPLACES this line's coverage rate and note"
                    : "Start the grout calculator with standard tile geometry (12×24×3/8″ @ 1/8″, 25 lb bag) — REPLACES this line's coverage rate and note with the derived values")}
                  style={{ padding: "2px 7px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>
                  {uiText(isLinearGrout(m) ? "derive from base geometry…" : "derive from tile geometry…")}
                </button>
                {uiText(ov("grout") && rv(m, "grout"))}
              </div>
            )}
          </div>
        );
      })}
      {/* Rows this twin threw away. They stay visible (struck through) rather than silently
          vanishing, because "this area has no moisture barrier" is a DECISION — and it is also
          what stops a later family edit from quietly putting it back. */}
      {twin && dropped.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 2, marginTop: 2, paddingTop: 4, borderTop: "1px dashed var(--ink-faint)" }}>
          {dropped.map((k) => {
            const src = parentRows.find((r) => r.id === k);
            return (
              <div key={k} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: "var(--ink-muted)" }}>
                <span style={{ color: "var(--c-danger)" }}>✕</span>
                <span style={{ textDecoration: "line-through" }}>{src?.name || uiText("(removed material)")}</span>
                <span style={{ fontSize: 10 }}>{uiText("removed here")}</span>
                {src && onRestoreDroppedRow && (
                  <button onClick={() => onRestoreDroppedRow(k)} title={uiText(`Put it back — takes the row from ${parentTag || "the family"} again`)}
                    style={{ padding: "1px 4px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 10, lineHeight: 1.4 }}>{uiText("↺ restore")}</button>
                )}
              </div>
            );
          })}
        </div>
      )}
      <button onClick={onAdd}
        style={{ marginTop: 2, padding: "4px 10px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 12 }}>{uiText("+ add material")}</button>
      {onAttach && (library || []).length > 0 && (
        <select name="attach-material" value="" onChange={(e) => { if (e.target.value) onAttach(e.target.value); }}
          title={uiText("Attach a material from the library — the line copies the library values and stays linked")}
          style={{ ...ip, marginLeft: 6, background: "var(--paper-bright)", color: "var(--ink-muted)" }}>
          <option value="">{uiText("+ from library…")}</option>
          {library.map((lm) => <option key={lm.id} value={lm.id}>{lm.name || uiText("(unnamed)")}{uiText(lm.per ? ` · ${lm.per}/${lm.unit || "?"}` : "")}</option>)}
        </select>
      )}
    </>
  );
}

// Per-condition custom-column assignment — one select per defined column.
// Unassigned = attrs key absent; a value deleted from the vocabulary
// keeps the condition's string, shown as "<value> (removed)".
function ColumnSelects({ columns, cond, onAssign }) {
  return (
    <>
      {columns.map((cc) => {
        const v = attrValue(cond?.attrs, cc.id);   // the shared assigned-value rule (hydrate sanitizes, this keeps the display consistent)
        return (
          <label key={cc.id} style={{ display: "inline-flex", alignItems: "center", gap: 5, marginRight: 12, marginBottom: 6 }}>
            <span style={{ color: "var(--ink-muted)" }}>{columnLabel(cc)}</span>
            <select name="assign-column-value" value={v} onChange={(e) => onAssign(cc.id, e.target.value)} style={{ ...ip, background: "var(--paper-bright)" }}>
              <option value="">{uiText("Unassigned")}</option>
              {cc.values.map((val) => <option key={val} value={val}>{val}</option>)}
              {v && !cc.values.includes(v) && <option value={v}>{v} {uiText("(removed)")}</option>}
            </select>
          </label>
        );
      })}
    </>
  );
}

// add-value input for the column manager — local draft state, commit on Enter/+
function AddValueInput({ onAdd }) {
  const [v, setV] = useState("");
  const commit = () => { const t = v.trim(); if (t) onAdd(t); setV(""); };
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
      <input name="column-add-value" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && !e.nativeEvent.isComposing && commit()} placeholder={uiText("add value")} style={{ ...ip, width: 90 }} />
      <button onClick={commit} title={uiText("Add this value to the list")}
        style={{ padding: "2px 7px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 12 }}>+</button>
    </span>
  );
}

// Appearance editor for ONE condition — tag, ×N, waste, line/fill color, hatch,
// line style, height, thickness, and custom-column assignment. This is the row
// that "used to live in its own toolbar row above the canvas"; extracted here so
// the docked panel AND the restored top-bar band render the SAME editor (one
// source of truth, like the app's single activateCondition path). Owns only its
// hatch-popover open state; everything else flows through the passed handlers.
export function ConditionAppearanceEditor({ cond: c, onUpdateCond, onSetCondParam, onAssignAttr, conditionColumns = [], layout = "stack", units = "imperial", rollInfo = null }) {
  const [hatchOpen, setHatchOpen] = useState(false);
  const activeColor = c.color || "#c96442";
  // Top-bar band ("row") only: the two palettes fold into two swatch buttons
  // with a popover each — one open at a time, Esc or a click outside closes.
  // The docked panel ("stack") keeps its inline palettes: it has the room.
  const [paletteOpen, setPaletteOpen] = useState(null); // null | "line" | "fill"
  const paletteRef = useRef(null);
  useEffect(() => {
    if (!paletteOpen) return;
    const onDown = (e) => { if (paletteRef.current && !paletteRef.current.contains(e.target)) setPaletteOpen(null); };
    const onKey = (e) => { if (e.key === "Escape") setPaletteOpen(null); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); };
  }, [paletteOpen]);
  // Two layouts, one editor. "stack" (docked panel, narrow) stacks the groups
  // vertically; "row" (top-bar band, wide) flows them left-to-right so they use
  // the horizontal space instead of clumping in a corner, split by thin rules.
  const isRow = layout === "row";
  const rule = () => <span aria-hidden style={{ width: 1, alignSelf: "stretch", background: "var(--ink-faint)", margin: "0 3px" }} />;
  return (
    <div style={isRow
      ? { padding: "6px 2px 2px", display: "flex", flexDirection: "row", flexWrap: "wrap", alignItems: "center", columnGap: 10, rowGap: 8, fontSize: 11 }
      : { padding: "4px 12px 10px", display: "flex", flexDirection: "column", gap: 7, fontSize: 11 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <input name="condition-finish-tag" value={c.finish_tag} onChange={(e) => onUpdateCond({ finish_tag: e.target.value })}
          title={uiText("Rename this condition / finish tag")}
          style={{ width: 88, padding: "3px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontFamily: "var(--f-mono)", fontWeight: 700, fontSize: 12, color: "var(--ink)" }} />
        <MultiplierField value={c.multiplier || 1} onChange={(n) => onUpdateCond({ multiplier: n })} />
        <span style={{ display: "flex", alignItems: "center", gap: 4 }} title={uiText("Waste % — a flooring allowance added on top of the measured quantity in the Report. You choose it per condition (e.g. ~8% straight-lay LVP, ~15% diagonal, ~20% herringbone).")}>
          <span style={{ color: "var(--ink-muted)" }}>{uiText("Waste")}</span>
          <input name="condition-waste-pct" type="number" min="0" step="1" value={c.waste_pct ?? 0}
            onChange={(e) => onUpdateCond({ waste_pct: Math.max(0, parseFloat(e.target.value) || 0) })}
            style={{ width: 50, padding: "3px 5px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 }} />
          <span style={{ color: "var(--ink-muted)" }}>%</span>
        </span>
        <label style={{ display: "flex", alignItems: "center", gap: 4 }} title="The trade this condition belongs to — what the status bar's Trade view filters on. Auto reads the tag prefix (RF-, SD-, GL-, P-, E- …), else Finishes.">
          <span style={{ color: "var(--ink-muted)" }}>Trade</span>
          <select name="condition-trade" value={typeof c.trade === "string" && suiteById(c.trade) ? c.trade : ""}
            onChange={(e) => onUpdateCond({ trade: e.target.value || undefined })}
            style={{ padding: "2px 4px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 }}>
            <option value="">Auto ({suiteById(conditionTrade({ finish_tag: c.finish_tag }))?.label})</option>
            {TRADE_SUITES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
          </select>
        </label>
      </div>
      {uiText(isRow && rule())}
      {isRow ? (
        <div ref={paletteRef} style={{ display: "flex", alignItems: "center", gap: 6, position: "relative" }}>
          <button data-testid="line-swatch" title={uiText(`Line color — ${c.color || "default"}`)} aria-expanded={paletteOpen === "line"}
            onClick={() => setPaletteOpen((v) => (v === "line" ? null : "line"))}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "2px 7px 2px 4px", borderRadius: 0, border: `1px solid ${paletteOpen === "line" ? "var(--ink)" : "var(--ink-faint)"}`, background: "var(--paper-bright)", cursor: "pointer", fontSize: 10.5, color: "var(--ink-muted)" }}>
            <span aria-hidden style={{ width: 16, height: 16, display: "block", borderRadius: 4, border: "1px solid var(--ink-faint)", background: `linear-gradient(to top right, transparent calc(50% - 1.5px), ${activeColor} calc(50% - 1.5px), ${activeColor} calc(50% + 1.5px), transparent calc(50% + 1.5px))` }} />
            {uiText("Line")}</button>
          <button data-testid="fill-swatch" title={uiText(`Fill color — ${c.fill === NO_FILL || !c.fill ? "none" : c.fill}`)} aria-expanded={paletteOpen === "fill"}
            onClick={() => setPaletteOpen((v) => (v === "fill" ? null : "fill"))}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "2px 7px 2px 4px", borderRadius: 0, border: `1px solid ${paletteOpen === "fill" ? "var(--ink)" : "var(--ink-faint)"}`, background: "var(--paper-bright)", cursor: "pointer", fontSize: 10.5, color: "var(--ink-muted)" }}>
            {c.fill && c.fill !== NO_FILL
              ? <span aria-hidden style={{ width: 16, height: 16, display: "block", borderRadius: 4, background: c.fill, opacity: 0.55, border: "1px solid var(--ink-faint)" }} />
              : <span aria-hidden style={{ width: 16, height: 16, display: "block", borderRadius: 4, border: "1px solid var(--ink-faint)", fontSize: 9, lineHeight: "14px", textAlign: "center", color: "var(--c-danger)" }}>⦸</span>}
            {uiText("Fill")}</button>
          {paletteOpen && (
            <div role="dialog" aria-label={uiText(paletteOpen === "line" ? "Line color" : "Fill color")}
              style={{ position: "absolute", top: 26, left: paletteOpen === "line" ? 0 : 62, zIndex: 30, display: "grid", gridTemplateColumns: "repeat(6, 16px)", gap: 4, padding: 8, background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", borderRadius: 0, boxShadow: "var(--shadow-pop)" }}>
              {paletteOpen === "fill" && (
                <button title={uiText("No fill")} onClick={() => { onUpdateCond({ fill: NO_FILL }); setPaletteOpen(null); }} style={{ width: 16, height: 16, borderRadius: 4, padding: 0, background: "var(--paper-bright)", border: c.fill === NO_FILL ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer", fontSize: 9, lineHeight: "12px", color: "var(--c-danger)" }}>⦸</button>
              )}
              {PALETTE.map((p) => {
                const on = paletteOpen === "line" ? c.color === p : c.fill === p;
                return <button key={p} title={uiText(p)} onClick={() => { onUpdateCond(paletteOpen === "line" ? { color: p } : { fill: p }); setPaletteOpen(null); }}
                  style={{ width: 16, height: 16, borderRadius: 4, padding: 0, background: p, opacity: paletteOpen === "fill" ? 0.55 : 1, border: on ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer" }} />;
              })}
            </div>
          )}
        </div>
      ) : (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
            <span style={{ color: "var(--ink-muted)", width: 26 }}>{uiText("Line")}</span>
            {PALETTE.map((p) => <button key={p} title={uiText(p)} onClick={() => onUpdateCond({ color: p })} style={{ width: 16, height: 16, borderRadius: 4, background: p, border: c.color === p ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer" }} />)}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
            <span style={{ color: "var(--ink-muted)", width: 26 }}>{uiText("Fill")}</span>
            <button title={uiText("No fill")} onClick={() => onUpdateCond({ fill: NO_FILL })} style={{ width: 16, height: 16, borderRadius: 4, background: "var(--paper-bright)", border: c.fill === NO_FILL ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer", fontSize: 9, lineHeight: "12px", color: "var(--c-danger)" }}>⦸</button>
            {PALETTE.map((p) => <button key={p} title={uiText(p)} onClick={() => onUpdateCond({ fill: p })} style={{ width: 16, height: 16, borderRadius: 4, background: p, opacity: 0.55, border: c.fill === p ? "2px solid var(--ink)" : "1px solid var(--ink-faint)", cursor: "pointer" }} />)}
          </div>
        </>
      )}
      {uiText(isRow && rule())}
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <span style={{ display: "flex", alignItems: "center", gap: 4, position: "relative" }}>
          <button onClick={() => setHatchOpen((v) => !v)} title={uiText("Choose a hatch pattern")}
            style={{ display: "flex", alignItems: "center", gap: 5, padding: "2px 7px 2px 2px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", cursor: "pointer", lineHeight: 0 }}>
            <span style={{ borderRadius: 4, overflow: "hidden", lineHeight: 0 }}><HatchSwatch type={c.hatch || "solid"} line={c.color} fill={c.fill} /></span>
            <span style={{ fontSize: 10.5, color: "var(--ink-muted)", lineHeight: 1 }}>{uiText((HATCHES.find((h) => h.id === (c.hatch || "solid")) || {}).label || "Solid")} ▾</span>
          </button>
          {hatchOpen && (
            <div style={{ position: "absolute", top: 26, left: 0, zIndex: 30, display: "grid", gridTemplateColumns: "repeat(6, auto)", gap: 4, padding: 8, background: "var(--paper-bright)", border: "1px solid var(--ink-faint)", borderRadius: 0, boxShadow: "var(--shadow-pop)" }}>
              {HATCHES.map((h) => {
                const hOn = (c.hatch || "solid") === h.id;
                return <button key={h.id} title={uiText(h.label)} onClick={() => { onUpdateCond({ hatch: h.id }); setHatchOpen(false); }} style={{ padding: 1, borderRadius: 0, border: hOn ? `2px solid ${activeColor}` : "1px solid var(--ink-faint)", background: "var(--paper-bright)", cursor: "pointer", lineHeight: 0 }}><HatchSwatch type={h.id} line={c.color} fill={c.fill} /></button>;
              })}
            </div>
          )}
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 4 }} title={uiText("Line style — the outline dash for this finish's floor-area and linear takeoffs (canvas + Marked Set PDF). Surface walls and deducts keep their own dashing.")}>
          <span style={{ color: "var(--ink-muted)" }}>{uiText("Style")}</span>
          <select name="condition-line-style" value={c.line_style || "solid"} onChange={(e) => onUpdateCond({ line_style: e.target.value })}
            style={{ fontSize: 11, border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", padding: "1px 3px" }}>
            {LINE_STYLE_IDS.map((id) => <option key={id} value={id}>{uiText(LINE_STYLES[id].label)}</option>)}
          </select>
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 4 }} title={uiText(`Height (${heightUnit(units)}) — the default for NEW wall traces (SF = LF × H) and the vertical-SF display on floor areas. Walls keep the height they were drawn at — select a wall to change just that one.`)}>
          <Icon name="height" size={13} /><span style={{ color: "var(--ink-muted)" }}>{uiText("Height")}</span>
          <DimParamInput name="condition-height-ft" internal={c.height_ft} units={units} kind="height" width={54}
            onCommit={(v) => onSetCondParam("height_ft", v)} />
        </span>
        {isCeilingCondition(c) && (
          <span style={{ display: "flex", alignItems: "center", gap: 4 }} title={`Ceiling height AFF (${heightUnit(units)}) — where this ceiling sits in the 3D view (the RCP height tag, e.g. 9'-0"). Display only: no quantity reads it. Blank = a 9'-0" allowance, flagged. Select an area to give it its own height (a soffit).`}>
            <span style={{ color: "var(--ink-muted)" }}>Ceiling AFF</span>
            <DimParamInput name="condition-ceiling-ft" internal={c.ceiling_ft} units={units} kind="height" width={54}
              onCommit={(v) => onUpdateCond({ ceiling_ft: v === "" ? null : v })} />
          </span>
        )}
        <span style={{ display: "flex", alignItems: "center", gap: 4 }} title={uiText(`Thickness (${thickUnit(units)}) — a Linear run with thickness also computes border/feature-strip SF = LF × T/12. Changing it re-flows existing linear runs.`)}>
          <Icon name="thickness" size={13} /><span style={{ color: "var(--ink-muted)" }}>{uiText("Thickness")}</span>
          <DimParamInput name="condition-thickness-in" internal={c.thickness_in} units={units} kind="thickness" width={50}
            onCommit={(v) => onSetCondParam("thickness_in", v)} />
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 4 }} title={uiText(`Rise (${heightUnit(units)}) — the vertical leg UP every Linear run of this condition adds to its plan length (a home run rising to a box, a riser to the ceiling). LF = plan + rise + drop. Changing it re-flows existing runs; select a run to give it its own rise.`)}>
          <span style={{ color: "var(--ink-muted)" }}>{uiText("↑ Rise")}</span>
          <DimParamInput name="condition-rise-ft" internal={c.rise_ft} units={units} kind="height" width={48}
            onCommit={(v) => onSetCondParam("rise_ft", v)} />
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 4 }} title={uiText(`Drop (${heightUnit(units)}) — the vertical leg DOWN every Linear run of this condition adds to its plan length (a drop from the ceiling to a panel or device). LF = plan + rise + drop. Changing it re-flows existing runs; select a run to give it its own drop.`)}>
          <span style={{ color: "var(--ink-muted)" }}>{uiText("↓ Drop")}</span>
          <DimParamInput name="condition-drop-ft" internal={c.drop_ft} units={units} kind="height" width={48}
            onCommit={(v) => onSetCondParam("drop_ft", v)} />
        </span>
      </div>
      {uiText(conditionColumns.length > 0 && isRow && rule())}
      {conditionColumns.length > 0 && (
        <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", rowGap: 2 }} title={uiText("Classify this condition — the Report can group and export by these (manage columns in the Columns tab)")}>
          <ColumnSelects columns={conditionColumns} cond={c} onAssign={onAssignAttr} />
        </div>
      )}
      {/* Imported product spec (mfr/style/color/size/description/remarks) —
          editable here, read-only columns in the Report. Docked ("stack") layout
          only: six text fields would crowd the wide top-bar band. The label
          column fits the longest header ("Schedule Remarks", ~97px at 11px).
          Shown only when a spec exists (schedule-imported conditions);
          hand-drawn conditions have none. Patch
          spreads c.spec so one edit can't clobber the other fields, and writes to
          spec.color — NOT the condition's line `color`. Guard that spec is a plain
          object first: a corrupted payload (spec an array/string) would otherwise
          render and let an edit spread it into a garbage shape ({0:"f",1:"o",…}). */}
      {/* Roll goods (#136) — OPT-IN per condition: conditions are trade-agnostic
          (no flooring-type field exists), so a roll_setup object PRESENT on the
          condition is what makes it roll goods. Docked ("stack") layout only,
          like spec. The engine (lib/rollgoods.js) figures seams/cuts/order
          footage from the condition's floor areas; the readout below comes back
          from the canvas via rollInfo. All lengths stored in feet (the lib/units
          contract); seam/wall allowances are inch-native like the engine. */}
      {!isRow && !hasRollSetup(c) && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, paddingTop: 6, marginTop: 1, borderTop: "1px solid var(--ink-faint)" }}>
          <select name="condition-roll-optin" value=""
            title={uiText("Make this condition a roll-goods material — its floor areas get figured into roll cuts (seams, order footage, a cut diagram)")}
            onChange={(e) => { if (e.target.value) onUpdateCond({ roll_setup: mintRollSetup(e.target.value) }); }}
            style={{ padding: "3px 6px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", fontSize: 11.5, cursor: "pointer" }}>
            <option value="">{uiText("+ roll goods…")}</option>
            <option value="carpet">{uiText("Broadloom carpet")}</option>
            <option value="sheet_vinyl">{uiText("Sheet vinyl")}</option>
            <option value="rubber">{uiText("Sheet rubber")}</option>
          </select>
        </div>
      )}
      {!isRow && hasRollSetup(c) && (() => {
        const rs = c.roll_setup;
        const patch = (p) => onUpdateCond({ roll_setup: { ...rs, ...p } });
        const wFt = Math.floor(Number(rs.roll_width_ft) || 0);
        const wIn = Math.round(((Number(rs.roll_width_ft) || 0) - wFt) * 12);
        const setW = (ft, inch) => patch({ roll_width_ft: Math.max(0.5, (Number(ft) || 0) + (Number(inch) || 0) / 12) });
        const numIp = { width: 46, padding: "3px 5px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 };
        const sel = { padding: "2px 4px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", fontSize: 11.5 };
        return (
          <div style={{ display: "flex", flexDirection: "column", gap: 5, paddingTop: 6, marginTop: 1, borderTop: "1px solid var(--ink-faint)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ color: "var(--ink-muted)", fontSize: 10, letterSpacing: 0.4, textTransform: "uppercase" }}
                title={uiText("Roll-goods setup — the engine figures seams, cuts, and order footage from this condition's floor areas")}>{uiText("Roll goods")}</span>
              <select name="condition-roll-material" value={rs.material || "carpet"} onChange={(e) => patch({ material: e.target.value })} style={sel}
                title={uiText("Material class — sets the cut overlay's material-true color")}>
                {ROLL_FLOORING_TYPES.map((ft) => <option key={ft} value={ft}>{uiText(ft === "carpet" ? "carpet" : ft === "sheet_vinyl" ? "sheet vinyl" : "rubber")}</option>)}
              </select>
              <button onClick={() => onUpdateCond({ roll_setup: undefined })} title={uiText("Remove the roll-goods setup (cuts and order footage stop being figured; manual cut edits on shapes are kept but inert)")}
                style={{ marginLeft: "auto", padding: "1px 6px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11 }}>✕</button>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 5, flexWrap: "wrap" }}>
              <span style={{ color: "var(--ink-muted)" }}>{uiText("Roll")}</span>
              {rs.material === "carpet" ? (
                <select name="condition-roll-width" value={String(rs.roll_width_ft)} onChange={(e) => patch({ roll_width_ft: parseFloat(e.target.value) || 12 })} style={sel}
                  title={uiText("Roll width — broadloom comes 12′ or 15′")}>
                  <option value="12">12′</option>
                  <option value="15">15′</option>
                </select>
              ) : (
                <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }} title={uiText("Roll width — resilient sheet widths vary by product (6′, 6′6″, 12′…)")}>
                  <input name="condition-roll-width-ft" type="number" min="0" step="1" value={wFt} onChange={(e) => setW(e.target.value, wIn)} style={numIp} /><span style={{ color: "var(--ink-muted)" }}>′</span>
                  <input name="condition-roll-width-in" type="number" min="0" max="11" step="1" value={wIn} onChange={(e) => setW(wFt, e.target.value)} style={numIp} /><span style={{ color: "var(--ink-muted)" }}>″</span>
                </span>
              )}
              <span style={{ color: "var(--ink-muted)" }} title={uiText("Max usable length of one physical roll — 0 = continuous (cut off one roll). When set, cuts pack across rolls and the diagram marks the roll breaks.")}>{uiText("max")}</span>
              <input name="condition-roll-length" type="number" min="0" step="5" value={rs.roll_length_ft || 0}
                onChange={(e) => patch({ roll_length_ft: Math.max(0, parseFloat(e.target.value) || 0) })} style={numIp} />
              <span style={{ color: "var(--ink-muted)" }}>′</span>
              <select name="condition-roll-direction" value={rs.direction || "auto"} onChange={(e) => patch({ direction: e.target.value })} style={sel}
                title={uiText("Run direction — auto picks whichever needs less footage; force it when the pattern or the light dictates")}>
                <option value="auto">{uiText("auto")}</option>
                <option value="ns">N–S</option>
                <option value="ew">E–W</option>
              </select>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 5, flexWrap: "wrap" }}>
              <span style={{ color: "var(--ink-muted)" }} title={uiText("Seam allowance — extra width where two cuts meet, per seamed edge")}>{uiText("Seam")}</span>
              <input name="condition-roll-seam" type="number" min="0" step="0.5" value={rs.seam_allowance_in ?? 2}
                onChange={(e) => patch({ seam_allowance_in: Math.max(0, parseFloat(e.target.value) || 0) })} style={numIp} />
              <span style={{ color: "var(--ink-muted)" }}>{uiText("″ · wall")}</span>
              <input name="condition-roll-wall" type="number" min="0" step="0.5" value={rs.wall_overage_in ?? 3}
                onChange={(e) => patch({ wall_overage_in: Math.max(0, parseFloat(e.target.value) || 0) })} style={numIp} />
              <span style={{ color: "var(--ink-muted)" }}>{uiText("″ · sells by")}</span>
              <select name="condition-roll-unit" value={rs.price_unit || "sf"} onChange={(e) => patch({ price_unit: e.target.value })} style={sel}
                title={uiText("The unit this material sells in — a unit, never a dollar (the takeoff stays quantities-only)")}>
                <option value="sy">{uiText("SY")}</option>
                <option value="sf">{uiText("SF")}</option>
                <option value="lf">{uiText("LF")}</option>
              </select>
            </div>
            {rollInfo && (
              <div style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 11, color: "var(--ink)" }}
                title={uiText("The figured order — how far down the roll the cuts reach (side-by-side cuts share length), rounded up to the inch. The Roll panel has the cut diagram.")}>
                {uiText("Figured: order ")}{uiText(ftIn(rollInfo.orderFt))} · {uiText(rollInfo.qty)} {uiText(rollInfo.unit.toUpperCase())}
                {uiText(rollInfo.config.rollLengthFt > 0 ? ` · ${rollInfo.rollCount} roll${rollInfo.rollCount === 1 ? "" : "s"}` : "")}
                {rollInfo.oversize && <span style={{ color: "var(--c-danger)" }}> {uiText("· a cut exceeds one roll")}</span>}
              </div>
            )}
          </div>
        );
      })()}
      {!isRow && c.spec && typeof c.spec === "object" && !Array.isArray(c.spec) && (
        <div style={{ display: "flex", flexDirection: "column", gap: 4, paddingTop: 6, marginTop: 1, borderTop: "1px solid var(--ink-faint)" }}>
          <span style={{ color: "var(--ink-muted)", fontSize: 10, letterSpacing: 0.4, textTransform: "uppercase" }}
            title={uiText("Product spec imported from the finish schedule — editable; shown as read-only columns in the Report / CSV / XLSX")}>{uiText("Spec")}</span>
          {SPEC_FIELDS.map(({ field, header }) => (
            <label key={field} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ color: "var(--ink-muted)", width: 104, flexShrink: 0 }}>{uiText(header)}</span>
              <input name={`condition-spec-${field}`} value={c.spec[field] || ""}
                onChange={(e) => onUpdateCond({ spec: { ...c.spec, [field]: e.target.value } })}
                style={{ flex: 1, minWidth: 0, padding: "3px 5px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12, color: "var(--ink)" }} />
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

// ── ⟂ Transitions — where two finishes meet, onto the active condition ───────
// The estimator's half of derive_transitions (#202). Two finishes go in; the
// runs where their rooms BUTT — meeting inside one open space, no wall between
// them — come back as dashed linear shapes on this condition, waiting on the
// Accept pill like any other machine proposal.
//
// What does NOT come back as a shape is the whole point. Two rooms across a
// partition are adjacent, not joined: the transition there is a threshold in a
// doorway, and a flood trace records how much boundary it sealed, never where.
// Committing 34 LF of threshold because two rooms share 34 LF of wall would be
// a wrong bid with a machine's confidence behind it — so those are listed here
// with their length and their gap, reported and never counted, for someone to
// place with the drawing in front of them.
function TransitionsAction({ cond: c, sources, draft, setDraft, result, setResult, onDerive, onLocate2 }) {
  const open = draft.id === c.id;
  // the transition lands on its OWN tag, so this condition is never a source —
  // deriving onto C-1 would add the joint's LF to the carpet it separates
  const opts = sources.filter((s) => s.id !== c.id);
  const ready = open && draft.a && draft.b && draft.a !== draft.b;
  const close = () => { setDraft({ id: "", a: "", b: "" }); setResult(null); };
  const run = () => { if (ready) setResult(onDerive(draft.a, draft.b)); };
  const selStyle = { ...ip, background: "var(--paper-bright)", color: "var(--ink)", maxWidth: 110 };
  return (
    <div style={{ padding: "7px 12px 9px", background: "var(--paper-cream)", borderTop: "1px solid var(--ink-faint)", fontSize: 11.5 }}>
      {!open ? (
        <button onClick={() => { setDraft({ id: c.id, a: opts[0]?.id || "", b: opts[1]?.id || "" }); setResult(null); }}
          disabled={opts.length < 2}
          title={uiText(opts.length < 2
            ? "Two finishes with measured rooms on the open sheets are needed before anything can meet."
            : `Derive where two finishes meet onto ${c.finish_tag}. Runs where the rooms butt inside one open space commit dashed, pending Accept; runs across a wall are reported and never counted — that transition is a threshold in a doorway no trace can locate.`)}
          style={{ padding: "3px 9px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent",
            color: opts.length < 2 ? "var(--ink-faint)" : "var(--ink)", cursor: opts.length < 2 ? "default" : "pointer", fontSize: 11.5 }}>
          {uiText("⟂ Transitions…")}</button>
      ) : (
        <div>
          <div style={{ color: "var(--ink-muted)", marginBottom: 5 }}>
            {uiText("Derive onto ")}<b style={{ color: "var(--ink)" }}>{finishLabel(c.finish_tag)}</b> {uiText("— where these two meet.")}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 5, flexWrap: "wrap" }}>
            <select name="transition-a" value={draft.a} onChange={(e) => setDraft({ ...draft, a: e.target.value })} style={selStyle}>
              {opts.map((s) => <option key={s.id} value={s.id}>{finishLabel(s.finish_tag)} ({uiText(s.rooms)})</option>)}
            </select>
            <span style={{ color: "var(--ink-muted)" }}>{uiText("meets")}</span>
            <select name="transition-b" value={draft.b} onChange={(e) => setDraft({ ...draft, b: e.target.value })} style={selStyle}>
              {opts.map((s) => <option key={s.id} value={s.id}>{finishLabel(s.finish_tag)} ({uiText(s.rooms)})</option>)}
            </select>
            <button name="transition-derive" onClick={run} disabled={!ready}
              style={{ padding: "2px 9px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent",
                color: ready ? "var(--ink)" : "var(--ink-faint)", cursor: ready ? "pointer" : "default", fontSize: 11 }}>{uiText("Derive")}</button>
            <button onClick={close} style={{ padding: "2px 6px", border: "none", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>{uiText("Cancel")}</button>
          </div>
          {result?.error && (
            <div style={{ marginTop: 6, padding: "4px 6px", border: "1px solid var(--c-warning)", color: "var(--ink)", background: "var(--paper-bright)" }}>{uiText(result.error)}</div>
          )}
          {result && !result.error && (
            <div style={{ marginTop: 6 }}>
              <div style={{ color: result.committed ? "var(--c-positive)" : "var(--ink-muted)" }}>
                {uiText(result.committed
                  ? `${result.committed} run${result.committed === 1 ? "" : "s"} · ${result.total_lf} LF proposed on ${result.onto} — dashed until you Accept.`
                  : "No butt joints between these two on the open sheets.")}
              </div>
              {result.withheld?.length > 0 && (
                <div style={{ marginTop: 5, paddingTop: 5, borderTop: "1px solid var(--ink-faint)" }}>
                  <div style={{ color: "var(--ink-muted)", fontSize: 10.5, letterSpacing: 0.4, textTransform: "uppercase" }}
                    title={uiText("These rooms are adjacent across a partition. The transition is a threshold in the doorway, and nothing in the trace record says where the doorway is — so it is reported, never counted. Measure it at the door.")}>
                    {uiText("Reported, never counted")}</div>
                  <ul style={{ margin: "3px 0 0", paddingLeft: 14, color: "var(--ink)" }}>
                    {result.withheld.map((w, i) => (
                      <li key={`${w.between_shape_ids.join("-")}-${i}`} style={{ marginBottom: 1 }}>
                        {uiText(w.length_lf)} {uiText("LF across ")}{uiText(w.gap_in)}{uiText("″ of wall")}<span style={{ color: "var(--ink-muted)" }}> — {uiText(w.between.join(" / "))}</span>
                        {onLocate2 && (
                          <button onClick={() => onLocate2(w.sheet_id, w.at)} title={uiText("Center the sheet on this run — find the door and measure the threshold there")}
                            style={{ marginLeft: 5, padding: 0, border: "none", background: "transparent", color: "var(--cobalt)", cursor: "pointer", fontSize: 11, textDecoration: "underline" }}>{uiText("look")}</button>
                        )}
                      </li>
                    ))}
                  </ul>
                  <div style={{ marginTop: 3, color: "var(--ink-muted)" }}>{uiText("Adjacent, not joined — measure the threshold at the door.")}</div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// The tag's floor in a condition row — wide enough for "CPT-12 ×120". Below
// it the row wraps its action cluster rather than squeeze the tag away.
export const ROW_TAG_MIN_W = 104;

// ×N on a condition row — a multiplier silently scales every quantity under
// the condition, so it reads as a chip, not as muted text after the tag.
// Nothing at ×1.
export function MultiplierChip({ mult }) {
  if (!(mult > 1)) return null;
  return (
    <span data-multiplier-chip title={uiText(`Every quantity on this condition is multiplied by ${mult} — measure one unit, count it ${mult} times`)}
      style={{ marginLeft: 6, padding: "0 4px", fontFamily: "var(--f-mono,monospace)", fontSize: 10.5, fontWeight: 700, color: "var(--cobalt)", border: "1px solid var(--cobalt)", borderRadius: 3 }}>×{uiText(mult)}</span>
  );
}

// "× [N] units" in the condition editor — the repeating-unit multiplier (trace
// one apartment, count it 120 times). Labelled because a bare × beside a small
// number box read as nothing; lit cobalt while it is actually multiplying.
export function MultiplierField({ value, onChange }) {
  const live = value > 1;
  return (
    <label style={{ display: "flex", alignItems: "center", gap: 4, cursor: "default" }}
      title={uiText("Repeating units — measure one identical unit and multiply every quantity on this condition by N (Report and buy list included). Need the same finish at ×1 elsewhere? Supporting Materials → Duplicate for another area.")}>
      <span style={{ color: live ? "var(--cobalt)" : "var(--ink-muted)", fontWeight: live ? 700 : 400 }}>×</span>
      <input name="condition-multiplier" type="number" min="1" step="1" value={value}
        onChange={(e) => onChange(Math.max(1, parseInt(e.target.value, 10) || 1))}
        style={{ width: 46, padding: "3px 5px", borderRadius: 0, border: `1px solid ${live ? "var(--cobalt)" : "var(--ink-faint)"}`, fontSize: 12, fontWeight: live ? 700 : 400 }} />
      <span style={{ color: live ? "var(--cobalt)" : "var(--ink-muted)" }}>{uiText(value === 1 ? "unit" : "units")}</span>
    </label>
  );
}

// Eye (#440) — leads a condition row, where a layer list puts it. Click hides /
// shows that condition's takeoffs on the canvas; ⌥-click isolates it.
// stopPropagation on click AND double-click: the row's own gestures (activate /
// zoom-to) must not fire under a fast toggle. Exported so the markup and the
// click contract are testable without mounting the whole panel.
export function ConditionEye({ tag, hidden, onToggle }) {
  return (
    <button type="button" aria-pressed={!hidden} aria-label={formatMessage("{0} {1} on the plan", [uiText(hidden ? "Show" : "Hide"), tag])}
      onClick={(e) => { e.stopPropagation(); onToggle(!!e.altKey); }}
      onDoubleClick={(e) => e.stopPropagation()}
      title={uiText(keyText(uiText(hidden ? "Hidden on the plan — click to show (⌥-click shows only this one). Still counted in totals, report and exports." : "Hide on the plan (⌥-click shows only this one). Hiding never changes a quantity.")))}
      style={{ flexShrink: 0, display: "inline-flex", alignItems: "center", justifyContent: "center", width: 24, height: 22, padding: 0, borderRadius: 0, border: `1px solid ${hidden ? "var(--c-danger)" : "var(--ink-faint)"}`, background: hidden ? "var(--c-danger)" : "transparent", color: hidden ? "var(--paper-bright)" : "var(--ink)", cursor: "pointer", lineHeight: 0 }}>
      <Icon name={hidden ? "eyeOff" : "eye"} size={15} />
    </button>
  );
}

// Hidden-conditions bar (#440) — a half-hidden sheet must never pass for a
// finished one, so the state is loud and one click undoes it. Renders nothing
// while everything is showing.
export function HiddenConditionsBar({ hidden, total, onShowAll }) {
  if (!hidden) return null;
  return (
    <div role="status" style={{ display: "flex", alignItems: "center", gap: 7, padding: "6px 10px", borderBottom: "1px solid var(--ink-faint)", background: "var(--c-danger)", color: "var(--paper-bright)", flexShrink: 0, fontSize: 11, fontWeight: 600 }}>
      <Icon name="eyeOff" size={14} />
      <span style={{ flex: 1, minWidth: 0 }}>{uiText(hidden)} {uiText("of ")}{uiText(total)} {uiText("hidden on the plan — totals unchanged")}</span>
      <button type="button" onClick={onShowAll} title={uiText("Show every hidden condition again")}
        style={{ flexShrink: 0, padding: "2px 8px", borderRadius: 0, border: "1px solid var(--paper-bright)", background: "transparent", color: "var(--paper-bright)", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>{uiText("Show all")}</button>
    </div>
  );
}

// stable empty default — a fresh Set per render would defeat React.memo
const NO_HIDDEN = new Set();

// The saved-assembly library (lib/assemblies.js, localStorage + .otprofile).
// Read here rather than threaded through the canvas: a save from this panel,
// a profile import and another tab all announce themselves, so the list stays
// current without a canvas-level copy.
export function useAssemblyLibrary() {
  const [list, setList] = useState(() => loadAssemblies());
  useEffect(() => {
    const reload = () => setList(loadAssemblies());
    const onStorage = (e) => { if (!e.key || e.key === ASSEMBLY_STORAGE_KEY) reload(); };
    window.addEventListener(ASSEMBLY_EVENT, reload);
    window.addEventListener("storage", onStorage);
    return () => { window.removeEventListener(ASSEMBLY_EVENT, reload); window.removeEventListener("storage", onStorage); };
  }, []);
  return list;
}

// Save the active condition's items as an assembly, or apply a saved one to it.
// Inline name input, never a window.prompt (prompts freeze scripted sessions).
function AssemblyBar({ cond, assemblies, onApply }) {
  const [draft, setDraft] = useState(null);   // null = closed; string = the name being typed
  const [msg, setMsg] = useState("");
  const named = (cond?.materials || []).filter((m) => m && m.name).length;
  const save = () => {
    const a = conditionToAssembly(cond, draft, `asm-${mintUuid()}`);
    if (!a) return;
    const others = assemblies.filter((x) => x.name.toLowerCase() !== a.name.toLowerCase());
    const replaced = others.length !== assemblies.length;
    setMsg(saveAssemblies([...others, a])
      ? `${replaced ? "Replaced" : "Saved"} assembly “${a.name}” — ${a.items.length} item${a.items.length === 1 ? "" : "s"}, no prices.`
      : "Couldn't save the assembly (browser storage is full or blocked).");
    setDraft(null);
  };
  const apply = (id) => {
    const a = assemblies.find((x) => x.id === id);
    if (!a || !onApply) return;
    const have = new Set((cond?.materials || []).filter((m) => m && m.name).map((m) => String(m.name).trim().toLowerCase()));
    const skipped = a.items.filter((it) => have.has(it.name.trim().toLowerCase())).map((it) => it.name);
    onApply(a);
    const added = a.items.length - skipped.length;
    setMsg(`Applied “${a.name}”: ${added} item${added === 1 ? "" : "s"} added${skipped.length ? `, ${skipped.join(", ")} already on ${cond.finish_tag}` : ""}. Price them in Estimate.`);
  };
  const btn = { padding: "2px 8px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 };
  return (
    <div data-assembly-bar style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, flexWrap: "wrap", fontSize: 11 }}>
      <span style={{ color: "var(--ink-muted)" }}>Assembly</span>
      {draft === null ? (
        <button onClick={() => { setDraft(cond?.finish_tag || ""); setMsg(""); }} disabled={!named} style={{ ...btn, cursor: named ? "pointer" : "default", color: named ? "var(--ink-muted)" : "var(--ink-faint)" }}
          title={named ? "Save these items (rules and waste, never prices) as an assembly you can apply to any condition" : "Add a named material first"}>save as…</button>
      ) : (
        <>
          <input name="assembly-name" autoFocus value={draft} placeholder="Assembly name" onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && draft.trim()) save(); if (e.key === "Escape") setDraft(null); }}
            style={{ ...ip, width: 140 }} />
          <button onClick={save} disabled={!draft.trim()} style={{ ...btn, border: "1px solid var(--ink-faint)", color: draft.trim() ? "var(--ink)" : "var(--ink-faint)" }}>Save</button>
        </>
      )}
      {onApply && assemblies.length > 0 && (
        <select name="apply-assembly" value="" onChange={(e) => { if (e.target.value) apply(e.target.value); }}
          title="Add a saved assembly's items to this condition (items it already has are skipped)"
          style={{ ...ip, background: "var(--paper-bright)", color: "var(--ink-muted)" }}>
          <option value="">+ apply assembly…</option>
          {assemblies.map((a) => <option key={a.id} value={a.id}>{a.name} · {a.items.length} item{a.items.length === 1 ? "" : "s"}</option>)}
        </select>
      )}
      {msg && <span role="status" style={{ flexBasis: "100%", color: "var(--ink-muted)" }}>{msg}</span>}
    </div>
  );
}

function TakeoffsPanel({
  open, width, overlay = false, multiSheet, dockSide, layoutLocked = false, dockHandle, units = "imperial",
  conditions, activeCond, visRowById, projRowById = new Map(), conditionColumns, shapeLabels = [], templates, palette = [], rollByCond = null,
  transitionSources = [],
  matLib, matLibById, linkedCountById,
  panelPrefs, onPanelPrefs, reassigning, epoch, clearSelectionRef,
  onActivate, onSetActive, onLocate,
  onAddCondition, onDeleteCondition, onUpdateCond, onSetCondParam, onAssignAttr,
  conditionEditProposals = [], onAcceptConditionEdit, onRejectConditionEdit,
  collisionsByCond = null, onLookAtCollision, revisionFlaggedByCond = null,
  onAddMaterial, onUpdateMaterial, onRemoveMaterial, onApplyAssembly,
  onDuplicateCondition, onSplitCondition, onFollowFamilyRow, onRestoreDroppedRow,
  onDeriveTransitions, onLocateTransition,
  onBulkWaste, onBulkColor, onBulkDelete,
  onSaveTemplate, onApplyTemplate, onRenameTemplate, onDeleteTemplate,
  onAttachLibMaterial, onPromoteMaterial, onRevertMatField, matFieldOverridden,
  onUpdateLibMaterial, onPushLibUpdate, onDeleteLibMaterial, onAddLibMaterial,
  onAddColumn, onRenameColumn, onDeleteColumn, onAddColumnValue, onRemoveColumnValue, onRenameColumnValue,
  onAddLabel, onRenameLabel, onRemoveLabel,
  onToggleCollapse, onHoldGesture, onTogglePin,
  hiddenConds = NO_HIDDEN, onToggleHidden,
  tradeHidden = NO_HIDDEN, viewTradeLabel = null, onShowAllTrades,
}) {
  useUiLocale();
  const [panelTab, setPanelTab] = useState("takeoffs");       // "takeoffs" | "library" | "materials" | "columns"
  const assemblies = useAssemblyLibrary();
  const [condQuery, setCondQuery] = useState("");             // live filter over the condition list (transient, never persisted)
  const [matLibQuery, setMatLibQuery] = useState("");         // Materials tab search (transient; describes the browser-global library, so hydrate/epoch leaves it alone)
  const [closedGroups, setClosedGroups] = useState(() => new Set()); // collapsed tag-family groups in the grouped view
  // multi-select for bulk edit — VIEW STATE ONLY, never persisted. ⌘/ctrl-click
  // toggles a row into the set, ⇧-click ranges from the last toggle in the
  // current view order, plain click clears (and activates, as always).
  const [checkedConds, setCheckedConds] = useState(() => new Set());
  const [bulkWaste, setBulkWaste] = useState("");
  const checkAnchorRef = useRef(null);
  const [panelMatOpen, setPanelMatOpen] = useState(false);    // supporting-materials editor expanded inline under the active row
  const [twinDraft, setTwinDraft] = useState({ id: "", label: uiText("") });   // inline "duplicate for another area" input (never a prompt)
  // ⟂ Transitions — the two finishes to compare, and the last run's report.
  // Inline for the same reason the twin input is: a window.prompt freezes a
  // CDP/automation-driven session dead, and this panel is scripted in demos.
  const [transDraft, setTransDraft] = useState({ id: "", a: "", b: "" });
  const [transResult, setTransResult] = useState(null);   // { committed, total_lf, withheld[], between, onto } | { error }
  const rootRef = useRef(null);   // panel root — mid-drag width writes bypass React
  const dragRef = useRef(null);   // { sx, sw, w } — w is the live width during the drag

  // hydrate (mount load or snapshot Load) replaced the conditions this view
  // state described — a checked set / range anchor / filter / collapsed groups
  // aimed at the PRE-load list would misfire on ids that happen to survive.
  // Cleared in place so panelTab (and the width pref) survive, matching the
  // pre-extraction behavior. On mount this is a no-op (fresh state).
  useEffect(() => {
    setCheckedConds((s) => (s.size ? new Set() : s));
    checkAnchorRef.current = null;
    setCondQuery("");
    setClosedGroups((s) => (s.size ? new Set() : s));
    setTransDraft((d) => (d.id ? { id: "", a: "", b: "" } : d));
    setTransResult(null);   // a report about shapes that no longer exist is worse than no report
  }, [epoch]);

  // the canvas's activateCondition (rows, strip, 1–9 hotkeys) dismisses a live
  // bulk selection — it reaches this view state through the shared ref
  useEffect(() => {
    if (!clearSelectionRef) return undefined;
    clearSelectionRef.current = () => setCheckedConds((s) => (s.size ? new Set() : s));
    return () => { clearSelectionRef.current = null; };
  }, [clearSelectionRef]);

  // ── condition list: VIEW-ONLY search / natural sort / grouping ────────────
  // Rows are wrapped as { c } so the view transforms (filter/sort/group) never
  // touch the condition objects; the hotkey badge now reflects palette order,
  // resolved per row from the palette prop (no original-index bookkeeping).
  const condQ = condQuery.trim().toLowerCase();
  const matQ = matLibQuery.trim().toLowerCase();   // Materials tab filter — hoisted so the row map below computes it once, not per row
  // the one finish-tag match rule — condView's filter and searchMiss must
  // agree on what "matches" means, or a row could show while the "no match"
  // message also shows (or vice versa)
  const matchesQuery = useCallback((c) => (c.finish_tag || "").toLowerCase().includes(condQ), [condQ]);
  const condView = useMemo(() => {
    let v = conditions.map((c) => ({ c }));
    // the ACTIVE condition is force-included past the filter: hotkeys, the
    // strip, and applyTemplate can activate a row the query hides, and the
    // properties editor lives only in the active row — it must stay reachable
    if (condQ) v = v.filter(({ c }) => matchesQuery(c) || c.id === activeCond);
    // the status bar's Trade view (lib/tradeSuites.ts) — same active-row exemption as the query
    if (tradeHidden.size) v = v.filter(({ c }) => !tradeHidden.has(c.id) || c.id === activeCond);
    if (panelPrefs.az) v = [...v].sort((a, b) => natCompare(a.c.finish_tag, b.c.finish_tag));
    return v;
  }, [conditions, condQ, matchesQuery, activeCond, panelPrefs.az, tradeHidden]);
  const condGroups = useMemo(() => {
    if (!panelPrefs.group) return [{ name: null, items: condView }];
    const by = new Map();
    for (const it of condView) {
      const fam = tagFamily(it.c);
      if (!by.has(fam)) by.set(fam, []);
      by.get(fam).push(it);
    }
    return [...by.entries()].sort((a, b) => natCompare(a[0], b[0])).map(([name, items]) => ({ name, items }));
  }, [condView, panelPrefs.group]);
  // "no match" keys on the QUERY missing, not on an empty view — the forced-in
  // active row would otherwise hide the message forever (includes("") is true)
  const searchMiss = conditions.length > 0 && !condView.some(({ c }) => matchesQuery(c));

  // the one "which rows does a collapsed group show" rule — a collapsed
  // group still renders its ACTIVE row: hotkeys, the strip, and applyTemplate
  // can activate a condition the view hides, and the editor lives only in
  // that row. Shared by the ⇧-range order below AND the render, below, so
  // they can never disagree on what's visible.
  const groupVisibleItems = useCallback(
    (g) => (g.name != null && closedGroups.has(g.name) ? g.items.filter((it) => it.c.id === activeCond) : g.items),
    [closedGroups, activeCond]
  );
  // bulk selection helpers — ranges follow the DISPLAYED order (current view,
  // skipping collapsed groups — except the active row, which a collapsed group
  // still renders, so ⇧-ranges anchored on or through it must see it too)
  const visibleCondOrder = useMemo(
    () => condGroups.flatMap((g) => groupVisibleItems(g).map((it) => it.c.id)),
    [condGroups, groupVisibleItems]
  );
  // bulk actions run on the LIVE intersection — checkedConds is view state and
  // deletes elsewhere (or a stale set) must never inflate a count or a patch
  const liveChecked = conditions.filter((c) => checkedConds.has(c.id));
  // hidden count over the LIVE list — never claims ids a delete took (#440)
  const liveHidden = hiddenConds.size ? conditions.reduce((n, c) => n + (hiddenConds.has(c.id) ? 1 : 0), 0) : 0;
  const liveIds = () => new Set(liveChecked.map((c) => c.id));
  const toggleChecked = (id) => {
    setCheckedConds((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
    checkAnchorRef.current = id;
  };
  const rangeCheck = (id) => {
    const a = checkAnchorRef.current;
    const ai = a ? visibleCondOrder.indexOf(a) : -1, bi = visibleCondOrder.indexOf(id);
    if (ai < 0 || bi < 0) { toggleChecked(id); return; }
    const [lo, hi] = ai < bi ? [ai, bi] : [bi, ai];
    setCheckedConds((s) => { const n = new Set(s); for (let k = lo; k <= hi; k++) n.add(visibleCondOrder[k]); return n; });
  };
  const applyBulkWaste = () => {
    const v = Math.max(0, parseFloat(bulkWaste));
    if (!Number.isFinite(v)) return;
    onBulkWaste(liveIds(), v);
  };
  const bulkDelete = () => {
    if (!liveChecked.length) return;
    // the canvas confirms + mutates; the selection clears only if it went through
    if (onBulkDelete(liveIds())) { setCheckedConds(new Set()); checkAnchorRef.current = null; }
  };

  // Resize by dragging the panel's left edge. Mid-drag the width lives in a
  // ref and goes straight to the panel root's DOM style — NO pref commit per
  // move (each one re-rendered the whole canvas tree and re-wrote
  // localStorage). The canvas's detail-crop gesture window is held per move
  // (onHoldGesture, like wheel zoom) and state commits ONCE on release, so the
  // persistence effect and the detail crop fire once per drag.
  const onResizeDown = (e) => {
    e.preventDefault();
    dragRef.current = { sx: e.clientX, sw: width, w: width };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onResizeMove = (e) => {
    const d = dragRef.current; if (!d) return;
    if (e.buttons === 0) { onResizeEnd(e); return; }   // release happened off-window — a missed pointerup must not leave a phantom drag
    onHoldGesture();
    d.w = clampPanelW(d.sw + (d.sx - e.clientX) * (dockSide === "left" ? -1 : 1));
    if (rootRef.current) rootRef.current.style.width = `${d.w}px`;
  };
  // shared by pointerup / pointercancel / lostpointercapture — any way the
  // gesture ends, the width commits exactly once
  const onResizeEnd = (e) => {
    const d = dragRef.current; if (!d) return;
    dragRef.current = null;
    onPanelPrefs((p) => (p.w === d.w ? p : { ...p, w: d.w }));
    try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* gone */ }
  };

  const aCond = conditions.find((c) => c.id === activeCond);
  // proposals (#365): one pending condition-edit diff per condition, by id
  const editProposalByCond = useMemo(() => new Map((Array.isArray(conditionEditProposals) ? conditionEditProposals : []).filter((p) => p && p.condition_id).map((p) => [p.condition_id, p])), [conditionEditProposals]);

  // unit-system display edge (mirrors the canvas HUD): internal math stays feet
  const fa = (sf) => `${num(areaVal(sf, units))} ${areaUnit(units)}`;
  const fl = (lf) => `${num(lenVal(lf, units))} ${lenUnit(units)}`;

  const renderCondRow = (c) => {
    const row = visRowById.get(c.id);
    const mult = c.multiplier || 1;
    const sf = row?.floor_sf || 0, lf = row?.lf || 0, ea = row?.ea || 0, wsf = row?.wall_sf || 0;
    const shapeCount = row?.shape_count || 0;
    // whole-project Σ suffix (#137): shown ONLY when the project holds more
    // than the open sheets, so the common everything-on-this-sheet case stays
    // one number. A condition entirely on closed sheets reads "Σ 412 SF"
    // instead of a dead "—".
    const qtys = (o) => [o.sf ? fa(o.sf) : "", o.wsf ? `${fa(o.wsf)} wall` : "", o.lf ? fl(o.lf) : "", o.ea ? `${num(o.ea, 0)} EA` : ""].filter(Boolean).join(" · ");
    const pr = projRowById.get(c.id);
    const prQ = pr ? { sf: pr.floor_sf || 0, wsf: pr.wall_sf || 0, lf: pr.lf || 0, ea: pr.ea || 0 } : null;
    const projDiff = prQ && (Math.abs(prQ.sf - sf) > 0.005 || Math.abs(prQ.wsf - wsf) > 0.005 || Math.abs(prQ.lf - lf) > 0.005 || Math.abs(prQ.ea - ea) > 0.005);
    const on = c.id === activeCond;
    const matOn = on && panelMatOpen;
    const checked = checkedConds.has(c.id);
    const hidden = hiddenConds.has(c.id);        // takeoffs hidden on the canvas (#440) — view only, quantities unaffected
    const pinIdx = palette.indexOf(c.id);        // position in the top-bar palette (−1 = not pinned)
    const pinned = pinIdx >= 0;
    // 1–9 hotkey badge follows the same rule as the keys (and the strip): palette
    // order when the palette is curated, condition-array order as the fallback
    // when nothing is pinned so the badge never under-advertises a working key
    const hIdx = palette.length ? pinIdx : conditions.findIndex((x) => x.id === c.id);
    const hot = hIdx >= 0 && hIdx < 9;
    return (
      <div key={c.id} data-cond-id={c.id} style={{ borderTop: "1px solid var(--ink-faint)", background: checked ? "var(--tint-select)" : on ? "var(--tint-active)" : "transparent", borderLeft: on ? `3px solid ${c.color}` : checked ? "3px solid var(--cobalt)" : "3px solid transparent" }}>
        <div draggable
          onDragStart={(e) => { e.dataTransfer.setData(CONDITION_DND_MIME, c.id); e.dataTransfer.effectAllowed = "copy"; }}
          onClick={(e) => {
            if (e.metaKey || e.ctrlKey) { toggleChecked(c.id); return; }
            if (e.shiftKey) { rangeCheck(c.id); return; }
            onActivate(c.id);
          }}
          onDoubleClick={() => onLocate(c.id)}
          title={uiText(reassigning ? "Reassign selected shape to this condition" : keyText(uiText("Make this the active condition (double-click zooms to its takeoffs · ⌘-click / ⇧-click selects for bulk edit · drag to the top-bar palette for one-click access)")))}
          style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 8, rowGap: 5, padding: "9px 12px", cursor: "pointer", outline: reassigning ? "1px dashed var(--cobalt)" : "none", outlineOffset: -3, userSelect: "none" }}>
          {hot && <span title={uiText(pinned ? `Palette shortcut — press ${hIdx + 1} to activate` : `Press ${hIdx + 1} to activate (pin to lock this number)`)} style={{ fontSize: 9, fontFamily: "var(--f-mono,monospace)", color: pinned ? "var(--cobalt)" : "var(--ink-muted)", border: `1px solid ${pinned ? "var(--cobalt)" : "var(--ink-faint)"}`, borderRadius: 3, padding: "0 3px", flexShrink: 0 }}>{uiText(hIdx + 1)}</span>}
          <ConditionEye tag={c.finish_tag} hidden={hidden} onToggle={(isolate) => onToggleHidden(c.id, isolate)} />
          <span style={{ borderRadius: 4, overflow: "hidden", lineHeight: 0, flexShrink: 0, opacity: hidden ? 0.35 : 1 }}><HatchSwatch type={c.hatch || "solid"} line={c.color} fill={c.fill} /></span>
          {/* the tag is the row's identity: it holds a floor (ROW_TAG_MIN_W) and
              the action cluster wraps under it on a narrow panel, instead of the
              tag collapsing to nothing beside buttons that never shrink */}
          <div style={{ minWidth: 0, flex: `1 1 ${ROW_TAG_MIN_W}px`, opacity: hidden ? 0.55 : 1 }}>
            <div style={{ fontWeight: on ? 700 : 600, color: "var(--ink)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {/* a twin reads as one: whose it is, and how many of its rows have gone their own way */}
              {c.variant_of ? <span aria-hidden title={uiText("A twin — its materials follow another condition")} style={{ color: "var(--ink-faint)", fontWeight: 400 }}>↳ </span> : null}
              {finishLabel(c.finish_tag)}<MultiplierChip mult={mult} />
              {c.variant_of && localCount(c) > 0 ? (
                <span title={uiText(`${localCount(c)} material row${localCount(c) === 1 ? "" : "s"} no longer follow${localCount(c) === 1 ? "s" : ""} the family`)}
                  style={{ marginLeft: 5, fontFamily: "var(--f-mono,monospace)", fontSize: 9, fontWeight: 500, color: "var(--cobalt)", border: "1px solid var(--cobalt)", borderRadius: 3, padding: "0 3px" }}>{uiText(localCount(c))}</span>
              ) : null}
            </div>
            <div style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 11, color: "var(--ink-muted)" }}>
              {uiText(qtys({ sf, wsf, lf, ea }))}{uiText(!sf && !wsf && !lf && !ea && !projDiff ? "—" : "")}
              {projDiff ? (
                <span title={uiText("Σ = whole project, every sheet. The leading numbers count the open sheets only.")} style={{ color: "var(--ink-faint)" }}>
                  {uiText((sf || wsf || lf || ea) ? " · " : "")}Σ {uiText(qtys(prQ) || "0")}
                </span>
              ) : null}
            </div>
          </div>
          <span data-row-actions style={{ display: "inline-flex", alignItems: "center", gap: 8, flexShrink: 0, marginLeft: "auto" }}>
          <span style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 10.5, color: "var(--ink-muted)", flexShrink: 0 }}>{uiText(shapeCount)}▦</span>
          {/* scope collision (#366): this condition shares floor with another
              (or with itself — a double trace). The badge is the count; the
              list under the ACTIVE row names each pair with a Look link. */}
          {collisionsByCond?.get(c.id)?.length ? (
            <span data-collision-badge={c.id} title={uiText(`${collisionsByCond.get(c.id).length} shared-floor pair${collisionsByCond.get(c.id).length === 1 ? "" : "s"} — another condition claims the same floor, or a room is traced twice. Activate the row to see each pair.`)}
              style={{ flexShrink: 0, fontFamily: "var(--f-mono,monospace)", fontSize: 10, fontWeight: 700, color: "var(--c-danger)", border: "1px solid var(--c-danger)", borderRadius: 3, padding: "0 4px" }}>⚠ {uiText(collisionsByCond.get(c.id).length)}</span>
          ) : null}
          {revisionFlaggedByCond?.has(c.id) ? (
            <span data-revision-badge={c.id} title={uiText("Shapes in this condition touch changed ink from a drawing revision. Check after revision.")}
              style={{ flexShrink: 0, fontFamily: "var(--f-mono,monospace)", fontSize: 10, fontWeight: 700, color: "var(--c-warning, #d97706)", border: "1px solid var(--c-warning, #d97706)", borderRadius: 3, padding: "0 4px" }}>Δ Check</span>
          ) : null}
          <button onClick={(e) => { e.stopPropagation(); onLocate(c.id); }} title={uiText("Zoom the canvas to this condition's takeoffs")}
            style={{ flexShrink: 0, padding: "2px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 12, lineHeight: 1 }}>⌖</button>
          <button onClick={(e) => { e.stopPropagation(); onSetActive(c.id); setPanelMatOpen((v) => (on ? !v : true)); }}
            title={uiText("Supporting Materials — labor, subfloor & materials for this condition")}
            style={{ flexShrink: 0, display: "inline-flex", alignItems: "center", gap: 3, padding: "2px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: matOn ? "var(--ink)" : "transparent", color: matOn ? "var(--paper-bright)" : "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>
            <Icon name="product" size={11} />{uiText("Materials")}{uiText(c.materials?.length ? ` (${c.materials.length})` : "")}
          </button>
          <button onClick={(e) => { e.stopPropagation(); onTogglePin(c.id); }}
            title={uiText(pinned ? "Unpin from the top-bar palette" : (palette.length >= 9 ? "Palette is full (9)" : "Pin to the top-bar palette for one-click access"))}
            style={{ flexShrink: 0, display: "inline-flex", alignItems: "center", padding: "2px 5px", borderRadius: 0, border: `1px solid ${pinned ? "var(--cobalt)" : "var(--ink-faint)"}`, background: "transparent", color: pinned ? "var(--cobalt)" : (!pinned && palette.length >= 9 ? "var(--ink-faint)" : "var(--ink-muted)"), cursor: "pointer", lineHeight: 0 }}>
            <Icon name="pin" size={12} />
          </button>
          <button onClick={(e) => { e.stopPropagation(); onDeleteCondition(c.id); }} title={uiText("Delete this condition (and its takeoffs)")}
            style={{ flexShrink: 0, padding: "2px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 12 }}>✕</button>
          </span>
        </div>
        {/* properties for the ACTIVE condition — the appearance editing that
            used to live in its own toolbar row above the canvas. Extracted to
            ConditionAppearanceEditor so the docked panel AND the top-bar band
            render the same editor from one source of truth. */}
        {on && collisionsByCond?.get(c.id)?.length ? (
          <div data-collision-list={c.id} onClick={(e) => e.stopPropagation()} style={{ margin: "0 12px 8px", padding: "6px 8px", border: "1px solid var(--c-danger)", background: "var(--paper-bright)", fontSize: 11 }}>
            <div style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 9.5, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--c-danger)", fontWeight: 700, marginBottom: 4 }}>{uiText("Shared floor · counted twice in the totals")}</div>
            {collisionsByCond.get(c.id).map((p) => {
              const other = p.a.condition_id === c.id ? p.b : p.a;
              const mine = p.a.condition_id === c.id ? p.a : p.b;
              return (
                <div key={`${p.a.shape_id}-${p.b.shape_id}`} style={{ display: "flex", alignItems: "center", gap: 6, fontFamily: "var(--f-mono,monospace)", fontSize: 11, color: "var(--ink)", padding: "1px 0" }}>
                  <span style={{ color: "var(--ink-muted)" }}>{uiText(p.same_condition ? "⧉" : "↔")}</span>
                  <span style={{ flex: 1, minWidth: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {uiText(p.same_condition ? `double trace${mine.label ? ` · ${mine.label}` : ""}` : `${other.condition}${other.label ? ` · ${other.label}` : ""}`)}
                    <span style={{ color: "var(--ink-muted)" }}> · {uiText(p.shared_sf === 0 ? "<0.01" : p.shared_sf)} {uiText("SF shared · ")}{uiText(Math.round(p.fraction_of_smaller * 100))}%{uiText(p.a.reviewed && p.b.reviewed ? " · both accepted" : "")}</span>
                  </span>
                  <button onClick={() => onLookAtCollision?.(p)} title={uiText("Frame both shapes on the plan")}
                    style={{ flexShrink: 0, padding: "1px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--cobalt)", cursor: "pointer", fontSize: 10.5, fontWeight: 600 }}>{uiText("Look")}</button>
                </div>
              );
            })}
          </div>
        ) : null}
        {/* proposals (#365): a pending condition-edit diff sits UNDER the row
            it targets — current → proposed per knob, the agent's rationale,
            and the decision. Nothing on the condition changes until Accept;
            Reject drops the diff. The row above always shows the current
            values, exactly like the report. */}
        {editProposalByCond.get(c.id) && (() => {
          const p = editProposalByCond.get(c.id);
          const rows = describeConditionEdit(c, p);
          return (
            <div data-condition-proposal={p.id} onClick={(e) => e.stopPropagation()}
              style={{ margin: "0 12px 8px", padding: "6px 8px", border: "1px dashed var(--cobalt)", background: "var(--paper-bright)", fontSize: 11.5 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                <span style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 9.5, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--cobalt)", fontWeight: 700 }}>{uiText("Proposed change")}</span>
                <span style={{ flex: 1 }} />
                <button onClick={() => onAcceptConditionEdit?.(p.id)} title={uiText("Apply the proposed values to this condition — the same edit typing them here would make")}
                  style={{ padding: "2px 8px", borderRadius: 0, border: "1px solid var(--c-positive)", background: "var(--c-positive)", color: "var(--paper-bright)", cursor: "pointer", fontSize: 11, fontWeight: 600 }}>{uiText("Accept")}</button>
                <button onClick={() => onRejectConditionEdit?.(p.id)} title={uiText("Drop the proposal — the condition stays as it is")}
                  style={{ padding: "2px 8px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11 }}>{uiText("Reject")}</button>
              </div>
              {rows.map((r) => (
                <div key={r.field} style={{ display: "flex", gap: 6, fontFamily: "var(--f-mono,monospace)", fontSize: 11, color: "var(--ink)" }}>
                  <span style={{ color: "var(--ink-muted)", minWidth: 68 }}>{uiText(r.field)}</span>
                  <span style={{ color: "var(--ink-muted)", textDecoration: "line-through" }}>{uiText(r.from)}</span>
                  <span>→</span>
                  <strong>{uiText(r.to)}</strong>
                </div>
              ))}
              {p.rationale ? <div style={{ marginTop: 4, color: "var(--ink-muted)", fontStyle: "italic" }}>{uiText(p.rationale)}</div> : null}
            </div>
          );
        })()}
        {on && <ConditionAppearanceEditor cond={c} onUpdateCond={onUpdateCond} onSetCondParam={onSetCondParam} onAssignAttr={onAssignAttr} conditionColumns={conditionColumns} units={units} rollInfo={rollByCond?.get(c.id) || null} />}
        {on && onDeriveTransitions && <TransitionsAction cond={c} sources={transitionSources} draft={transDraft} setDraft={setTransDraft}
          result={transResult} setResult={setTransResult} onDerive={onDeriveTransitions} onLocate2={onLocateTransition} />}
        {matOn && (
          <div style={{ padding: "8px 12px 10px", background: "var(--paper-cream)", borderTop: "1px solid var(--ink-faint)", fontSize: 11.5 }}>
            <div style={{ marginBottom: 6, color: "var(--ink-muted)" }}>{uiText("Supporting Materials — order qty = measured ÷ coverage, rounded up.")}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4, marginBottom: 8 }}>
              <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ color: "var(--ink-muted)", width: 56, flexShrink: 0 }}>{uiText("Labor")}</span>
                <input name="condition-labor-type" value={c.laborType || ""} placeholder={uiText("e.g. Glue-down, Float, Nail-down")}
                  onChange={(e) => onUpdateCond({ laborType: e.target.value })}
                  style={{ ...ip, flex: 1, minWidth: 0 }} />
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ color: "var(--ink-muted)", width: 56, flexShrink: 0 }}>{uiText("Subfloor")}</span>
                <input name="condition-subfloor-type" value={c.subfloorType || ""} placeholder={uiText("e.g. Ply, Concrete slab, OSB")}
                  onChange={(e) => onUpdateCond({ subfloorType: e.target.value })}
                  style={{ ...ip, flex: 1, minWidth: 0 }} />
              </label>
            </div>
            {/* Family: a twin says whose it is, and how to cut it loose. */}
            {c.variant_of && (() => {
              const par = conditions.find((x) => x.id === c.variant_of);
              const n = localCount(c);
              return (
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6, padding: "3px 6px", border: "1px solid var(--ink-faint)", background: "var(--paper-cream)", fontSize: 11 }}>
                  <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: "var(--ink-muted)" }}
                    title={uiText(`These materials follow “${par?.finish_tag || "the original"}”. Edit a row and only that row stops following.`)}>
                    {uiText("↳ twin of ")}<b style={{ color: "var(--ink)" }}>{finishLabel(par?.finish_tag || "—")}</b>
                    {n ? <span style={{ color: "var(--cobalt)" }}> · {uiText(n)} {uiText("local")}</span> : null}
                  </span>
                  {onSplitCondition && (
                    <button onClick={() => onSplitCondition(c.id)}
                      title={uiText(`Split out — freeze the following rows where they stand and stop following “${par?.finish_tag || "the original"}”. Keeps its name and still groups with the family.`)}
                      style={{ padding: "1px 6px", border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 10.5, color: "var(--ink)", flexShrink: 0 }}>{uiText("⤴ Split out")}</button>
                  )}
                </div>
              );
            })()}
            <MaterialsEditor materials={c.materials} onAdd={onAddMaterial} onUpdate={onUpdateMaterial} onRemove={onRemoveMaterial}
              library={matLib} libById={matLibById} overridden={matFieldOverridden} onRevert={onRevertMatField}
              onAttach={onAttachLibMaterial} onPromote={onPromoteMaterial}
              twin={!!c.variant_of} parentTag={(conditions.find((x) => x.id === c.variant_of) || {}).finish_tag || ""}
              dropped={c.materials_dropped || []} parentRows={(conditions.find((x) => x.id === c.variant_of) || {}).materials || []}
              onFollowFamilyRow={onFollowFamilyRow} onRestoreDroppedRow={onRestoreDroppedRow}
              heightFt={c.height_ft} />
            <AssemblyBar cond={c} assemblies={assemblies} onApply={onApplyAssembly} />
            {/* Duplicate, inline — deliberately NOT a window.prompt: those freeze a
                CDP/automation-driven session dead, and this panel is scripted in demos. */}
            {onDuplicateCondition && (twinDraft.id === c.id ? (
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, flexWrap: "wrap" }}>
                <span style={{ color: "var(--ink-muted)", fontSize: 11 }}>{uiText("Duplicate for")}</span>
                <input name="twin-label" autoFocus value={twinDraft.label}
                  onChange={(e) => setTwinDraft({ id: c.id, label: e.target.value })}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && twinDraft.label.trim()) { onDuplicateCondition(c.id, twinDraft.label.trim()); setTwinDraft({ id: "", label: uiText("") }); }
                    if (e.key === "Escape") setTwinDraft({ id: "", label: uiText("") });
                  }}
                  placeholder={uiText("e.g. Level 2")} style={{ ...ip, width: 120 }} />
                <span style={{ color: "var(--ink-muted)", fontSize: 11 }}>
                  → <b style={{ color: "var(--ink)" }}>{uiText(twinDraft.label.trim() ? `${baseTagOf(c.finish_tag)} – ${twinDraft.label.trim()}` : "…")}</b>
                </span>
                <button onClick={() => { if (twinDraft.label.trim()) { onDuplicateCondition(c.id, twinDraft.label.trim()); setTwinDraft({ id: "", label: uiText("") }); } }}
                  disabled={!twinDraft.label.trim()}
                  style={{ padding: "2px 8px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: twinDraft.label.trim() ? "var(--ink)" : "var(--ink-faint)", cursor: twinDraft.label.trim() ? "pointer" : "default", fontSize: 11 }}>{uiText("Duplicate")}</button>
                <button onClick={() => setTwinDraft({ id: "", label: uiText("") })}
                  style={{ padding: "2px 6px", border: "none", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>{uiText("Cancel")}</button>
              </div>
            ) : (
              <button onClick={() => setTwinDraft({ id: c.id, label: uiText("") })}
                title={uiText("Duplicate this condition — the same finish measured somewhere else, with its own materials. Name the area (e.g. Level 2); no takeoffs come along, you measure into it, and its materials keep following this condition until you change them there.")}
                style={{ marginTop: 6, padding: "3px 9px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", cursor: "pointer", fontSize: 11.5 }}>{uiText("⎘ Duplicate for another area…")}</button>
            ))}
          </div>
        )}
      </div>
    );
  };

  if (!open) return null;
  return (
    // Narrow screens (`overlay`): the panel slides OVER the canvas instead of
    // docking beside it — a docked 240px+ column plus the canvas doesn't fit a
    // phone (the panel was covering the whole screen). Desktop docked layout
    // is unchanged. The header's » collapse button is the close affordance.
    <div ref={rootRef} data-workspace-takeoffs data-dock-side={dockSide} style={overlay
      ? { position: "absolute", top: 0, [dockSide === "left" ? "left" : "right"]: 0, bottom: 0, width: "min(100%, 420px)", zIndex: Z.drawer, boxShadow: "var(--shadow-pop)", display: "flex", background: "var(--paper-bright)", borderLeft: "1px solid var(--ink-faint)", fontSize: 12.5 }
      : { width, order: dockSide ? dockSide === "left" ? -11 : 11 : undefined, flexShrink: 0, display: "flex", background: "var(--paper-bright)", borderLeft: "1px solid var(--ink-faint)", fontSize: 12.5 }}>
      {!overlay && !layoutLocked && <div onPointerDown={onResizeDown} onPointerMove={onResizeMove} onPointerUp={onResizeEnd}
        onPointerCancel={onResizeEnd} onLostPointerCapture={onResizeEnd}
        title={uiText("Drag to resize")}
        style={{ order: dockSide === "left" ? 1 : undefined, width: 5, flexShrink: 0, cursor: "col-resize", touchAction: "none", background: "transparent", borderRight: "1px solid var(--ink-faint)" }} />}
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <div data-takeoffs-header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, padding: "7px 12px", background: "var(--ink)", color: "var(--paper-cream)", flexShrink: 0 }}>
          {uiText(dockHandle)}<span style={{ display: "inline-flex", gap: 2 }}>
            {[["takeoffs", `Takeoffs · ${multiSheet ? "these sheets" : "this sheet"}`], ["library", `Library${templates.length ? ` (${templates.length})` : ""}`], ["materials", `Materials${matLib.length ? ` (${matLib.length})` : ""}`], ["columns", `Columns${conditionColumns.length ? ` (${conditionColumns.length})` : ""}`]].map(([id, label]) => (
              <button key={id} aria-pressed={panelTab === id} onClick={() => setPanelTab(id)}
                style={{ padding: "3px 8px", border: "none", borderBottom: panelTab === id ? "2px solid var(--paper-cream)" : "2px solid transparent", background: "none", color: "var(--paper-cream)", opacity: panelTab === id ? 1 : 0.65, cursor: "pointer", fontWeight: 700, fontSize: 12.5 }}>{uiText(label)}</button>
            ))}
          </span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
            <button onClick={() => onPanelPrefs((p) => ({ ...p, strip: !p.strip }))}
              title={uiText("Compact strip — also show the conditions as a horizontal strip above the canvas (handy on small projects with the panel collapsed)")}
              style={{ background: panelPrefs.strip ? "var(--paper-cream)" : "none", border: "1px solid var(--paper-cream)", color: panelPrefs.strip ? "var(--ink)" : "var(--paper-cream)", fontSize: 9.5, fontFamily: "var(--f-mono)", letterSpacing: "0.08em", textTransform: "uppercase", cursor: "pointer", padding: "2px 6px", lineHeight: 1.4 }}>{uiText("strip")}</button>
            <button onClick={onToggleCollapse} title={uiText("Collapse the panel (the ☰ button on the canvas edge brings it back)")}
              style={{ background: "none", border: "none", color: "var(--paper-cream)", fontSize: 15, cursor: "pointer", lineHeight: 1 }}>»</button>
          </span>
        </div>
        {panelTab === "takeoffs" && <>
        {/* view controls — search / natural sort / tag-family grouping.
            All VIEW-ONLY: the array order (hotkeys, payload) never changes. */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "7px 10px", borderBottom: "1px solid var(--ink-faint)", flexShrink: 0 }}>
          <input name="condition-filter" value={condQuery} onChange={(e) => setCondQuery(e.target.value)} placeholder={uiText("filter conditions…")}
            style={{ flex: 1, minWidth: 0, padding: "4px 8px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 }} />
          {condQuery && <button onClick={() => setCondQuery("")} title={uiText("Clear the filter")} style={btnClearX}>×</button>}
          <button onClick={() => onPanelPrefs((p) => ({ ...p, az: !p.az }))}
            title={uiText("Natural sort by tag (CT-2 before CT-10) — a view; hotkeys 1–9 keep their original numbering")}
            style={{ padding: "3px 7px", borderRadius: 0, border: `1px solid ${panelPrefs.az ? "var(--cobalt)" : "var(--ink-faint)"}`, background: panelPrefs.az ? "var(--cobalt)" : "transparent", color: panelPrefs.az ? "var(--paper-bright)" : "var(--ink-muted)", cursor: "pointer", fontSize: 10.5, fontFamily: "var(--f-mono)", lineHeight: 1.4 }}>A→Z</button>
          <button onClick={() => onPanelPrefs((p) => ({ ...p, group: !p.group }))}
            title={uiText("Group by tag family (the text before the dash: CPT, LVT, CT…)")}
            style={{ padding: "3px 7px", borderRadius: 0, border: `1px solid ${panelPrefs.group ? "var(--cobalt)" : "var(--ink-faint)"}`, background: panelPrefs.group ? "var(--cobalt)" : "transparent", color: panelPrefs.group ? "var(--paper-bright)" : "var(--ink-muted)", cursor: "pointer", fontSize: 10.5, fontFamily: "var(--f-mono)", lineHeight: 1.4 }}>{uiText("≡ grp")}</button>
        </div>
        {viewTradeLabel && tradeHidden.size > 0 && (
          <div style={{ padding: "5px 10px", borderBottom: "1px solid var(--ink-faint)", flexShrink: 0 }}>
            <button type="button" data-trade-view-note="" onClick={onShowAllTrades}
              title={`The canvas shows ${viewTradeLabel} only; ${tradeHidden.size} other condition(s) are hidden from view (the Report, estimate and exports keep them). Click to show all trades.`}
              style={{ padding: "3px 7px", borderRadius: 0, border: "1px solid var(--cobalt)", background: "transparent", color: "var(--cobalt)", cursor: "pointer", fontSize: 10.5, fontFamily: "var(--f-mono)", lineHeight: 1.4, whiteSpace: "nowrap" }}>
              {viewTradeLabel} · {tradeHidden.size} hidden ×
            </button>
          </div>
        )}
        {/* bulk actions — appear while a ⌘/⇧ multi-selection is live
            (liveChecked: the count never claims ids the list lost) */}
        {liveChecked.length > 0 && (
          <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "6px 10px", borderBottom: "1px solid var(--ink-faint)", background: "var(--tint-select)", flexShrink: 0, flexWrap: "wrap", fontSize: 11 }}>
            <strong style={{ color: "var(--cobalt)" }}>{uiText(liveChecked.length)} {uiText("selected")}</strong>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }} title={uiText("Set the waste % on every selected condition")}>
              <span style={{ color: "var(--ink-muted)" }}>{uiText("Waste")}</span>
              <input name="bulk-waste" type="number" min="0" step="1" value={bulkWaste} onChange={(e) => setBulkWaste(e.target.value)} placeholder={uiText("%")}
                onKeyDown={(e) => e.key === "Enter" && applyBulkWaste()}
                style={{ width: 44, padding: "2px 5px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 11 }} />
              <button onClick={applyBulkWaste} title={uiText("Apply waste % to the selection")} style={{ padding: "2px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 11 }}>✓</button>
            </span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }} title={uiText("Set the line color on every selected condition")}>
              {PALETTE.map((p) => <button key={p} title={uiText(p)} onClick={() => onBulkColor(liveIds(), p)} style={{ width: 13, height: 13, borderRadius: 3, background: p, border: "1px solid var(--ink-faint)", cursor: "pointer", padding: 0 }} />)}
            </span>
            <button onClick={bulkDelete} title={uiText("Delete every selected condition (and their takeoffs)")}
              style={{ padding: "2px 7px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11, fontWeight: 600 }}>{uiText("Delete")}</button>
            <button onClick={() => setCheckedConds(new Set())} title={uiText("Clear the selection")}
              style={{ marginLeft: "auto", padding: "2px 6px", border: "none", background: "none", color: "var(--ink-muted)", cursor: "pointer", fontSize: 12 }}>✕</button>
          </div>
        )}
        <HiddenConditionsBar hidden={liveHidden} total={conditions.length} onShowAll={() => onToggleHidden(null)} />
        <div style={{ flex: 1, overflow: "auto" }}>
          {conditions.length === 0 && <div style={{ padding: "12px", color: "var(--ink-muted)" }}>{uiText("No conditions yet — add one and start tracing.")}</div>}
          {condGroups.map((g) => (
            <React.Fragment key={g.name ?? "_all"}>
              {g.name != null && (
                <div onClick={() => setClosedGroups((s) => { const n = new Set(s); if (n.has(g.name)) n.delete(g.name); else n.add(g.name); return n; })}
                  title={uiText("Collapse / expand this tag family")}
                  style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", borderTop: "1px solid var(--ink-faint)", background: "var(--paper-cream)", cursor: "pointer", fontFamily: "var(--f-mono,monospace)", fontSize: 10.5, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-muted)", userSelect: "none" }}>
                  <span style={{ width: 10 }}>{uiText(closedGroups.has(g.name) ? "▸" : "▾")}</span>
                  <span style={{ fontWeight: 700, color: "var(--ink)" }}>{uiText(g.name)}</span>
                  <span>· {uiText(g.items.length)}</span>
                </div>
              )}
              {/* groupVisibleItems: a collapsed group still renders its
                  ACTIVE row (see the shared rule above visibleCondOrder) */}
              {uiText(groupVisibleItems(g).map(({ c }) => renderCondRow(c)))}
            </React.Fragment>
          ))}
          {searchMiss && <div style={{ padding: "12px", color: "var(--ink-muted)" }}>{uiText("No conditions match “")}{uiText(condQuery)}”.</div>}
          <div style={{ padding: "6px 12px", borderTop: "1px solid var(--ink-faint)" }}>
            <button onClick={onAddCondition} style={{ width: "100%", padding: "6px 10px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", cursor: "pointer", fontSize: 12.5, color: "var(--ink-muted)" }}>{uiText("+ condition")}</button>
          </div>
          <div style={{ padding: "8px 12px", borderTop: "1px solid var(--ink-faint)", color: "var(--ink-muted)", fontSize: 10.5 }}>
            {uiText(keyText(uiText("Select a shape on the plan, then ⧉ Copy / ⎘ Paste (⌘C / ⌘V) — it lands on the sheet under your cursor.")))}
            <br />{uiText("⌫ undo point · Esc cancel · scroll = zoom · pan mid-measure: press-and-drag (a click without dragging places the point).")}</div>
        </div>
        </>}
        {/* Library tab — reusable condition templates, browser-wide */}
        {panelTab === "library" && (
          <div style={{ flex: 1, overflow: "auto" }}>
            <div style={{ padding: "8px 12px 4px", color: "var(--ink-muted)", fontSize: 11 }}>
              {uiText("Reusable condition templates, shared across every plan in this browser. A fresh workspace seeds from this library (built-in flooring defaults when it's empty).")}</div>
            <div style={{ padding: "6px 12px 10px" }}>
              <button onClick={onSaveTemplate} disabled={!aCond}
                title={uiText("Snapshot the active condition (appearance, waste, H/T, materials) into the library")}
                style={{ width: "100%", padding: "6px 10px", borderRadius: 0, border: "1px dashed var(--ink-faint)", background: "transparent", cursor: aCond ? "pointer" : "default", fontSize: 12, color: aCond ? "var(--ink)" : "var(--ink-faint)" }}>
                {uiText("+ save ")}{uiText(aCond?.finish_tag || "the active condition")} {uiText("to the library")}</button>
            </div>
            {templates.length === 0 && <div style={{ padding: "2px 12px 12px", color: "var(--ink-muted)" }}>{uiText("No templates yet — make a condition the way you like it, then save it here.")}</div>}
            {templates.map((t, idx) => (
              <div key={`${t.finish_tag}-${idx}`} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", borderTop: "1px solid var(--ink-faint)" }}>
                <span style={{ borderRadius: 4, overflow: "hidden", lineHeight: 0, flexShrink: 0 }}><HatchSwatch type={t.hatch || "solid"} line={t.color} fill={t.fill} /></span>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ fontWeight: 600, color: "var(--ink)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{finishLabel(t.finish_tag)}</div>
                  <div style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 10.5, color: "var(--ink-muted)" }}>
                    {uiText(t.waste_pct || 0)}{uiText("% waste")}{uiText(t.height_ft != null ? ` · H ${dimInputStr(t.height_ft, units, "height")}${units === "metric" ? " m" : "′"}` : "")}{uiText(t.thickness_in != null ? ` · T ${dimInputStr(t.thickness_in, units, "thickness")}${units === "metric" ? " mm" : "″"}` : "")}{uiText(t.rise_ft > 0 ? ` · ↑${dimInputStr(t.rise_ft, units, "height")}${units === "metric" ? " m" : "′"}` : "")}{uiText(t.drop_ft > 0 ? ` · ↓${dimInputStr(t.drop_ft, units, "height")}${units === "metric" ? " m" : "′"}` : "")}{uiText(t.materials?.length ? ` · ${t.materials.length} material${t.materials.length === 1 ? "" : "s"}` : "")}
                  </div>
                </div>
                <button onClick={() => { onApplyTemplate(t); setPanelTab("takeoffs"); }} title={uiText("Add a condition from this template to the takeoff")}
                  style={{ flexShrink: 0, padding: "3px 8px", borderRadius: 0, border: "1px solid var(--ink)", background: "var(--ink)", color: "var(--paper-bright)", cursor: "pointer", fontSize: 11, fontWeight: 600 }}>{uiText("Apply")}</button>
                <button onClick={() => onRenameTemplate(idx)} title={uiText("Rename this template")}
                  style={{ flexShrink: 0, padding: "3px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>✎</button>
                <button onClick={() => onDeleteTemplate(idx)} title={uiText("Remove this template from the library")}
                  style={{ flexShrink: 0, padding: "3px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11 }}>✕</button>
              </div>
            ))}
            {/* Assemblies — saved item recipes (lib/assemblies.js). Saved from a condition's
                Materials editor; applied here or there to the ACTIVE condition. */}
            <div data-assembly-library style={{ padding: "12px 12px 4px", borderTop: "1px solid var(--ink)", color: "var(--ink-muted)", fontSize: 11 }}>
              <strong style={{ color: "var(--ink)", letterSpacing: "0.06em", textTransform: "uppercase", fontSize: 10.5 }}>Assemblies</strong>
              {" "}— a condition's items (quantity rule, waste %) saved to apply to another. Recipes only: prices stay with each project. Travels in your .otprofile.
            </div>
            {assemblies.length === 0 && <div style={{ padding: "2px 12px 12px", color: "var(--ink-muted)" }}>No assemblies yet — open a condition's Materials and use “Assembly: save as…”.</div>}
            {assemblies.map((a) => (
              <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", borderTop: "1px solid var(--ink-faint)" }}>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ fontWeight: 600, color: "var(--ink)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.name}</div>
                  <div style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 10.5, color: "var(--ink-muted)" }}>
                    {a.items.map((it) => `${it.name} (${coverageLabel(it)})`).join(" · ")}
                  </div>
                </div>
                <button onClick={() => { if (aCond && onApplyAssembly) onApplyAssembly(a); }} disabled={!aCond || !onApplyAssembly}
                  title={aCond ? `Add these items to ${aCond.finish_tag} (items it already has are skipped)` : "Pick a condition first"}
                  style={{ flexShrink: 0, padding: "3px 8px", borderRadius: 0, border: "1px solid var(--ink)", background: "var(--ink)", color: "var(--paper-bright)", cursor: aCond ? "pointer" : "default", fontSize: 11, fontWeight: 600 }}>
                  Apply{aCond ? ` to ${aCond.finish_tag}` : ""}
                </button>
                <button onClick={() => saveAssemblies(assemblies.filter((x) => x.id !== a.id))} title="Remove this assembly from the library (conditions that used it keep their items)"
                  style={{ flexShrink: 0, padding: "3px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11 }}>✕</button>
              </div>
            ))}
          </div>
        )}
        {/* Materials tab — the material library (#47/#48): canonical
            consumables shared across every plan in this browser. Conditions
            COPY on attach (lib_id link); edits here never propagate unless
            explicitly pushed to linked lines. */}
        {panelTab === "materials" && (
          <div style={{ flex: 1, overflow: "auto", fontSize: 11.5 }}>
            <div style={{ padding: "8px 12px 4px", color: "var(--ink-muted)", fontSize: 11 }}>
              {uiText("Reusable materials, browser-wide. Attaching one to a condition copies its values and keeps a link — edits here only reach linked lines when you push them.")}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px 8px" }}>
              <input name="material-library-filter" value={matLibQuery} onChange={(e) => setMatLibQuery(e.target.value)} placeholder={uiText("filter materials…")}
                style={{ flex: 1, minWidth: 0, padding: "4px 8px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12 }} />
              {matLibQuery && <button onClick={() => setMatLibQuery("")} title={uiText("Clear the filter")} style={btnClearX}>×</button>}
            </div>
            {matLib.length === 0 && <div style={{ padding: "2px 12px 12px", color: "var(--ink-muted)" }}>{uiText("No library materials yet — add one below, or use “→ lib” on a condition's material line.")}</div>}
            {matLib.filter((lm) => !matQ || (lm.name || "").toLowerCase().includes(matQ)).map((lm) => {
              const n = linkedCountById[lm.id] || 0;
              return (
                <div key={lm.id} style={{ padding: "8px 12px", borderTop: "1px solid var(--ink-faint)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                    {/* name is draft-buffered like per/note (round-3 finding 3): a per-keystroke
                        commit routes every transient value through libEntryPatch's rename
                        re-classification, where a select-all-retype walks the entry's kind
                        through arbitrary intermediate classifications */}
                    <LibDraftInput name="library-material-name" value={lm.name} placeholder={uiText("Material (e.g. Adhesive)")} width={150}
                      onCommitText={(t) => onUpdateLibMaterial(lm.id, { name: t })} />
                    <span style={{ color: "var(--ink-muted)" }}>1</span>
                    <input name="library-material-unit" value={lm.unit} onChange={(e) => onUpdateLibMaterial(lm.id, { unit: e.target.value })} placeholder={uiText("unit")} style={{ ...ip, width: 54 }} />
                    <span style={{ color: "var(--ink-muted)" }}>{uiText("per")}</span>
                    <LibDraftInput name="library-material-per" number value={lm.per || ""} placeholder={uiText("0")} width={62}
                      onCommitText={(t) => onUpdateLibMaterial(lm.id, { per: Math.max(0, parseFloat(t) || 0) })} />
                    <select name="library-material-basis" value={lm.basis || "area"} onChange={(e) => onUpdateLibMaterial(lm.id, { basis: e.target.value })} style={{ ...ip, background: "var(--paper-bright)" }}>
                      <option value="area">{uiText("floor SF")}</option>
                      <option value="linear">{uiText("linear LF")}</option>
                      <option value="count">{uiText("each")}</option>
                      <option value="seam_lf" title={uiText("Figured seam length from the roll layout — 0 until the condition carries a roll setup")}>{uiText("seam LF")}</option>
                    </select>
                    <label style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "var(--ink-muted)" }} title={uiText("Round up to whole units")}>
                      <input name="library-material-round" type="checkbox" checked={lm.round !== false} onChange={(e) => onUpdateLibMaterial(lm.id, { round: e.target.checked })} />{uiText("round up")}</label>
                    <CoveragePresetSelect material={lm} onPick={(patch) => onUpdateLibMaterial(lm.id, patch)} />
                    <LibDraftInput name="library-material-note" value={lm.note || ""} placeholder={uiText("note")} width={120}
                      onCommitText={(t) => onUpdateLibMaterial(lm.id, { note: t })} />
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 5 }}>
                    <span style={{ fontFamily: "var(--f-mono,monospace)", fontSize: 10.5, color: "var(--ink-muted)" }}>{uiText(n ? `⛓ ${n} linked line${n === 1 ? "" : "s"}` : "not linked yet")}</span>
                    <div style={{ flex: 1 }} />
                    {n > 0 && (
                      <button onClick={() => onPushLibUpdate(lm.id)} title={uiText("Replace the values on every linked condition line with these library values (overrides included)")}
                        style={{ padding: "2px 8px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", cursor: "pointer", fontSize: 11 }}>{uiText("update linked (")}{uiText(n)})</button>
                    )}
                    <button onClick={() => onDeleteLibMaterial(lm.id)} title={uiText("Remove from the library — linked lines keep their values, only the link is removed")}
                      style={{ padding: "2px 8px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11 }}>✕</button>
                  </div>
                </div>
              );
            })}
            <div style={{ padding: "6px 12px", borderTop: matLib.length ? "1px solid var(--ink-faint)" : "none" }}>
              <button onClick={onAddLibMaterial} style={btnAddFull}>{uiText("+ add library material")}</button>
            </div>
          </div>
        )}
        {/* Columns tab — the custom-columns manager (#31/#33): project-level
            vocabulary; per-condition assignment lives in the active row's
            properties on the Takeoffs tab */}
        {panelTab === "columns" && (
          <div style={{ flex: 1, overflow: "auto", fontSize: 11.5 }}>
            {/* Shape labels (#110) — a flat project-level vocabulary; each shape
                carries at most one label. Lives here rather than a 5th panel tab:
                it's the degenerate single-column case. */}
            <details open style={{ borderBottom: "2px solid var(--ink-faint)" }}>
              <summary style={{ padding: "8px 12px 4px", cursor: "pointer", fontWeight: 600, fontSize: 11.5 }}>
                {uiText("Shape labels")}{uiText(shapeLabels.length ? ` (${shapeLabels.length})` : "")}
              </summary>
              <div style={{ padding: "0 12px 4px", color: "var(--ink-muted)", fontSize: 11 }}>
                {uiText("Phase / area labels (e.g. Phase 1, East Wing) for grouping the Report by shape.")}</div>
              <div style={{ padding: "2px 12px 10px", display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                {shapeLabels.map((v) => (
                  <span key={v} style={{ display: "inline-flex", alignItems: "center", gap: 3, padding: "2px 3px 2px 8px", border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", fontSize: 11.5, color: "var(--ink)" }}>
                    {uiText(v)}
                    <button onClick={() => onRenameLabel(v)} title={uiText("Rename this label — labeled shapes follow")}
                      style={{ padding: "0 3px", border: "none", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>✎</button>
                    <button onClick={() => onRemoveLabel(v)} title={uiText("Remove from the list — labeled shapes keep the value (shown ungrouped in the Report)")}
                      style={{ padding: "0 3px", border: "none", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11 }}>✕</button>
                  </span>
                ))}
                <AddValueInput onAdd={onAddLabel} />
              </div>
            </details>
            <div style={{ padding: "8px 12px 4px", color: "var(--ink-muted)", fontSize: 11 }}>
              {uiText("Custom columns (e.g. CSI Division) classify conditions for report grouping and exports. Columns and values apply to the whole project; assign values on a condition in the Takeoffs tab.")}</div>
            {conditionColumns.length === 0 && <div style={{ padding: "2px 12px 8px", color: "var(--ink-muted)" }}>{uiText("Add a column, e.g. CSI Division.")}</div>}
            {conditionColumns.map((cc) => (
              <div key={cc.id} style={{ padding: "8px 12px", borderTop: "1px solid var(--ink-faint)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
                  <input name="column-name" value={cc.name} onChange={(e) => onRenameColumn(cc.id, e.target.value)} placeholder={uiText("Column name (e.g. CSI Division)")}
                    style={{ padding: "3px 6px", borderRadius: 0, border: "1px solid var(--ink-faint)", fontSize: 12, flex: 1, minWidth: 0 }} />
                  <button onClick={() => onDeleteColumn(cc.id)} title={uiText("Delete this column (whole project)")}
                    style={{ flexShrink: 0, padding: "2px 7px", borderRadius: 0, border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 12 }}>{uiText("✕ column")}</button>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                  {cc.values.map((v) => (
                    <span key={v} style={{ display: "inline-flex", alignItems: "center", gap: 3, padding: "2px 3px 2px 8px", border: "1px solid var(--ink-faint)", background: "var(--paper-bright)", fontSize: 11.5, color: "var(--ink)" }}>
                      {uiText(v)}
                      <button onClick={() => onRenameColumnValue(cc.id, v)} title={uiText("Rename this value — assigned conditions follow")}
                        style={{ padding: "0 3px", border: "none", background: "transparent", color: "var(--ink-muted)", cursor: "pointer", fontSize: 11 }}>✎</button>
                      <button onClick={() => onRemoveColumnValue(cc.id, v)} title={uiText("Remove from the list — conditions keep the value, shown as (removed)")}
                        style={{ padding: "0 3px", border: "none", background: "transparent", color: "var(--c-danger)", cursor: "pointer", fontSize: 11 }}>✕</button>
                    </span>
                  ))}
                  <AddValueInput onAdd={(v) => onAddColumnValue(cc.id, v)} />
                </div>
              </div>
            ))}
            <div style={{ padding: "6px 12px", borderTop: conditionColumns.length ? "1px solid var(--ink-faint)" : "none" }}>
              <button onClick={onAddColumn} style={btnAddFull}>{uiText("+ add column")}</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default React.memo(TakeoffsPanel);
