import { localizeText as uiText } from "../lib/i18n/core.js";
// The guided first takeoff — a small card docked over the canvas that walks a
// new user through one real takeoff: open the sample plan, set its scale, arm
// Area, trace a room, open the Report.
//
// Hands-on by design. The card never does a step for you and has no "Next"
// button: each step completes when the canvas sees you do it (the rules live in
// lib/firstTakeoff.js). It is NOT a modal — no scrim, no focus trap, no key
// capture — so every canvas shortcut it teaches (A, ⏎, scroll-zoom) works while
// it is up. The spotlight ring around the control a step names is
// pointer-events:none for the same reason.
import { useEffect, useRef, useState } from "react";
import { Z } from "../lib/ui.js";
import { ScanStar } from "../brand/marks.jsx";
import { keyText } from "../lib/keys.ts";
import { TOUR_STEPS, TOUR_CARD_W as CARD_W, TOUR_CARD_GAP, cardPlacement, stepBody } from "../lib/firstTakeoff.js";

// Outline the first VISIBLE element matching `selector`. Polled rather than
// observed: the target can move with panel docking, layout switches and the
// toolbar's own scroll, and a 250 ms poll of one getBoundingClientRect is
// cheaper than reasoning about every one of those.
function Spotlight({ selector }) {
  const [rect, setRect] = useState(null);
  useEffect(() => {
    if (!selector) { setRect(null); return; }
    const read = () => {
      // a tag on a control's inner label outlines the control itself
      const el = [...document.querySelectorAll(selector)].map((n) => n.closest("button") || n).find((n) => {
        const r = n.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });
      const r = el?.getBoundingClientRect();
      setRect((prev) => {
        if (!r) return null;
        if (prev && prev.left === r.left && prev.top === r.top && prev.width === r.width && prev.height === r.height) return prev;
        return { left: r.left, top: r.top, width: r.width, height: r.height };
      });
    };
    read();
    const id = setInterval(read, 250);
    return () => clearInterval(id);
  }, [selector]);
  if (!rect) return null;
  const pad = 4;
  return (
    <div aria-hidden="true" className="ot-tour-spotlight" style={{
      position: "fixed", left: rect.left - pad, top: rect.top - pad, width: rect.width + pad * 2, height: rect.height + pad * 2,
      border: "2px solid var(--cobalt)", borderRadius: 6, pointerEvents: "none", zIndex: Z.toast,
      boxShadow: "0 0 0 4px color-mix(in srgb, var(--cobalt) 25%, transparent)",
    }} />
  );
}

const fmtSf = (n) => `${Math.round(n).toLocaleString()} SF`;

const GAP = TOUR_CARD_GAP;

function readRail() {
  const el = document.querySelector("[data-tool-rail]");
  if (!el) return null;
  const r = el.getBoundingClientRect();
  if (!r.width || !r.height) return null;
  return { side: el.getAttribute("data-dock-side") || "left", left: r.left, right: r.right, top: r.top, bottom: r.bottom };
}

function useRailPlacement(cardRef) {
  const [place, setPlace] = useState(() => cardPlacement(null, 0));
  useEffect(() => {
    const read = () => {
      const cardLeft = cardRef.current?.getBoundingClientRect().left;
      const next = cardPlacement(readRail(), window.innerHeight, cardLeft);
      setPlace((prev) => (prev.bottom === next.bottom && prev.side === next.side ? prev : next));
    };
    read();
    const id = setInterval(read, 250);
    window.addEventListener("resize", read);
    return () => { clearInterval(id); window.removeEventListener("resize", read); };
  }, [cardRef]);
  return place;
}

export default function FirstTakeoffTour({ done, step, sheetOpen, sampleBusy, onLoadSample, onClose, onConnect, result }) {
  const doneSet = new Set(done);
  const n = TOUR_STEPS.findIndex((s) => s.id === step?.id);
  const finished = !step;
  const cardRef = useRef(null);
  const place = useRailPlacement(cardRef);
  const [cardH, setCardH] = useState(0);
  useEffect(() => {
    const el = cardRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => setCardH(Math.ceil(el.getBoundingClientRect().height)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const body = stepBody(step, place.side);
  return (
    <>
      <style>{uiText(`
        @keyframes ot-tour-pulse { 0%, 100% { opacity: 1 } 50% { opacity: .35 } }
        .ot-tour-spotlight { animation: ot-tour-pulse 1.4s ease-in-out infinite }
        @media (prefers-reduced-motion: reduce) { .ot-tour-spotlight { animation: none } }
        /* the card floats over the Report on the last step: give the Report room
           to scroll its last rows (the buy list) clear of it */
        .report-scroll { padding-bottom: ${cardH + place.bottom + 16}px !important }
      `)}</style>
      {!finished && <Spotlight selector={step.target} />}
      <section ref={cardRef}
        role="region" aria-label={uiText("Guided first takeoff")} aria-live="polite"
        style={{
          position: "fixed", left: `calc(var(--rail-w, 52px) + ${GAP}px)`, bottom: place.bottom,
          // in progress it sits under every menu and dialog; the done card rises
          // over the Report (z 50, which is where the last step lands you) but
          // stays under the Report's own popovers (60+)
          zIndex: finished ? Z.modal + 5 : Z.drawer + 1,
          width: `min(${CARD_W}px, calc(100vw - var(--rail-w, 52px) - ${GAP * 2}px))`,
          background: "var(--paper-bright)", color: "var(--ink)", border: "1px solid var(--ink-faint)",
          boxShadow: "var(--shadow-2)", padding: "14px 16px 14px", fontFamily: "var(--f-body)",
        }}>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10 }}>
          <span className="t-label" style={{ color: "var(--cobalt)" }}>
            {uiText(finished ? "First takeoff — done" : `First takeoff · step ${n + 1} of ${TOUR_STEPS.length}`)}
          </span>
          <button type="button" onClick={onClose} title={uiText("End the guided takeoff")} aria-label={uiText("End the guided takeoff")}
            style={{ background: "none", border: "none", color: "var(--ink-soft)", fontSize: 17, cursor: "pointer", lineHeight: 1, padding: 2 }}>×</button>
        </div>

        {finished ? (
          <div style={{ marginTop: 8 }}>
            <strong style={{ fontFamily: "var(--f-display)", fontSize: 16 }}>
              {uiText(result?.sf ? `You measured ${fmtSf(result.sf)}${result.tag ? ` of ${result.tag}` : ""}.` : "That's a takeoff.")}
            </strong>
            <p style={{ fontSize: 12.5, lineHeight: 1.55, color: "var(--ink-soft)", margin: "6px 0 12px" }}>
              {uiText("Same loop for every finish: pick a condition, trace, read the Report. Press ")}<kbd>?</kbd> {uiText("any time for the shortcuts. Next, hand the same engine to an AI agent.")}</p>
            <div style={{ display: "flex", gap: 8 }}>
              <button type="button" onClick={onConnect}
                style={{ display: "inline-flex", alignItems: "center", gap: 7, padding: "8px 13px", border: "none", background: "var(--cobalt)", color: "var(--accent-contrast)", fontWeight: 700, fontSize: 12.5, cursor: "pointer" }}>
                <ScanStar size={12} />{uiText("Connect your AI")}</button>
              <button type="button" onClick={onClose}
                style={{ padding: "8px 13px", border: "1px solid var(--ink-faint)", background: "transparent", color: "var(--ink)", fontSize: 12.5, cursor: "pointer" }}>
                {uiText("Close")}</button>
            </div>
          </div>
        ) : (
          <>
            <strong style={{ display: "block", marginTop: 6, fontFamily: "var(--f-display)", fontSize: 16 }}>{uiText(step.title)}</strong>
            <p style={{ fontSize: 12.5, lineHeight: 1.55, color: "var(--ink-soft)", margin: "5px 0 0" }}>{uiText(keyText(uiText(body)))}</p>
            {step.id === "open" && !sheetOpen && (
              <button type="button" onClick={onLoadSample} disabled={sampleBusy}
                style={{ marginTop: 11, padding: "8px 13px", border: "none", background: "var(--cobalt)", color: "var(--accent-contrast)", fontWeight: 700, fontSize: 12.5, cursor: sampleBusy ? "default" : "pointer", opacity: sampleBusy ? 0.65 : 1 }}>
                {uiText(sampleBusy ? "Loading sample…" : "Load the sample plan")}
              </button>
            )}
          </>
        )}

        <ol aria-label={uiText("Steps")} style={{ listStyle: "none", margin: "13px 0 0", padding: "10px 0 0", borderTop: "1px solid var(--ink-faint)", display: "flex", gap: 6 }}>
          {TOUR_STEPS.map((s, i) => {
            const isDone = doneSet.has(s.id);
            const isNow = s.id === step?.id;
            return (
              <li key={s.id} title={uiText(s.title)} aria-current={isNow ? "step" : undefined}
                style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4, fontSize: 10, fontFamily: "var(--f-mono)", color: isDone ? "var(--c-positive)" : isNow ? "var(--cobalt)" : "var(--ink-muted)" }}>
                <span style={{ height: 3, background: isDone ? "var(--c-positive)" : isNow ? "var(--cobalt)" : "var(--ink-faint)" }} />
                {uiText(isDone ? "✓ " : `${i + 1} `)}{uiText(s.title.split(" ").slice(-1)[0].toLowerCase())}
              </li>
            );
          })}
        </ol>
      </section>
    </>
  );
}
