// Which bytes an OCR read pairs with (#471): the canvas's document cache
// and the hash source its reads and lookups use. Pinned: a read's page and
// the hash it is stored under come from the same loaded document, so a
// file whose bytes changed under an open document (a cloud re-drop) never
// gets the old page's text stored under the new bytes' hash.
import { test } from "node:test";
import assert from "node:assert/strict";
import { createDocCache, createSheetSource, docIdleMax, readHooks, readdEffects } from "../src/lib/ocr/sheetSource.ts";
import { createPageReader, type ReadRegion } from "../src/lib/ocr/pageRead.ts";
import { createPageCache, ocrCacheKey } from "../src/lib/ocr/pageCache.ts";
import type { OcrProbe } from "../src/lib/ocr/client.ts";
import type { OcrRunResult } from "../src/lib/ocr/session.ts";

const shaHex = async (bytes: number[]) => Buffer.from(await crypto.subtle.digest("SHA-256", new Uint8Array(bytes))).toString("hex");
const tick = () => new Promise((r) => setTimeout(r, 0));

/** A page that says which bytes it came from. */
interface FakePage { from: number; getViewport(o: { scale: number }): { width: number; height: number } }

/** A store whose bytes per file can change; counts loads and hash asks. */
function fakeStore(initial: Record<string, number[]>) {
  const bytes = new Map(Object.entries(initial));
  const calls = { loads: 0, storeHash: 0, storeKnown: 0 };
  return {
    calls,
    set(file: string, b: number[]) { bytes.set(file, b); },
    load: async (file: string) => {
      calls.loads++;
      if (!bytes.has(file)) throw new Error(`no ${file}`);
      return new Uint8Array(bytes.get(file)!);
    },
    storeHash: async (file: string) => { calls.storeHash++; return shaHex(bytes.get(file)!); },
    storeKnown: async (_file: string): Promise<string | null> => { calls.storeKnown++; return null; },
  };
}

/** pdf.js's getDocument, faked: detaches the bytes the way pdf.js may, and
 * its pages are gone once destroyed. `held`: the parse waits for
 * resolve()/reject(). */
function fakeOpen(data: Uint8Array, held = false) {
  const from = data[0];
  structuredClone(data.buffer, { transfer: [data.buffer] });
  let destroyed = false;
  const doc = {
    getPage: async (n: number): Promise<FakePage> => {
      if (destroyed) throw new Error("destroyed");
      if (n > 1) throw new Error(`no page ${n}`);
      return { from, getViewport: ({ scale }) => ({ width: 100 * scale, height: 50 * scale }) };
    },
  };
  let resolve = () => {}, reject = (_e: Error) => {};
  const promise = held ? new Promise<typeof doc>((res, rej) => { resolve = () => res(doc); reject = rej; }) : Promise.resolve(doc);
  return { from, destroyed: () => destroyed, destroy() { destroyed = true; }, promise, resolve, reject };
}

interface SetupOpts { pinned?: () => Iterable<string>; maxIdle?: number; held?: (from: number) => boolean }

function setup(initial: Record<string, number[]>, hashing = true, o: SetupOpts = {}) {
  const store = fakeStore(initial);
  const remembered: Promise<string | null>[] = [];
  const opened: ReturnType<typeof fakeOpen>[] = [];
  const docs = createDocCache<FakePage>({
    load: store.load,
    open: (data) => { const t = fakeOpen(data, o.held?.(data[0]) ?? false); opened.push(t); return t; },
    hashing: () => (hashing ? (h) => { remembered.push(h); } : null),
    pinned: o.pinned,
    maxIdle: o.maxIdle,
  });
  // leases the source took and releases it made, counted
  const leases = { taken: 0, released: 0 };
  const lease = (f: string) => { leases.taken++; const r = docs.lease(f); return () => { leases.released++; r(); }; };
  const source = createSheetSource<FakePage>({ cached: docs.cached, open: docs.open, lease, storeHash: (f) => store.storeHash(f), storeKnown: (f) => store.storeKnown(f) });
  /** the first bytes of every destroyed document, in open order */
  const destroyed = () => opened.filter((d) => d.destroyed()).map((d) => d.from);
  return { store, docs, source, remembered, opened, destroyed, leases };
}

/** Files a.pdf, b.pdf, ... whose first byte is 1, 2, ... */
const files = (n: number) => Object.fromEntries(Array.from({ length: n }, (_, i) => [`${"abcdefgh"[i]}.pdf`, [i + 1]]));
const loadAll = async (t: ReturnType<typeof setup>, names: string[]) => { for (const f of names) { await t.docs.doc(f); await tick(); } };

test("the doc cache hashes the bytes it loaded before pdf.js can detach them, and loads once", async () => {
  const t = setup({ "a.pdf": [1, 2, 3] });
  const doc = await t.docs.doc("a.pdf");
  assert.equal((await doc.getPage(1)).from, 1);
  assert.equal(await t.docs.cached("a.pdf")!.hash, await shaHex([1, 2, 3]));
  assert.equal(await t.remembered[0], await shaHex([1, 2, 3]), "the store is told the same digest");
  await t.docs.doc("a.pdf");
  assert.equal(t.store.calls.loads, 1);
});

test("a load evicted before its bytes land reports no hash to the store", async () => {
  const t = setup({ "a.pdf": [1] });
  const p = t.docs.doc("a.pdf");
  t.docs.evict("a.pdf");
  await p;
  assert.equal(t.remembered.length, 0);
});

test("a failed load isn't kept and its hash is null", async () => {
  const t = setup({});
  const e = t.docs.open("missing.pdf");
  await assert.rejects(e.doc());
  // raced against a timer, so a hash that never settles fails here
  const hash = await Promise.race([e.hash, new Promise((r) => setTimeout(() => r("unsettled"), 50))]);
  assert.equal(hash, null, "a failed load's hash settles null");
  assert.equal(t.docs.has("missing.pdf"), false);
});

test("evict and clear destroy the documents' worker copies", async () => {
  const t = setup({ "a.pdf": [1], "b.pdf": [2], "c.pdf": [3] });
  await Promise.all([t.docs.doc("a.pdf"), t.docs.doc("b.pdf"), t.docs.doc("c.pdf")]);
  t.docs.evict("a.pdf");
  await tick();
  assert.deepEqual(t.opened.map((o) => o.destroyed()), [true, false, false]);
  t.docs.clear();
  await tick();
  assert.deepEqual(t.opened.map((o) => o.destroyed()), [true, true, true]);
  assert.equal(t.docs.has("b.pdf"), false);
});

test("hash: a loaded document's own hash; the store isn't asked", async () => {
  const t = setup({ "a.pdf": [1] });
  await t.docs.doc("a.pdf");
  t.store.set("a.pdf", [2]);   // the bytes changed under the open document
  assert.equal(await t.source.hash("a.pdf"), await shaHex([1]));
  assert.deepEqual([t.store.calls.storeHash, t.store.calls.storeKnown], [0, 0]);
});

test("hash: no document loaded, a hash the store already has; nothing loads", async () => {
  const t = setup({ "a.pdf": [1] });
  t.store.storeKnown = async () => "d".repeat(64);
  assert.equal(await t.source.hash("a.pdf"), "d".repeat(64));
  assert.equal(t.store.calls.loads, 0);
});

test("hash with known: no document and nothing known is null, and nothing loads", async () => {
  const t = setup({ "a.pdf": [1] });
  assert.equal(await t.source.hash("a.pdf", { known: true }), null);
  assert.equal(t.store.calls.loads, 0);
});

test("hash: nothing loaded or known loads the document once and takes its hash", async () => {
  const t = setup({ "a.pdf": [7] });
  assert.equal(await t.source.hash("a.pdf"), await shaHex([7]));
  await t.source.page("a.pdf", 1);
  assert.equal(t.store.calls.loads, 1);
  assert.equal(t.store.calls.storeHash, 0);
});

test("hash() keeps the document it loads until its hash settles", async () => {
  // a store that doesn't hash here: the hash is the store's, held back
  const t = setup(files(1), false, { maxIdle: 0 });
  let settle!: (h: string) => void;
  t.store.storeHash = () => new Promise((r) => { settle = r; });
  const h = t.source.hash("a.pdf");
  for (let i = 0; i < 5; i++) await tick();
  assert.equal(t.docs.loaded("a.pdf"), true, "parsed, so a trim could take it");
  assert.deepEqual(t.destroyed(), [], "held while its hash is pending");
  settle("d".repeat(64));
  assert.equal(await h, "d".repeat(64));
  await tick();
  assert.deepEqual(t.destroyed(), [1], "settled, it is let go");
});

test("a hash() whose load fails still releases its lease", async () => {
  const t = setup(files(1), false, { maxIdle: 0 });
  t.store.storeHash = async () => { throw new Error("offline"); };
  await assert.rejects(t.source.hash("a.pdf"), /offline/);
  await tick();
  assert.deepEqual(t.leases, { taken: 1, released: 1 });
  assert.deepEqual(t.destroyed(), [1], "released, the idle document goes");
});

test("a store that doesn't hash here (local) keys on the store's hash", async () => {
  const t = setup({ "a.pdf": [1] }, false);
  await t.docs.doc("a.pdf");
  assert.equal(await t.source.hash("a.pdf"), await shaHex([1]));
  assert.equal(t.store.calls.storeHash, 1);
});

test("hash with known: a loaded document with no hash of its own asks what the store already has, hashing nothing", async () => {
  const t = setup({ "a.pdf": [1] }, false);
  await t.docs.doc("a.pdf");
  assert.equal(await t.source.hash("a.pdf", { known: true }), null);
  assert.deepEqual([t.store.calls.storeHash, t.store.calls.storeKnown], [0, 1]);
});

test("readHooks.release twice releases once", async () => {
  const t = setup(files(1));
  const h = readHooks(t.source, "a.pdf", 1);
  await h.getPage();
  h.release();
  h.release();
  assert.deepEqual(t.leases, { taken: 1, released: 1 });
});

test("page: the page and the hash of the document it came from", async () => {
  const t = setup({ "a.pdf": [3] });
  const { page, hash } = await t.source.page("a.pdf", 1);
  assert.equal(page.from, 3);
  assert.equal(await hash, await shaHex([3]));
});

// ── which documents stay loaded ─────────────────────────────────────────────

test("over the idle cap, the least recently used documents are destroyed", async () => {
  const t = setup(files(5), true, { maxIdle: 2 });
  await loadAll(t, ["a.pdf", "b.pdf", "c.pdf", "d.pdf", "e.pdf"]);
  await tick();
  assert.deepEqual(t.destroyed(), [1, 2, 3]);
  assert.deepEqual(["a.pdf", "b.pdf", "c.pdf", "d.pdf", "e.pdf"].map((f) => t.docs.has(f)), [false, false, false, true, true]);
});

test("a pinned document is never trimmed; the pins are asked afresh on every trim", async () => {
  const pins = new Set(["a.pdf"]);
  const t = setup(files(3), true, { maxIdle: 1, pinned: () => pins });
  await loadAll(t, ["a.pdf", "b.pdf", "c.pdf"]);
  await tick();
  assert.deepEqual(t.destroyed(), [2], "a stays pinned; b, unpinned and older than c, goes");
  pins.clear();
  t.docs.trim();
  await tick();
  assert.deepEqual(t.destroyed(), [1, 2], "unpinned, a goes next");
  assert.equal(t.docs.has("c.pdf"), true);
});

test("asking for a document makes it the most recent; looking at its cache entry doesn't", async () => {
  const t = setup(files(3), true, { maxIdle: 2 });
  await loadAll(t, ["a.pdf", "b.pdf"]);
  await t.docs.doc("a.pdf");
  await loadAll(t, ["c.pdf"]);
  await tick();
  assert.deepEqual(t.destroyed(), [2], "b, not a, is the victim");

  const u = setup(files(3), true, { maxIdle: 2 });
  await loadAll(u, ["a.pdf", "b.pdf"]);
  u.docs.cached("a.pdf");
  await loadAll(u, ["c.pdf"]);
  await tick();
  assert.deepEqual(u.destroyed(), [1], "cached left a the oldest");
});

test("a document still parsing is never trimmed", async () => {
  const t = setup(files(3), true, { maxIdle: 1, held: (from) => from === 1 });
  const pending = t.docs.doc("a.pdf");
  await tick();
  await loadAll(t, ["b.pdf", "c.pdf"]);
  await tick();
  assert.deepEqual(t.destroyed(), [2], "b goes; a, still parsing, stays");
  assert.equal(t.docs.has("a.pdf"), true);
  t.opened[0].resolve();
  await pending;
});

test("a document pdf.js can't parse is destroyed and dropped", async () => {
  const t = setup(files(1), true, { held: () => true });
  const p = t.docs.doc("a.pdf");
  await tick();
  t.opened[0].reject(new Error("bad pdf"));
  await assert.rejects(p, /bad pdf/);
  await tick();
  assert.equal(t.docs.has("a.pdf"), false);
  assert.deepEqual(t.destroyed(), [1]);
});

test("a document in use inside withDoc outlives siblings past the cap; released, it goes", async () => {
  const t = setup(files(4), true, { maxIdle: 1 });
  const page = await t.docs.withDoc("a.pdf", async (doc) => {
    await loadAll(t, ["b.pdf", "c.pdf", "d.pdf"]);
    await tick();
    assert.deepEqual(t.destroyed(), [2, 3], "the idle siblings past the cap go");
    return doc.getPage(1);
  });
  assert.equal(page.from, 1);
  await tick();
  assert.deepEqual(t.destroyed(), [1, 2, 3], "released, a is older than d");
});

test("releasing a lease twice is a no-op: a second lease still holds the document", async () => {
  const t = setup(files(2), true, { maxIdle: 0 });
  const r1 = t.docs.lease("a.pdf"), r2 = t.docs.lease("a.pdf");
  await t.docs.doc("a.pdf");
  await loadAll(t, ["b.pdf"]);
  r1();
  r1();
  await tick();
  assert.deepEqual(t.destroyed(), [2], "idle b goes; a is still leased");
  r2();
  await tick();
  assert.deepEqual(t.destroyed(), [1, 2]);
});

test("a lease taken before a forced evict doesn't release the re-added document", async () => {
  const t = setup(files(2), true, { maxIdle: 0 });
  const old = t.docs.lease("a.pdf");
  await t.docs.doc("a.pdf");
  t.docs.evict("a.pdf");
  const now = t.docs.lease("a.pdf");
  await t.docs.doc("a.pdf");
  await loadAll(t, ["b.pdf"]);
  old();
  await tick();
  assert.deepEqual(t.destroyed(), [1, 2], "the evicted a and idle b go; the new a is still leased");
  assert.equal(t.docs.has("a.pdf"), true);
  now();
  await tick();
  assert.equal(t.docs.has("a.pdf"), false);
});

test("withLoadedDoc runs only on a document already loaded, never loading one", async () => {
  const t = setup(files(3), true, { maxIdle: 1 });
  let ran = false;
  assert.equal(await t.docs.withLoadedDoc("a.pdf", () => { ran = true; }), undefined);
  assert.equal(ran, false);
  assert.equal(t.store.calls.loads, 0);
  await loadAll(t, ["a.pdf"]);
  const page = await t.docs.withLoadedDoc("a.pdf", async (doc) => {
    await loadAll(t, ["b.pdf", "c.pdf"]);
    await tick();
    assert.deepEqual(t.destroyed(), [2], "idle b goes; a is leased");
    return doc.getPage(1);
  });
  assert.equal(page!.from, 1);
});

test("a touched document becomes the last one trimmed", async () => {
  const pins = new Set(["a.pdf"]);
  const t = setup(files(3), true, { maxIdle: 2, pinned: () => pins });
  await loadAll(t, ["a.pdf", "b.pdf", "c.pdf"]);
  pins.clear();       // a's tab just closed
  t.docs.touch(["a.pdf"]);
  t.docs.trim();
  await tick();
  assert.deepEqual(t.destroyed(), [2], "b goes, not the a just unpinned");
  assert.equal(t.docs.has("a.pdf"), true);
});

test("withDoc releases its lease when fn throws, and rethrows", async () => {
  const t = setup(files(1), true, { maxIdle: 0 });
  await assert.rejects(t.docs.withDoc("a.pdf", () => { throw new Error("boom"); }), /boom/);
  await tick();
  assert.deepEqual(t.destroyed(), [1]);
});

test("wasLoaded outlives a trim; a forced evict or clear forgets it", async () => {
  const t = setup(files(3), true, { maxIdle: 0 });
  await loadAll(t, ["a.pdf"]);
  assert.equal(t.docs.has("a.pdf"), false, "trimmed");
  assert.equal(t.docs.wasLoaded("a.pdf"), true, "a cloud re-add must still reset it");
  const b = t.docs.lease("b.pdf");
  await t.docs.doc("b.pdf");
  t.docs.evict("b.pdf");
  b();
  assert.equal(t.docs.wasLoaded("b.pdf"), false);
  const c = t.docs.lease("c.pdf");
  await t.docs.doc("c.pdf");
  t.docs.clear();
  c();
  assert.deepEqual(["a.pdf", "c.pdf"].map((f) => t.docs.wasLoaded(f)), [false, false]);
});

test("the idle-document budget is finite on both device tiers, smaller on low memory", () => {
  assert.equal(docIdleMax(true), 2);
  assert.equal(docIdleMax(false), 4);
});

test("page: a page that fails to open releases its lease", async () => {
  const t = setup(files(2), true, { maxIdle: 0 });
  const ok = await t.source.page("a.pdf", 1);
  await assert.rejects(t.source.page("a.pdf", 2), /no page 2/);
  await loadAll(t, ["b.pdf"]);
  await tick();
  assert.deepEqual(t.destroyed(), [2], "idle b goes; the first page's lease still holds a");
  ok.release();
  await tick();
  assert.deepEqual(t.destroyed(), [1, 2], "the failed page's lease didn't");
});

test("withLoadedDoc skips a document still parsing, without waiting for it", async () => {
  const t = setup(files(1), true, { held: () => true });
  const pending = t.docs.doc("a.pdf");
  await tick();
  let ran = false;
  // raced against a timer, so one that waits for the parse fails here
  const out = await Promise.race([t.docs.withLoadedDoc("a.pdf", () => { ran = true; }), tick().then(() => "waited")]);
  assert.equal(out, undefined);
  assert.equal(ran, false);
  assert.equal(t.store.calls.loads, 1);
  t.opened[0].resolve();
  await pending;
});

// ── through the page reader: what the cache stores ──────────────────────────

const available: OcrProbe = { state: "available", manifest: { rev: "r1", files: [] }, cached: true, downloadBytes: 0 };
const session = {
  async run<T>(task: (s?: AbortSignal) => Promise<T>, o: { signal?: AbortSignal } = {}): Promise<OcrRunResult<T>> {
    try { return { ok: true, value: await task(o.signal) }; } catch (error) { return { ok: false, reason: "failed", error }; }
  },
  availability: async () => available,
};
/** Reads one line naming the bytes the page came from. */
const readRegion: ReadRegion = async (pg) => ({ lines: [{ str: `BYTES ${(pg as unknown as FakePage).from}`, x: 1, y: 20, w: 50, h: 10 }], ms: 1, rasters: 1 });

function readerOver(t: ReturnType<typeof setup>, meta = new Map<string, { lines: { str: string }[] }>()) {
  const puts: string[] = [];
  const cache = createPageCache({ metaGet: async (k) => meta.get(k), metaPut: async (k, v) => { puts.push(k); meta.set(k, v as { lines: { str: string }[] }); } });
  const reader = createPageReader({ session, cache, readRegion, onLines: () => {} });
  // the canvas's readSheet wiring; `hooked` also hands back the hooks
  const hooked = (file: string) => {
    const h = readHooks(t.source, file, 1);
    return { hooks: h, done: reader.read({ key: file, file, page: 1, rs: 1, pdfHash: h.pdfHash, getPage: h.getPage, pageHash: h.pageHash }) };
  };
  const read = (file: string) => hooked(file).done;
  return { reader, read, hooked, puts, meta };
}

test("a re-added file's read never pairs the open document's page with the new bytes' hash", async () => {
  const t = setup({ "a.pdf": [1] });
  await t.docs.doc("a.pdf");                    // the canvas has the old bytes open
  t.store.set("a.pdf", [2]);                    // a cloud re-drop replaced them
  t.store.storeKnown = async () => shaHex([2]); // and the store already knows the new hash
  const r = readerOver(t);
  const out = await r.read("a.pdf");
  assert.equal(out.ok && out.lines[0].str, "BYTES 1");
  const oldKey = ocrCacheKey(await shaHex([1]), 1), newKey = ocrCacheKey(await shaHex([2]), 1);
  assert.deepEqual(r.puts, [oldKey], "the old page's text goes under the old bytes' hash");
  assert.equal(r.meta.has(newKey), false);
  // the stale document goes (evictDoc): the next read is of the new bytes
  t.docs.evict("a.pdf");
  r.reader.dropFile("a.pdf");
  const again = await r.read("a.pdf");
  assert.equal(again.ok && again.lines[0].str, "BYTES 2");
  assert.deepEqual(r.puts, [oldKey, newKey]);
  assert.equal(r.meta.get(newKey)!.lines[0].str, "BYTES 2");
});

test("a document replaced between the lookup and the page: stored under the page's document", async () => {
  const t = setup({ "a.pdf": [1] });
  await t.docs.doc("a.pdf");
  // the cache lookup (under the old document's hash) waits until the file
  // has been re-added and its old document evicted
  let release!: () => void;
  const gate = new Promise<void>((r) => { release = r; });
  const puts: string[] = [];
  const cache = createPageCache({
    metaGet: async () => { await gate; return undefined; },
    metaPut: async (k) => { puts.push(k); },
  });
  const reader = createPageReader({ session, cache, readRegion, onLines: () => {} });
  const h = readHooks(t.source, "a.pdf", 1);
  const p = reader.read({ key: "a.pdf", file: "a.pdf", page: 1, rs: 1, pdfHash: h.pdfHash, getPage: h.getPage, pageHash: h.pageHash });
  await tick();
  t.docs.evict("a.pdf");
  t.store.set("a.pdf", [2]);
  release();
  const out = await p;
  assert.equal(out.ok && out.lines[0].str, "BYTES 2", "the page came from the new document");
  assert.deepEqual(puts, [ocrCacheKey(await shaHex([2]), 1)], "so its read goes under the new bytes' hash");
});

test("a read answered from the cache takes no lease and loads nothing", async () => {
  const seed = readerOver(setup({ "a.pdf": [1] }));
  await seed.read("a.pdf");
  assert.equal(seed.meta.has(ocrCacheKey(await shaHex([1]), 1)), true, "seeded");
  const t = setup({ "a.pdf": [1] });
  t.store.storeKnown = async () => shaHex([1]);
  const { hooks, done } = readerOver(t, seed.meta).hooked("a.pdf");
  const out = await done;
  assert.equal(out.ok && out.cached, true);
  hooks.release();
  assert.equal(t.store.calls.loads, 0);
});

test("a read that opens its page holds the document until released", async () => {
  const t = setup(files(3), true, { maxIdle: 1 });
  await loadAll(t, ["c.pdf"]);
  const { hooks, done } = readerOver(t).hooked("a.pdf");
  assert.equal((await done).ok, true);
  await loadAll(t, ["b.pdf"]);
  await tick();
  assert.deepEqual(t.destroyed(), [3], "idle c goes; a, read, is still held");
  hooks.release();
  await tick();
  assert.deepEqual(t.destroyed(), [3, 1], "released, a is older than b");
});

// ── what re-adding files resets ──────────────────────────────────────────────

test("re-adding: identical local bytes keep everything; a revision or a fresh add resets", () => {
  const loaded = () => true;
  assert.deepEqual(readdEffects([{ name: "same.pdf", unchanged: true }], { cloud: false, loaded }), { reset: [], evict: [] });
  assert.deepEqual(readdEffects([{ name: "rev.pdf", revised: true }], { cloud: false, loaded }), { reset: ["rev.pdf"], evict: ["rev.pdf"] });
  assert.deepEqual(readdEffects([{ name: "new.pdf" }], { cloud: false, loaded: () => false }), { reset: ["new.pdf"], evict: [] });
});

test("re-adding in the cloud: every name resets, and one with a loaded document is evicted", () => {
  const loaded = (n: string) => n === "open.pdf";
  assert.deepEqual(
    readdEffects([{ name: "open.pdf" }, { name: "closed.pdf" }], { cloud: true, loaded }),
    { reset: ["open.pdf", "closed.pdf"], evict: ["open.pdf"] },
  );
});

test("loaded: only once the document has finished loading, and not after it's gone", async () => {
  const t = setup({ "a.pdf": [1], "b.pdf": [2] });
  let open!: () => void;
  const held = new Promise<void>((r) => { open = r; });
  const docs = createDocCache<FakePage>({
    load: t.store.load,
    open: (data) => { const f = fakeOpen(data); return { ...f, promise: held.then(() => f.promise) }; },
    hashing: () => null,
  });
  docs.doc("a.pdf");
  await tick();
  assert.equal(docs.has("a.pdf"), true, "a's load has started");
  assert.equal(docs.loaded("a.pdf"), false, "but its document isn't in yet");
  open();
  await docs.doc("a.pdf");
  assert.equal(docs.loaded("a.pdf"), true);
  assert.equal(docs.loaded("b.pdf"), false, "never asked for");
  docs.evict("a.pdf");
  assert.equal(docs.loaded("a.pdf"), false);
});

