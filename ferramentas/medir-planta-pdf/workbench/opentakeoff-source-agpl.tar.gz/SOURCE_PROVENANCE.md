# OpenTakeoff corresponding source provenance

- Upstream: `https://github.com/Kentucky-ai/opentakeoff.git`
- Pinned commit: `5570658f4312cb006c25b471ce5da2cd9d6e9b4e`
- Upstream commit date: `2026-11-23T07:21:12-05:00`
- License: `AGPL-3.0-only` (see `LICENSE`)
- Dependency lock: `web/package-lock.json`
- CONFENGE runtime recipe: `web/CONFENGE_RUNTIME.md`
- CONFENGE base adaptations: `web/CONFENGE_RUNTIME.patch`
- CodeQL #898 remediation: `CONFENGE_CODEQL_898.patch`

The CodeQL patch replaces only the entropy source used by Three.js UUID v4
generation. The byte layout and string serialization remain unchanged. The
included repack script applies the equivalent exact replacement to the staged
PR #898 bundle without renaming the public asset.
