Complemento da distribuição CONFENGE

Use CONFENGE-OFFLINE-BUILD.md do código-fonte Chili3D para criar a distribuição.
Execute confenge/chili/normalize-runtime-css.mjs passando o diretório público compilado.
A normalização usa Node 24 e PostCSS 8, resolvido por AEC_CHILI_POSTCSS_PACKAGE.
Copie index.html e app-shell.mjs de confenge/web-cfg/ para o diretório compilado.
O index institucional vincula 367.css estaticamente antes do bundle para que a folha base do editor
esteja pronta no primeiro layout, inclusive sob auditoria concorrente e em redes lentas.
O site mantém o CSS global em https://github.com/tjsasakifln/web-cfg.
