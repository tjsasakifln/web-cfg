// Part of the Chili3d Project, under the LGPL-3.0 License.
// See LICENSE-chili-wasm.text file in the project root for full license information.

#include <emscripten/bind.h>
#include <emscripten/val.h>

#include "shared.hpp"
#include "utils.hpp"
#include <BOPAlgo_Builder.hxx>
#include <BOPAlgo_BuilderFace.hxx>
#include <BOPAlgo_GlueEnum.hxx>
#include <BOPAlgo_Splitter.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepAlgoAPI_BooleanOperation.hxx>
#include <BRepAlgoAPI_Common.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepAlgoAPI_Defeaturing.hxx>
#include <BRepAlgoAPI_Fuse.hxx>
#include <BRepBndLib.hxx>
#include <BRepBuilderAPI_Copy.hxx>
#include <BRepBuilderAPI_GTransform.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepBuilderAPI_MakePolygon.hxx>
#include <BRepBuilderAPI_MakeShape.hxx>
#include <BRepBuilderAPI_MakeSolid.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepBuilderAPI_MakeWire.hxx>
#include <BRepBuilderAPI_Sewing.hxx>
#include <BRepBuilderAPI_Transform.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepExtrema_DistShapeShape.hxx>
#include <BRepFeat_MakePrism.hxx>
#include <BRepFilletAPI_MakeChamfer.hxx>
#include <BRepFilletAPI_MakeFillet.hxx>
#include <BRepGProp.hxx>
#include <BRepLProp_SLProps.hxx>
#include <BRepLib.hxx>
#include <BRepLib_MakeFace.hxx>
#include <BRepOffsetAPI_DraftAngle.hxx>
#include <BRepOffsetAPI_MakePipe.hxx>
#include <BRepOffsetAPI_MakePipeShell.hxx>
#include <BRepOffsetAPI_MakeThickSolid.hxx>
#include <BRepOffsetAPI_ThruSections.hxx>
#include <BRepOffset_MakeOffset.hxx>
#include <BRepOffset_Mode.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <BRepPrimAPI_MakeCone.hxx>
#include <BRepPrimAPI_MakeCylinder.hxx>
#include <BRepPrimAPI_MakePrism.hxx>
#include <BRepPrimAPI_MakeRevol.hxx>
#include <BRepPrimAPI_MakeSphere.hxx>
#include <BRepPrimAPI_MakeSweep.hxx>
#include <BRepProj_Projection.hxx>
#include <BRepTools.hxx>
#include <BRepTools_History.hxx>
#include <BRepTools_ReShape.hxx>
#include <BRep_Builder.hxx>
#include <BRep_Tool.hxx>
#include <Bnd_Box.hxx>
#include <ChFi2d_Builder.hxx>
#include <ChFi2d_ChamferAPI.hxx>
#include <ChFi2d_FilletAPI.hxx>
#include <ChFi2d_FilletAlgo.hxx>
#include <ElCLib.hxx>
#include <GProp_GProps.hxx>
#include <Geom2d_Curve.hxx>
#include <GeomAPI_ExtremaCurveCurve.hxx>
#include <GeomAPI_ProjectPointOnCurve.hxx>
#include <GeomFill_Gordon.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Geom_BSplineSurface.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_Circle.hxx>
#include <Geom_ConicalSurface.hxx>
#include <Geom_CylindricalSurface.hxx>
#include <Geom_Ellipse.hxx>
#include <Geom_Hyperbola.hxx>
#include <Geom_Line.hxx>
#include <Geom_OffsetCurve.hxx>
#include <Geom_Parabola.hxx>
#include <Geom_RectangularTrimmedSurface.hxx>
#include <Geom_SphericalSurface.hxx>
#include <Geom_Surface.hxx>
#include <Geom_ToroidalSurface.hxx>
#include <Geom_TrimmedCurve.hxx>
#include <HelixBRep_BuilderHelix.hxx>
#include <NCollection_Array1.hxx>
#include <NCollection_DataMap.hxx>
#include <NCollection_IndexedDataMap.hxx>
#include <NCollection_IndexedMap.hxx>
#include <NCollection_List.hxx>
#include <NCollection_Map.hxx>
#include <Precision.hxx>
#include <ShapeAnalysis_Edge.hxx>
#include <ShapeFix_Face.hxx>
#include <ShapeFix_FixSmallFace.hxx>
#include <ShapeFix_Shape.hxx>
#include <ShapeFix_ShapeTolerance.hxx>
#include <ShapeFix_Solid.hxx>
#include <ShapeFix_Wire.hxx>
#include <ShapeUpgrade_ShapeDivideClosed.hxx>
#include <ShapeUpgrade_UnifySameDomain.hxx>
#include <Standard_Failure.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopTools_ShapeMapHasher.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Iterator.hxx>
#include <TopoDS_Shape.hxx>
#include <algorithm>
#include <cmath>
#include <deque>
#include <gp_Ax2.hxx>
#include <gp_Circ.hxx>
#include <memory>
#include <set>

using namespace emscripten;

struct ShapeResult {
    TopoDS_Shape shape;
    bool isOk;
    std::string error;
};

struct RemoveFilletResult {
    TopoDS_Shape shape;
    bool isOk;
    std::string error;
    ShapeArray newEdges;
};

struct ShapesResult {
    ShapeArray shapes;
    bool isOk;
    std::string error;
};

// Minimal bounded regions with per-region source identity: region k is bounded by
// segments of the input edges sourceIds[sum(counts<k) .. +counts[k]] (sorted, unique).
struct RegionsResult {
    ShapeArray faces;
    std::vector<int> sourceCounts;
    std::vector<int> sourceIds;
    bool isOk;
    std::string error;
};

struct TrackedShapeResult {
    TopoDS_Shape shape;
    bool isOk;
    std::string error;
    // Every (output, input) derivation as flat pairs (out0, in0, out1, in1, ...), in
    // ascending input order (identity first for each input). This is the WHOLE relation:
    // a caller wanting "the first ancestor" per output derives it, rather than the kernel
    // dropping the rest here — so a sub-shape MERGED from several inputs records each of
    // them whichever operation merged it. A sub-shape nothing derives from has no pair.
    std::vector<int> faceAncestors;
    std::vector<int> edgeAncestors;
    // output face index -> input edge index for faces Generated from an input edge
    // (a sweep's side faces), -1 = not edge-generated
    std::vector<int> faceEdgeMap = {};
    // Output face indexes of a sweep's end cap —
    // BRepPrimAPI's LastShape(): a prism's top face, a PARTIAL revolve's end cap. A
    // separate channel on purpose: the cap must not go through the derivation
    // (it would claim the profile face's index and collide with the identical
    // bottom/start face). Empty for non-sweeps and for a full 360° revolve, where the
    // first and last shapes coincide and there is no distinct cap.
    // A solid LOFT reports BOTH caps instead, in [start, end] section order (a vertex
    // end has no cap): loft inputs are wires/vertices, so no derivation channel can
    // name a cap, and the two ends never coincide.
    std::vector<int> capFaces = {};
    // Output sub-shape index -> input sub-shape index of the PARALLEL COPY a thicken
    // offsets it into (its "offset surface" / the rim it carries at that distance),
    // -1 = not an offset image. A separate channel on purpose: the derivation pair
    // set reports the input face as its own descendant AND the parallel copy off it,
    // so a caller reading only the pairs would stamp one id on two distinct faces
    // (measured: a box top thickened by -2 yields 6 faces — the kept top, 4 rim
    // bands, and the copy at z = 28 — with the copy reported from the same input
    // face). The offset image has to be told apart from the kept one, and only the
    // kernel can do that.
    std::vector<int> offsetFaceMap = {};
    std::vector<int> offsetEdgeMap = {};
    // Why an offset of faces failed, when it did: [status, valueMilli]. Empty on success
    // (and for every op that is not an offset). A separate channel on purpose — the
    // failure has to say WHICH kind of failure it was, and for the common one ("too far")
    // how far the body would have taken, which OCCT only gives by bisecting. The generic
    // `error` string cannot carry that: the caller words the message, per locale.
    // status: 1 too far (valueMilli = the largest distance that works, ×1000),
    // 2 no distance works (valueMilli = the smallest distance known to fail — the probe the
    // answer rests on; 0 when the request was too small to probe), 3 not a solid,
    // 4 a sealed void inside, 5 an OCCT failure,
    // 6 rounded edges meet at a sharp corner inside one smooth chain, 7 the rounds beside a
    // moving face cannot be kept (only on a `requireRounds` call, and only when the move itself
    // would have worked — a distance the plain path also refuses keeps its own status).
    std::vector<int> offsetReport = {};
};

// Appends every output sub-shape identical to or derived (Modified/Generated — guarded,
// some algorithms only implement Generated) from `inShape`, as an (output, input) pair.
//
// Templated on the builder because not every OCCT algorithm that reports a history derives
// from BRepBuilderAPI_MakeShape: BRepOffset_MakeOffset (8.0) declares Modified/Generated/
// IsDeleted on its own, and the divided offset composes its history by hand. All three shapes
// of the interface are what the body below needs.
template <typename Builder>
static void mapInputShape(Builder& algo, const TopoDS_Shape& inShape, int inIndex,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& outMap, std::vector<int>& ancestors)
{
    auto markDerived = [&](const NCollection_List<TopoDS_Shape>& derived) {
        for (const TopoDS_Shape& shape : derived) {
            int outIndex = outMap.FindIndex(shape);
            if (outIndex > 0) {
                ancestors.push_back(outIndex - 1);
                ancestors.push_back(inIndex);
            }
        }
    };
    int identical = outMap.FindIndex(inShape);
    if (identical > 0) {
        ancestors.push_back(identical - 1);
        ancestors.push_back(inIndex);
    }
    try {
        markDerived(algo.Modified(inShape));
    } catch (const Standard_Failure&) {
    }
    try {
        markDerived(algo.Generated(inShape));
    } catch (const Standard_Failure&) {
    }
}

// Every (output, input) derivation of `type` between `input` and `output`, as flat pairs in
// ascending input order (identity first — some algorithms keep input shapes as-is, e.g. the
// prism bottom face). A sub-shape no input derives does not appear.
template <typename Builder>
static std::vector<int> shapeHistory(Builder& algo, const TopoDS_Shape& input,
    const TopoDS_Shape& output, TopAbs_ShapeEnum type)
{
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> inMap;
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> outMap;
    TopExp::MapShapes(input, type, inMap);
    TopExp::MapShapes(output, type, outMap);
    std::vector<int> ancestors;
    for (int i = 1; i <= inMap.Extent(); i++) {
        mapInputShape(algo, inMap.FindKey(i), i - 1, outMap, ancestors);
    }
    return ancestors;
}

template <typename Builder>
static std::vector<int> faceHistory(Builder& algo, const TopoDS_Shape& input, const TopoDS_Shape& output)
{
    return shapeHistory(algo, input, output, TopAbs_FACE);
}

template <typename Builder>
static std::vector<int> edgeHistory(Builder& algo, const TopoDS_Shape& input, const TopoDS_Shape& output)
{
    return shapeHistory(algo, input, output, TopAbs_EDGE);
}

// Maps each output face Generated from an input edge (a prism/revol side face) to that
// edge's input index, so the caller can seed the side face with the edge's stable id —
// face enumeration order is not stable across rebuilds, the generating edge is.
// Faces without an edge origin keep -1.
static std::vector<int> faceFromEdgeHistory(BRepBuilderAPI_MakeShape& algo, const TopoDS_Shape& input,
    const TopoDS_Shape& output)
{
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> inEdges;
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> outFaces;
    TopExp::MapShapes(input, TopAbs_EDGE, inEdges);
    TopExp::MapShapes(output, TopAbs_FACE, outFaces);
    std::vector<int> map(outFaces.Extent(), -1);
    for (int i = 1; i <= inEdges.Extent(); i++) {
        try {
            for (const TopoDS_Shape& generated : algo.Generated(inEdges.FindKey(i))) {
                int outIndex = outFaces.FindIndex(generated);
                if (outIndex > 0 && map[outIndex - 1] < 0) {
                    map[outIndex - 1] = i - 1;
                }
            }
        } catch (const Standard_Failure&) {
        }
    }
    return map;
}

// The output sub-shape a thicken OFFSETS each input sub-shape into — its parallel copy at
// the thickness distance, -1 where the input has no copy.
//
// Deliberately NOT the derivation channel (see `TrackedShapeResult::offsetFaceMap`): a
// thicken reports EVERY input face as derived from itself AND reports the parallel copy off
// it, so `shapeHistory` folds the kept wall and the copy into one ancestor list (measured:
// a box top thickened by -2 gives in0->[0,2] — the kept top at z=30 and its copy at z=28 —
// and the same for every input EDGE, in0->[0,7]). The copy is told apart by subtracting the
// identity hit, which is the only member of that list that IS the input.
//
// `removed` (optional) is the input sub-shapes that do NOT survive in `output` — a shell's
// closing faces, which the join deletes. A REMOVED face has no parallel copy, so the
// identity hit that would have filtered its report is gone too, and the RIM the offset
// raises around the opening comes back as if it were the copy (measured: a 40x40x20 box with
// the top open and thickness -2 gives out5<-in5, where out5 is the 40^2-36^2 border band).
// Skipping it here is what keeps the channel's contract — "the parallel copy" — true; only
// the kernel knows which faces were the closing set, so a caller-side filter would leave
// every future reader of this map to rediscover the lie. Nothing is lost by skipping: these
// pairs are a subset of `shapeHistory`'s, because both walks read the same Modified/
// Generated lists and this one only ever subtracts from them (the identity skip below), so
// the rim is still claimed from the derivation channel.
static std::vector<int> offsetHistory(BRepBuilderAPI_MakeShape& algo, const TopoDS_Shape& input,
    const TopoDS_Shape& output, TopAbs_ShapeEnum type,
    const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>* removed = nullptr)
{
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> inMap;
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> outMap;
    TopExp::MapShapes(input, type, inMap);
    TopExp::MapShapes(output, type, outMap);
    std::vector<int> map(outMap.Extent(), -1);
    for (int i = 1; i <= inMap.Extent(); i++) {
        const TopoDS_Shape& inShape = inMap.FindKey(i);
        if (removed != nullptr && removed->Contains(inShape)) {
            continue;
        }
        auto mark = [&](const NCollection_List<TopoDS_Shape>& derived) {
            for (const TopoDS_Shape& shape : derived) {
                if (shape.IsSame(inShape)) {
                    continue;
                }
                int outIndex = outMap.FindIndex(shape);
                if (outIndex > 0 && map[outIndex - 1] < 0) {
                    map[outIndex - 1] = i - 1;
                }
            }
        };
        try {
            mark(algo.Modified(inShape));
        } catch (const Standard_Failure&) {
        }
        try {
            mark(algo.Generated(inShape));
        } catch (const Standard_Failure&) {
        }
    }
    return map;
}

// Face indexes (MapShapes order on `output`, matching the history maps) of a sweep's
// end shape — BRepPrimAPI's LastShape(): a prism's top face, a partial revolve's end
// cap. Empty when the sweep has no distinct end shape: a null LastShape (degenerate
// input) or a full 360° revolve, whose first and last shapes coincide (LastShape
// returns the start shape there, so the IsSame check filters it out). Faces of the
// end shape that are not in the output are skipped.
static std::vector<int> sweepCapFaces(BRepPrimAPI_MakeSweep& sweep, const TopoDS_Shape& output)
{
    std::vector<int> capFaces;
    const TopoDS_Shape lastShape = sweep.LastShape();
    if (lastShape.IsNull() || lastShape.IsSame(sweep.FirstShape())) {
        return capFaces;
    }
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> outFaces;
    TopExp::MapShapes(output, TopAbs_FACE, outFaces);
    for (TopExp_Explorer explorer(lastShape, TopAbs_FACE); explorer.More(); explorer.Next()) {
        int outIndex = outFaces.FindIndex(explorer.Current());
        if (outIndex > 0) {
            capFaces.push_back(outIndex - 1);
        }
    }
    return capFaces;
}

// Face indexes (MapShapes order on `output`, matching the history maps) of a loft's
// START and END caps — the faces BRepOffsetAPI_ThruSections builds from the first/last
// wire sections when isSolid. Both ends are reported (unlike a sweep's single
// LastShape cap): loft inputs are wires/vertices, so the derivation channels can never
// name a cap. Vertex end sections have no cap. A cap face is detected either through
// the builder's Generated(section wire) or by identity: ThruSections builds its caps
// from the section wires as-is, so the cap is the face whose ENTIRE edge set is shared
// with the section's (IsSame) — a side face shares only its one generating edge, which
// is why a subset test would misfire on single-edge sections (a circle cap and the
// cylindrical side face share that one edge, but the side face also has the next
// section's edge).
static std::vector<int> loftCapFaces(BRepOffsetAPI_ThruSections& builder, const std::vector<TopoDS_Shape>& sections,
    const TopoDS_Shape& output)
{
    std::vector<int> caps;
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> outFaces;
    TopExp::MapShapes(output, TopAbs_FACE, outFaces);

    auto collectCap = [&](const TopoDS_Shape& section) {
        if (section.ShapeType() != TopAbs_WIRE) {
            return;
        }
        try {
            for (const TopoDS_Shape& generated : builder.Generated(section)) {
                int outIndex = outFaces.FindIndex(generated);
                if (outIndex > 0 && generated.ShapeType() == TopAbs_FACE) {
                    caps.push_back(outIndex - 1);
                }
            }
        } catch (const Standard_Failure&) {
        }
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> sectionEdges;
        TopExp::MapShapes(section, TopAbs_EDGE, sectionEdges);
        for (int i = 1; i <= outFaces.Extent(); i++) {
            NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> faceEdges;
            TopExp::MapShapes(outFaces.FindKey(i), TopAbs_EDGE, faceEdges);
            bool allShared = faceEdges.Extent() > 0;
            for (int e = 1; e <= faceEdges.Extent() && allShared; e++) {
                allShared = sectionEdges.Contains(faceEdges.FindKey(e));
            }
            if (allShared) {
                caps.push_back(i - 1);
            }
        }
    };
    collectCap(sections.front());
    collectCap(sections.back());
    // Keep [start caps, end caps] order — the caller seeds them with the first/last
    // section's identity; dedup only repeats (both channels hitting the same face).
    std::vector<int> unique;
    for (int index : caps) {
        if (std::find(unique.begin(), unique.end(), index) == unique.end()) {
            unique.push_back(index);
        }
    }
    return unique;
}

// Compute the plane formed by two edges at their shared vertex from their tangent vectors.
static std::optional<gp_Dir> computeNormal(const TopoDS_Edge& edge1, const TopoDS_Edge& edge2, const TopoDS_Vertex& vertex)
{
    double p1 = BRep_Tool::Parameter(vertex, edge1);
    double p2 = BRep_Tool::Parameter(vertex, edge2);

    double cf, cl;
    Handle(Geom_Curve) curve1 = BRep_Tool::Curve(edge1, cf, cl);
    Handle(Geom_Curve) curve2 = BRep_Tool::Curve(edge2, cf, cl);

    gp_Pnt pt;
    gp_Vec tan1, tan2;
    curve1->D1(p1, pt, tan1);
    curve2->D1(p2, pt, tan2);

    gp_Vec normal = tan1.Crossed(tan2);
    if (normal.Magnitude() < Precision::Angular()) {
        return std::nullopt;
    }

    return gp_Dir(normal);
}

// Find the common vertex shared by two edges. Returns null if none.
static TopoDS_Vertex findCommonVertex(const TopoDS_Edge& edge1, const TopoDS_Edge& edge2)
{
    TopExp_Explorer v1(edge1, TopAbs_VERTEX);
    for (; v1.More(); v1.Next()) {
        auto vertex1 = v1.Current();
        TopExp_Explorer v2(edge2, TopAbs_VERTEX);
        for (; v2.More(); v2.Next()) {
            if (vertex1.IsSame(v2.Current())) {
                return TopoDS::Vertex(vertex1);
            }
        }
    }
    return TopoDS_Vertex();
}

// Build a JS array [edge1, edge2, edge3] from three edges.
static val buildEdgeTriple(const TopoDS_Edge& a, const TopoDS_Edge& b, const TopoDS_Edge& c)
{
    val edges = val::array();
    edges.call<void>("push", a);
    edges.call<void>("push", b);
    edges.call<void>("push", c);
    return edges;
}

// Line equivalent of a curve, unwrapping trimmed and offset curves (an offset of a line
// is the same line translated, with the same parametrization). Null when not linear.
static Handle(Geom_Line) asLine(const Handle(Geom_Curve) & curve)
{
    if (auto trimmed = Handle(Geom_TrimmedCurve)::DownCast(curve))
        return asLine(trimmed->BasisCurve());
    if (auto line = Handle(Geom_Line)::DownCast(curve))
        return line;
    if (auto offset = Handle(Geom_OffsetCurve)::DownCast(curve)) {
        if (auto basisLine = asLine(offset->BasisCurve())) {
            gp_Vec shift(basisLine->Value(0.0), offset->Value(0.0));
            return new Geom_Line(
                gp_Lin(basisLine->Lin().Location().Translated(shift), basisLine->Lin().Direction()));
        }
    }
    return nullptr;
}

// The curve underlying an edge with its parameter range, unwrapping trimmed curves. An
// offset of a line is replaced by the equivalent plain line, so that fillet/chamfer
// operate at the offset position instead of the pre-offset one.
static Handle(Geom_Curve) basisCurve(const TopoDS_Edge& edge, double& first, double& last)
{
    Handle(Geom_Curve) curve = BRep_Tool::Curve(edge, first, last);
    if (auto line = asLine(curve))
        return line;
    if (auto trimmed = Handle(Geom_TrimmedCurve)::DownCast(curve))
        curve = trimmed->BasisCurve();
    return curve;
}

// The curve kinds the kernel's B-spline conversion knows. An OffsetCurve is deliberately
// left out: GeomConvert turns it into a 1e-4 approximation, which would break Gordon's
// exact-interpolation promise, and a failed approximation raises — a raise aborts the whole
// module with exception catching disabled. Any other kind raises outright. Both are
// rejected up front instead.
static bool isGordonCurveKind(const Handle(Geom_Curve) & curve)
{
    return curve->IsKind(STANDARD_TYPE(Geom_Line)) || curve->IsKind(STANDARD_TYPE(Geom_Circle))
        || curve->IsKind(STANDARD_TYPE(Geom_Ellipse)) || curve->IsKind(STANDARD_TYPE(Geom_Hyperbola))
        || curve->IsKind(STANDARD_TYPE(Geom_Parabola)) || curve->IsKind(STANDARD_TYPE(Geom_BezierCurve))
        || curve->IsKind(STANDARD_TYPE(Geom_BSplineCurve));
}

// The curve Gordon takes for one edge: the edge's own parameter window on an atomic basis
// curve. Gordon reads FirstParameter/LastParameter off the curve it is handed, so a bare
// basis curve would make it search the whole (possibly infinite) curve. The window is
// checked against the basis before Geom_TrimmedCurve is built, because its constructor
// raises on an empty or out-of-range window.
static Handle(Geom_Curve) edgeCurveForGordon(const TopoDS_Edge& edge, std::string& error)
{
    if (edge.IsNull() || BRep_Tool::Degenerated(edge)) {
        error = "Failed to create Gordon surface: an edge is null or degenerate";
        return nullptr;
    }

    double first = 0.0;
    double last = 0.0;
    Handle(Geom_Curve) curve = BRep_Tool::Curve(edge, first, last);
    if (curve.IsNull()) {
        error = "Failed to create Gordon surface: an edge has no 3D curve";
        return nullptr;
    }

    Handle(Geom_Curve) basis = curve;
    while (auto trimmed = Handle(Geom_TrimmedCurve)::DownCast(basis)) {
        basis = trimmed->BasisCurve();
    }
    if (!isGordonCurveKind(basis)) {
        error = "Failed to create Gordon surface: an edge uses a curve type Gordon cannot "
                "interpolate exactly (offset curves are not supported)";
        return nullptr;
    }

    if (!basis->IsPeriodic()) {
        first = std::max(first, basis->FirstParameter());
        last = std::min(last, basis->LastParameter());
    }
    if (first > last) {
        error = "Failed to create Gordon surface: an edge has a reversed parameter range";
        return nullptr;
    }
    if (std::abs(last - first) <= Precision::PConfusion()) {
        error = "Failed to create Gordon surface: an edge has an empty parameter range";
        return nullptr;
    }
    return new Geom_TrimmedCurve(basis, first, last);
}

// Gordon's intersection pass is not defensive: when a profile has no contact with a guide
// it aborts the module (a raise, and Release builds cannot catch it) instead of reporting
// IntersectionFailed. Run the same extrema query the kernel would and refuse up front.
static bool gordonNetworkMeets(const NCollection_Array1<Handle(Geom_Curve)>& profiles,
    const NCollection_Array1<Handle(Geom_Curve)>& guides, double tolerance)
{
    for (int i = profiles.Lower(); i <= profiles.Upper(); i++) {
        for (int j = guides.Lower(); j <= guides.Upper(); j++) {
            GeomAPI_ExtremaCurveCurve extrema(profiles(i), guides(j));
            if (extrema.NbExtrema() > 0) {
                if (extrema.LowerDistance() > tolerance)
                    return false;
                continue;
            }
            gp_Pnt profilePoint;
            gp_Pnt guidePoint;
            if (!extrema.TotalNearestPoints(profilePoint, guidePoint)
                || profilePoint.Distance(guidePoint) > tolerance)
                return false;
        }
    }
    return true;
}

// One line per failure family: the caller words the user-facing message per locale, so
// the kernel's many statuses collapse to the ones a user can act on.
static std::string mapGordonError(GeomFill_Gordon::ResultStatus status)
{
    const std::string prefix = "Failed to create Gordon surface: ";
    switch (status) {
    case GeomFill_Gordon::ResultStatus::InvalidInput:
        return prefix + "at least 2 profile edges and 2 guide edges are required";
    case GeomFill_Gordon::ResultStatus::ConversionFailed:
        return prefix + "a curve could not be converted to a B-spline";
    case GeomFill_Gordon::ResultStatus::IntersectionFailed:
        return prefix + "every profile must intersect every guide";
    case GeomFill_Gordon::ResultStatus::OrderingFailed:
    case GeomFill_Gordon::ResultStatus::CompatibilityFailed:
    case GeomFill_Gordon::ResultStatus::CurveCompatibilityFailed:
        return prefix + "the curve network is not consistent";
    case GeomFill_Gordon::ResultStatus::ReparametrizationFailed:
    case GeomFill_Gordon::ResultStatus::RationalReparametrizationFailed:
        return prefix + "the curves could not be made compatible";
    case GeomFill_Gordon::ResultStatus::RationalDegreeOverflow:
        return prefix + "the rational surface is too complex for the kernel";
    case GeomFill_Gordon::ResultStatus::SkinningFailed:
    case GeomFill_Gordon::ResultStatus::ReferenceSurfaceFailed:
    case GeomFill_Gordon::ResultStatus::KnotAlignmentFailed:
    case GeomFill_Gordon::ResultStatus::ConstructionFailed:
        return prefix + "the exact surface construction failed";
    case GeomFill_Gordon::ResultStatus::RationalConstructionFailed:
        return prefix + "the rational surface could not be built";
    case GeomFill_Gordon::ResultStatus::PeriodicityFailed:
        return prefix + "the closed network could not be made periodic";
    case GeomFill_Gordon::ResultStatus::ApproximationFailed:
        return prefix + "the approximate fallback failed";
    default:
        return prefix + "unknown failure";
    }
}

struct CornerPlane {
    gp_Pnt point; // the point the two edges meet at
    gp_Dir normal; // normal of the plane containing both edges
    double param1 = 0.0; // corner parameter on the first edge's curve
    double param2 = 0.0; // corner parameter on the second edge's curve
    TopoDS_Vertex cornerVertex; // set when the corner is a real point of both edges
};

// Whether the curve is one the 2D fillet/chamfer algorithms handle. ChFi2d works on
// linear and circular edges; anything else is refused up front.
static bool isCornerCurve(const Handle(Geom_Curve) & curve)
{
    return curve->IsKind(STANDARD_TYPE(Geom_Line)) || curve->IsKind(STANDARD_TYPE(Geom_Circle));
}

// The parameter of a point on a line or circle, as the curve reports it (a circle's angle
// may be on either branch around 2*pi).
static bool rawCurveParameter(const Handle(Geom_Curve) & curve, const gp_Pnt& point, double& parameter)
{
    if (auto line = Handle(Geom_Line)::DownCast(curve)) {
        parameter = ElCLib::Parameter(line->Lin(), point);
        return true;
    }
    if (auto circle = Handle(Geom_Circle)::DownCast(curve)) {
        parameter = ElCLib::Parameter(circle->Circ(), point);
        return true;
    }
    return false;
}

// The parameter of a corner point on its curve. A circle is periodic, so the angle is
// moved into this edge's own window — the projection could otherwise report the other
// branch of the same point.
static bool cornerParameter(const Handle(Geom_Curve) & curve, double first, double last, const gp_Pnt& point,
    double& parameter)
{
    if (!rawCurveParameter(curve, point, parameter))
        return false;
    if (curve->IsKind(STANDARD_TYPE(Geom_Line)))
        return true;

    double period = 2.0 * M_PI;
    double shifted = std::fmod(parameter - first, period);
    if (shifted < 0.0)
        shifted += period;
    parameter = first + shifted;
    if (parameter > last)
        parameter -= period;
    if (std::abs(parameter - first) <= Precision::PConfusion())
        parameter = first;
    else if (std::abs(parameter - last) <= Precision::PConfusion())
        parameter = last;
    return true;
}

// Whether a point lies on the edge's own parameter window. A circle is periodic, so the
// angle is moved to the window's branch first; a tangent point on the other side of the
// circle then falls outside it.
static bool pointOnEdgeWindow(const Handle(Geom_Curve) & curve, double first, double last,
    const gp_Pnt& point)
{
    double parameter = 0.0;
    if (!rawCurveParameter(curve, point, parameter))
        return false;
    if (curve->IsKind(STANDARD_TYPE(Geom_Line)))
        return parameter >= first - Precision::PConfusion() && parameter <= last + Precision::PConfusion();

    double period = 2.0 * M_PI;
    double shifted = std::fmod(parameter - first, period);
    if (shifted < 0.0)
        shifted += period;
    return first + shifted <= last + Precision::PConfusion();
}

// The parameter step that travels `distance` along the curve: a line's parameter is a
// length, a circle's is an angle.
static bool cornerParameterStep(const Handle(Geom_Curve) & curve, double distance, double& step)
{
    if (curve->IsKind(STANDARD_TYPE(Geom_Line))) {
        step = distance;
        return true;
    }
    if (auto circle = Handle(Geom_Circle)::DownCast(curve)) {
        step = distance / circle->Circ().Radius();
        return true;
    }
    return false;
}

// Whether the cut leaves some edge behind. A straight edge can be extended to reach it —
// that is how a corner beyond the segment is handled — but a circular edge cannot. A cut
// landing exactly on the far endpoint leaves nothing: MakeEdge(p, p) raises on a line (the
// Release build cannot catch it) and silently turns a circle into its full period.
static bool cutWithinEdge(
    const Handle(Geom_Curve) & curve, double cut, double first, double last, double farEnd)
{
    if (curve->IsKind(STANDARD_TYPE(Geom_Line)))
        return std::abs(cut - farEnd) > Precision::Confusion();
    return cut >= first + Precision::Confusion() && cut <= last - Precision::Confusion();
}

// Whether the whole curve lies on the plane, sampled at its ends and middle. The corner's
// point and the two tangents only define the plane; this is what checks the curves stay in
// it.
static bool curveOnPlane(const Handle(Geom_Curve) & curve, double first, double last, const gp_Pln& plane)
{
    const double parameters[] = { first, (first + last) / 2.0, last };
    for (double parameter : parameters) {
        if (plane.Distance(curve->Value(parameter)) > Precision::Confusion())
            return false;
    }
    return true;
}

// The point the two edges share. A wire's adjacent edges share a topological vertex;
// standalone edge bodies hold independent TShapes, so their endpoints are matched
// geometrically instead.
static bool edgesShareCorner(const TopoDS_Edge& edge1, const Handle(Geom_Curve) & curve1, double first1,
    double last1, const TopoDS_Edge& edge2, const Handle(Geom_Curve) & curve2, double first2, double last2,
    gp_Pnt& point)
{
    TopoDS_Vertex common = findCommonVertex(edge1, edge2);
    if (!common.IsNull()) {
        point = BRep_Tool::Pnt(common);
        return true;
    }

    const gp_Pnt ends1[] = { curve1->Value(first1), curve1->Value(last1) };
    const gp_Pnt ends2[] = { curve2->Value(first2), curve2->Value(last2) };
    bool found = false;
    double best = Precision::Confusion();
    for (const gp_Pnt& p1 : ends1) {
        for (const gp_Pnt& p2 : ends2) {
            double distance = p1.Distance(p2);
            if (distance <= best) {
                best = distance;
                point = p1;
                found = true;
            }
        }
    }
    return found;
}

// The corner between two edges when at least one is circular. Unlike straight edges —
// whose support lines give a corner even when it lies beyond them — a circular edge has no
// such extension, so the edges must actually meet. They must also be coplanar and leave a
// real angle: a tangent pair has no corner to round.
static std::optional<CornerPlane> curvedCorner(const TopoDS_Edge& edge1, const Handle(Geom_Curve) & curve1,
    double first1, double last1, const TopoDS_Edge& edge2, const Handle(Geom_Curve) & curve2, double first2,
    double last2, std::string& error)
{
    gp_Pnt point;
    if (!edgesShareCorner(edge1, curve1, first1, last1, edge2, curve2, first2, last2, point)) {
        error = "Edges must share a common vertex";
        return std::nullopt;
    }

    double param1 = 0.0;
    double param2 = 0.0;
    if (!cornerParameter(curve1, first1, last1, point, param1)
        || !cornerParameter(curve2, first2, last2, point, param2)) {
        error = "Edges must be Line or Circle";
        return std::nullopt;
    }

    gp_Pnt onCurve1;
    gp_Pnt onCurve2;
    gp_Vec tangent1;
    gp_Vec tangent2;
    curve1->D1(param1, onCurve1, tangent1);
    curve2->D1(param2, onCurve2, tangent2);
    if (tangent1.Magnitude() <= Precision::Confusion() || tangent2.Magnitude() <= Precision::Confusion()) {
        error = "Edges must be Line or Circle";
        return std::nullopt;
    }
    tangent1.Normalize();
    tangent2.Normalize();

    gp_Vec cross = tangent1.Crossed(tangent2);
    if (cross.Magnitude() <= Precision::Angular()) {
        error = "Edges must not be tangent";
        return std::nullopt;
    }

    // The plane's normal follows the circular edge's own axis. ChFi2d's analytical
    // algorithm turns its 2D tangents by that circle's own orientation, so a plane flipped
    // against the circle mirrors the coordinates and its result fails; the tangents' cross
    // product describes the same plane but may pick the flipped side.
    gp_Dir normal;
    if (auto circle = Handle(Geom_Circle)::DownCast(curve1))
        normal = circle->Circ().Axis().Direction();
    else if (auto circle = Handle(Geom_Circle)::DownCast(curve2))
        normal = circle->Circ().Axis().Direction();
    else
        normal = gp_Dir(cross);

    gp_Pln plane(point, normal);
    if (!curveOnPlane(curve1, first1, last1, plane) || !curveOnPlane(curve2, first2, last2, plane)) {
        error = "Edges must be coplanar";
        return std::nullopt;
    }
    // One vertex shared by both rebuilt edges: ChFi2d joins them into a wire internally, and
    // a wire only connects edges whose vertices are the same TShape. Two independent edge
    // bodies do not share one.
    return CornerPlane { point, gp_Dir(normal), param1, param2, BRepBuilderAPI_MakeVertex(point) };
}

// Compute the corner reference point and the plane for a 2D fillet/chamfer between two
// edges. Two straight edges keep their support-line corner, which need not lie on the
// edges themselves; any corner involving a circular edge is a point the two edges share.
// Either way the edges must be coplanar and leave an angle.
static std::optional<CornerPlane> computeCornerPlane(const TopoDS_Edge& edge1, const TopoDS_Edge& edge2,
    std::string& error)
{
    double first1, last1, first2, last2;
    Handle(Geom_Curve) curve1 = basisCurve(edge1, first1, last1);
    Handle(Geom_Curve) curve2 = basisCurve(edge2, first2, last2);
    if (curve1.IsNull() || curve2.IsNull() || !isCornerCurve(curve1) || !isCornerCurve(curve2)) {
        error = "Edges must be Line or Circle";
        return std::nullopt;
    }

    Handle(Geom_Line) line1 = Handle(Geom_Line)::DownCast(curve1);
    Handle(Geom_Line) line2 = Handle(Geom_Line)::DownCast(curve2);
    if (line1.IsNull() || line2.IsNull())
        return curvedCorner(edge1, curve1, first1, last1, edge2, curve2, first2, last2, error);

    gp_Vec d1(line1->Lin().Direction());
    gp_Vec d2(line2->Lin().Direction());
    gp_Vec normal = d1.Crossed(d2);
    if (normal.Magnitude() < Precision::Angular()) {
        error = "Edges must not be parallel";
        return std::nullopt;
    }

    gp_Vec p12(line1->Lin().Location(), line2->Lin().Location());
    if (std::abs(p12.Dot(normal) / normal.Magnitude()) > Precision::Confusion()) {
        error = "Edges must be coplanar";
        return std::nullopt;
    }

    // intersection of the support lines: p12 = t1 * d1 - t2 * d2, solved by crossing with d2 and d1 respectively
    double denom = normal.SquareMagnitude();
    double t1 = p12.Crossed(d2).Dot(normal) / denom;
    double t2 = p12.Crossed(d1).Dot(normal) / denom;
    return CornerPlane { line1->Lin().Location().Translated(d1.Multiplied(t1)), gp_Dir(normal), t1, t2 };
}

// Build an edge whose range covers the corner parameter p. When p cuts the edge in two,
// only the longer side is kept, so that fillets/chamfers consume the shorter side; when p
// lies outside, the edge is extended up to p (OCCT fillets can trim but never prolongate).
static TopoDS_Edge edgeThroughCorner(const Handle(Geom_Curve) & basis, double first, double last, double p)
{
    if (p > first && p < last) {
        return p - first >= last - p ? BRepBuilderAPI_MakeEdge(basis, first, p).Edge()
                                     : BRepBuilderAPI_MakeEdge(basis, p, last).Edge();
    }
    return BRepBuilderAPI_MakeEdge(basis, std::min(first, p), std::max(last, p)).Edge();
}

// The edge rebuilt with the shared corner vertex at one end and a fresh vertex at the far
// endpoint. ChFi2d joins the two edges into a wire internally, which only works when their
// common vertex is the same TShape.
static TopoDS_Edge edgeFromCorner(const Handle(Geom_Curve) & basis, double first, double last,
    double cornerParam, const TopoDS_Vertex& cornerVertex)
{
    bool cornerAtStart = std::abs(cornerParam - first) <= std::abs(cornerParam - last);
    double farParam = cornerAtStart ? last : first;
    TopoDS_Vertex farVertex = BRepBuilderAPI_MakeVertex(basis->Value(farParam));
    return cornerAtStart ? BRepBuilderAPI_MakeEdge(basis, cornerVertex, farVertex).Edge()
                         : BRepBuilderAPI_MakeEdge(basis, farVertex, cornerVertex).Edge();
}

// Endpoints of an edge, evaluated on its underlying curve.
static void edgeEndPoints(const TopoDS_Edge& edge, gp_Pnt& start, gp_Pnt& end)
{
    double first, last;
    Handle(Geom_Curve) curve = BRep_Tool::Curve(edge, first, last);
    start = curve->Value(first);
    end = curve->Value(last);
}

// Whether a trimmed fillet neighbour keeps its tangent point on the original edge. The
// algorithm also finds a symmetric solution on the other side of a circular edge, and only
// one of the two lies on the arc the user picked.
static bool trimOnEdge(const TopoDS_Edge& trimmed, const Handle(Geom_Curve) & basis, double first,
    double last, const gp_Pnt& corner)
{
    gp_Pnt start, end;
    edgeEndPoints(trimmed, start, end);
    const gp_Pnt& tangent = start.Distance(corner) <= end.Distance(corner) ? start : end;
    return pointOnEdgeWindow(basis, first, last, tangent);
}

// ChFi2d may trim either side of the corner, so the kept side is rebuilt
// deterministically: from the fillet tangent point (whichever arc endpoint lies on this
// curve) to the end of the edge farthest from the corner. The far end is chosen by actual
// distance, because a circle's parameter is an angle, not a length.
static TopoDS_Edge edgeToFarEnd(const Handle(Geom_Curve) & basis, double first, double last,
    double cornerParam, const gp_Pnt& arcStart, const gp_Pnt& arcEnd)
{
    GeomAPI_ProjectPointOnCurve fromStart(arcStart, basis);
    GeomAPI_ProjectPointOnCurve fromEnd(arcEnd, basis);
    if (fromStart.NbPoints() == 0 || fromEnd.NbPoints() == 0)
        return TopoDS_Edge();

    const gp_Pnt& tangentPoint = fromStart.LowerDistance() <= fromEnd.LowerDistance() ? arcStart : arcEnd;
    double tangent = 0.0;
    if (!cornerParameter(basis, first, last, tangentPoint, tangent))
        return TopoDS_Edge();

    const gp_Pnt corner = basis->Value(cornerParam);
    double farEnd = corner.Distance(basis->Value(first)) >= corner.Distance(basis->Value(last)) ? first : last;
    return BRepBuilderAPI_MakeEdge(basis, std::min(tangent, farEnd), std::max(tangent, farEnd)).Edge();
}

static std::string mapBuildWireError(const BRepBuilderAPI_WireError& error)
{
    switch (error) {
    case BRepBuilderAPI_EmptyWire:
        return "Empty Wire";
    case BRepBuilderAPI_DisconnectedWire:
        return "Disconnected Wire";
    case BRepBuilderAPI_NonManifoldWire:
        return "Non Mainfold Wire";
    default:
        return "Done";
    }
};

// The split edges plus a map from each split segment to its input edge index.
struct SplitEdgesResult {
    TopoDS_Shape shape;
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> segments;
    std::vector<int> segmentSources;
    bool isOk;
    std::string error;
};

// Adds both orientations of `segment` to the map (lookups ignore orientation, but be
// explicit), extending the parallel source array only on real insertions — the map
// dedupes shapes that are IsSame.
static void addSegment(SplitEdgesResult& result, const TopoDS_Shape& segment, int inputIndex)
{
    const int added = result.segments.Add(segment.Oriented(TopAbs_FORWARD));
    result.segments.Add(segment.Oriented(TopAbs_REVERSED));
    if (added == result.segments.Extent()) {
        result.segmentSources.push_back(inputIndex);
    }
}

// Splits `edges` at their mutual intersections, recording which input edge each split
// segment comes from (an unmodified edge maps to itself).
static SplitEdgesResult splitAtIntersections(const NCollection_List<TopoDS_Shape>& edges)
{
    BOPAlgo_Splitter splitter;
    splitter.SetArguments(edges);
    splitter.SetRunParallel(true);
    splitter.SetNonDestructive(true);
    splitter.Perform();
    if (splitter.HasErrors()) {
        return SplitEdgesResult { TopoDS_Shape(), {}, {}, false, "Failed to split edges at intersections" };
    }

    SplitEdgesResult result { splitter.Shape(), {}, {}, true, "" };
    int inputIndex = 0;
    for (const TopoDS_Shape& edge : edges) {
        const NCollection_List<TopoDS_Shape>& modified = splitter.Modified(edge);
        if (modified.IsEmpty()) {
            addSegment(result, edge, inputIndex);
        } else {
            for (const TopoDS_Shape& segment : modified) {
                addSegment(result, segment, inputIndex);
            }
        }
        inputIndex++;
    }
    return result;
}

// Builds a base face dwarfing the split edges so BuilderFace can tell bounded regions from
// the unbounded exterior (FORWARD orientation required). `faceEdges` receives every edge in
// both orientations — so every region boundary is found — with pcurves on the base face.
static TopoDS_Face baseFaceForRegions(const TopoDS_Shape& splitEdges, const gp_Pln& pln,
    NCollection_List<TopoDS_Shape>& faceEdges, double& extent)
{
    Bnd_Box geomBox;
    for (TopExp_Explorer explorer(splitEdges, TopAbs_EDGE); explorer.More(); explorer.Next()) {
        const TopoDS_Edge& edge = TopoDS::Edge(explorer.Current());
        BRepBndLib::Add(edge, geomBox);
        faceEdges.Append(edge.Oriented(TopAbs_FORWARD));
        faceEdges.Append(edge.Oriented(TopAbs_REVERSED));
    }
    extent = std::max(1.0e8, 10.0 * std::sqrt(geomBox.SquareExtent()));
    TopoDS_Face baseFace = BRepBuilderAPI_MakeFace(pln, -extent, extent, -extent, extent).Face();
    baseFace.Orientation(TopAbs_FORWARD);
    BRepLib::BuildPCurveForEdgesOnPlane(faceEdges, baseFace);
    return baseFace;
}

// Recovers every minimal bounded area covered by `faceEdges` on `baseFace`, with the
// sorted unique input edge indexes bounding each region (see SplitEdgesResult).
static RegionsResult boundedAreas(const TopoDS_Face& baseFace, const NCollection_List<TopoDS_Shape>& faceEdges,
    double extent, const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& segments,
    const std::vector<int>& segmentSources)
{
    // AvoidInternalShapes keeps dangling edges from becoming internal wires.
    BOPAlgo_BuilderFace faceBuilder;
    faceBuilder.SetFace(baseFace);
    faceBuilder.SetShapes(faceEdges);
    faceBuilder.SetAvoidInternalShapes(true);
    faceBuilder.Perform();
    if (faceBuilder.HasErrors()) {
        return RegionsResult { ShapeArray(val::array()), {}, {}, false, "Failed to build faces from edges" };
    }

    const double outerThreshold = extent * extent;
    val faces = val::array();
    std::vector<int> sourceCounts;
    std::vector<int> sourceIds;
    for (const TopoDS_Shape& area : faceBuilder.Areas()) {
        Bnd_Box box;
        BRepBndLib::Add(area, box);
        GProp_GProps props;
        BRepGProp::SurfaceProperties(area, props);
        if (box.SquareExtent() > outerThreshold || props.Mass() < Precision::Confusion()) {
            continue;
        }
        faces.call<void>("push", area);
        std::set<int> sources;
        for (TopExp_Explorer explorer(area, TopAbs_EDGE); explorer.More(); explorer.Next()) {
            const int index = segments.FindIndex(explorer.Current());
            if (index > 0) {
                sources.insert(segmentSources[index - 1]);
            }
        }
        sourceCounts.push_back(static_cast<int>(sources.size()));
        sourceIds.insert(sourceIds.end(), sources.begin(), sources.end());
    }
    if (sourceCounts.empty()) {
        return RegionsResult { ShapeArray(val::array()), {}, {}, false, "No bounded regions found" };
    }
    return RegionsResult { ShapeArray(faces), sourceCounts, sourceIds, true, "" };
}

// ---------------------------------------------------------------- offset face --
static constexpr double OFFSET_TANGENT_DOT = 0.99756; // 4 degrees, OCCT's own tangent test
static constexpr double OFFSET_MASS_EPS = 1e-7;

// Whether a face of `shape` is a B-spline, Bezier or offset surface — the shapes the bounded
// integral below has to be used on.
static bool needsBoundedIntegral(const TopoDS_Shape& shape)
{
    for (TopExp_Explorer face(shape, TopAbs_FACE); face.More(); face.Next()) {
        BRepAdaptor_Surface surface(TopoDS::Face(face.Current()), false);
        const GeomAbs_SurfaceType type = surface.GetType();
        if (type == GeomAbs_BSplineSurface || type == GeomAbs_BezierSurface || type == GeomAbs_OffsetSurface) {
            return true;
        }
    }
    return false;
}

// Whether one of `shape`'s edges is a rational curve (a sketch conic, or a rational B-spline
// from a STEP file). OCCT's fixed Gauss order is exact on lines, circles and polynomial curves
// but not on a rational one (measured 1e-3 out on a hyperbola arc's face).
static bool hasRationalCurve(const TopoDS_Shape& shape)
{
    for (TopExp_Explorer edge(shape, TopAbs_EDGE); edge.More(); edge.Next()) {
        const TopoDS_Edge& e = TopoDS::Edge(edge.Current());
        if (BRep_Tool::Degenerated(e))
            continue;
        BRepAdaptor_Curve curve(e);
        const GeomAbs_CurveType type = curve.GetType();
        if ((type == GeomAbs_BSplineCurve || type == GeomAbs_BezierCurve) && curve.IsRational()) {
            return true;
        }
    }
    return false;
}

// A solid's volume, integrated to `OFFSET_MASS_EPS` where that is the better form: Gauss-Kronrod
// for a rational curve (the bounded one loses a prism's volume to cancellation), the bounded
// integral for a B-spline face, and OCCT's fixed order elsewhere. `offsetIsGood`'s volume-sign
// test compares against a 1e-6 relative slack, which OCCT's fixed order on a B-spline body
// (1-3 % out) is far too coarse for — that is why this is not simply VolumeProperties.
static void integrateVolume(const TopoDS_Shape& shape, GProp_GProps& props)
{
    if (hasRationalCurve(shape)) {
        BRepGProp::VolumePropertiesGK(shape, props, OFFSET_MASS_EPS);
    } else if (needsBoundedIntegral(shape)) {
        BRepGProp::VolumeProperties(shape, props, OFFSET_MASS_EPS, false);
    } else {
        BRepGProp::VolumeProperties(shape, props);
    }
}

// `shape`'s volume by the integral above — exact enough for a 1e-6 comparison.
static double exactVolume(const TopoDS_Shape& shape)
{
    GProp_GProps props;
    integrateVolume(shape, props);
    return props.Mass();
}

// `shape`'s volume with its SIGN. Only a sign is read off this, so OCCT's fixed order is
// enough and the bounded integral is not paid for.
static double signedVolume(const TopoDS_Shape& shape)
{
    GProp_GProps props;
    BRepGProp::VolumeProperties(shape, props);
    return props.Mass();
}

// The outward normal of `face` at the middle of `edge`; false when the surface has none there.
static bool edgeNormal(const TopoDS_Edge& edge, const TopoDS_Face& face, gp_Dir& normal)
{
    double first = 0;
    double last = 0;
    const Handle(Geom2d_Curve) pcurve = BRep_Tool::CurveOnSurface(edge, face, first, last);
    if (pcurve.IsNull())
        return false;
    const gp_Pnt2d uv = pcurve->Value(0.5 * (first + last));
    BRepAdaptor_Surface surface(face);
    BRepLProp_SLProps props(surface, uv.X(), uv.Y(), 1, 1e-7);
    if (!props.IsNormalDefined())
        return false;
    normal = props.Normal();
    if (face.Orientation() == TopAbs_REVERSED)
        normal.Reverse();
    return true;
}

// The two faces `body` meets along each of its edges, and whether they run into each other
// SMOOTHLY — the normals of both agreeing within `OFFSET_TANGENT_DOT`, the angle OCCT's offset
// carries across. A seam (one face on the edge) or a stray edge joins nothing and is not
// reported. Every reader of "how the faces run into each other" goes through this one reading of
// it: `smoothChains` unions the smooth pairs, `buildReblendedOffset` walks them.
struct FacePair {
    int a;
    int b;
    bool smooth;
};

static std::vector<FacePair> facePairs(const TopoDS_Shape& body,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces)
{
    NCollection_IndexedDataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> edgeFaces;
    TopExp::MapShapesAndUniqueAncestors(body, TopAbs_EDGE, TopAbs_FACE, edgeFaces);
    std::vector<FacePair> pairs;
    for (int e = 1; e <= edgeFaces.Extent(); e++) {
        std::vector<int> around;
        for (const TopoDS_Shape& other : edgeFaces.FindFromIndex(e)) {
            const int index = faces.FindIndex(other) - 1;
            if (index >= 0 && std::find(around.begin(), around.end(), index) == around.end()) {
                around.push_back(index);
            }
        }
        if (around.size() != 2)
            continue;
        const TopoDS_Edge edge = TopoDS::Edge(edgeFaces.FindKey(e));
        gp_Dir a;
        gp_Dir b;
        const bool smooth = edgeNormal(edge, TopoDS::Face(faces(around[0] + 1)), a) && edgeNormal(edge, TopoDS::Face(faces(around[1] + 1)), b) && a.Dot(b) > OFFSET_TANGENT_DOT;
        pairs.push_back(FacePair { around[0], around[1], smooth });
    }
    return pairs;
}

// How the faces of a body run into each other: its smooth chains (sets of faces joined through
// edges whose normals agree within `OFFSET_TANGENT_DOT` — the angle OCCT's offset carries
// across) and whether any chain has a SHARP edge inside it, which is the body OCCT's offset
// traps on. Fills `chain` (per face: the lowest face index of its chain) and returns that flag.
static bool smoothChains(const TopoDS_Shape& body,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, std::vector<int>& chain)
{
    const int count = faces.Extent();
    chain.assign(static_cast<size_t>(count), 0);
    for (int i = 0; i < count; i++) {
        chain[static_cast<size_t>(i)] = i;
    }
    const auto root = [&chain](int i) {
        while (chain[static_cast<size_t>(i)] != i) {
            chain[static_cast<size_t>(i)] = chain[static_cast<size_t>(chain[static_cast<size_t>(i)])];
            i = chain[static_cast<size_t>(i)];
        }
        return i;
    };
    std::vector<std::pair<int, int>> creases;
    for (const FacePair& pair : facePairs(body, faces)) {
        if (pair.smooth) {
            const int ra = root(pair.a);
            const int rb = root(pair.b);
            if (ra != rb)
                chain[static_cast<size_t>(std::max(ra, rb))] = std::min(ra, rb);
        } else {
            creases.emplace_back(pair.a, pair.b);
        }
    }
    for (int i = 0; i < count; i++) {
        chain[static_cast<size_t>(i)] = root(i);
    }
    for (const auto& crease : creases) {
        if (chain[static_cast<size_t>(crease.first)] == chain[static_cast<size_t>(crease.second)]) {
            return true;
        }
    }
    return false;
}

// The faces OCCT's offset moves together with the picked ones: their smooth chains, them
// included, as sorted indices. These are the faces `offsetIsGood` checks, not just the picks —
// OCCT extends or trims a neighbour at a 90-degree edge as a matter of course.
static std::vector<int> smoothClosure(const std::vector<int>& chain, const std::vector<int>& picked)
{
    std::vector<int> moving;
    for (size_t i = 0; i < chain.size(); i++) {
        for (int index : picked) {
            if (index >= 0 && index < static_cast<int>(chain.size()) && chain[static_cast<size_t>(index)] == chain[i]) {
                moving.push_back(static_cast<int>(i));
                break;
            }
        }
    }
    return moving;
}

// `shape` as a solid with positive volume: a solid as it is, a shell closed into one (OCCT's
// offset returns a SHELL for most bodies — a plain box is the exception), a compound holding
// exactly one solid. A null shape when it is none of those or does not close.
static TopoDS_Shape asSolid(const TopoDS_Shape& shape)
{
    TopoDS_Solid solid;
    if (shape.ShapeType() == TopAbs_SOLID) {
        solid = TopoDS::Solid(shape);
    } else if (shape.ShapeType() == TopAbs_SHELL) {
        BRepBuilderAPI_MakeSolid maker;
        maker.Add(TopoDS::Shell(shape));
        if (!maker.IsDone())
            return TopoDS_Shape();
        solid = maker.Solid();
    } else if (shape.ShapeType() == TopAbs_COMPOUND) {
        int solids = 0;
        for (TopExp_Explorer it(shape, TopAbs_SOLID); it.More(); it.Next()) {
            solid = TopoDS::Solid(it.Current());
            solids++;
        }
        if (solids != 1)
            return TopoDS_Shape();
    } else {
        return TopoDS_Shape();
    }
    // An offset that turned a body inside out comes back with a negative volume; flipping the
    // ORIENTATION FLAG (not the geometry) keeps every index map taken from it valid.
    if (signedVolume(solid) < 0)
        return solid.Reversed();
    return solid;
}

// Builds the offset of `input` (always a fresh copy — OCCT repairs its input in place) into
// `result`, with `builder` kept by the caller for its history. A skin offset of 0 everywhere
// but on the picked faces, which move by `distance`, with sharp joins
// (`GeomAbs_Intersection`, so a slanted neighbour is extended rather than rounded).
static bool buildOffset(BRepOffset_MakeOffset& builder, const TopoDS_Shape& input,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
    double distance, TopoDS_Shape& result)
{
    try {
        builder.Initialize(input, 0.0, 1e-4, BRepOffset_Skin, true, false, GeomAbs_Intersection, false, false);
        for (int index : picked) {
            builder.SetOffsetOnFace(TopoDS::Face(faces(index + 1)), distance);
        }
        builder.MakeOffsetShape();
        if (!builder.IsDone())
            return false;
        result = asSolid(builder.Shape());
        return !result.IsNull();
    } catch (...) {
        result.Nullify();
        return false;
    }
}

// Whether every face of `input` that neither moves nor shares an edge with a moving face comes
// through the offset unchanged: the same area at the same place. OCCT can build a valid,
// smaller solid out of a face pushed through the body — a slot's cap pushed 12 mm through a
// 12 mm slot across a cylinder's seam left a 5 mm disk of a 21 mm cylinder, which grew no
// volume and kept its moved faces far enough from where they were, so every other test passed.
// A far face vanishing, shrinking or moving gives it away. Faces NEXT to a moving one are
// extended or trimmed by design, so they are not checked.
static bool farFacesKept(BRepOffset_MakeOffset& builder, const TopoDS_Shape& input,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& moving,
    const TopoDS_Shape& result)
{
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> resultFaces;
    TopExp::MapShapes(result, TopAbs_FACE, resultFaces);
    NCollection_IndexedDataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> edgeFaces;
    TopExp::MapShapesAndUniqueAncestors(input, TopAbs_EDGE, TopAbs_FACE, edgeFaces);
    NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> near;
    for (int index : moving) {
        const TopoDS_Shape& face = faces(index + 1);
        near.Add(face);
        for (TopExp_Explorer e(face, TopAbs_EDGE); e.More(); e.Next()) {
            const int at = edgeFaces.FindIndex(e.Current());
            if (at == 0)
                continue;
            for (const TopoDS_Shape& other : edgeFaces.FindFromIndex(at)) {
                near.Add(other);
            }
        }
    }
    for (int i = 1; i <= faces.Extent(); i++) {
        const TopoDS_Shape& face = faces(i);
        if (near.Contains(face))
            continue;
        GProp_GProps before;
        BRepGProp::SurfaceProperties(face, before);
        GProp_GProps after;
        for (const TopoDS_Shape& made : builder.Generated(face)) {
            if (made.ShapeType() != TopAbs_FACE || resultFaces.FindIndex(made) == 0)
                continue;
            BRepGProp::SurfaceProperties(made, after);
        }
        if (std::fabs(after.Mass() - before.Mass()) > 1e-6 * before.Mass() + 1e-6)
            return false;
        if (after.Mass() > 0 && after.CentreOfMass().Distance(before.CentreOfMass()) > 1e-4)
            return false;
    }
    return true;
}

// Whether `result` is a sound offset of `input`: a valid solid that has grown where faces moved
// out and shrunk where they moved in, whose moved faces stay at least `distance` from the
// faces they came from, and whose far faces are untouched. Together these catch the junk OCCT
// returns with a success status (see the block comment above).
static bool offsetIsGood(BRepOffset_MakeOffset& builder, const TopoDS_Shape& input,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& moving,
    const TopoDS_Shape& result, double distance)
{
    if (result.IsNull() || !TopExp_Explorer(result, TopAbs_SOLID).More())
        return false;
    if (!BRepCheck_Analyzer(result).IsValid())
        return false;
    const double volume = exactVolume(result);
    const double before = exactVolume(input);
    if (!(volume > 0))
        return false;
    const double slack = 1e-6 * before;
    if (distance > 0 && volume < before - slack)
        return false;
    if (distance < 0 && volume > before + slack)
        return false;
    BRep_Builder compounds;
    TopoDS_Compound originals;
    TopoDS_Compound offsets;
    compounds.MakeCompound(originals);
    compounds.MakeCompound(offsets);
    bool any = false;
    for (int index : moving) {
        const TopoDS_Shape& face = faces(index + 1);
        for (const TopoDS_Shape& made : builder.Generated(face)) {
            if (made.ShapeType() != TopAbs_FACE)
                continue;
            compounds.Add(offsets, made);
            any = true;
        }
        compounds.Add(originals, face);
    }
    if (!farFacesKept(builder, input, faces, moving, result))
        return false;
    // No generated face means the result cannot be shown to have moved the picked faces at
    // all — OCCT has been observed to return a body it calls successful here. Refuse rather
    // than hand back geometry the caller would commit.
    if (!any)
        return false;
    // A true offset surface is exactly `|distance|` from the original everywhere; 0.999 of it
    // leaves room for the joins without letting a face that barely moved pass.
    BRepExtrema_DistShapeShape measure(originals, offsets, Extrema_ExtFlag_MIN);
    if (!measure.IsDone())
        return false;
    return measure.Value() >= 0.999 * std::fabs(distance) - 1e-3;
}

// Whether some face of `shape` has a seam — a cylinder's or a cone's wall, a sphere.
static bool hasSeam(const TopoDS_Shape& shape)
{
    for (TopExp_Explorer f(shape, TopAbs_FACE); f.More(); f.Next()) {
        const TopoDS_Face& face = TopoDS::Face(f.Current());
        for (TopExp_Explorer e(face, TopAbs_EDGE); e.More(); e.Next()) {
            if (BRep_Tool::IsClosed(TopoDS::Edge(e.Current()), face))
                return true;
        }
    }
    return false;
}

// The history of an offset built on a body whose closed faces were divided first and merged
// back after (`buildDividedOffset`): each sub-shape taken through the divide, the offset (with
// the relation the offset itself gives) and the merge. Deriving from BRepBuilderAPI_MakeShape
// is what lets the file's `faceHistory`/`edgeHistory` read it beside a real OCCT builder,
// rather than needing a second, generic history recorder.
class DividedOffset : public BRepBuilderAPI_MakeShape {
public:
    Handle(BRepTools_History) divide;
    BRepOffset_MakeOffset offset;
    Handle(BRepTools_History) unify;

    const NCollection_List<TopoDS_Shape>& Modified(const TopoDS_Shape& sub) override
    {
        collect(sub, false);
        return modified;
    }

    const NCollection_List<TopoDS_Shape>& Generated(const TopoDS_Shape& sub) override
    {
        collect(sub, true);
        return generated;
    }

    // Deleted only when EVERY piece of `sub` is deleted by the offset: one surviving piece is
    // the face.
    bool IsDeleted(const TopoDS_Shape& sub) override
    {
        for (const TopoDS_Shape& piece : pieces(sub)) {
            if (!offset.IsDeleted(piece))
                return false;
        }
        return true;
    }

    // Every piece `sub` became in the divide step — itself when the divide left it alone. Public
    // because the build has to map the caller's face indices through it.
    NCollection_List<TopoDS_Shape> pieces(const TopoDS_Shape& sub) const
    {
        NCollection_List<TopoDS_Shape> out;
        if (divide->IsRemoved(sub))
            return out;
        const NCollection_List<TopoDS_Shape>& split = divide->Modified(sub);
        if (split.IsEmpty())
            out.Append(sub);
        else
            out = split;
        return out;
    }

private:
    NCollection_List<TopoDS_Shape> modified;
    NCollection_List<TopoDS_Shape> generated;

    // `made`'s images through the merge, deduplicated: the merge is what puts the body's
    // original faces back together, so a face the offset split in two names one face again.
    static void merged(const Handle(BRepTools_History) & unify, const NCollection_List<TopoDS_Shape>& made,
        NCollection_List<TopoDS_Shape>& out, NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& seen)
    {
        for (const TopoDS_Shape& shape : made) {
            if (unify->IsRemoved(shape))
                continue;
            const NCollection_List<TopoDS_Shape>& back = unify->Modified(shape);
            if (back.IsEmpty()) {
                if (seen.Add(shape))
                    out.Append(shape);
                continue;
            }
            for (const TopoDS_Shape& one : back) {
                if (seen.Add(one))
                    out.Append(one);
            }
        }
    }

    void collect(const TopoDS_Shape& sub, bool generatedByOffset)
    {
        NCollection_List<TopoDS_Shape>& out = generatedByOffset ? generated : modified;
        out.Clear();
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> seen;
        for (const TopoDS_Shape& piece : pieces(sub)) {
            const NCollection_List<TopoDS_Shape>& made = generatedByOffset ? offset.Generated(piece) : offset.Modified(piece);
            merged(unify, made, out, seen);
        }
    }
};

// The offset of `input` (a copy) with its closed faces divided into seamless pieces first and
// merged back after, into `result`, with `divided` holding the composed history. OCCT's offset
// reports success with NO shape at all for a body whose cylinder wall has a notch across its
// seam (the seam edge cut in two), whichever face is moved; on seamless pieces it builds. A
// picked or moving face stands for all of its pieces. Tried only after the plain offset failed,
// and only for a body that has a seam — everyone else never pays for it.
static bool buildDividedOffset(DividedOffset& divided, const TopoDS_Shape& input,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
    const std::vector<int>& moving, double distance, TopoDS_Shape& result)
{
    try {
        ShapeUpgrade_ShapeDivideClosed divide(input);
        divide.SetNbSplitPoints(1);
        if (!divide.Perform())
            return false;
        const TopoDS_Shape split = divide.Result();
        divided.divide = divide.GetContext()->History();
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> splitFaces;
        TopExp::MapShapes(split, TopAbs_FACE, splitFaces);
        const auto piecesOf = [&](const std::vector<int>& indices) {
            std::vector<int> out;
            for (int index : indices) {
                for (const TopoDS_Shape& piece : divided.pieces(faces(index + 1))) {
                    const int at = splitFaces.FindIndex(piece) - 1;
                    if (at >= 0 && std::find(out.begin(), out.end(), at) == out.end())
                        out.push_back(at);
                }
            }
            return out;
        };
        const std::vector<int> pickedPieces = piecesOf(picked);
        const std::vector<int> movingPieces = piecesOf(moving);
        if (pickedPieces.empty())
            return false;
        TopoDS_Shape offset;
        if (!buildOffset(divided.offset, split, splitFaces, pickedPieces, distance, offset) || !offsetIsGood(divided.offset, split, splitFaces, movingPieces, offset, distance)) {
            return false;
        }
        ShapeUpgrade_UnifySameDomain unify(offset, true, true, false);
        unify.Build();
        divided.unify = unify.History();
        result = asSolid(unify.Shape());
        if (result.IsNull() || !BRepCheck_Analyzer(result).IsValid())
            return false;
        // The merge must not change the body: the same volume, within the integral's bound.
        const double before = exactVolume(offset);
        return std::fabs(exactVolume(result) - before) <= 1e-6 * std::fabs(before) + 1e-9;
    } catch (...) {
        result.Nullify();
        return false;
    }
}

/** The radius of a round's face: a cylinder's, or a torus's minor one; 0 for anything else. */
static double roundRadius(const TopoDS_Face& face)
{
    BRepAdaptor_Surface surface(face, false);
    if (surface.GetType() == GeomAbs_Cylinder)
        return surface.Cylinder().Radius();
    if (surface.GetType() == GeomAbs_Torus)
        return surface.Torus().MinorRadius();
    return 0;
}

/** Whether `face` is the kind of surface a fillet's round is: a cylinder or a torus. */
static bool isRoundSurface(const TopoDS_Face& face)
{
    BRepAdaptor_Surface surface(face, false);
    const GeomAbs_SurfaceType type = surface.GetType();
    return type == GeomAbs_Cylinder || type == GeomAbs_Torus;
}

// The history of an offset whose rounds were removed first and made again after
// (`buildReblendedOffset`): each sub-shape taken through the removal, the offset (with the
// relation the offset gives) and the new rounds. A re-made round's old face is MODIFIED into its
// new faces rather than generated — it is the same round at the same radius, re-made — which is
// what keeps its name. Deriving from BRepBuilderAPI_MakeShape lets the file's `faceHistory`
// read it beside a real OCCT builder, as `DividedOffset` does.
class ReblendedOffset : public BRepBuilderAPI_MakeShape {
public:
    BRepAlgoAPI_Defeaturing removal;
    BRepOffset_MakeOffset offset;
    std::unique_ptr<BRepFilletAPI_MakeFillet> rounds;
    NCollection_DataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> remade;

    // What `sub` is on the body with the rounds removed: itself when the removal left it alone.
    NCollection_List<TopoDS_Shape> removed(const TopoDS_Shape& sub)
    {
        NCollection_List<TopoDS_Shape> out;
        if (removal.IsDeleted(sub))
            return out;
        const NCollection_List<TopoDS_Shape>& modified = removal.Modified(sub);
        if (modified.IsEmpty())
            out.Append(sub);
        else
            out = modified;
        return out;
    }

    const NCollection_List<TopoDS_Shape>& Modified(const TopoDS_Shape& sub) override
    {
        workModified.Clear();
        if (remade.IsBound(sub)) {
            workModified = remade(sub);
            return workModified;
        }
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> seen;
        for (const TopoDS_Shape& piece : removed(sub)) {
            rounded(offset.Modified(piece), workModified, seen);
        }
        return workModified;
    }

    const NCollection_List<TopoDS_Shape>& Generated(const TopoDS_Shape& sub) override
    {
        workGenerated.Clear();
        // A re-made round is reported through Modified (see the class note), never here.
        if (remade.IsBound(sub))
            return workGenerated;
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> seen;
        for (const TopoDS_Shape& piece : removed(sub)) {
            rounded(offset.Generated(piece), workGenerated, seen);
        }
        return workGenerated;
    }

    bool IsDeleted(const TopoDS_Shape& sub) override
    {
        if (remade.IsBound(sub))
            return false;
        for (const TopoDS_Shape& piece : removed(sub)) {
            if (!offset.IsDeleted(piece))
                return false;
        }
        return true;
    }

private:
    NCollection_List<TopoDS_Shape> workModified;
    NCollection_List<TopoDS_Shape> workGenerated;

    // `made`'s images through the new rounds, deduplicated.
    void rounded(const NCollection_List<TopoDS_Shape>& made, NCollection_List<TopoDS_Shape>& out,
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& seen)
    {
        for (const TopoDS_Shape& shape : made) {
            if (rounds->IsDeleted(shape))
                continue;
            const NCollection_List<TopoDS_Shape>& modified = rounds->Modified(shape);
            if (modified.IsEmpty()) {
                if (seen.Add(shape))
                    out.Append(shape);
                continue;
            }
            for (const TopoDS_Shape& one : modified) {
                if (seen.Add(one))
                    out.Append(one);
            }
        }
    }
};

// The offset of `input` (a copy) with the rounds `blends` (0-based face indices, none of them
// picked) that run smoothly into a moving face REMOVED first (`BRepAlgoAPI_Defeaturing`), the
// picked faces moved by `distance`, and each round made again at its radius on the edges between
// the faces it ran between.
//
// **Why this exists.** OCCT offsets a face's smooth neighbours with it, so a round beside a moved
// face travels too and comes back with a CHANGED radius (measured: a 40 × 30 × 20 block with its
// two vertical edges rounded 3 mm, the x = 40 face moved +1 mm, gave 4 mm rounds on the old axes
// and pushed the front and back faces out as well). Fusion keeps the round's radius and moves its
// axis instead, and so does this: the moving faces are found as OCCT finds them but WITHOUT
// passing through a round, so a face past a round does not move.
//
// Each step runs once — no retries — and the body's smooth chains are checked after the removal
// as they are before an offset. False (into `result`, with `made` left unusable) when the rounds
// cannot be removed, the offset fails or is unsound, or the rounds cannot be made again; the
// plain offset of this file then runs unchanged.
// Faces next to each face across a smooth edge, as `smoothChains` judges it: the adjacency the
// reblend walks to find what a picked face drags along.
static std::vector<std::vector<int>> smoothAdjacency(const TopoDS_Shape& input,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces)
{
    std::vector<std::vector<int>> smooth(static_cast<size_t>(faces.Extent()));
    for (const FacePair& pair : facePairs(input, faces)) {
        if (!pair.smooth)
            continue;
        smooth[static_cast<size_t>(pair.a)].push_back(pair.b);
        smooth[static_cast<size_t>(pair.b)].push_back(pair.a);
    }
    return smooth;
}

// The faces a reblend moves: the picked ones and their smooth neighbours, NOT through a round — a
// face past a round stays exactly where it is, which is what taking the rounds off first is for.
static std::vector<char> movingWithoutRounds(const std::vector<int>& picked, const std::vector<int>& blends,
    const std::vector<std::vector<int>>& smooth)
{
    std::vector<char> isBlend(smooth.size(), 0);
    for (int index : blends) {
        isBlend[static_cast<size_t>(index)] = 1;
    }
    std::vector<char> moves(smooth.size(), 0);
    std::vector<int> queue;
    for (int index : picked) {
        if (!moves[static_cast<size_t>(index)]) {
            moves[static_cast<size_t>(index)] = 1;
            queue.push_back(index);
        }
    }
    for (size_t at = 0; at < queue.size(); at++) {
        for (int next : smooth[static_cast<size_t>(queue[at])]) {
            if (moves[static_cast<size_t>(next)] || isBlend[static_cast<size_t>(next)])
                continue;
            moves[static_cast<size_t>(next)] = 1;
            queue.push_back(next);
        }
    }
    return moves;
}

// The rounds that have to be made again: the ones beside a moving face.
static std::vector<int> roundsToRemake(const std::vector<int>& blends, const std::vector<char>& moves,
    const std::vector<std::vector<int>>& smooth)
{
    std::vector<int> remake;
    for (int index : blends) {
        for (int next : smooth[static_cast<size_t>(index)]) {
            if (moves[static_cast<size_t>(next)]) {
                remake.push_back(index);
                break;
            }
        }
    }
    return remake;
}

// Each round to remake as the two faces it runs between — its SMOOTH neighbours that are not
// themselves such rounds — and its own radius, into `rails`/`radii`. False when a round does not
// have exactly two of those, or has no radius left to give back.
static bool roundRails(const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces,
    const std::vector<int>& remake, const std::vector<std::vector<int>>& smooth,
    std::vector<std::vector<int>>& rails, std::vector<double>& radii)
{
    std::vector<char> remadeFlag(smooth.size(), 0);
    for (int index : remake) {
        remadeFlag[static_cast<size_t>(index)] = 1;
    }
    for (int index : remake) {
        std::vector<int> sides;
        for (int next : smooth[static_cast<size_t>(index)]) {
            if (!remadeFlag[static_cast<size_t>(next)] && std::find(sides.begin(), sides.end(), next) == sides.end()) {
                sides.push_back(next);
            }
        }
        const double radius = roundRadius(TopoDS::Face(faces(index + 1)));
        if (sides.size() != 2 || !(radius > 1e-6))
            return false;
        rails.push_back(sides);
        radii.push_back(radius);
    }
    return true;
}

// Where `face` went in the body the rounds were removed from: the pieces
// `BRepAlgoAPI_Defeaturing` answered for it, as indices into `plainFaces`.
static std::vector<int> removedImages(ReblendedOffset& made, const TopoDS_Shape& face,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& plainFaces)
{
    std::vector<int> out;
    for (const TopoDS_Shape& piece : made.removed(face)) {
        const int at = plainFaces.FindIndex(piece) - 1;
        if (at >= 0 && std::find(out.begin(), out.end(), at) == out.end())
            out.push_back(at);
    }
    return out;
}

// The faces `moved` kept for the face `face` of the plain body: the piece itself where the offset
// carried it through, plus every face the offset reported it Modified or Generated into.
static NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> movedImages(ReblendedOffset& made,
    const TopoDS_Shape& face, const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& plainFaces,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& movedFaces)
{
    NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> out;
    for (int at : removedImages(made, face, plainFaces)) {
        const TopoDS_Shape& piece = plainFaces(at + 1);
        if (movedFaces.Contains(piece))
            out.Add(piece);
        for (const TopoDS_Shape& m : made.offset.Modified(piece)) {
            if (movedFaces.Contains(m))
                out.Add(m);
        }
        for (const TopoDS_Shape& m : made.offset.Generated(piece)) {
            if (m.ShapeType() == TopAbs_FACE && movedFaces.Contains(m))
                out.Add(m);
        }
    }
    return out;
}

// Puts every round back on the edge between the faces its two sides became: the edge of `moved`
// whose two faces are one image of `rails[k][0]` and one image of `rails[k][1]`, at `radii[k]`.
// `roundEdges[k]` collects the edges round k went on. False when a round finds none — it would
// silently drop out of the body.
static bool addRoundEdges(ReblendedOffset& made,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& plainFaces, const TopoDS_Shape& moved,
    const std::vector<int>& remake, const std::vector<std::vector<int>>& rails, const std::vector<double>& radii,
    std::vector<std::vector<TopoDS_Shape>>& roundEdges)
{
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> movedFaces;
    TopExp::MapShapes(moved, TopAbs_FACE, movedFaces);
    NCollection_IndexedDataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> movedEdgeFaces;
    TopExp::MapShapesAndUniqueAncestors(moved, TopAbs_EDGE, TopAbs_FACE, movedEdgeFaces);
    made.rounds = std::make_unique<BRepFilletAPI_MakeFillet>(moved);
    NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> taken;
    for (size_t k = 0; k < remake.size(); k++) {
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> one = movedImages(made, faces(rails[k][0] + 1), plainFaces, movedFaces);
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> two = movedImages(made, faces(rails[k][1] + 1), plainFaces, movedFaces);
        for (int e = 1; e <= movedEdgeFaces.Extent(); e++) {
            const NCollection_List<TopoDS_Shape>& around = movedEdgeFaces.FindFromIndex(e);
            if (around.Extent() != 2)
                continue;
            const TopoDS_Shape& a = around.First();
            const TopoDS_Shape& b = around.Last();
            if (!((one.Contains(a) && two.Contains(b)) || (one.Contains(b) && two.Contains(a))))
                continue;
            const TopoDS_Shape& edge = movedEdgeFaces.FindKey(e);
            // One edge takes one round: two rounds sharing it would be built twice.
            if (!taken.Add(edge))
                continue;
            made.rounds->Add(radii[k], TopoDS::Edge(edge));
            roundEdges[k].push_back(edge);
        }
        if (roundEdges[k].empty())
            return false;
    }
    return true;
}

// The body with the rounds taken off: `BRepAlgoAPI_Defeaturing` extends their neighbours to meet,
// which is what frees the picked faces of running into a round. `plainFaces` is the face map every
// later step measures against — the removal renumbers, so the caller's `faces` indices no longer
// describe this body. False when the removal does not answer a valid solid.
static bool removeRounds(ReblendedOffset& made, const TopoDS_Shape& input,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& remake,
    TopoDS_Shape& plain, NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& plainFaces)
{
    made.removal.SetShape(input);
    for (int index : remake) {
        made.removal.AddFaceToRemove(faces(index + 1));
    }
    made.removal.SetRunParallel(false);
    made.removal.SetToFillHistory(true);
    made.removal.Build();
    if (!made.removal.IsDone() || made.removal.HasErrors())
        return false;
    plain = asSolid(made.removal.Shape());
    if (plain.IsNull() || !BRepCheck_Analyzer(plain).IsValid())
        return false;
    TopExp::MapShapes(plain, TopAbs_FACE, plainFaces);
    return true;
}

// Moves the picked faces on the round-free body, into `moved`. `picked` are indices into the
// ORIGINAL `faces`, mapped through the removal first — a picked face can come back as several
// pieces, and one that comes back as none means there is nothing left to move. The picked faces'
// smooth neighbours are checked with them (OCCT moves those too, see `smoothClosure`). False when
// the body's chains are the ones OCCT traps on, or the offset is unsound.
static bool offsetPlain(ReblendedOffset& made, const TopoDS_Shape& plain,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& plainFaces,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
    double distance, TopoDS_Shape& moved)
{
    std::vector<int> pickedPlain;
    for (int index : picked) {
        for (int at : removedImages(made, faces(index + 1), plainFaces)) {
            if (std::find(pickedPlain.begin(), pickedPlain.end(), at) == pickedPlain.end()) {
                pickedPlain.push_back(at);
            }
        }
    }
    if (pickedPlain.empty())
        return false;
    // OCCT's offset traps on a smooth chain with a crease inside it (see `smoothChains`).
    std::vector<int> chain;
    if (smoothChains(plain, plainFaces, chain))
        return false;
    const std::vector<int> movingPlain = smoothClosure(chain, pickedPlain);
    return buildOffset(made.offset, plain, plainFaces, pickedPlain, distance, moved) && offsetIsGood(made.offset, plain, plainFaces, movingPlain, moved, distance);
}

// The finished body grew where the faces moved out and shrank where they moved in, with a slack for
// the joins — the same check `offsetIsGood` makes, run again on the body that has the rounds back
// on (a round put back at the wrong place shows up here as a body that did not move at all).
static bool grewTheRightWay(const TopoDS_Shape& result, const TopoDS_Shape& input, double distance)
{
    const double before = exactVolume(input);
    const double after = exactVolume(result);
    const double slack = 1e-6 * before;
    return after > 0 && !(distance > 0 && after < before - slack) && !(distance < 0 && after > before + slack);
}

// Names each remade round on the face it replaced: `ReblendedOffset` reports a round through
// Modified from `made.remade`, so the round keeps the id it had and a later offset of it still finds
// the feature that built it. False when a round's edges generate no face of the result — the round
// did not really come back.
static bool bindRemadeRounds(ReblendedOffset& made,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& remake,
    const std::vector<std::vector<TopoDS_Shape>>& roundEdges, const TopoDS_Shape& result)
{
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> resultFaces;
    TopExp::MapShapes(result, TopAbs_FACE, resultFaces);
    for (size_t k = 0; k < remake.size(); k++) {
        NCollection_List<TopoDS_Shape> news;
        for (const TopoDS_Shape& edge : roundEdges[k]) {
            for (const TopoDS_Shape& face : made.rounds->Generated(edge)) {
                if (face.ShapeType() == TopAbs_FACE && resultFaces.Contains(face))
                    news.Append(face);
            }
        }
        if (news.IsEmpty())
            return false;
        made.remade.Bind(faces(remake[k] + 1), news);
    }
    return true;
}

static bool buildReblendedOffset(ReblendedOffset& made, const TopoDS_Shape& input,
    const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
    const std::vector<int>& blends, double distance, TopoDS_Shape& result, bool everyRound = false,
    bool* roundsAtRisk = nullptr)
{
    try {
        // What has to move, and which rounds that drags in: every round the moving faces run into
        // comes off first and goes back on at its own radius afterwards. `everyRound` takes all of
        // them off instead — what a body the crease guard refuses needs, since a pick far from
        // every round drags none of them in and leaves the crease that made it unusual in place.
        const std::vector<std::vector<int>> smooth = smoothAdjacency(input, faces);
        const std::vector<char> moves = movingWithoutRounds(picked, blends, smooth);
        // The rounds the move would otherwise re-radius — what `requireRounds` needs told apart
        // from the rounds merely handed over (a body may carry rounds nowhere near the pick).
        const std::vector<int> atRisk = roundsToRemake(blends, moves, smooth);
        if (roundsAtRisk != nullptr)
            *roundsAtRisk = !atRisk.empty();
        const std::vector<int> remake = everyRound ? blends : atRisk;
        if (remake.empty())
            return false;
        std::vector<std::vector<int>> rails;
        std::vector<double> radii;
        if (!roundRails(faces, remake, smooth, rails, radii))
            return false;

        TopoDS_Shape plain;
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> plainFaces;
        if (!removeRounds(made, input, faces, remake, plain, plainFaces))
            return false;
        TopoDS_Shape moved;
        if (!offsetPlain(made, plain, plainFaces, faces, picked, distance, moved))
            return false;

        // Each round goes back on the edges between the faces its two sides became.
        std::vector<std::vector<TopoDS_Shape>> roundEdges(remake.size());
        if (!addRoundEdges(made, faces, plainFaces, moved, remake, rails, radii, roundEdges))
            return false;
        made.rounds->Build();
        if (!made.rounds->IsDone())
            return false;
        result = asSolid(made.rounds->Shape());
        if (result.IsNull() || !BRepCheck_Analyzer(result).IsValid())
            return false;
        return grewTheRightWay(result, input, distance) && bindRemadeRounds(made, faces, remake, roundEdges, result);
    } catch (...) {
        result.Nullify();
        return false;
    }
}

// Whether the offset builds and is sound, on a fresh copy (nothing is kept: a probe). The
// divided retry is the probe's too, so the bisection below asks the same question the build
// does.
static bool offsetWorks(const TopoDS_Shape& input, const std::vector<int>& picked,
    const std::vector<int>& moving, double distance)
{
    const TopoDS_Shape copy = BRepBuilderAPI_Copy(input, true, false).Shape();
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> faces;
    TopExp::MapShapes(copy, TopAbs_FACE, faces);
    BRepOffset_MakeOffset builder;
    TopoDS_Shape result;
    if (buildOffset(builder, copy, faces, picked, distance, result) && offsetIsGood(builder, copy, faces, moving, result, distance)) {
        return true;
    }
    if (!hasSeam(input))
        return false;
    const TopoDS_Shape again = BRepBuilderAPI_Copy(input, true, false).Shape();
    NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> againFaces;
    TopExp::MapShapes(again, TopAbs_FACE, againFaces);
    DividedOffset divided;
    return buildDividedOffset(divided, again, againFaces, picked, moving, distance, result);
}

// The largest magnitude (same sign as `failing`) that works, or 0 when nothing down to
// failing/128 does: 7 bisection steps, each a fresh probe. Every step is 1/2^n of the range, so
// the answer is within ~0.8 % of the true bound — enough for a message that rounds to two
// digits anyway.
template <typename Probe>
static double largestThatWorks(Probe works, double failing)
{
    double good = 0;
    double bad = failing;
    for (int step = 0; step < 7; step++) {
        const double middle = 0.5 * (good + bad);
        if (works(middle))
            good = middle;
        else
            bad = middle;
    }
    return good;
}

// Why an offset failed, as `TrackedShapeResult::offsetReport` reads it: [status, valueMilli]
// with status 1 ("too far", valueMilli = the largest distance that works ×1000) or 2 ("no
// distance works"). Only the failures that NEED a search get here — a body that is not a solid,
// a sealed void or a sharp-edged chain is known before anything is built.
static std::vector<int> explainOffset(const TopoDS_Shape& input, const std::vector<int>& picked,
    const std::vector<int>& moving, double distance)
{
    const double sign = distance < 0 ? -1.0 : 1.0;
    const double magnitude = std::fabs(distance);
    // Whether even a hair-thin offset builds decides between "too far" (1, with a bound) and
    // "nothing works" (2) without paying the seven bisection builds. The probe is a fixed 1e-3 mm
    // rather than |d|/128: below the build's own 1e-4 tolerance OCCT refuses offsets that work a
    // little further out (measured: 2e-4 mm builds, 8e-5 does not), and a probe that fails for
    // THAT reason would report an offsettable body as unoffsettable. A body OCCT cannot offset at
    // all is the common refusal, and a drag asks this per pick — one build instead of eight.
    // The probe's distance rides back in the report as the smallest distance known to fail.
    const double probe = 1e-3;
    if (magnitude > probe && !offsetWorks(input, picked, moving, sign * probe))
        return { 2, static_cast<int>(std::lround(probe * 1000.0)) };
    const double largest = largestThatWorks([&](double m) { return offsetWorks(input, picked, moving, sign * m); },
        magnitude);
    const int status = largest > 0 ? 1 : 2;
    return { status, static_cast<int>(std::lround(largest * 1000.0)) };
}

// A refused offset: the message the caller words its own way, and the report saying which kind of
// refusal it was — `{ status, value }`, see `TrackedShapeResult::offsetReport`. Empty for the
// refusals that are not one of the reported kinds (a bad pick, no distance).
static TrackedShapeResult refused(const std::string& error, const std::vector<int>& report = {})
{
    return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {}, {}, {}, {}, {}, report };
}

// How many shells `shape` is built of: one for a plain solid, two or more for one with a sealed
// void inside it.
static int shellCount(const TopoDS_Shape& shape)
{
    int count = 0;
    for (TopExp_Explorer it(shape, TopAbs_SHELL); it.More(); it.Next()) {
        count++;
    }
    return count;
}

// `picked` as indices into `faces`, deduplicated, in the order given. False when one of them is not
// a face of the shape at all: the caller resolves its handles off the shape it holds, so that is a
// bug rather than a geometry problem, and a build over index -1 would read a face nobody picked.
static bool faceIndices(const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces,
    const std::vector<TopoDS_Face>& picked, std::vector<int>& indices)
{
    for (const TopoDS_Face& face : picked) {
        const int index = faces.FindIndex(face) - 1;
        if (index < 0)
            return false;
        if (std::find(indices.begin(), indices.end(), index) == indices.end()) {
            indices.push_back(index);
        }
    }
    return true;
}

// ---------------------------------------------------------------- prism up to face --

// A copy of `face`'s surface padded in UV by `margin` (millimetres; angular directions scale
// by the radius), naturally restricted. BRepFeat_MakePrism takes its boolean path (rather than
// the old gluer) only when the limit face is wire-free or naturally restricted
// (TransformShapeFU), and only for plane/cylinder/cone surfaces — the padded copy is what
// makes a trimmed solid face qualify, while the padding lets the limit cover a cross-section
// slightly wider than the face itself. BRep_Tool::Surface already returns the surface moved
// by the face's location, so the copy must NOT take the location again.
//
// Any other surface returns a null face: its padded copy would take the gluer path anyway (no
// boolean path exists for it), and PADDING it is not even safe — Geom_RectangularTrimmedSurface
// raises ConstructionError when a padded bound crosses a UV-BOUNDED surface's natural range
// (a sphere's V, a B-spline's), which with exception catching disabled aborts the module. The
// caller skips a null attempt, leaving the raw face to try the gluer path alone.
static TopoDS_Face paddedLimitFace(const TopoDS_Face& face, double margin)
{
    Handle(Geom_Surface) surface = BRep_Tool::Surface(face);
    while (auto trimmed = Handle(Geom_RectangularTrimmedSurface)::DownCast(surface)) {
        surface = trimmed->BasisSurface();
    }
    if (!surface->IsKind(STANDARD_TYPE(Geom_Plane)) && !surface->IsKind(STANDARD_TYPE(Geom_CylindricalSurface))
        && !surface->IsKind(STANDARD_TYPE(Geom_ConicalSurface))) {
        return TopoDS_Face();
    }
    double u1, u2, v1, v2;
    BRepTools::UVBounds(face, u1, u2, v1, v2);
    double padU = margin;
    double padV = margin;
    if (auto cylinder = Handle(Geom_CylindricalSurface)::DownCast(surface)) {
        padU = margin / cylinder->Radius();
    } else if (auto cone = Handle(Geom_ConicalSurface)::DownCast(surface)) {
        padU = margin / std::max(cone->RefRadius(), 1e-3);
    }
    u1 -= padU;
    u2 += padU;
    v1 -= padV;
    v2 += padV;
    // A periodic direction padded past its period overlaps itself — clamp to one full turn.
    if (surface->IsUPeriodic() && u2 - u1 > surface->UPeriod()) {
        const double middle = 0.5 * (u1 + u2);
        u1 = middle - 0.5 * surface->UPeriod();
        u2 = middle + 0.5 * surface->UPeriod();
    }
    if (surface->IsVPeriodic() && v2 - v1 > surface->VPeriod()) {
        const double middle = 0.5 * (v1 + v2);
        v1 = middle - 0.5 * surface->VPeriod();
        v2 = middle + 0.5 * surface->VPeriod();
    }
    // The bounds ride a trimmed-surface wrapper and the face is built wire-free on it
    // (BRepLib_MakeFace, as BRepFeat::FaceUntil does) — BRepFeat's boolean path requires a
    // wire-free or naturally-restricted limit (TransformShapeFU), and a bounded MakeFace
    // would materialize a boundary wire instead.
    Handle(Geom_Surface) trimmed = new Geom_RectangularTrimmedSurface(surface, u1, u2, v1, v2);
    BRepLib_MakeFace maker(trimmed, Precision::Confusion());
    if (!maker.IsDone()) {
        return TopoDS_Face();
    }
    return maker.Face();
}

// The result's termination faces ON the bounded limit face — found geometrically (booleans
// may copy surfaces, so a handle comparison misses them): a face qualifies when the midpoint
// of its own UV bounds lies within tolerance of the limit. There must be at least one (a
// build that never limited the prism, or limited it past the face's boundary, qualifies
// vacuously otherwise), and no vertex of a qualifying face may float off the limit — a cap
// the padded copy produced past the real boundary reads as a vertex at a positive distance.
//
// With a base (join/cut) the qualifying face must also be NEW — not an unmodified face of the
// base. The base's own face on the limit surface passes the geometric test as well, so
// without the exclusion a prism that never reaches the limit at all (fused as a disconnected
// lump off its side, the volume check satisfied by the added material) still finds its "cap":
// the base's untouched until-side face.
static bool capsOnLimitFace(const TopoDS_Shape& result, const TopoDS_Face& limit, const TopoDS_Shape& base)
{
    NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> baseFaces;
    if (!base.IsNull()) {
        for (TopExp_Explorer it(base, TopAbs_FACE); it.More(); it.Next()) {
            baseFaces.Add(it.Current());
        }
    }
    bool found = false;
    for (TopExp_Explorer it(result, TopAbs_FACE); it.More(); it.Next()) {
        const TopoDS_Face& face = TopoDS::Face(it.Current());
        double u1, u2, v1, v2;
        BRepTools::UVBounds(face, u1, u2, v1, v2);
        TopLoc_Location location;
        const Handle(Geom_Surface)& surface = BRep_Tool::Surface(face, location);
        const gp_Pnt center = surface->Value(0.5 * (u1 + u2), 0.5 * (v1 + v2)).Transformed(location);
        BRepBuilderAPI_MakeVertex makeCenter(center);
        BRepExtrema_DistShapeShape onLimit(makeCenter.Vertex(), limit, Extrema_ExtFlag_MIN);
        if (!onLimit.IsDone() || onLimit.Value() > 1e-4) {
            continue;
        }
        if (baseFaces.Contains(face)) {
            continue;
        }
        found = true;
        for (TopExp_Explorer vertices(face, TopAbs_VERTEX); vertices.More(); vertices.Next()) {
            BRepExtrema_DistShapeShape offLimit(vertices.Current(), limit, Extrema_ExtFlag_MIN);
            if (!offLimit.IsDone() || offLimit.Value() > 1e-4) {
                return false;
            }
        }
    }
    return found;
}

// The rounds the caller asked to keep that ARE rounds — a chamfer's `:f` faces are planes — and that
// are not themselves being moved. The caller finds them by name (`edgeCorner.ts`); telling a round
// from a flat is the surface's job.
static std::vector<int> blendIndices(const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces,
    const std::vector<TopoDS_Face>& rounds, const std::vector<int>& picked)
{
    std::vector<int> blends;
    for (const TopoDS_Face& face : rounds) {
        const int index = faces.FindIndex(face) - 1;
        if (index < 0 || std::find(picked.begin(), picked.end(), index) != picked.end())
            continue;
        if (std::find(blends.begin(), blends.end(), index) != blends.end())
            continue;
        if (isRoundSurface(face))
            blends.push_back(index);
    }
    return blends;
}

class ShapeFactory {
public:
    static ShapeResult box(const Pln& ax3, double x, double y, double z)
    {
        gp_Pln pln = Pln::toPln(ax3);
        BRepBuilderAPI_MakeFace makeFace(pln, 0, x, 0, y);
        if (!makeFace.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create box" };
        }

        gp_Vec vec(pln.Axis().Direction());
        vec.Multiply(z);
        BRepPrimAPI_MakePrism box(makeFace.Face(), vec);
        if (!box.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create box" };
        }
        return ShapeResult { box.Shape(), true, "" };
    }

    static ShapeResult cone(const Vector3& normal, const Vector3& center, double radius, double radiusUp, double height)
    {
        gp_Ax2 ax2(Vector3::toPnt(center), Vector3::toDir(normal));
        TopoDS_Shape cone = BRepPrimAPI_MakeCone(ax2, radius, radiusUp, height).Shape();
        return ShapeResult { cone, true, "" };
    }

    static ShapeResult sphere(const Vector3& center, double radius)
    {
        TopoDS_Shape sphere = BRepPrimAPI_MakeSphere(Vector3::toPnt(center), radius).Shape();
        return ShapeResult { sphere, true, "" };
    }

    static ShapeResult ellipse(const Vector3& normal, const Vector3& center, const Vector3& xvec, double majorRadius,
        double minorRadius)
    {
        gp_Ax2 ax2(Vector3::toPnt(center), Vector3::toDir(normal), Vector3::toDir(xvec));
        gp_Elips ellipse(ax2, majorRadius, minorRadius);
        BRepBuilderAPI_MakeEdge edge(ellipse);
        if (!edge.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create ellipse" };
        }
        return ShapeResult { edge.Edge(), true, "" };
    }

    /**
     * TODO
     */
    static ShapeResult ellipsoid(const Vector3& normal, const Vector3& center, const Vector3& xvec, double xRadius,
        double yRadius, double zRadius)
    {
        TopoDS_Shape sphere = BRepPrimAPI_MakeSphere(1).Solid();

        gp_GTrsf transform;
        transform.SetValue(1, 1, xRadius);
        transform.SetValue(2, 2, yRadius);
        transform.SetValue(3, 3, zRadius);
        transform.SetTranslationPart(gp_XYZ(center.x, center.y, center.z));

        BRepBuilderAPI_GTransform builder(sphere, transform);
        if (builder.IsDone()) {
            TopoDS_Shape ellipsoid = builder.Shape();
            return ShapeResult { ellipsoid, true, "" };
        }
        return ShapeResult { TopoDS_Shape(), false, "" };
    }

    static ShapeResult pyramid(const Pln& ax3, double x, double y, double z)
    {
        if (abs(x) <= Precision::Confusion() || abs(y) <= Precision::Confusion() || abs(z) <= Precision::Confusion()) {
            return ShapeResult { TopoDS_Shape(), false, "Invalid dimensions" };
        }

        gp_Pln pln = Pln::toPln(ax3);
        auto xvec = gp_Vec(pln.XAxis().Direction()).Multiplied(x);
        auto yvec = gp_Vec(pln.YAxis().Direction()).Multiplied(y);
        auto zvec = gp_Vec(pln.Axis().Direction()).Multiplied(z);
        auto p1 = pln.Location();
        auto p2 = p1.Translated(xvec);
        auto p3 = p1.Translated(xvec).Translated(yvec);
        auto p4 = p1.Translated(yvec);
        auto top = pln.Location().Translated((xvec + yvec) * 0.5 + zvec);

        std::vector<TopoDS_Face> faces = {
            TopoDS::Face(pointsToFace({ p1, p2, p3, p4, p1 }).shape), TopoDS::Face(pointsToFace({ p1, p2, top, p1 }).shape),
            TopoDS::Face(pointsToFace({ p2, p3, top, p2 }).shape), TopoDS::Face(pointsToFace({ p3, p4, top, p3 }).shape),
            TopoDS::Face(pointsToFace({ p4, p1, top, p4 }).shape)
        };

        return facesToSolid(faces);
    }

    static ShapeResult pointsToFace(std::vector<gp_Pnt>&& points)
    {
        auto wire = pointsToWire(points);
        if (!wire.isOk) {
            return wire;
        }

        BRepBuilderAPI_MakeFace face(TopoDS::Wire(wire.shape));
        if (!face.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create face" };
        }
        return ShapeResult { face.Face(), true, "" };
    }

    static ShapeResult pointsToWire(std::vector<gp_Pnt>& points)
    {
        BRepBuilderAPI_MakePolygon poly;
        for (auto& p : points) {
            poly.Add(p);
        }
        if (!poly.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create polygon" };
        }
        return ShapeResult { poly.Wire(), true, "" };
    }

    static ShapeResult facesToSolid(const std::vector<TopoDS_Face>& faces)
    {
        TopoDS_Shell shell;
        BRep_Builder shellBuilder;
        shellBuilder.MakeShell(shell);
        for (const auto& face : faces) {
            shellBuilder.Add(shell, face);
        }

        BRepBuilderAPI_MakeSolid solidBuilder(shell);
        if (!solidBuilder.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create solid" };
        }

        return ShapeResult { solidBuilder.Solid(), true, "" };
    }

    static ShapeResult cylinder(const Vector3& normal, const Vector3& center, double radius, double height)
    {
        gp_Ax2 ax2(Vector3::toPnt(center), Vector3::toDir(normal));
        BRepPrimAPI_MakeCylinder cylinder(ax2, radius, height);
        cylinder.Build();
        if (!cylinder.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create cylinder" };
        }
        return ShapeResult { cylinder.Solid(), true, "" };
    }

    // Shared build of `sweep`/`sweepTracked`/`sweepMode`/`sweepModeTracked`: mode setup,
    // profiles added, Build, then MakeSolid — except when the sweep already produced a solid,
    // where MakeSolid throws. A FACE profile is swept as its outer wire: sweeping the face
    // itself raises inside MakePipeShell (and an OCCT raise aborts the whole module with
    // exceptions disabled). `mode` is the profile orientation: 0 = Frenet, 1 = corrected
    // Frenet (the MakePipeShell default, i.e. no SetMode call), 2 = fixed binormal — the
    // profile is carried along the path with `fixedDirection` held as its binormal, which
    // is validated before SetMode: a null gp_Dir raises. Returns an error message, empty on
    // success.
    static std::string buildPipe(BRepOffsetAPI_MakePipeShell& pipe, const std::vector<TopoDS_Shape>& profiles,
        int mode, bool isForceC1, const Vector3& fixedDirection)
    {
        if (mode == 0) {
            pipe.SetMode(true);
        } else if (mode == 2) {
            gp_XYZ direction = Vector3::toXYZ(fixedDirection);
            if (direction.Modulus() < 1e-9) {
                return "Fixed sweep mode requires a non-zero direction";
            }
            pipe.SetMode(gp_Dir(direction));
        } else if (mode != 1) {
            return "Unknown sweep profile mode";
        }
        if (isForceC1) {
            pipe.SetTransitionMode(BRepBuilderAPI_RoundCorner);
            pipe.SetForceApproxC1(isForceC1);
        } else {
            pipe.SetTransitionMode(BRepBuilderAPI_RightCorner);
        }
        for (const auto& profile : profiles) {
            if (profile.ShapeType() == TopAbs_FACE) {
                pipe.Add(BRepTools::OuterWire(TopoDS::Face(profile)));
            } else {
                pipe.Add(profile);
            }
        }
        pipe.Build();
        if (!pipe.IsDone()) {
            return "Failed to sweep profile";
        }
        if (pipe.Shape().ShapeType() != TopAbs_SOLID) {
            pipe.MakeSolid();
            if (!pipe.IsDone()) {
                return "Failed to sweep profile";
            }
        }
        return "";
    }

    static ShapeResult sweep(const ShapeArray& sections, const TopoDS_Wire& path, bool isFrenet, bool isForceC1)
    {
        BRepOffsetAPI_MakePipeShell pipe(path);
        std::string error = buildPipe(pipe, vecFromJSArray<TopoDS_Shape>(sections), isFrenet ? 0 : 1, isForceC1,
            Vector3 { 0, 0, 0 });
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }
        return ShapeResult { pipe.Shape(), true, "" };
    }

    // Single-profile tracked sweep: the TS side sweeps each profile separately (same
    // geometry as the multi-profile call — every profile travels the whole spine) so
    // the history input is one face and `capFaces` names only its own end cap.
    static TrackedShapeResult sweepTracked(const TopoDS_Shape& profile, const TopoDS_Wire& path, bool isFrenet,
        bool isForceC1)
    {
        BRepOffsetAPI_MakePipeShell pipe(path);
        std::string error = buildPipe(pipe, { profile }, isFrenet ? 0 : 1, isForceC1, Vector3 { 0, 0, 0 });
        if (!error.empty()) {
            return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {} };
        }
        TrackedShapeResult result { pipe.Shape(), true, "", faceHistory(pipe, profile, pipe.Shape()),
            edgeHistory(pipe, profile, pipe.Shape()), faceFromEdgeHistory(pipe, profile, pipe.Shape()) };
        result.capFaces = sweepCapFaces(pipe, pipe.Shape());
        return result;
    }

    static ShapeResult sweepMode(const ShapeArray& sections, const TopoDS_Wire& path, int mode, bool isForceC1,
        const Vector3& fixedDirection)
    {
        BRepOffsetAPI_MakePipeShell pipe(path);
        std::string error = buildPipe(pipe, vecFromJSArray<TopoDS_Shape>(sections), mode, isForceC1, fixedDirection);
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }
        return ShapeResult { pipe.Shape(), true, "" };
    }

    static TrackedShapeResult sweepModeTracked(const TopoDS_Shape& profile, const TopoDS_Wire& path, int mode,
        bool isForceC1, const Vector3& fixedDirection)
    {
        BRepOffsetAPI_MakePipeShell pipe(path);
        std::string error = buildPipe(pipe, { profile }, mode, isForceC1, fixedDirection);
        if (!error.empty()) {
            return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {} };
        }
        TrackedShapeResult result { pipe.Shape(), true, "", faceHistory(pipe, profile, pipe.Shape()),
            edgeHistory(pipe, profile, pipe.Shape()), faceFromEdgeHistory(pipe, profile, pipe.Shape()) };
        result.capFaces = sweepCapFaces(pipe, pipe.Shape());
        return result;
    }

    static ShapeResult revolve(const TopoDS_Shape& profile, const Ax1& axis, double rad)
    {
        BRepPrimAPI_MakeRevol revol(profile, Ax1::toAx1(axis), rad);
        if (!revol.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to revolve profile" };
        }
        return ShapeResult { revol.Shape(), true, "" };
    }

    static TrackedShapeResult revolveTracked(const TopoDS_Shape& profile, const Ax1& axis, double rad)
    {
        BRepPrimAPI_MakeRevol revol(profile, Ax1::toAx1(axis), rad);
        if (!revol.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to revolve profile", {}, {} };
        }
        TrackedShapeResult result { revol.Shape(), true, "", faceHistory(revol, profile, revol.Shape()),
            edgeHistory(revol, profile, revol.Shape()), faceFromEdgeHistory(revol, profile, revol.Shape()) };
        result.capFaces = sweepCapFaces(revol, revol.Shape());
        return result;
    }

    static ShapeResult prism(const TopoDS_Shape& profile, const Vector3& vec)
    {
        gp_Vec vec3 = Vector3::toVec(vec);
        BRepPrimAPI_MakePrism prism(profile, vec3);
        if (!prism.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create prism" };
        }
        return ShapeResult { prism.Shape(), true, "" };
    }

    static TrackedShapeResult prismTracked(const TopoDS_Shape& profile, const Vector3& vec)
    {
        gp_Vec vec3 = Vector3::toVec(vec);
        BRepPrimAPI_MakePrism prism(profile, vec3);
        if (!prism.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to create prism", {}, {} };
        }
        TrackedShapeResult result { prism.Shape(), true, "", faceHistory(prism, profile, prism.Shape()),
            edgeHistory(prism, profile, prism.Shape()), faceFromEdgeHistory(prism, profile, prism.Shape()) };
        result.capFaces = sweepCapFaces(prism, prism.Shape());
        return result;
    }

    // Extrudes the profile face up to the limit face, the end capped BY the limit surface
    // itself (BRepFeat_MakePrism::Perform(Until)) instead of by a plane. `mode`: 0 = cut from
    // `sbase`, 1 = fuse into `sbase`, 2 = the limited prism alone (BRepFeat's JustFeat —
    // `sbase` then feeds only the internal length estimate, so the limit face itself is used).
    //
    // The limit handed to OCCT is a padded natural-restriction copy of `until`'s surface (see
    // `paddedLimitFace`) — a trimmed solid face would take the gluer path, which a profile
    // floating off the base body cannot survive — so every cap is checked against the real
    // face afterwards (`capsOnLimitFace`): a cap past its boundary is a refusal, not a shape.
    //
    // Every guard runs BEFORE any OCCT call: Perform raises on a null or face-less limit and
    // gp_Dir on a zero vector — with exception catching disabled (Release) a raise aborts the
    // whole module. The history input mirrors the tracked boolean's [args, tools]: base first
    // (mode 0/1), then the profile and the limit face — the limit slot holds the padded copy,
    // whose single face index coincides with the original's for the caller's enumeration.
    static TrackedShapeResult prismToFaceTracked(const TopoDS_Shape& sbase, const TopoDS_Shape& pbase,
        const TopoDS_Shape& until, const Vector3& direction, int mode)
    {
        if (pbase.ShapeType() != TopAbs_FACE) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Prism base must be a face", {}, {} };
        }
        if (until.IsNull() || until.ShapeType() != TopAbs_FACE) {
            return TrackedShapeResult { TopoDS_Shape(), false, "The limit must be a single face", {}, {} };
        }
        if (mode < 0 || mode > 2 || (mode != 2 && sbase.IsNull())) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Invalid prism-to-face arguments", {}, {} };
        }
        gp_XYZ xyz = Vector3::toXYZ(direction);
        if (xyz.Modulus() < 1e-9) {
            return TrackedShapeResult { TopoDS_Shape(), false, "The direction is zero", {}, {} };
        }
        try {
            // The padding margin spans everything involved: past the profile and past the
            // base, so the copy covers wherever the sweep can cross the real face.
            Bnd_Box span;
            BRepBndLib::Add(pbase, span);
            BRepBndLib::Add(until, span);
            if (mode != 2) {
                BRepBndLib::Add(sbase, span);
            }
            const double margin = 3.0 * std::sqrt(span.SquareExtent());
            const TopoDS_Face& limit = TopoDS::Face(until);
            TopoDS_Face padded = paddedLimitFace(limit, margin);
            // The padded copy takes the boolean path (a floating profile survives it), the
            // face as given the gluer path (a limit that IS a face of the base survives
            // that); try the boolean first.
            std::string error = "Failed to prism up to the face";
            int attemptIndex = 0;
            for (const TopoDS_Face& attempt : { padded, limit }) {
                attemptIndex++;
                if (attempt.IsNull()) {
                    continue;
                }
                TrackedShapeResult built = prismToFaceAttempt(sbase, pbase, limit, attempt, xyz, mode);
                if (built.isOk) {
                    return built;
                }
                error += " | attempt " + std::to_string(attemptIndex) + ": " + built.error;
            }
            return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {} };
        } catch (const Standard_Failure& failure) {
            const char* message = failure.GetMessageString();
            return TrackedShapeResult { TopoDS_Shape(), false,
                message != nullptr ? message : "Failed to prism up to the face", {}, {} };
        }
    }

    // One BRepFeat attempt with `attempt` as the Until, validated against the REAL limit face:
    // refused (with the kernel's status error worded in) unless every cap lies on the limit
    // (`capsOnLimitFace`) and — for join/cut — the base's volume actually moved, which a
    // silently empty build the gluer reports as success does not.
    static TrackedShapeResult prismToFaceAttempt(const TopoDS_Shape& sbase, const TopoDS_Shape& pbase,
        const TopoDS_Face& limit, const TopoDS_Face& attempt, const gp_XYZ& direction, int mode)
    {
        const TopoDS_Shape& base = mode == 2 ? attempt : sbase;
        BRepFeat_MakePrism prism(base, pbase, TopoDS::Face(pbase), gp_Dir(direction), mode, false);
        prism.Perform(attempt);
        // The gluer path can report success with an empty shape — refuse it like a failure.
        if (!prism.IsDone() || prism.Shape().IsNull() || !TopExp_Explorer(prism.Shape(), TopAbs_FACE).More()) {
            return TrackedShapeResult { TopoDS_Shape(), false,
                "Failed to prism up to the face (status " + std::to_string(static_cast<int>(prism.CurrentStatusError())) + ")", {}, {} };
        }
        const TopoDS_Shape& result = prism.Shape();
        if (!capsOnLimitFace(result, limit, mode == 2 ? TopoDS_Shape() : sbase)) {
            return TrackedShapeResult { TopoDS_Shape(), false,
                "The limit face does not cover the prism cross-section", {}, {} };
        }
        if (mode != 2) {
            const double before = exactVolume(sbase);
            const double after = exactVolume(result);
            const double slack = 1e-6 * std::fabs(before) + 1e-9;
            if (!(mode == 1 ? after > before + slack : after < before - slack)) {
                return TrackedShapeResult { TopoDS_Shape(), false,
                    "The prism did not reach the limit face", {}, {} };
            }
        }
        TopoDS_Compound input = mode == 2 ? compoundOf({ pbase, attempt })
                                          : compoundOf({ sbase, pbase, attempt });
        TrackedShapeResult tracked { result, true, "", faceHistory(prism, input, result),
            edgeHistory(prism, input, result) };
        // The side faces are edge-generated from the profile, exactly like a plain prism's.
        tracked.faceEdgeMap = faceFromEdgeHistory(prism, pbase, result);
        return tracked;
    }

    static ShapeResult pushPull(const TopoDS_Shape& sbase, const TopoDS_Shape& pbase, const Vector3& vec)
    {
        gp_Vec v = Vector3::toVec(vec);
        gp_Trsf trsf;
        trsf.SetTranslation(v);
        BRepBuilderAPI_Transform transform(trsf);
        transform.Perform(pbase);
        gp_Dir dir(v);
        auto sur = BRep_Tool::Surface(TopoDS::Face(pbase));
        auto plane = Handle(Geom_Plane)::DownCast(sur);
        auto method = plane->Pln().Axis().Direction().Dot(dir) > 0 ? 1 : 0;
        if (pbase.Orientation() == TopAbs_REVERSED) {
            method = 1 - method;
        }
        BRepFeat_MakePrism prism(sbase, pbase, TopoDS::Face(transform.Shape()), dir, method, false);
        prism.Perform(v.Magnitude());
        if (!prism.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create prism" };
        }
        return ShapeResult { prism.Shape(), true, "" };
    }

    static ShapeResult polygon(const Vector3Array& points)
    {
        std::vector<Vector3> vector3s = vecFromJSArray<Vector3>(points);
        std::vector<gp_Pnt> pnts;
        for (auto& p : vector3s) {
            pnts.push_back(Vector3::toPnt(p));
        }
        return pointsToWire(pnts);
    }

    static ShapeResult arc(const Vector3& normal, const Vector3& center, const Vector3& start, double rad)
    {
        gp_Pnt centerPnt = Vector3::toPnt(center);
        gp_Pnt startPnt = Vector3::toPnt(start);
        gp_Dir xvec = gp_Dir(startPnt.XYZ() - centerPnt.XYZ());
        gp_Ax2 ax2(centerPnt, Vector3::toDir(normal), xvec);
        gp_Circ circ(ax2, centerPnt.Distance(startPnt));
        double startAng(0), endAng(rad);
        if (rad < 0) {
            startAng = Math::PI_2 + rad;
            endAng = Math::PI_2;
        }
        BRepBuilderAPI_MakeEdge edge(circ, startAng, endAng);
        if (!edge.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create arc" };
        }
        return ShapeResult { edge.Edge(), true, "" };
    }

    static ShapeResult circle(const Vector3& normal, const Vector3& center, double radius)
    {
        gp_Ax2 ax2(Vector3::toPnt(center), Vector3::toDir(normal));
        gp_Circ circ(ax2, radius);
        BRepBuilderAPI_MakeEdge edge(circ);
        if (!edge.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create circle" };
        }
        return ShapeResult { edge.Edge(), true, "" };
    }

    static ShapeResult rect(const Pln& pln, double width, double height)
    {
        BRepBuilderAPI_MakeFace makeFace(Pln::toPln(pln), 0, width, 0, height);
        if (!makeFace.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create rectangle" };
        }
        return ShapeResult { makeFace.Face(), true, "" };
    }

    static ShapeResult bezier(const Vector3Array& points, const NumberArray& weights)
    {
        std::vector<Vector3> pts = vecFromJSArray<Vector3>(points);
        // Nothing below may raise, for the same reason the B-spline's guards are here: the Release
        // build catches nothing, so a raise inside the kernel aborts the module. A pole list of
        // fewer than two is one of the ways in — `Geom_BezierCurve` refuses it outright — and it
        // is what a program that left `points` out arrives as, which the AI tool path can reach.
        if (pts.size() < 2) {
            return ShapeResult { TopoDS_Shape(), false, "A bezier needs at least two poles" };
        }
        std::string error = poleError("A bezier", pts);
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }

        std::vector<double> wts = vecFromJSArray<double>(weights);
        error = weightError("A bezier", wts, static_cast<int>(pts.size()));
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }

        NCollection_Array1<gp_Pnt> arrayofPnt(1, pts.size());
        for (int i = 0; i < pts.size(); i++) {
            arrayofPnt.SetValue(i + 1, Vector3::toPnt(pts[i]));
        }

        NCollection_Array1<double> arrayOfWeight(1, wts.size());
        for (int i = 0; i < wts.size(); i++) {
            arrayOfWeight.SetValue(i + 1, wts[i]);
        }

        Handle(Geom_Curve) curve = wts.size() > 0 ? new Geom_BezierCurve(arrayofPnt, arrayOfWeight) : new Geom_BezierCurve(arrayofPnt);
        BRepBuilderAPI_MakeEdge edge(curve);
        if (!edge.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create bezier" };
        }
        return ShapeResult { edge.Edge(), true, "" };
    }

    /// A rational B-spline (NURBS) edge, of which `bezier` is the special case. `knots` is the
    /// *flat* vector the sketch entity stores — one entry per index, repeats and all, its length
    /// always poles + degree + 1 — folded here into the distinct knots and multiplicities the
    /// kernel takes. An empty `weights` means the non-rational form.
    ///
    /// Nothing below may raise: the Release build sets `-sDISABLE_EXCEPTION_CATCHING=1`, so an
    /// OCCT raise aborts the module instead of unwinding. Every way the kernel could refuse the
    /// input — a degree out of range or past what the pole count carries, a decreasing or
    /// unclamped knot vector, an interior multiplicity past the degree, knots too close to tell
    /// apart, a weight it cannot divide by — is answered here first, before the curve is built.
    static ShapeResult bspline(
        const Vector3Array& poles, const NumberArray& weights, const NumberArray& knots, int degree)
    {
        std::vector<Vector3> pts = vecFromJSArray<Vector3>(poles);
        int count = static_cast<int>(pts.size());
        if (degree < 1 || degree > Geom_BSplineCurve::MaxDegree()) {
            return ShapeResult { TopoDS_Shape(), false, "A bspline degree is out of range" };
        }
        if (count < degree + 1) {
            return ShapeResult { TopoDS_Shape(), false, "A bspline needs at least degree + 1 poles" };
        }
        std::string error = poleError("A bspline", pts);
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }

        std::vector<double> wts = vecFromJSArray<double>(weights);
        error = weightError("A bspline", wts, count);
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }

        std::vector<double> kn = vecFromJSArray<double>(knots);
        if (static_cast<int>(kn.size()) != count + degree + 1) {
            return ShapeResult { TopoDS_Shape(), false, "A bspline knot vector is poles + degree + 1 long" };
        }
        std::vector<double> distinct;
        std::vector<int> mults;
        error = foldKnots(kn, degree, distinct, mults);
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }

        BRepBuilderAPI_MakeEdge edge(makeBsplineCurve(pts, wts, distinct, mults, degree));
        if (!edge.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create bspline" };
        }
        return ShapeResult { edge.Edge(), true, "" };
    }

    /// The reason a pole list is not one the kernel takes for `kind` — which the message names,
    /// there being more than one curve that takes poles — or `""` when it is. `CheckCurveData` is
    /// about degree and knots and reads the coordinates not at all, so a non-finite pole reaches
    /// the curve's own arithmetic — where a raise is an abort, the Release build catching nothing.
    static std::string poleError(const char* kind, const std::vector<Vector3>& pts)
    {
        for (size_t i = 0; i < pts.size(); i++) {
            if (!std::isfinite(pts[i].x) || !std::isfinite(pts[i].y) || !std::isfinite(pts[i].z)) {
                return std::string(kind) + " pole must be finite";
            }
        }
        return "";
    }

    /// The reason a weight list is not one the kernel takes for `kind` — which the message names,
    /// there being more than one curve that takes weights — or `""` when it is. An empty list is
    /// the non-rational form and always fits.
    static std::string weightError(const char* kind, const std::vector<double>& wts, int count)
    {
        if (!wts.empty() && static_cast<int>(wts.size()) != count) {
            return std::string(kind) + " needs one weight per pole";
        }
        for (size_t i = 0; i < wts.size(); i++) {
            // `gp::Resolution()`, not a comfortable epsilon: it is the bound the kernel's own
            // `CheckCurveData` refuses on, and the documented contract here is "a non-positive
            // weight comes back as an error" — anything above this the kernel builds, so
            // refusing more would refuse curves it accepts.
            if (!std::isfinite(wts[i]) || wts[i] <= gp::Resolution()) {
                return std::string(kind) + " weight must be positive";
            }
        }
        return "";
    }

    /// Folds the *flat* knot vector — one entry per index, repeats and all — into the distinct
    /// knots and multiplicities the kernel takes, or returns the reason it is not one it accepts.
    /// The last of those reasons matters as much as the first: an interval between distinct knots
    /// thinner than an ULP is what `CheckCurveData` refuses, so knots that close fold here too.
    /// The caller has checked the vector's length, so the fold always has both ends to read.
    static std::string foldKnots(
        const std::vector<double>& kn,
        int degree,
        std::vector<double>& distinct,
        std::vector<int>& mults)
    {
        for (size_t i = 0; i < kn.size(); i++) {
            if (!std::isfinite(kn[i])) {
                return "A bspline knot must be finite";
            }
            if (!distinct.empty() && kn[i] < distinct.back()) {
                return "A bspline knot vector must not decrease";
            }
            if (!distinct.empty() && kn[i] - distinct.back() <= Epsilon(std::abs(distinct.back()))) {
                mults.back() += 1;
            } else {
                distinct.push_back(kn[i]);
                mults.push_back(1);
            }
        }
        // non-periodic: clamped at both ends, and no interior multiplicity past the degree
        if (mults.front() != degree + 1 || mults.back() != degree + 1) {
            return "A bspline must be clamped at both ends";
        }
        for (size_t i = 1; i + 1 < mults.size(); i++) {
            if (mults[i] > degree) {
                return "A bspline knot multiplicity is too high";
            }
        }
        return "";
    }

    /// The kernel curve for a bspline whose poles, weights and knots have all been checked: the
    /// four arrays `Geom_BSplineCurve` reads, built as the one call that needs them all at once.
    static Handle(Geom_Curve) makeBsplineCurve(
        const std::vector<Vector3>& pts,
        const std::vector<double>& wts,
        const std::vector<double>& distinct,
        const std::vector<int>& mults,
        int degree)
    {
        int count = static_cast<int>(pts.size());
        NCollection_Array1<gp_Pnt> arrayofPnt(1, count);
        for (int i = 0; i < count; i++) {
            arrayofPnt.SetValue(i + 1, Vector3::toPnt(pts[i]));
        }
        NCollection_Array1<double> arrayOfWeight(1, count);
        for (int i = 0; i < count; i++) {
            arrayOfWeight.SetValue(i + 1, wts.empty() ? 1.0 : wts[i]);
        }
        NCollection_Array1<double> arrayOfKnot(1, static_cast<int>(distinct.size()));
        NCollection_Array1<int> arrayOfMult(1, static_cast<int>(mults.size()));
        for (size_t i = 0; i < distinct.size(); i++) {
            arrayOfKnot.SetValue(static_cast<int>(i) + 1, distinct[i]);
            arrayOfMult.SetValue(static_cast<int>(i) + 1, mults[i]);
        }
        return new Geom_BSplineCurve(arrayofPnt, arrayOfWeight, arrayOfKnot, arrayOfMult, degree);
    }

    static ShapeResult helix(
        const Vector3& origin,
        const Vector3& normal,
        const Vector3& xDir,
        double radius,
        double pitch,
        double angle)
    {
        if (radius < Precision::Confusion()) {
            return ShapeResult { TopoDS_Shape(), false, "The radius is too small." };
        }
        if (std::abs(pitch) < Precision::Confusion()) {
            return ShapeResult { TopoDS_Shape(), false, "The pitch is too small." };
        }
        if (std::abs(angle) < Precision::Angular()) {
            return ShapeResult { TopoDS_Shape(), false, "The angle is too small." };
        }

        gp_Ax3 axis(Vector3::toPnt(origin), Vector3::toDir(normal), Vector3::toDir(xDir));

        NCollection_Array1<double> pitches(1, 1);
        pitches(1) = pitch;
        NCollection_Array1<double> nbTurns(1, 1);
        nbTurns(1) = std::abs(angle) / Math::PI_2;

        HelixBRep_BuilderHelix helixBuilder;
        helixBuilder.SetParameters(axis, 2.0 * radius, pitches, nbTurns);
        helixBuilder.Perform();

        if (helixBuilder.ErrorStatus() != 0) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create helix" };
        }

        return ShapeResult { helixBuilder.Shape(), true, "" };
    }

    static ShapeResult point(const Vector3& point)
    {
        BRepBuilderAPI_MakeVertex makeVertex(Vector3::toPnt(point));
        if (!makeVertex.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create point" };
        }
        return ShapeResult { makeVertex.Vertex(), true, "" };
    }

    static ShapeResult line(const Vector3& start, const Vector3& end)
    {
        BRepBuilderAPI_MakeEdge makeEdge(Vector3::toPnt(start), Vector3::toPnt(end));
        if (!makeEdge.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create line" };
        }
        return ShapeResult { makeEdge.Edge(), true, "" };
    }

    struct EdgeEndpoints {
        gp_Pnt first;
        gp_Pnt last;
    };

    // Returns the unused edge whose endpoint is nearest to either chain end within confusion
    // tolerance, or ends.size() when nothing connects. `prepend` selects the chain end to
    // extend, `reversed` tells whether the edge must be flipped to continue the chain.
    static size_t nextChainEdge(
        const std::vector<EdgeEndpoints>& ends,
        const std::vector<bool>& used,
        const gp_Pnt& front,
        const gp_Pnt& back,
        bool& prepend,
        bool& reversed)
    {
        size_t next = ends.size();
        double best = Precision::Confusion() * Precision::Confusion();
        for (size_t i = 0; i < ends.size(); i++) {
            if (used[i]) {
                continue;
            }
            auto tryCandidate = [&](double squareDistance, bool candidatePrepend, bool candidateReversed) {
                if (squareDistance < best) {
                    best = squareDistance;
                    next = i;
                    prepend = candidatePrepend;
                    reversed = candidateReversed;
                }
            };
            tryCandidate(back.SquareDistance(ends[i].first), false, false);
            tryCandidate(back.SquareDistance(ends[i].last), false, true);
            tryCandidate(front.SquareDistance(ends[i].last), true, false);
            tryCandidate(front.SquareDistance(ends[i].first), true, true);
        }
        return next;
    }

    // Chains edges into a wire deterministically: start from the first edge, then repeatedly
    // extend the chain at whichever end has the nearest connecting edge, reversing edges
    // that connect backwards. Extending at both ends is required because the first edge may
    // sit anywhere along the geometric chain. ShapeAnalysis_WireOrder was dropped: with
    // near-coincident endpoints (e.g. edges from an offset curve) it could assign a wrong
    // orientation, twisting the wire.
    static bool orderEdge(const std::vector<TopoDS_Edge>& edges, std::vector<TopoDS_Edge>& ordered)
    {
        ShapeAnalysis_Edge analysis;
        std::vector<EdgeEndpoints> ends;
        ends.reserve(edges.size());
        for (const auto& edge : edges) {
            ends.push_back(
                { BRep_Tool::Pnt(analysis.FirstVertex(edge)), BRep_Tool::Pnt(analysis.LastVertex(edge)) });
        }

        std::vector<bool> used(edges.size(), false);
        used[0] = true;
        std::deque<std::pair<size_t, bool>> chain; // (edge index, reversed)
        chain.emplace_back(0, false);
        gp_Pnt front = ends[0].first;
        gp_Pnt back = ends[0].last;

        for (size_t count = 1; count < edges.size(); count++) {
            bool prepend = false;
            bool reversed = false;
            size_t next = nextChainEdge(ends, used, front, back, prepend, reversed);
            if (next == edges.size()) {
                return false; // remaining edges are disconnected from the chain
            }
            if (prepend) {
                chain.emplace_front(next, reversed);
                front = reversed ? ends[next].last : ends[next].first;
            } else {
                chain.emplace_back(next, reversed);
                back = reversed ? ends[next].first : ends[next].last;
            }
            used[next] = true;
        }

        ordered.reserve(edges.size());
        for (const auto& [index, reversed] : chain) {
            TopoDS_Edge edge = edges[index];
            if (reversed) {
                edge.Reverse();
            }
            ordered.push_back(edge);
        }
        return true;
    }

    static ShapeResult wire(const EdgeArray& edges)
    {
        std::vector<TopoDS_Edge> edgesVec = vecFromJSArray<TopoDS_Edge>(edges);
        if (edgesVec.size() == 0) {
            return ShapeResult { TopoDS_Shape(), false, "No edges provided" };
        }

        // BRepBuilderAPI_MakeWire replaces coincident vertices of the added edges in place
        // (vertex sharing). Repeated calls with the same input edges would progressively
        // corrupt them, so build from copies instead.
        std::vector<TopoDS_Edge> copies;
        copies.reserve(edgesVec.size());
        for (auto& edge : edgesVec) {
            copies.push_back(TopoDS::Edge(BRepBuilderAPI_Copy(edge).Shape()));
        }

        BRepBuilderAPI_MakeWire wire;
        if (copies.size() == 1) {
            wire.Add(copies[0]);
        } else {
            std::vector<TopoDS_Edge> ordered;
            if (!orderEdge(copies, ordered)) {
                return ShapeResult { TopoDS_Shape(), false, mapBuildWireError(BRepBuilderAPI_DisconnectedWire) };
            }
            for (const auto& edge : ordered) {
                wire.Add(edge);
            }
        }

        if (!wire.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, mapBuildWireError(wire.Error()) };
        }
        return ShapeResult { wire.Wire(), true, "" };
    }

    static ShapeResult face(const WireArray& wires)
    {
        std::vector<TopoDS_Wire> wiresVec = vecFromJSArray<TopoDS_Wire>(wires);
        BRepBuilderAPI_MakeFace makeFace(wiresVec[0]);
        for (int i = 1; i < wiresVec.size(); i++) {
            makeFace.Add(wiresVec[i]);
        }
        if (!makeFace.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create face" };
        }

        ShapeFix_Face faceFix(makeFace.Face());
        faceFix.FixOrientation();
        faceFix.Perform();

        return ShapeResult { faceFix.Face(), true, "" };
    }

    static ShapeResult faceFromSurface(const WireArray& wires, const TopoDS_Face& sourceFace)
    {
        std::vector<TopoDS_Wire> wiresVec = vecFromJSArray<TopoDS_Wire>(wires);
        Handle(Geom_Surface) surface = BRep_Tool::Surface(sourceFace);
        for (auto& w : wiresVec) {
            ShapeFix_Wire sfw(w, sourceFace, Precision::Confusion());
            sfw.FixReorder();
            sfw.FixConnected();
            sfw.Perform();
            w = sfw.Wire();
        }

        BRepBuilderAPI_MakeFace makeFace(surface, wiresVec[0]);
        for (int i = 1; i < wiresVec.size(); i++) {
            makeFace.Add(wiresVec[i]);
        }
        if (!makeFace.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create face from surface" };
        }

        TopoDS_Face result = makeFace.Face();

        // Rebuild pcurves on the new face — missing pcurves cause mesh defects.
        BRepLib::BuildCurves3d(result, Precision::Confusion());

        ShapeFix_Face faceFix(result);
        faceFix.FixOrientation();
        faceFix.Perform();

        return ShapeResult { faceFix.Face(), true, "" };
    }

    static RegionsResult facesFromEdges(const EdgeArray& edges, const Pln& plane)
    {
        std::vector<TopoDS_Edge> edgesVec = vecFromJSArray<TopoDS_Edge>(edges);
        if (edgesVec.empty()) {
            return RegionsResult { ShapeArray(val::array()), {}, {}, false, "No edges provided" };
        }

        NCollection_List<TopoDS_Shape> arguments;
        for (const auto& edge : edgesVec) {
            arguments.Append(edge);
        }
        SplitEdgesResult split = splitAtIntersections(arguments);
        if (!split.isOk) {
            return RegionsResult { ShapeArray(val::array()), {}, {}, false, split.error };
        }

        NCollection_List<TopoDS_Shape> faceEdges;
        double extent;
        TopoDS_Face baseFace = baseFaceForRegions(split.shape, Pln::toPln(plane), faceEdges, extent);
        return boundedAreas(baseFace, faceEdges, extent, split.segments, split.segmentSources);
    }

    static ShapeResult shell(const FaceArray& faces)
    {
        std::vector<TopoDS_Face> facesVec = vecFromJSArray<TopoDS_Face>(faces);

        TopoDS_Shell shell;
        BRep_Builder shellBuilder;
        shellBuilder.MakeShell(shell);
        for (const auto& face : facesVec) {
            shellBuilder.Add(shell, face);
        }

        return ShapeResult { shell, true, "" };
    }

    // BRepBuilderAPI_MakeSolid accepts anything it is handed: an OPEN shell, and any number of
    // unrelated ones, each becomes a "solid" as soon as the builder is done. Downstream every
    // boolean, offset and export takes that at face value, and all of them fail on a shell that
    // never closes — the split/face tools used to pile exactly such shells up. A solid built
    // here must at least be closed; several closed shells (a body with voids) remain valid.
    static ShapeResult solid(const ShellArray& shells)
    {
        std::vector<TopoDS_Shell> shellsVec = vecFromJSArray<TopoDS_Shell>(shells);
        if (shellsVec.empty()) {
            return ShapeResult { TopoDS_Shape(), false, "No shells provided" };
        }

        BRepBuilderAPI_MakeSolid makeSolid;
        for (auto shell : shellsVec) {
            if (shell.IsNull() || !BRep_Tool::IsClosed(shell)) {
                return ShapeResult { TopoDS_Shape(), false, "Shell is not closed" };
            }
            makeSolid.Add(shell);
        }
        if (!makeSolid.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create solid" };
        }
        return ShapeResult { makeSolid.Solid(), true, "" };
    }

    // A thicken's result is INSIDE-OUT whenever the offset runs along the input face's own
    // normal: measured on a box, thickening the top by -2 gives volume +400 while the
    // bottom's +2 gives -400, and a cylinder side gives -691 at +1 but +565 at -1. The
    // materials render DoubleSide, so it does not show on screen — but Measure prints the
    // volume straight to the user (`commands/measure/select.ts`), and an export writes the
    // triangles winding inward.
    //
    // Reversing the solid's own orientation flag fixes the sign without rebuilding a single
    // TShape, so `IsSame` and every index map taken from the same result stay valid.
    static TopoDS_Shape orientedOutward(const TopoDS_Shape& shape)
    {
        TopExp_Explorer solidExplorer(shape, TopAbs_SOLID);
        if (!solidExplorer.More()) {
            return shape;
        }
        GProp_GProps props;
        BRepGProp::VolumeProperties(shape, props);
        if (props.Mass() >= 0) {
            return shape;
        }
        TopoDS_Shape reversed = shape;
        reversed.Reverse();
        return reversed;
    }

    static ShapeResult makeThickSolidBySimple(const TopoDS_Shape& shape, double thickness)
    {
        BRepOffsetAPI_MakeThickSolid makeThickSolid;
        makeThickSolid.MakeThickSolidBySimple(shape, thickness);
        if (!makeThickSolid.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create thick solid" };
        }
        return ShapeResult { orientedOutward(makeThickSolid.Shape()), true, "" };
    }

    static TrackedShapeResult makeThickSolidBySimpleTracked(const TopoDS_Shape& shape, double thickness)
    {
        BRepOffsetAPI_MakeThickSolid makeThickSolid;
        makeThickSolid.MakeThickSolidBySimple(shape, thickness);
        if (!makeThickSolid.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to create thick solid", {}, {} };
        }
        const TopoDS_Shape result = orientedOutward(makeThickSolid.Shape());
        return TrackedShapeResult { result, true, "", faceHistory(makeThickSolid, shape, result),
            edgeHistory(makeThickSolid, shape, result), faceFromEdgeHistory(makeThickSolid, shape, result),
            {}, offsetHistory(makeThickSolid, shape, result, TopAbs_FACE),
            offsetHistory(makeThickSolid, shape, result, TopAbs_EDGE) };
    }

    static ShapeResult makeThickSolidByJoin(const TopoDS_Shape& shape,
        const ShapeArray& shapes,
        double thickness,
        const GeomAbs_JoinType& joinType,
        const BRepOffset_Mode& mode,
        bool intersection)
    {
        auto shapesList = shapeArrayToListOfShape(shapes);

        BRepOffsetAPI_MakeThickSolid makeThickSolid;
        makeThickSolid.MakeThickSolidByJoin(shape, shapesList, thickness, 1e-6, mode, intersection, false, joinType);
        if (!makeThickSolid.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create thick solid" };
        }
        return ShapeResult { makeThickSolid.Shape(), true, "" };
    }

    static TrackedShapeResult makeThickSolidByJoinTracked(const TopoDS_Shape& shape,
        const ShapeArray& shapes,
        double thickness,
        const GeomAbs_JoinType& joinType,
        const BRepOffset_Mode& mode,
        bool intersection)
    {
        auto shapesList = shapeArrayToListOfShape(shapes);

        BRepOffsetAPI_MakeThickSolid makeThickSolid;
        makeThickSolid.MakeThickSolidByJoin(shape, shapesList, thickness, 1e-6, mode, intersection, false, joinType);
        if (!makeThickSolid.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to create thick solid", {}, {} };
        }
        const TopoDS_Shape result = makeThickSolid.Shape();
        // The closing faces are the removed set of the FACE offset channel only. The EDGE
        // channel needs no skip: a closing face's boundary edges also bound kept faces, so
        // they survive as themselves and the identity subtraction handles them (measured:
        // five box/cylinder cases, no spurious edge entry).
        const auto openFaces = shapeArrayToMapOfShape(shapes);
        return TrackedShapeResult { result, true, "", faceHistory(makeThickSolid, shape, result),
            edgeHistory(makeThickSolid, shape, result), faceFromEdgeHistory(makeThickSolid, shape, result),
            {}, offsetHistory(makeThickSolid, shape, result, TopAbs_FACE, &openFaces),
            offsetHistory(makeThickSolid, shape, result, TopAbs_EDGE) };
    }

    // The neutral plane a draft rotates about, from the JS-side plane carrier. Deliberately
    // NOT `Pln::toPln`: that builds a gp_Ax3, which raises when the x direction is not
    // orthogonal to the normal — and a draft reads only the plane's POSITION and NORMAL,
    // never its frame. The host's transform may carry a non-uniform scale, which the
    // caller's world-to-local mapping of the plane can turn non-orthogonal.
    static gp_Pln toNeutralPlane(const Pln& plane)
    {
        return gp_Pln(Vector3::toPnt(plane.location), Vector3::toDir(plane.direction));
    }

    // Adds every face of `facesVec` to `draft` and builds it. False (with `error` set) when
    // anything would make the algorithm raise — which under -sDISABLE_EXCEPTION_CATCHING=1
    // aborts the whole module, so both guards are load-bearing:
    //
    // - A face that is not a sub-shape of `shape` is rejected up front: the algorithm never
    //   checks membership, and the edge-to-face index it walks (`Draft_Modification::Add`)
    //   raises Standard_NoSuchObject on a foreign face's edges.
    // - A failed `Add` returns BEFORE `Build()`: `Perform()`, which Build calls with no
    //   try/catch, raises Standard_ConstructionError while a face is problematic. `AddDone()`
    //   is what reports that state (its implementation is ProblematicShape().IsNull(), NOT
    //   IsDone() — see BRepOffsetAPI_DraftAngle.cxx).
    //
    // A face is problematic when its surface is not planar, cylindrical or conical: OCCT
    // computes the tapered surface EAGERLY (the Flag of Add defaults to true) and reports
    // failure instead of silently skipping the face, which is the behaviour a feature wants.
    static bool buildDraft(BRepOffsetAPI_DraftAngle& draft, const TopoDS_Shape& shape,
        const std::vector<TopoDS_Face>& facesVec, const gp_Dir& direction, double angle,
        const gp_Pln& neutralPlane, std::string& error)
    {
        if (facesVec.empty()) {
            error = "No faces to draft";
            return false;
        }
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> shapeFaces;
        TopExp::MapShapes(shape, TopAbs_FACE, shapeFaces);
        for (const TopoDS_Face& face : facesVec) {
            if (shapeFaces.FindIndex(face) <= 0) {
                error = "Face does not belong to the shape";
                return false;
            }
        }
        for (const TopoDS_Face& face : facesVec) {
            draft.Add(face, direction, angle, neutralPlane);
            if (!draft.AddDone()) {
                error = "Only planar, cylindrical and conical faces can be drafted";
                return false;
            }
        }
        draft.Build();
        if (!draft.IsDone()) {
            error = "Failed to draft";
            return false;
        }
        return true;
    }

    // Draft: taper each of `faces` about its intersection line with `neutralPlane`, rotating
    // it by `angle` (radians). `direction` is the pull direction — the side of the plane a
    // POSITIVE angle removes material from (OCCT's convention), so the UI's "opposite
    // direction" reaches the kernel by flipping it. `faces` must be sub-shapes of `shape`
    // (same TShape), which the caller resolves off the shape it holds.
    static ShapeResult draft(const TopoDS_Shape& shape, const ShapeArray& faces,
        const Vector3& direction, double angle, const Pln& neutralPlane)
    {
        std::string error;
        BRepOffsetAPI_DraftAngle draft(shape);
        bool done = buildDraft(draft, shape, vecFromJSArray<TopoDS_Face>(faces), Vector3::toDir(direction),
            angle, toNeutralPlane(neutralPlane), error);
        if (!done) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }
        return ShapeResult { draft.Shape(), true, "" };
    }

    static TrackedShapeResult draftTracked(const TopoDS_Shape& shape, const ShapeArray& faces,
        const Vector3& direction, double angle, const Pln& neutralPlane)
    {
        std::string error;
        BRepOffsetAPI_DraftAngle draft(shape);
        bool done = buildDraft(draft, shape, vecFromJSArray<TopoDS_Face>(faces), Vector3::toDir(direction),
            angle, toNeutralPlane(neutralPlane), error);
        if (!done) {
            return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {} };
        }
        const TopoDS_Shape result = draft.Shape();
        // `faceFromEdgeHistory` and both offset channels stay empty, and that is correct
        // rather than an omission: `BRepOffsetAPI_DraftAngle::Generated` only answers for
        // FACES (an edge generates nothing), and a draft has no parallel-copy channel the
        // way a thicken does. A face the draft simply TILTS still reports here — through
        // Generated, which `mapInputShape` reads beside Modified — so it keeps the id of
        // the face it was.
        return TrackedShapeResult { result, true, "", faceHistory(draft, shape, result),
            edgeHistory(draft, shape, result), {}, {}, {}, {} };
    }

    // A fresh copy of `shape` to hand one offset attempt, with the face enumeration the picked
    // indices were taken on: OCCT repairs its input in place, so every build gets a copy of its own,
    // and the copy has to enumerate the same faces or the indices would name others. False when it
    // does not — the attempt then cannot run at all, which is a failure like any other.
    static bool copyForBuild(const TopoDS_Shape& shape,
        const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, TopoDS_Shape& copy,
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& copyFaces)
    {
        copy = BRepBuilderAPI_Copy(shape, true, false).Shape();
        TopExp::MapShapes(copy, TopAbs_FACE, copyFaces);
        return copyFaces.Extent() == faces.Extent();
    }

    // One failed attempt: not-ok with no message and no report. The three below are tried in order and
    // only the LAST one to fail has anything to say (see `explainOffset`), so an attempt that did not
    // work carries nothing.
    static TrackedShapeResult noOffset()
    {
        return TrackedShapeResult { TopoDS_Shape(), false, "", {}, {} };
    }

    // The plain per-face offset of `picked`, on a copy of its own. `moving` is the picked faces and
    // everything OCCT moves with them (see `smoothClosure`) — what `offsetIsGood` verifies.
    static TrackedShapeResult plainOffsetAttempt(const TopoDS_Shape& shape,
        const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
        const std::vector<int>& moving, double distance)
    {
        TopoDS_Shape copy;
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> copyFaces;
        if (!copyForBuild(shape, faces, copy, copyFaces))
            return noOffset();
        BRepOffset_MakeOffset builder;
        TopoDS_Shape result;
        if (!buildOffset(builder, copy, copyFaces, picked, distance, result) || !offsetIsGood(builder, copy, copyFaces, moving, result, distance)) {
            return noOffset();
        }
        return TrackedShapeResult { result, true, "", faceHistory(builder, copy, result),
            edgeHistory(builder, copy, result), {}, {}, {}, {} };
    }

    // The offset that keeps the rounds at their own radius, tried FIRST and only when the caller named
    // some: OCCT would move a round with the face it runs into and change its radius (see
    // `buildReblendedOffset`). When this works the plain path never runs; when it does not, the
    // caller still has to classify the failure — `roundsAtRisk` says whether a round was actually
    // beside a moving face, which is what decides between "too far" (the plain path's own answer)
    // and "the rounds cannot be kept".
    static TrackedShapeResult reblendedAttempt(const TopoDS_Shape& shape,
        const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
        const std::vector<int>& blends, double distance, bool everyRound = false, bool* roundsAtRisk = nullptr)
    {
        TopoDS_Shape copy;
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> copyFaces;
        if (!copyForBuild(shape, faces, copy, copyFaces))
            return noOffset();
        ReblendedOffset reblended;
        TopoDS_Shape result;
        if (!buildReblendedOffset(
                reblended, copy, copyFaces, picked, blends, distance, result, everyRound, roundsAtRisk))
            return noOffset();
        return TrackedShapeResult { result, true, "", faceHistory(reblended, copy, result),
            edgeHistory(reblended, copy, result), {}, {}, {}, {} };
    }

    // The retry through a divided body — the seam case `buildDividedOffset` documents. Only ever
    // reached after the plain build failed, and only for a body that has a seam at all.
    static TrackedShapeResult dividedAttempt(const TopoDS_Shape& shape,
        const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
        const std::vector<int>& moving, double distance)
    {
        TopoDS_Shape copy;
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> copyFaces;
        if (!copyForBuild(shape, faces, copy, copyFaces))
            return noOffset();
        DividedOffset divided;
        TopoDS_Shape result;
        if (!buildDividedOffset(divided, copy, copyFaces, picked, moving, distance, result))
            return noOffset();
        return TrackedShapeResult { result, true, "", faceHistory(divided, copy, result),
            edgeHistory(divided, copy, result), {}, {}, {}, {} };
    }

    // How far the REBLEND will go on this body, 0 when it takes no distance at all. The crease guard
    // refuses the plain path outright, so this is the only measurement left to make on a body it
    // refuses — and it is what turns "this body is unusual" into "too far, and here is how far".
    static double largestReblend(const TopoDS_Shape& shape,
        const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
        const std::vector<int>& blends, double failing, bool everyRound)
    {
        const double sign = failing < 0 ? -1.0 : 1.0;
        double good = 0;
        double bad = std::fabs(failing);
        for (int step = 0; step < 7; step++) {
            const double middle = 0.5 * (good + bad);
            TopoDS_Shape copy;
            NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> copyFaces;
            ReblendedOffset made;
            TopoDS_Shape result;
            const bool worked = copyForBuild(shape, faces, copy, copyFaces) && buildReblendedOffset(made, copy, copyFaces, picked, blends, sign * middle, result, everyRound);
            if (worked)
                good = middle;
            else
                bad = middle;
        }
        return good;
    }

    // What the crease guard answers. A body whose rounds the reblend can still carry is not unusable at
    // all — it is being dragged too far — so it says so, with the reach it measured; only one the
    // reblend cannot carry either is the body OCCT's plain offset corrupts its own heap on.
    static TrackedShapeResult creaseRefusal(const TopoDS_Shape& shape,
        const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
        const std::vector<int>& blends, double distance)
    {
        const double reach = blends.empty() ? 0.0 : largestReblend(shape, faces, picked, blends, distance, true);
        if (reach > 0) {
            return refused("Offset face: OCCT can't do it at this distance",
                { 1, static_cast<int>(std::lround(reach * 1000.0)) });
        }
        return refused("Offset face: rounded edges meet at a sharp corner", { 6, 0 });
    }

    // The builds to fall back on when nothing was kept: the plain offset, then the divided retry — which
    // only a body with a seam pays for, and only after the plain build failed. Neither words its own
    // failure, so a body that survives both gets its explanation from `explainOffset` instead.
    //
    // The REBLEND is deliberately not in here. It is tried by the caller BEFORE the smooth-chain guard,
    // because taking the rounds off is exactly what saves a body whose chains are the crease-shaped
    // ones the guard refuses every plain offset of — putting it behind the guard made such a body
    // unpushable.
    static TrackedShapeResult plainThenDivided(const TopoDS_Shape& shape,
        const NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher>& faces, const std::vector<int>& picked,
        const std::vector<int>& moving, double distance)
    {
        const TrackedShapeResult plain = plainOffsetAttempt(shape, faces, picked, moving, distance);
        if (plain.isOk)
            return plain;
        if (hasSeam(shape)) {
            const TrackedShapeResult divided = dividedAttempt(shape, faces, picked, moving, distance);
            if (divided.isOk)
                return divided;
        }
        return refused(
            "Offset face: OCCT can't do it at this distance", explainOffset(shape, picked, moving, distance));
    }

    // Offset Face: move each face of `faces` (sub-shapes of `shape`) by `distance` along its own
    // outward normal, the faces that run smoothly into it following. Positive moves a face OUT
    // (the body grows there, a hole's wall closes in), negative moves it in, and a curved wall's
    // radius changes with the move — that is how a cylinder or a hole is resized.
    //
    // The faces the caller picked are matched by IDENTITY (`IsSame` through the index map), not
    // by index: the JS side hands over the `IFace` handles it resolved off this same shape, and
    // nothing here depends on its enumeration order matching OCCT's.
    //
    // Failures come back as `isOk == false` with a plain `error` (the JS side words its own
    // message) and, where the failure needed a search to describe, an `offsetReport`. The three
    // guards before the build are the ones that must NOT reach OCCT — a trap is not catchable
    // under -sDISABLE_EXCEPTION_CATCHING=1, and the heap may already be corrupt.
    //
    // `requireRounds` turns the reblend's silent fallback into a refusal: when the plain path COULD
    // do the move but only by re-radiusing the named rounds beside it, the answer is status 7
    // instead of a body whose rounds quietly changed radius. The refusal is deliberately checked
    // after the plain build: a distance that path refuses too is a genuine "too far" (1, with its
    // bound) or a crease (6), not a rounding complaint. A named round nowhere near a moving face is
    // not at risk and never causes a refusal.
    static TrackedShapeResult offsetFacesTracked(const TopoDS_Shape& shape, const ShapeArray& faces, double distance,
        const ShapeArray& rounds, bool requireRounds)
    {
        const std::vector<TopoDS_Face> pickedFaces = vecFromJSArray<TopoDS_Face>(faces);
        if (shape.IsNull() || pickedFaces.empty())
            return refused("Offset face: no face to move");
        if (!(std::fabs(distance) > 1e-9))
            return refused("Offset face: the distance is 0");
        try {
            if (!TopExp_Explorer(shape, TopAbs_SOLID).More())
                return refused("Offset face needs a solid body", { 3, 0 });
            // A body with a sealed void (two shells) is refused up front. Measured on a block with a
            // sealed cavity: `BRepOffset_MakeOffset` answers not-done at EVERY distance and does not
            // raise, so there is nothing here to try — the refusal is what says WHY, instead of
            // letting it fall through to "no distance works".
            if (shellCount(shape) != 1)
                return refused("Offset face: the solid has a sealed void", { 4, 0 });
            NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> facesMap;
            TopExp::MapShapes(shape, TopAbs_FACE, facesMap);
            std::vector<int> picked;
            if (!faceIndices(facesMap, pickedFaces, picked)) {
                return refused("Offset face: a face does not belong to the shape");
            }
            const std::vector<int> blends = blendIndices(facesMap, vecFromJSArray<TopoDS_Face>(rounds), picked);
            // Whether a named round actually runs into a moving face; topology alone, so it says
            // nothing about whether THIS distance works.
            bool roundsAtRisk = false;
            const auto tryReblend = [&](bool everyRound) {
                return reblendedAttempt(
                    shape, facesMap, picked, blends, distance, everyRound, &roundsAtRisk);
            };
            // The reblend gets FIRST refusal, ahead of the smooth-chain guard below: taking the
            // rounds off is what makes a body whose chains carry a crease offsettable at all, and
            // the guard refuses every plain offset of one.
            if (!blends.empty()) {
                const TrackedShapeResult reblended = tryReblend(false);
                if (reblended.isOk)
                    return reblended;
                // Not a status 7 yet: whether the move is possible at all is decided below, and a
                // distance the plain path refuses has a more accurate answer than "the rounds
                // cannot be kept".
            }
            // The body OCCT's offset corrupts its own heap on: one smooth chain with a sharp edge
            // inside it (two fillets meeting at a corner with no blend). Refused for ANY offset of
            // that body, whichever face was picked — the floor traps too. So a distance the plain
            // path could take is unanswerable; the reblend's own reach is not, and a body whose
            // rounds it CAN carry is simply being dragged too far rather than being unusable.
            std::vector<int> chain;
            if (smoothChains(shape, facesMap, chain)) {
                // The plain path is out (see above), and the reblend's usual scope is the rounds
                // BESIDE a moving face — which a pick away from every round leaves empty, with the
                // crease still in the body. So take every round the caller named off instead: that
                // is what the crease is made of.
                if (!blends.empty()) {
                    const TrackedShapeResult all = tryReblend(true);
                    if (all.isOk)
                        return all;
                }
                // There is no plain-offset alternative to withhold here — the guard forbids one —
                // so the reblend's own reach is the answer: too far (with its bound), or 6.
                return creaseRefusal(shape, facesMap, picked, blends, distance);
            }
            // OCCT moves a picked face's smooth neighbours with it, so those are checked too.
            const std::vector<int> moving = smoothClosure(chain, picked);
            const TrackedShapeResult plain = plainThenDivided(shape, facesMap, picked, moving, distance);
            // The move works — but only by re-radiusing the rounds beside it, which is exactly
            // what `requireRounds` refuses. No distance is given: a smaller one would not help.
            if (plain.isOk && requireRounds && roundsAtRisk)
                return refused("Offset face: the rounds beside the moved face cannot be kept", { 7, 0 });
            return plain;
        } catch (...) {
            return refused("Offset face failed", { 5, 0 });
        }
    }

    // Removes every edge of `shape` that is not in `keepShapes` through the given
    // ReShape. Returns true if at least one edge was removed.
    static bool removeNonKeptEdges(
        BRepTools_ReShape& reshape,
        const TopoDS_Shape& shape,
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& keepShapes)
    {
        bool removed = false;
        for (TopExp_Explorer edgeExplorer(shape, TopAbs_EDGE); edgeExplorer.More(); edgeExplorer.Next()) {
            if (!keepShapes.Contains(edgeExplorer.Current())) {
                reshape.Remove(edgeExplorer.Current());
                removed = true;
            }
        }
        return removed;
    }

    // Splitting a face with an edge that ends inside the face leaves a dangling "spur"
    // edge as an open internal wire. UnifySameDomain cannot remove it, and the shared
    // vertex also blocks unification of the collinear boundary edges it touches. Such
    // open internal wires are invalid as holes, so drop them before unifying. A spur
    // wire is dropped entirely only when none of its edges is requested to be kept;
    // otherwise only the edges that are not in keepShapes are removed from it.
    // Returns true if anything was removed from `face`.
    static bool removeSpurWires(
        BRepTools_ReShape& reshape,
        const TopoDS_Shape& face,
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& keepShapes)
    {
        TopExp_Explorer wireExplorer(face, TopAbs_WIRE);
        if (!wireExplorer.More()) {
            return false;
        }
        bool removed = false;
        // The first wire is the outer boundary and is always kept.
        for (wireExplorer.Next(); wireExplorer.More(); wireExplorer.Next()) {
            const TopoDS_Shape& wire = wireExplorer.Current();
            if (BRep_Tool::IsClosed(wire)) {
                continue;
            }
            bool hasKeptEdge = false;
            for (TopExp_Explorer edgeExplorer(wire, TopAbs_EDGE); edgeExplorer.More(); edgeExplorer.Next()) {
                if (keepShapes.Contains(edgeExplorer.Current())) {
                    hasKeptEdge = true;
                    break;
                }
            }
            if (!hasKeptEdge) {
                reshape.Remove(wire);
                removed = true;
            } else if (removeNonKeptEdges(reshape, wire, keepShapes)) {
                removed = true;
            }
        }
        return removed;
    }

    // Returns true when `face` has at least one edge and every boundary edge is in `keepShapes`.
    static bool isFullyKeptFace(
        const TopoDS_Shape& face,
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& keepShapes)
    {
        bool hasEdge = false;
        for (TopExp_Explorer edgeExplorer(face, TopAbs_EDGE); edgeExplorer.More(); edgeExplorer.Next()) {
            if (!keepShapes.Contains(edgeExplorer.Current())) {
                return false;
            }
            hasEdge = true;
        }
        return hasEdge;
    }

    // Prepares `shape` for UnifySameDomain in a single traversal with a single ReShape:
    // drops spur wires (see removeSpurWires) and detaches faces that are fully bounded
    // by kept edges. Such faces must survive unification as separate faces: with
    // AllowInternalEdges enabled, UnifySameDomain would otherwise merge them into their
    // same-domain neighbors and demote the kept edges to internal edges of the merged
    // face. Detached faces are appended to `protectedFaces`; the caller sews them back
    // after unifying. A fully kept face needs no spur check: every edge of it is kept,
    // so spur removal would be a no-op for it anyway.
    static TopoDS_Shape preprocessForUnify(
        const TopoDS_Shape& shape,
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& keepShapes,
        NCollection_List<TopoDS_Shape>& protectedFaces)
    {
        BRepTools_ReShape reshape;
        bool modified = false;
        for (TopExp_Explorer faceExplorer(shape, TopAbs_FACE); faceExplorer.More(); faceExplorer.Next()) {
            const TopoDS_Shape& face = faceExplorer.Current();
            if (!keepShapes.IsEmpty() && isFullyKeptFace(face, keepShapes)) {
                reshape.Remove(face);
                protectedFaces.Append(face);
                modified = true;
                continue;
            }
            modified |= removeSpurWires(reshape, face, keepShapes);
        }
        return modified ? reshape.Apply(shape) : shape;
    }

    static ShapeResult simplifyShape(
        const TopoDS_Shape& shape,
        const bool theUnifyEdges,
        const bool theUnifyFaces,
        const ShapeArray& keepShapes,
        double linearTolerance,
        double angularTolerance)
    {
        auto keepShapesList = shapeArrayToMapOfShape(keepShapes);

        NCollection_List<TopoDS_Shape> protectedFaces;
        TopoDS_Shape input = preprocessForUnify(shape, keepShapesList, protectedFaces);
        if (!protectedFaces.IsEmpty() && !TopExp_Explorer(input, TopAbs_FACE).More()) {
            // Every face is fully bounded by kept edges; nothing can be unified.
            return ShapeResult { shape, true, "" };
        }

        ShapeUpgrade_UnifySameDomain anUnifier(input, theUnifyEdges, theUnifyFaces, true);
        anUnifier.SetLinearTolerance(linearTolerance);
        anUnifier.SetAngularTolerance(angularTolerance);
        anUnifier.KeepShapes(keepShapesList);
        if (!keepShapesList.IsEmpty()) {
            anUnifier.AllowInternalEdges(true);
        }
        anUnifier.Build();

        TopoDS_Shape result = anUnifier.Shape();
        if (!protectedFaces.IsEmpty()) {
            BRepBuilderAPI_Sewing sewing;
            sewing.Add(result);
            for (const auto& face : protectedFaces) {
                sewing.Add(face);
            }
            sewing.Perform();
            result = sewing.SewedShape();
            if (result.ShapeType() == TopAbs_SHELL && BRep_Tool::IsClosed(result)) {
                BRepBuilderAPI_MakeSolid makeSolid(TopoDS::Shell(result));
                if (makeSolid.IsDone()) {
                    result = makeSolid.Solid();
                }
            }
        }
        return ShapeResult { result, true, "" };
    }

    static ShapeResult booleanOperate(BRepAlgoAPI_BooleanOperation& boolOperater, const ShapeArray& args,
        const ShapeArray& tools)
    {
        auto argsList = shapeArrayToListOfShape(args);
        auto toolsList = shapeArrayToListOfShape(tools);

        boolOperater.SetToFillHistory(false);
        boolOperater.SetArguments(argsList);
        boolOperater.SetTools(toolsList);
        boolOperater.SetFuzzyValue(1e-6);
        boolOperater.Build();

        if (!boolOperater.IsDone()) {
            std::ostringstream oss;
            boolOperater.DumpErrors(oss);
            return ShapeResult { TopoDS_Shape(), false, oss.str() };
        }

        return ShapeResult { boolOperater.Shape(), true, "" };
    }

    static ShapeResult booleanCommon(const ShapeArray& args, const ShapeArray& tools)
    {
        BRepAlgoAPI_Common api;
        return booleanOperate(api, args, tools);
    }

    static ShapeResult booleanCut(const ShapeArray& args, const ShapeArray& tools)
    {
        BRepAlgoAPI_Cut api;
        return booleanOperate(api, args, tools);
    }

    static ShapeResult booleanFuse(const ShapeArray& args, const ShapeArray& tools)
    {
        BRepAlgoAPI_Fuse api;
        return booleanOperate(api, args, tools);
    }

    static TopoDS_Compound compoundOf(const std::vector<TopoDS_Shape>& shapes)
    {
        TopoDS_Compound compound;
        BRep_Builder builder;
        builder.MakeCompound(compound);
        for (auto shape : shapes) {
            builder.Add(compound, shape);
        }
        return compound;
    }

    // Unlike booleanOperate, history filling stays enabled — it is the whole point here.
    // The history input enumerates args then tools, so output indexes >= arg face count
    // originate from a tool body. `simplify` unifies same-domain faces (as the untracked
    // fuse path does); OCCT merges the simplification into the operation history.
    static TrackedShapeResult booleanOperateTracked(BRepAlgoAPI_BooleanOperation& boolOperater,
        const ShapeArray& args, const ShapeArray& tools, bool simplify)
    {
        auto argsList = shapeArrayToListOfShape(args);
        auto toolsList = shapeArrayToListOfShape(tools);

        boolOperater.SetArguments(argsList);
        boolOperater.SetTools(toolsList);
        boolOperater.SetFuzzyValue(1e-6);
        boolOperater.Build();

        if (!boolOperater.IsDone()) {
            std::ostringstream oss;
            boolOperater.DumpErrors(oss);
            return TrackedShapeResult { TopoDS_Shape(), false, oss.str(), {}, {} };
        }

        // SimplifyResult runs after Build; it merges the unification into the history.
        if (simplify) {
            boolOperater.SimplifyResult(true, true);
        }

        TopoDS_Compound inputCompound;
        {
            std::vector<TopoDS_Shape> inputs = vecFromJSArray<TopoDS_Shape>(args);
            auto toolVec = vecFromJSArray<TopoDS_Shape>(tools);
            inputs.insert(inputs.end(), toolVec.begin(), toolVec.end());
            inputCompound = compoundOf(inputs);
        }
        return TrackedShapeResult { boolOperater.Shape(), true, "",
            faceHistory(boolOperater, inputCompound, boolOperater.Shape()),
            edgeHistory(boolOperater, inputCompound, boolOperater.Shape()) };
    }

    static TrackedShapeResult booleanCommonTracked(const ShapeArray& args, const ShapeArray& tools)
    {
        BRepAlgoAPI_Common api;
        return booleanOperateTracked(api, args, tools, false);
    }

    static TrackedShapeResult booleanCutTracked(const ShapeArray& args, const ShapeArray& tools)
    {
        BRepAlgoAPI_Cut api;
        return booleanOperateTracked(api, args, tools, false);
    }

    static TrackedShapeResult booleanFuseTracked(const ShapeArray& args, const ShapeArray& tools)
    {
        BRepAlgoAPI_Fuse api;
        return booleanOperateTracked(api, args, tools, true);
    }

    static ShapeResult combine(const ShapeArray& shapes)
    {
        std::vector<TopoDS_Shape> shapesVec = vecFromJSArray<TopoDS_Shape>(shapes);
        return ShapeResult { compoundOf(shapesVec), true, "" };
    }

    static ShapeResult fillet(const TopoDS_Shape& shape, const NumberArray& edges, double radius)
    {
        std::vector<int> edgeVec = vecFromJSArray<int>(edges);

        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> edgeMap;
        TopExp::MapShapes(shape, TopAbs_EDGE, edgeMap);

        BRepFilletAPI_MakeFillet makeFillet(shape);
        for (auto edge : edgeVec) {
            makeFillet.Add(radius, TopoDS::Edge(edgeMap.FindKey(edge + 1)));
        }
        makeFillet.Build();
        if (!makeFillet.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to fillet" };
        }

        return ShapeResult { makeFillet.Shape(), true, "" };
    }

    static TrackedShapeResult filletTracked(const TopoDS_Shape& shape, const NumberArray& edges, double radius)
    {
        std::vector<int> edgeVec = vecFromJSArray<int>(edges);

        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> edgeMap;
        TopExp::MapShapes(shape, TopAbs_EDGE, edgeMap);

        BRepFilletAPI_MakeFillet makeFillet(shape);
        for (auto edge : edgeVec) {
            makeFillet.Add(radius, TopoDS::Edge(edgeMap.FindKey(edge + 1)));
        }
        makeFillet.Build();
        if (!makeFillet.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to fillet", {}, {} };
        }

        return TrackedShapeResult { makeFillet.Shape(), true, "", faceHistory(makeFillet, shape, makeFillet.Shape()),
            edgeHistory(makeFillet, shape, makeFillet.Shape()) };
    }

    // Shared edge adding of `filletVariable`/`filletVariableTracked`: `radii` carries one
    // (R1, R2) pair per edge, flat — R1 at the edge's start vertex, R2 at its end vertex
    // (OCCT's Add(R1, R2, edge) interpolates linearly along the edge; equal pairs are a
    // constant-radius fillet by another name). Everything is validated BEFORE any Add: an
    // out-of-range FindKey raises, and the release build turns a raise into a module abort.
    // Returns an error message, empty on success.
    static std::string addVariableFillet(BRepFilletAPI_MakeFillet& makeFillet, const TopoDS_Shape& shape,
        const NumberArray& edges, const NumberArray& radii)
    {
        std::vector<int> edgeVec = vecFromJSArray<int>(edges);
        std::vector<double> radiiVec = vecFromJSArray<double>(radii);
        if (edgeVec.empty() || radiiVec.size() != edgeVec.size() * 2) {
            return "Fillet radii must come in one (R1, R2) pair per edge";
        }
        for (double r : radiiVec) {
            if (r <= 0) {
                return "Fillet radii must be positive";
            }
        }

        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> edgeMap;
        TopExp::MapShapes(shape, TopAbs_EDGE, edgeMap);
        for (size_t i = 0; i < edgeVec.size(); i++) {
            if (edgeVec[i] < 0 || edgeVec[i] >= (int)edgeMap.Extent()) {
                return "Fillet edge index out of range";
            }
            makeFillet.Add(radiiVec[2 * i], radiiVec[2 * i + 1], TopoDS::Edge(edgeMap.FindKey(edgeVec[i] + 1)));
        }
        return "";
    }

    static ShapeResult filletVariable(const TopoDS_Shape& shape, const NumberArray& edges, const NumberArray& radii)
    {
        BRepFilletAPI_MakeFillet makeFillet(shape);
        std::string error = addVariableFillet(makeFillet, shape, edges, radii);
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }
        makeFillet.Build();
        if (!makeFillet.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to fillet" };
        }
        return ShapeResult { makeFillet.Shape(), true, "" };
    }

    static TrackedShapeResult filletVariableTracked(const TopoDS_Shape& shape, const NumberArray& edges,
        const NumberArray& radii)
    {
        BRepFilletAPI_MakeFillet makeFillet(shape);
        std::string error = addVariableFillet(makeFillet, shape, edges, radii);
        if (!error.empty()) {
            return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {} };
        }
        makeFillet.Build();
        if (!makeFillet.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to fillet", {}, {} };
        }
        return TrackedShapeResult { makeFillet.Shape(), true, "", faceHistory(makeFillet, shape, makeFillet.Shape()),
            edgeHistory(makeFillet, shape, makeFillet.Shape()) };
    }

    static ShapeResult chamfer(const TopoDS_Shape& shape, const NumberArray& edges, double distance)
    {
        std::vector<int> edgeVec = vecFromJSArray<int>(edges);

        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> edgeMap;
        TopExp::MapShapes(shape, TopAbs_EDGE, edgeMap);

        BRepFilletAPI_MakeChamfer makeChamfer(shape);
        for (auto edge : edgeVec) {
            makeChamfer.Add(distance, TopoDS::Edge(edgeMap.FindKey(edge + 1)));
        }
        makeChamfer.Build();
        if (!makeChamfer.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to chamfer" };
        }
        return ShapeResult { makeChamfer.Shape(), true, "" };
    }

    static TrackedShapeResult chamferTracked(const TopoDS_Shape& shape, const NumberArray& edges, double distance)
    {
        std::vector<int> edgeVec = vecFromJSArray<int>(edges);

        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> edgeMap;
        TopExp::MapShapes(shape, TopAbs_EDGE, edgeMap);

        BRepFilletAPI_MakeChamfer makeChamfer(shape);
        for (auto edge : edgeVec) {
            makeChamfer.Add(distance, TopoDS::Edge(edgeMap.FindKey(edge + 1)));
        }
        makeChamfer.Build();
        if (!makeChamfer.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to chamfer", {}, {} };
        }

        return TrackedShapeResult { makeChamfer.Shape(), true, "", faceHistory(makeChamfer, shape, makeChamfer.Shape()),
            edgeHistory(makeChamfer, shape, makeChamfer.Shape()) };
    }

    // Shared edge adding of `chamferTwoDist`/`chamferTwoDistTracked`: `faces[i]` is the
    // reference face of `edges[i]` (both indexes in TopExp::MapShapes order, as with
    // `chamfer`) — OCCT's Add(d1, d2, edge, face) measures d1 ON that face and d2 on the
    // edge's other face. Everything is validated BEFORE any Add, as in `addVariableFillet`.
    // Returns an error message, empty on success.
    static std::string addTwoDistChamfer(BRepFilletAPI_MakeChamfer& makeChamfer, const TopoDS_Shape& shape,
        const NumberArray& edges, double d1, double d2, const NumberArray& faces)
    {
        std::vector<int> edgeVec = vecFromJSArray<int>(edges);
        std::vector<int> faceVec = vecFromJSArray<int>(faces);
        if (edgeVec.empty() || faceVec.size() != edgeVec.size()) {
            return "Chamfer edges and reference faces must pair up";
        }
        if (d1 <= 0 || d2 <= 0) {
            return "Chamfer distances must be positive";
        }

        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> edgeMap;
        NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> faceMap;
        TopExp::MapShapes(shape, TopAbs_EDGE, edgeMap);
        TopExp::MapShapes(shape, TopAbs_FACE, faceMap);
        NCollection_IndexedDataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> mapEF;
        TopExp::MapShapesAndAncestors(shape, TopAbs_EDGE, TopAbs_FACE, mapEF);
        for (size_t i = 0; i < edgeVec.size(); i++) {
            if (edgeVec[i] < 0 || edgeVec[i] >= (int)edgeMap.Extent() || faceVec[i] < 0
                || faceVec[i] >= (int)faceMap.Extent()) {
                return "Chamfer edge or face index out of range";
            }
            const TopoDS_Shape& edge = edgeMap.FindKey(edgeVec[i] + 1);
            const TopoDS_Shape& face = faceMap.FindKey(faceVec[i] + 1);
            // Add(d1, d2, edge, face) requires the face to border the edge; OCCT never checks
            // and measures d1 on a foreign face's surface, which corrupts the chamfer.
            bool adjacent = false;
            for (const auto& edgeFace : mapEF.FindFromKey(edge)) {
                if (edgeFace.IsSame(face)) {
                    adjacent = true;
                    break;
                }
            }
            if (!adjacent) {
                return "Chamfer reference face is not adjacent to its edge";
            }
            makeChamfer.Add(d1, d2, TopoDS::Edge(edge), TopoDS::Face(face));
        }
        return "";
    }

    static ShapeResult chamferTwoDist(const TopoDS_Shape& shape, const NumberArray& edges, double d1, double d2,
        const NumberArray& faces)
    {
        BRepFilletAPI_MakeChamfer makeChamfer(shape);
        std::string error = addTwoDistChamfer(makeChamfer, shape, edges, d1, d2, faces);
        if (!error.empty()) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }
        makeChamfer.Build();
        if (!makeChamfer.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to chamfer" };
        }
        return ShapeResult { makeChamfer.Shape(), true, "" };
    }

    static TrackedShapeResult chamferTwoDistTracked(const TopoDS_Shape& shape, const NumberArray& edges, double d1,
        double d2, const NumberArray& faces)
    {
        BRepFilletAPI_MakeChamfer makeChamfer(shape);
        std::string error = addTwoDistChamfer(makeChamfer, shape, edges, d1, d2, faces);
        if (!error.empty()) {
            return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {} };
        }
        makeChamfer.Build();
        if (!makeChamfer.IsDone()) {
            return TrackedShapeResult { TopoDS_Shape(), false, "Failed to chamfer", {}, {} };
        }
        return TrackedShapeResult { makeChamfer.Shape(), true, "", faceHistory(makeChamfer, shape, makeChamfer.Shape()),
            edgeHistory(makeChamfer, shape, makeChamfer.Shape()) };
    }

    static ShapeResult fillet2d(const TopoDS_Face& face, const TopoDS_Edge& edge1, const TopoDS_Edge& edge2, double radius)
    {
        TopoDS_Vertex commonVertex = findCommonVertex(edge1, edge2);
        if (commonVertex.IsNull()) {
            return ShapeResult { TopoDS_Shape(), false, "Edges must share a common vertex" };
        }

        ChFi2d_Builder builder(face);
        builder.AddFillet(commonVertex, radius);
        if (builder.Status() != ChFi2d_IsDone) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create 2D fillet" };
        }

        return ShapeResult { builder.Result(), true, "" };
    }

    static ShapesResult filletEdge2d(const TopoDS_Edge& edge1, const TopoDS_Edge& edge2, double radius)
    {
        std::string error;
        auto corner = computeCornerPlane(edge1, edge2, error);
        if (!corner.has_value()) {
            return ShapesResult { ShapeArray(val::array()), false, error };
        }

        double f1, l1, f2, l2;
        Handle(Geom_Curve) c1 = basisCurve(edge1, f1, l1);
        Handle(Geom_Curve) c2 = basisCurve(edge2, f2, l2);
        TopoDS_Edge e1 = corner->cornerVertex.IsNull()
            ? edgeThroughCorner(c1, f1, l1, corner->param1)
            : edgeFromCorner(c1, f1, l1, corner->param1, corner->cornerVertex);
        TopoDS_Edge e2 = corner->cornerVertex.IsNull()
            ? edgeThroughCorner(c2, f2, l2, corner->param2)
            : edgeFromCorner(c2, f2, l2, corner->param2, corner->cornerVertex);

        gp_Pln plane(corner->point, corner->normal);
        TopoDS_Edge newE1, newE2;
        TopoDS_Edge filletEdge;
        if (corner->cornerVertex.IsNull()) {
            ChFi2d_FilletAPI fillet(e1, e2, plane);
            if (!fillet.Perform(radius)) {
                return ShapesResult { ShapeArray(val::array()), false, "Failed to create 2D fillet" };
            }
            filletEdge = fillet.Result(corner->point, newE1, newE2);
        } else {
            // A circular corner has several tangent solutions — one on each side of the
            // circle — and the analytical algorithm only offers one. The iterative one
            // enumerates them; keep the one whose tangent points stay on the picked arcs.
            ChFi2d_FilletAlgo fillet(e1, e2, plane);
            if (!fillet.Perform(radius)) {
                return ShapesResult { ShapeArray(val::array()), false, "Failed to create 2D fillet" };
            }
            int count = fillet.NbResults(corner->point);
            for (int i = 1; i <= count && filletEdge.IsNull(); i++) {
                TopoDS_Edge candidate1, candidate2;
                TopoDS_Edge candidate = fillet.Result(corner->point, candidate1, candidate2, i);
                if (candidate.IsNull())
                    continue;
                if (trimOnEdge(candidate1, c1, f1, l1, corner->point)
                    && trimOnEdge(candidate2, c2, f2, l2, corner->point)) {
                    filletEdge = candidate;
                    newE1 = candidate1;
                    newE2 = candidate2;
                }
            }
            if (filletEdge.IsNull())
                filletEdge = fillet.Result(corner->point, newE1, newE2);
        }
        if (filletEdge.IsNull()) {
            return ShapesResult { ShapeArray(val::array()), false, "Failed to get fillet result" };
        }

        gp_Pnt arcStart, arcEnd;
        edgeEndPoints(filletEdge, arcStart, arcEnd);
        newE1 = edgeToFarEnd(c1, f1, l1, corner->param1, arcStart, arcEnd);
        newE2 = edgeToFarEnd(c2, f2, l2, corner->param2, arcStart, arcEnd);
        if (newE1.IsNull() || newE2.IsNull()) {
            return ShapesResult { ShapeArray(val::array()), false, "Failed to get fillet result" };
        }

        return ShapesResult { ShapeArray(buildEdgeTriple(newE1, filletEdge, newE2)), true, "" };
    }

    static ShapeResult chamfer2d(const TopoDS_Face& face, const TopoDS_Edge& edge1, const TopoDS_Edge& edge2, double distance)
    {
        ChFi2d_Builder builder(face);
        builder.AddChamfer(edge1, edge2, distance, distance);
        if (builder.Status() != ChFi2d_IsDone) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create 2D chamfer" };
        }

        return ShapeResult { builder.Result(), true, "" };
    }

    static ShapesResult chamferEdge2d(const TopoDS_Edge& edge1, const TopoDS_Edge& edge2, double distance)
    {
        std::string error;
        auto corner = computeCornerPlane(edge1, edge2, error);
        if (!corner.has_value()) {
            return ShapesResult { ShapeArray(val::array()), false, error };
        }

        double f1, l1, f2, l2;
        Handle(Geom_Curve) c1 = basisCurve(edge1, f1, l1);
        Handle(Geom_Curve) c2 = basisCurve(edge2, f2, l2);

        // The distance is measured along the edge: a line's parameter is a length, a
        // circle's is an angle, so the same distance lands at a different parameter step.
        double step1 = 0.0;
        double step2 = 0.0;
        if (!cornerParameterStep(c1, distance, step1) || !cornerParameterStep(c2, distance, step2)) {
            return ShapesResult { ShapeArray(val::array()), false, "Edges must be Line or Circle" };
        }

        double p1 = corner->param1;
        double p2 = corner->param2;
        // keep the side of the corner that contains the edge midpoint
        double cut1 = p1 + ((f1 + l1) / 2 > p1 ? step1 : -step1);
        double cut2 = p2 + ((f2 + l2) / 2 > p2 ? step2 : -step2);
        double end1 = cut1 > p1 ? l1 : f1;
        double end2 = cut2 > p2 ? l2 : f2;
        if (!cutWithinEdge(c1, cut1, f1, l1, end1) || !cutWithinEdge(c2, cut2, f2, l2, end2)) {
            return ShapesResult { ShapeArray(val::array()), false, "The chamfer distance is too large" };
        }

        TopoDS_Edge newE1 = BRepBuilderAPI_MakeEdge(c1, std::min(cut1, end1), std::max(cut1, end1)).Edge();
        TopoDS_Edge newE2 = BRepBuilderAPI_MakeEdge(c2, std::min(cut2, end2), std::max(cut2, end2)).Edge();
        TopoDS_Edge chamferEdge = BRepBuilderAPI_MakeEdge(c1->Value(cut1), c2->Value(cut2)).Edge();

        return ShapesResult { ShapeArray(buildEdgeTriple(newE1, chamferEdge, newE2)), true, "" };
    }

    // Shared build of `loft`/`loftTracked`: validates the sections and runs
    // BRepOffsetAPI_ThruSections, returning the LIVE builder — the tracked variant
    // queries its shape history afterwards, so it must outlive the call.
    // `sectionVector` receives the converted sections (their order defines the history
    // input enumeration). Null on failure, with `error` set.
    static std::unique_ptr<BRepOffsetAPI_ThruSections> buildLoft(const ShapeArray& sections, bool isSolid,
        bool isRuled, GeomAbs_Shape continuity, std::vector<TopoDS_Shape>& sectionVector, std::string& error)
    {
        sectionVector = emscripten::vecFromJSArray<TopoDS_Shape>(sections);
        if (sectionVector.size() < 2) {
            error = "Failed to loft: at least 2 sections are required";
            return nullptr;
        }
        if (sectionVector.size() == 2 && sectionVector[0].ShapeType() == TopAbs_VERTEX
            && sectionVector[1].ShapeType() == TopAbs_VERTEX) {
            error = "Failed to loft: must have at least 1 wires";
            return nullptr;
        }

        auto loftBuilder = std::make_unique<BRepOffsetAPI_ThruSections>(isSolid, isRuled);
        if (!isRuled) {
            loftBuilder->SetContinuity(continuity);
        }
        for (auto& profile : sectionVector) {
            if (profile.ShapeType() == TopAbs_WIRE) {
                loftBuilder->AddWire(TopoDS::Wire(profile));
            } else if (profile.ShapeType() == TopAbs_VERTEX) {
                loftBuilder->AddVertex(TopoDS::Vertex(profile));
            }
        }
        loftBuilder->Build();
        if (!loftBuilder->IsDone()) {
            error = "Failed to loft";
            return nullptr;
        }
        return loftBuilder;
    }

    static ShapeResult loft(const ShapeArray& sections, bool isSolid, bool isRuled, GeomAbs_Shape continuity)
    {
        std::vector<TopoDS_Shape> sectionVector;
        std::string error;
        auto loftBuilder = buildLoft(sections, isSolid, isRuled, continuity, sectionVector, error);
        if (!loftBuilder) {
            return ShapeResult { TopoDS_Shape(), false, error };
        }
        return ShapeResult { loftBuilder->Shape(), true, "" };
    }

    // Tracked loft: the history input is the compound of ALL sections in order, so the
    // edge indexes enumerate section 0's edges first, then section 1's, and so on (the
    // caller enumerates the same way). Loft inputs carry no faces, so faceHistory is
    // always empty; the caps (isSolid) travel through the dedicated capFaces channel.
    static TrackedShapeResult loftTracked(const ShapeArray& sections, bool isSolid, bool isRuled,
        GeomAbs_Shape continuity)
    {
        std::vector<TopoDS_Shape> sectionVector;
        std::string error;
        auto loftBuilder = buildLoft(sections, isSolid, isRuled, continuity, sectionVector, error);
        if (!loftBuilder) {
            return TrackedShapeResult { TopoDS_Shape(), false, error, {}, {} };
        }

        TopoDS_Compound inputCompound;
        BRep_Builder compoundBuilder;
        compoundBuilder.MakeCompound(inputCompound);
        for (const auto& section : sectionVector) {
            compoundBuilder.Add(inputCompound, section);
        }

        TrackedShapeResult result { loftBuilder->Shape(), true, "", faceHistory(*loftBuilder, inputCompound, loftBuilder->Shape()),
            edgeHistory(*loftBuilder, inputCompound, loftBuilder->Shape()),
            faceFromEdgeHistory(*loftBuilder, inputCompound, loftBuilder->Shape()) };
        if (isSolid) {
            result.capFaces = loftCapFaces(*loftBuilder, sectionVector, loftBuilder->Shape());
        }
        return result;
    }

    // Transfinite interpolation over a curve network: every profile must meet every guide.
    // Edges are converted to their atomic basis curves first, because Gordon reads the
    // curve's own parameter range and the conversion it runs internally raises on curve
    // kinds it does not know (a raise aborts the module in Release). The result is one
    // face; the inputs are not consumed.
    static ShapeResult gordon(const EdgeArray& profiles, const EdgeArray& guides, double tolerance,
        bool approximate)
    {
        std::vector<TopoDS_Edge> profileEdges = vecFromJSArray<TopoDS_Edge>(profiles);
        std::vector<TopoDS_Edge> guideEdges = vecFromJSArray<TopoDS_Edge>(guides);
        if (profileEdges.size() < 2 || guideEdges.size() < 2) {
            return ShapeResult { TopoDS_Shape(), false,
                "Failed to create Gordon surface: at least 2 profile edges and 2 guide edges are required" };
        }
        if (!(tolerance > 0.0)) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create Gordon surface: invalid tolerance" };
        }

        std::string error;
        NCollection_Array1<Handle(Geom_Curve)> profileCurves(1, static_cast<int>(profileEdges.size()));
        for (size_t i = 0; i < profileEdges.size(); i++) {
            Handle(Geom_Curve) curve = edgeCurveForGordon(profileEdges[i], error);
            if (curve.IsNull())
                return ShapeResult { TopoDS_Shape(), false, error };
            profileCurves.SetValue(static_cast<int>(i) + 1, curve);
        }

        NCollection_Array1<Handle(Geom_Curve)> guideCurves(1, static_cast<int>(guideEdges.size()));
        for (size_t i = 0; i < guideEdges.size(); i++) {
            Handle(Geom_Curve) curve = edgeCurveForGordon(guideEdges[i], error);
            if (curve.IsNull())
                return ShapeResult { TopoDS_Shape(), false, error };
            guideCurves.SetValue(static_cast<int>(i) + 1, curve);
        }

        if (!gordonNetworkMeets(profileCurves, guideCurves, tolerance))
            return ShapeResult { TopoDS_Shape(), false,
                "Failed to create Gordon surface: every profile must intersect every guide" };

        GeomFill_Gordon gordon;
        gordon.SetApproximationMode(approximate ? GeomFill_Gordon::ApproximationMode::AllowApproximateFallback
                                                : GeomFill_Gordon::ApproximationMode::ExactOnly);
        gordon.Init(profileCurves, guideCurves, tolerance);
        gordon.Perform();
        // Surface() raises StdFail_NotDone while the build has not succeeded — a raise
        // aborts the module, so the status is checked first.
        if (!gordon.IsDone())
            return ShapeResult { TopoDS_Shape(), false, mapGordonError(gordon.Status()) };

        auto surface = gordon.Surface();
        if (surface.IsNull())
            return ShapeResult { TopoDS_Shape(), false, "Failed to create Gordon surface: the kernel returned no surface" };
        BRepBuilderAPI_MakeFace makeFace(surface, Precision::Confusion());
        if (!makeFace.IsDone())
            return ShapeResult { TopoDS_Shape(), false, "Failed to create Gordon surface: could not build a face" };

        // Perform() also fixes the orientation when needed (ShapeFix_Face::NeedFix), so an
        // explicit FixOrientation() here would run the same pass twice.
        ShapeFix_Face faceFix(makeFace.Face());
        faceFix.Perform();
        TopoDS_Face fixed = faceFix.Face();
        if (fixed.IsNull())
            return ShapeResult { TopoDS_Shape(), false,
                "Failed to create Gordon surface: the face repair returned nothing" };
        return ShapeResult { fixed, true, "" };
    }

    static ShapeResult curveProjection(const TopoDS_Shape& curve, const TopoDS_Shape& targetFace, const gp_Dir& dir)
    {
        BRepProj_Projection curveProjection(curve, targetFace, dir);
        if (!curveProjection.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to create curve projection" };
        }
        return ShapeResult { curveProjection.Shape(), true, "" };
    }

    static ShapeResult fixShape(const TopoDS_Shape& shape, double tolerance)
    {
        ShapeFix_Shape fixer(shape);
        fixer.SetPrecision(tolerance);
        fixer.Perform();
        return ShapeResult { fixer.Shape(), true, "" };
    }

    static ShapeResult fixSmallFace(const TopoDS_Shape& shape, double tolerance)
    {
        ShapeFix_FixSmallFace fixer;
        fixer.Init(shape);
        fixer.SetPrecision(tolerance);
        fixer.Perform();
        return ShapeResult { fixer.Shape(), true, "" };
    }

    static ShapeResult fixSolid(const TopoDS_Shape& shape, double tolerance)
    {
        ShapeFix_Solid fixer;
        fixer.Init(TopoDS::Solid(shape));
        fixer.SetPrecision(tolerance);
        fixer.Perform();
        return ShapeResult { fixer.Shape(), true, "" };
    }

    static bool hasAnySub(const TopoDS_Shape& shape, TopAbs_ShapeEnum shapeType)
    {
        TopExp_Explorer explorer;
        explorer.Init(shape, shapeType);
        return explorer.More();
    }

    // Rebuilds `shape` with the removals recorded in `reShape`. Wires and edges that must
    // outlive their face are appended alongside the result, so their geometry is preserved.
    // An edge can arrive both on its own (an orphan edge of an explicitly removed face) and
    // inside a kept wire (a face dropped with a removed edge); it is appended once.
    static TopoDS_Shape applyKeepingWires(BRepTools_ReShape& reShape,
        const TopoDS_Shape& shape,
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& keptShapes)
    {
        auto result = reShape.Apply(shape);
        if (keptShapes.IsEmpty() && !result.IsNull()) {
            return result;
        }

        std::vector<TopoDS_Shape> kept;
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> wiredEdges;
        for (NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>::Iterator it(keptShapes); it.More(); it.Next()) {
            auto image = reShape.Apply(it.Value());
            if (image.IsNull() || !hasAnySub(image, TopAbs_EDGE)) {
                continue;
            }
            kept.push_back(image);
            if (image.ShapeType() != TopAbs_EDGE) {
                for (TopExp_Explorer explorer(image, TopAbs_EDGE); explorer.More(); explorer.Next()) {
                    wiredEdges.Add(explorer.Current());
                }
            }
        }

        BRep_Builder builder;
        TopoDS_Compound compound;
        builder.MakeCompound(compound);
        if (!result.IsNull()) {
            builder.Add(compound, result);
        }
        for (const auto& image : kept) {
            if (image.ShapeType() == TopAbs_EDGE && wiredEdges.Contains(image)) {
                continue;
            }
            builder.Add(compound, image);
        }
        return compound;
    }

    static ShapeResult removeFeature(const TopoDS_Shape& shape, const ShapeArray& faces)
    {
        std::vector<TopoDS_Shape> facesVector = vecFromJSArray<TopoDS_Shape>(faces);
        BRepAlgoAPI_Defeaturing defea;
        defea.SetShape(shape);
        for (auto& face : facesVector) {
            defea.AddFaceToRemove(face);
        }
        defea.SetRunParallel(true);
        defea.Build();
        if (!defea.IsDone()) {
            return ShapeResult { TopoDS_Shape(), false, "Failed to remove feature" };
        }
        return ShapeResult { defea.Shape(), true, "" };
    }

    static RemoveFilletResult removeFillet(const TopoDS_Shape& shape, const ShapeArray& faces)
    {
        std::vector<TopoDS_Shape> facesVector = vecFromJSArray<TopoDS_Shape>(faces);
        BRepAlgoAPI_Defeaturing defea;
        defea.SetShape(shape);
        for (auto& face : facesVector) {
            defea.AddFaceToRemove(face);
        }
        defea.SetRunParallel(true);
        defea.Build();
        if (!defea.IsDone()) {
            return RemoveFilletResult { TopoDS_Shape(), false, "Failed to remove fillet", ShapeArray(val::array()) };
        }

        val newEdges = val::array();
        TopExp_Explorer explorer;
        for (explorer.Init(shape, TopAbs_FACE); explorer.More(); explorer.Next()) {
            auto face = TopoDS::Face(explorer.Current());
            auto list = defea.Generated(face);
            for (auto& s : list) {
                newEdges.call<void>("push", s);
            }
        }
        return RemoveFilletResult { defea.Shape(), true, "", ShapeArray(newEdges) };
    }

    // A face referencing a removed edge becomes invalid: drop it, but keep its
    // wires so the remaining edges are preserved.
    static void removeFacesUsingEdge(BRepTools_ReShape& reShape,
        const NCollection_IndexedDataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher>& mapEF,
        const TopoDS_Shape& edge,
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& removedFaces,
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& keptShapes)
    {
        if (!mapEF.Contains(edge)) {
            return;
        }
        for (const auto& face : mapEF.FindFromKey(edge)) {
            if (!removedFaces.Add(face)) {
                continue;
            }
            reShape.Remove(face);
            for (TopExp_Explorer explorer(face, TopAbs_WIRE); explorer.More(); explorer.Next()) {
                keptShapes.Add(explorer.Current());
            }
        }
    }

    // Every edge of a removed face that no surviving face uses would vanish with the face —
    // the outline of a standalone face, or the free boundary of an open shell. Keep those
    // edges as free edges, as SketchUp and the edge-delete path above do, so the opening can
    // still be redrawn and healed. Edges another face still uses stay with that face.
    static void keepOrphanEdges(
        const NCollection_List<TopoDS_Shape>& removedFaceList,
        const NCollection_IndexedDataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher>& mapEF,
        const NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& removedFaces,
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher>& keptShapes)
    {
        for (NCollection_List<TopoDS_Shape>::Iterator it(removedFaceList); it.More(); it.Next()) {
            for (TopExp_Explorer explorer(it.Value(), TopAbs_EDGE); explorer.More(); explorer.Next()) {
                const TopoDS_Shape& edge = explorer.Current();
                if (!mapEF.Contains(edge)) {
                    continue;
                }
                bool survivorUses = false;
                for (const auto& face : mapEF.FindFromKey(edge)) {
                    if (!removedFaces.Contains(face)) {
                        survivorUses = true;
                        break;
                    }
                }
                if (!survivorUses) {
                    keptShapes.Add(edge);
                }
            }
        }
    }

    static ShapeResult removeSubShape(const TopoDS_Shape& shape, const ShapeArray& subShapes)
    {
        std::vector<TopoDS_Shape> subShapesVector = vecFromJSArray<TopoDS_Shape>(subShapes);
        if (subShapesVector.empty()) {
            return ShapeResult { shape, false, "Not remove anything" };
        }

        NCollection_IndexedDataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> mapEF;
        TopExp::MapShapesAndAncestors(shape, TopAbs_EDGE, TopAbs_FACE, mapEF);

        BRepTools_ReShape reShape;
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> removedFaces; // dedupe faces dropped because one of their edges was removed
        NCollection_Map<TopoDS_Shape, TopTools_ShapeMapHasher> keptShapes;
        NCollection_List<TopoDS_Shape> removedFaceList; // faces the caller removed on their own
        for (const auto& subShape : subShapesVector) {
            reShape.Remove(subShape);
            if (subShape.ShapeType() == TopAbs_FACE) {
                removedFaces.Add(subShape);
                removedFaceList.Append(subShape);
                continue;
            }
            if (subShape.ShapeType() != TopAbs_EDGE) {
                continue;
            }
            removeFacesUsingEdge(reShape, mapEF, subShape, removedFaces, keptShapes);
        }
        keepOrphanEdges(removedFaceList, mapEF, removedFaces, keptShapes);

        TopoDS_Shape result = applyKeepingWires(reShape, shape, keptShapes);
        if (result.IsSame(shape)) {
            return ShapeResult { shape, false, "Not remove anything" };
        }

        return ShapeResult { result, true, "" };
    }

    static ShapeResult replaceSubShapes(const TopoDS_Shape& shape,
        const ShapeArray& oldShapes, const ShapeArray& newShapes)
    {
        NCollection_Sequence<TopoDS_Shape> oldSeq = shapeArrayToSequenceOfShape(oldShapes);
        NCollection_Sequence<TopoDS_Shape> newSeq = shapeArrayToSequenceOfShape(newShapes);

        BRepTools_ReShape reShape;
        for (int i = 1; i <= oldSeq.Length() && i <= newSeq.Length(); i++) {
            reShape.Replace(oldSeq.Value(i), newSeq.Value(i));
        }

        return ShapeResult { reShape.Apply(shape), true, "" };
    }

    // General-fuse gluing: every shape's image keeps its own dimension (a solid stays a
    // solid, a flange face stays a face), while sub-shapes that coincide across shapes
    // become a single shared instance — e.g. a face drawn against a body's edge shares
    // that edge instead of duplicating it (sewing refuses such non-manifold merges).
    static ShapeResult glueShapes(const ShapeArray& shapes)
    {
        std::vector<TopoDS_Shape> shapeVector = emscripten::vecFromJSArray<TopoDS_Shape>(shapes);
        if (shapeVector.empty()) {
            return ShapeResult { TopoDS_Shape(), false, "No shapes provided" };
        }
        if (shapeVector.size() == 1) {
            return ShapeResult { shapeVector[0], true, "" };
        }

        NCollection_List<TopoDS_Shape> arguments;
        for (const auto& shape : shapeVector) {
            arguments.Append(shape);
        }

        BOPAlgo_Builder builder;
        builder.SetArguments(arguments);
        builder.SetGlue(BOPAlgo_GlueFull);
        builder.SetNonDestructive(true);
        builder.Perform();
        if (builder.HasErrors()) {
            return ShapeResult { TopoDS_Shape(), false, "Glue failed" };
        }
        return ShapeResult { builder.Shape(), true, "" };
    }

    // A sewing pass whose faces fall into several connected groups returns a COMPOUND, not a
    // shell; taking only a top-level SHELL therefore lost every closed volume as soon as an
    // unrelated loose face rode along with the body. Walk the result and upgrade each closed
    // shell on its own, leaving open shells and free faces/edges exactly as sewn.
    static TopoDS_Shape sewnToSolids(const TopoDS_Shape& shape)
    {
        if (shape.IsNull()) {
            return shape;
        }
        if (shape.ShapeType() == TopAbs_SHELL) {
            if (!BRep_Tool::IsClosed(shape)) {
                return shape;
            }
            BRepCheck_Analyzer analyzer(shape);
            if (!analyzer.IsValid()) {
                return shape;
            }
            BRepBuilderAPI_MakeSolid mkSolid(TopoDS::Shell(shape));
            return mkSolid.IsDone() ? TopoDS_Shape(mkSolid.Solid()) : shape;
        }
        if (shape.ShapeType() != TopAbs_COMPOUND) {
            return shape;
        }

        TopoDS_Compound compound;
        BRep_Builder builder;
        builder.MakeCompound(compound);
        bool changed = false;
        for (TopoDS_Iterator it(shape); it.More(); it.Next()) {
            TopoDS_Shape upgraded = sewnToSolids(it.Value());
            changed = changed || !upgraded.IsSame(it.Value());
            builder.Add(compound, upgraded);
        }
        return changed ? TopoDS_Shape(compound) : shape;
    }

    // A closed solid is already sewn. Folding a face onto it along one of its edges makes that
    // edge non-manifold, and the sew collapses the whole connected set — solid included — into
    // one open shell: a rectangle drawn against a box edge is the measured case, and it loses
    // the box's solidity for nothing. Keep closed bodies out of the pass and put them back
    // beside whatever the remaining faces/sewn shells formed.
    static bool isClosedSolidBody(const TopoDS_Shape& shape)
    {
        if (shape.IsNull() || shape.ShapeType() != TopAbs_SOLID) {
            return false;
        }
        for (TopExp_Explorer shell(shape, TopAbs_SHELL); shell.More(); shell.Next()) {
            if (!BRep_Tool::IsClosed(shell.Current())) {
                return false;
            }
        }
        return true;
    }

    static void partitionSewingInput(const TopoDS_Shape& shape, std::vector<TopoDS_Shape>& bodies,
        std::vector<TopoDS_Shape>& rest)
    {
        if (shape.ShapeType() == TopAbs_COMPOUND || shape.ShapeType() == TopAbs_COMPSOLID) {
            for (TopoDS_Iterator it(shape); it.More(); it.Next()) {
                partitionSewingInput(it.Value(), bodies, rest);
            }
            return;
        }
        (isClosedSolidBody(shape) ? bodies : rest).push_back(shape);
    }

    static ShapeResult sewing(const ShapeArray& shapes)
    {
        std::vector<TopoDS_Shape> shapeVector = emscripten::vecFromJSArray<TopoDS_Shape>(shapes);
        std::vector<TopoDS_Shape> bodies;
        std::vector<TopoDS_Shape> rest;
        for (auto& shape : shapeVector) {
            partitionSewingInput(shape, bodies, rest);
        }

        TopoDS_Shape result;
        if (rest.empty()) {
            result = bodies.size() == 1 ? bodies.front() : TopoDS_Shape(compoundOf(bodies));
        } else {
            BRepBuilderAPI_Sewing sewing;
            for (auto& shape : rest) {
                sewing.Add(shape);
            }
            sewing.Perform();
            result = sewnToSolids(sewing.SewedShape());
            if (!bodies.empty()) {
                std::vector<TopoDS_Shape> pieces { result };
                pieces.insert(pieces.end(), bodies.begin(), bodies.end());
                result = compoundOf(pieces);
            }
        }

        return ShapeResult { result, true, "" };
    }
};

EMSCRIPTEN_BINDINGS(ShapeFactory)
{
    class_<ShapeResult>("ShapeResult")
        .property("shape", &ShapeResult::shape, return_value_policy::reference())
        .property("isOk", &ShapeResult::isOk)
        .property("error", &ShapeResult::error);

    class_<RemoveFilletResult>("RemoveFilletResult")
        .property("shape", &RemoveFilletResult::shape, return_value_policy::reference())
        .property("isOk", &RemoveFilletResult::isOk)
        .property("error", &RemoveFilletResult::error)
        .property("newEdges", &RemoveFilletResult::newEdges);

    class_<ShapesResult>("ShapesResult")
        .property("shapes", &ShapesResult::shapes)
        .property("isOk", &ShapesResult::isOk)
        .property("error", &ShapesResult::error);

    class_<RegionsResult>("RegionsResult")
        .property("faces", &RegionsResult::faces)
        .property("sourceCounts", &RegionsResult::sourceCounts)
        .property("sourceIds", &RegionsResult::sourceIds)
        .property("isOk", &RegionsResult::isOk)
        .property("error", &RegionsResult::error);

    class_<TrackedShapeResult>("TrackedShapeResult")
        .property("shape", &TrackedShapeResult::shape, return_value_policy::reference())
        .property("isOk", &TrackedShapeResult::isOk)
        .property("error", &TrackedShapeResult::error)
        .property("faceEdgeMap", &TrackedShapeResult::faceEdgeMap)
        .property("faceAncestors", &TrackedShapeResult::faceAncestors)
        .property("edgeAncestors", &TrackedShapeResult::edgeAncestors)
        .property("capFaces", &TrackedShapeResult::capFaces)
        .property("offsetFaceMap", &TrackedShapeResult::offsetFaceMap)
        .property("offsetEdgeMap", &TrackedShapeResult::offsetEdgeMap)
        .property("offsetReport", &TrackedShapeResult::offsetReport);

    class_<ShapeFactory>("ShapeFactory")
        .class_function("box", &ShapeFactory::box)
        .class_function("cone", &ShapeFactory::cone)
        .class_function("sphere", &ShapeFactory::sphere)
        .class_function("ellipsoid", &ShapeFactory::ellipsoid)
        .class_function("ellipse", &ShapeFactory::ellipse)
        .class_function("cylinder", &ShapeFactory::cylinder)
        .class_function("pyramid", &ShapeFactory::pyramid)
        .class_function("sweep", &ShapeFactory::sweep)
        .class_function("sweepTracked", &ShapeFactory::sweepTracked)
        .class_function("sweepMode", &ShapeFactory::sweepMode)
        .class_function("sweepModeTracked", &ShapeFactory::sweepModeTracked)
        .class_function("revolve", &ShapeFactory::revolve)
        .class_function("prism", &ShapeFactory::prism)
        .class_function("pushPull", &ShapeFactory::pushPull)
        .class_function("polygon", &ShapeFactory::polygon)
        .class_function("circle", &ShapeFactory::circle)
        .class_function("arc", &ShapeFactory::arc)
        .class_function("bezier", &ShapeFactory::bezier)
        .class_function("bspline", &ShapeFactory::bspline)
        .class_function("helix", &ShapeFactory::helix)
        .class_function("rect", &ShapeFactory::rect)
        .class_function("point", &ShapeFactory::point)
        .class_function("line", &ShapeFactory::line)
        .class_function("wire", &ShapeFactory::wire)
        .class_function("face", &ShapeFactory::face)
        .class_function("faceFromSurface", &ShapeFactory::faceFromSurface)
        .class_function("facesFromEdges", &ShapeFactory::facesFromEdges)
        .class_function("shell", &ShapeFactory::shell)
        .class_function("solid", &ShapeFactory::solid)
        .class_function("makeThickSolidBySimple", &ShapeFactory::makeThickSolidBySimple)
        .class_function("makeThickSolidBySimpleTracked", &ShapeFactory::makeThickSolidBySimpleTracked)
        .class_function("makeThickSolidByJoin", &ShapeFactory::makeThickSolidByJoin)
        .class_function("makeThickSolidByJoinTracked", &ShapeFactory::makeThickSolidByJoinTracked)
        .class_function("draft", &ShapeFactory::draft)
        .class_function("draftTracked", &ShapeFactory::draftTracked)
        .class_function("offsetFacesTracked", &ShapeFactory::offsetFacesTracked)
        .class_function("simplifyShape", &ShapeFactory::simplifyShape)
        .class_function("booleanCommon", &ShapeFactory::booleanCommon)
        .class_function("booleanCut", &ShapeFactory::booleanCut)
        .class_function("booleanFuse", &ShapeFactory::booleanFuse)
        .class_function("combine", &ShapeFactory::combine)
        .class_function("fillet", &ShapeFactory::fillet)
        .class_function("chamfer", &ShapeFactory::chamfer)
        .class_function("filletVariable", &ShapeFactory::filletVariable)
        .class_function("chamferTwoDist", &ShapeFactory::chamferTwoDist)
        .class_function("revolveTracked", &ShapeFactory::revolveTracked)
        .class_function("prismTracked", &ShapeFactory::prismTracked)
        .class_function("prismToFaceTracked", &ShapeFactory::prismToFaceTracked)
        .class_function("loftTracked", &ShapeFactory::loftTracked)
        .class_function("booleanCommonTracked", &ShapeFactory::booleanCommonTracked)
        .class_function("booleanCutTracked", &ShapeFactory::booleanCutTracked)
        .class_function("booleanFuseTracked", &ShapeFactory::booleanFuseTracked)
        .class_function("filletTracked", &ShapeFactory::filletTracked)
        .class_function("chamferTracked", &ShapeFactory::chamferTracked)
        .class_function("filletVariableTracked", &ShapeFactory::filletVariableTracked)
        .class_function("chamferTwoDistTracked", &ShapeFactory::chamferTwoDistTracked)
        .class_function("fillet2d", &ShapeFactory::fillet2d)
        .class_function("chamfer2d", &ShapeFactory::chamfer2d)
        .class_function("filletEdge2d", &ShapeFactory::filletEdge2d)
        .class_function("chamferEdge2d", &ShapeFactory::chamferEdge2d)
        .class_function("fixShape", &ShapeFactory::fixShape)
        .class_function("fixSmallFace", &ShapeFactory::fixSmallFace)
        .class_function("fixSolid", &ShapeFactory::fixSolid)
        .class_function("loft", &ShapeFactory::loft)
        .class_function("gordon", &ShapeFactory::gordon)
        .class_function("curveProjection", &ShapeFactory::curveProjection)
        .class_function("removeFeature", &ShapeFactory::removeFeature)
        .class_function("removeFillet", &ShapeFactory::removeFillet)
        .class_function("removeSubShape", &ShapeFactory::removeSubShape)
        .class_function("replaceSubShapes", &ShapeFactory::replaceSubShapes)
        .class_function("glueShapes", &ShapeFactory::glueShapes)
        .class_function("sewing", &ShapeFactory::sewing);
}