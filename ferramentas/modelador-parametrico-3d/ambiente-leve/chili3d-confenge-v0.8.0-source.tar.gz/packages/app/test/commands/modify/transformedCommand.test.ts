// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import {
    BodyInstanceNode,
    BoundingBox,
    ComponentNode,
    DimensionAnnotation,
    GeometryNode,
    Matrix4,
    MeshNode,
    MultistepCommand,
    Plane,
    PubSub,
    VisualConfig,
    XYZ,
} from "@chili3d/core";
import { TestDocument } from "@chili3d/core/test-utils";
import { afterAll, beforeAll, describe, expect, rs, test } from "@rstest/core";
import { BoxNode } from "../../../src/bodys/box";
import { Move } from "../../../src/commands/modify/move";
import {
    ensureGlobalStubApp,
    makeParent,
    mockVisualNode,
    pointStepResult,
    seedStepDatas,
    stubTransactionRun,
    wireCommand,
} from "../commandTestUtils";

let restoreApp: () => void;
beforeAll(() => {
    restoreApp = ensureGlobalStubApp();
});
afterAll(() => restoreApp());

/**
 * The base class uses `instanceof MeshNode/GeometryNode/ComponentNode` to pick
 * a branch inside `canExcute`. `mockVisualNode` returns plain objects, so we
 * reassign the prototype so the instanceof checks resolve to the intended class
 * without constructing a real node (which would need a full document).
 */
function asInstance<T>(node: unknown, klass: abstract new (...args: any[]) => T): T {
    Object.setPrototypeOf(node, klass.prototype);
    return node as T;
}

describe("TransformedCommand (via Move)", () => {
    test("isClone should default to false", () => {
        const cmd = new Move();
        expect(cmd.isClone).toBe(false);
    });

    test("isClone setter should update property", () => {
        const cmd = new Move();
        cmd.isClone = true;
        expect(cmd.isClone).toBe(true);
    });

    test("should extend MultistepCommand", () => {
        const cmd = new Move();
        expect(cmd instanceof MultistepCommand).toBe(true);
    });

    describe("transformPreview", () => {
        test("should apply transfrom() to the seeded positions and return an EdgeMeshData", () => {
            const cmd = new Move();
            wireCommand(cmd);
            seedStepDatas(cmd, [pointStepResult({ point: XYZ.zero })]);
            // seed positions the base class reads in transformPreview
            (cmd as any).positions = [0, 0, 0, 1, 1, 1];

            const data = (cmd as any).transformPreview(new XYZ({ x: 2, y: 3, z: 4 }));

            // Move.transfrom is a pure translation by (point - stepDatas[0].point)
            // so each seeded vertex shifts by (2, 3, 4).
            expect(data.position instanceof Float32Array).toBe(true);
            expect(Array.from(data.position)).toEqual([
                2,
                3,
                4, // (0,0,0) + (2,3,4)
                3,
                4,
                5, // (1,1,1) + (2,3,4)
            ]);
            expect(data.lineType).toBe("solid");
            expect(data.color).toBe(VisualConfig.defaultEdgeColor);
        });

        test("should produce an identity-transformed preview when the translation is zero", () => {
            const cmd = new Move();
            wireCommand(cmd);
            seedStepDatas(cmd, [pointStepResult({ point: new XYZ({ x: 1, y: 1, z: 1 }) })]);
            (cmd as any).positions = [1, 2, 3];

            const data = (cmd as any).transformPreview(new XYZ({ x: 1, y: 1, z: 1 }));
            expect(Array.from(data.position)).toEqual([1, 2, 3]);
        });
    });

    describe("getTempLineData", () => {
        test("should build an edge mesh between two points with the temporary edge color", () => {
            const cmd = new Move();
            wireCommand(cmd);

            const start = new XYZ({ x: 0, y: 0, z: 0 });
            const end = new XYZ({ x: 5, y: 0, z: 0 });
            const data = (cmd as any).getTempLineData(start, end);

            expect(Array.from(data.position)).toEqual([0, 0, 0, 5, 0, 0]);
            expect(data.color).toBe(VisualConfig.temporaryEdgeColor);
            expect(data.lineType).toBe("solid");
        });
    });

    describe("ensureSelectedModels", () => {
        test("should skip the picker when selection already returns nodes", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const { node } = mockVisualNode("mesh", { position: [0, 0, 0] });
            (doc.selection as any).getSelectedVisualNodes = () => [node];
            const pickNodeSpy = rs.spyOn(doc.picker as any, "pickNode");

            const ok = await (cmd as any).ensureSelectedModels();

            expect(ok).toBe(true);
            expect((cmd as any).models).toEqual([node]);
            expect(pickNodeSpy).not.toHaveBeenCalled();
        });

        test("should explain a selection made only of world-space inputs", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            (doc.selection as any).getSelectedVisualNodes = () => [{ transformMode: "none" }];
            const pickNodeSpy = rs.spyOn(doc.picker as any, "pickNode");
            const pubSpy = rs.spyOn(PubSub.default, "pub");
            try {
                const ok = await (cmd as any).ensureSelectedModels();

                expect(ok).toBe(false);
                expect(pubSpy).toHaveBeenCalledWith("showToast", "toast.node.notTransformable");
                expect(pickNodeSpy).not.toHaveBeenCalled();
            } finally {
                pubSpy.mockRestore();
            }
        });

        test("should fall back to pickNode and return true when it yields models", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const { node } = mockVisualNode("mesh", { position: [0, 0, 0] });
            (doc.selection as any).getSelectedVisualNodes = () => [];
            const pickNodeSpy = rs.spyOn(doc.picker as any, "pickNode");
            pickNodeSpy.mockResolvedValue([node]);

            const ok = await (cmd as any).ensureSelectedModels();

            expect(ok).toBe(true);
            expect((cmd as any).models).toEqual([node]);
            expect(pickNodeSpy).toHaveBeenCalled();
        });

        test("should publish toast.select.noSelected when picker succeeds but returns nothing", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            (doc.selection as any).getSelectedVisualNodes = () => [];
            // pickNode receives the AsyncController created inside ensureSelectedModels;
            // mark it success before resolving so the toast branch fires.
            (doc.picker as any).pickNode = rs.fn(async (_p: string, controller: any) => {
                controller.success();
                return [];
            });
            const pubSpy = rs.spyOn(PubSub.default, "pub");
            try {
                const ok = await (cmd as any).ensureSelectedModels();

                expect(ok).toBe(false);
                expect(pubSpy).toHaveBeenCalledWith("showToast", "toast.select.noSelected");
            } finally {
                pubSpy.mockRestore();
            }
        });

        test("should return false without toast when picker resolves empty but controller is not success", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            (doc.selection as any).getSelectedVisualNodes = () => [];
            (doc.picker as any).pickNode = rs.fn(async () => []);
            const pubSpy = rs.spyOn(PubSub.default, "pub");
            try {
                const ok = await (cmd as any).ensureSelectedModels();

                expect(ok).toBe(false);
                expect(pubSpy).not.toHaveBeenCalled();
            } finally {
                pubSpy.mockRestore();
            }
        });
    });

    describe("canExcute", () => {
        test("should flatten MeshNode mesh.position through the node transform", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const { node } = mockVisualNode("mesh", { position: [1, 2, 3, 4, 5, 6] });
            asInstance(node, MeshNode);
            (doc.selection as any).getSelectedVisualNodes = () => [node];

            const ok = await (cmd as any).canExcute();

            expect(ok).toBe(true);
            // identity transform → positions pass through unchanged
            expect((cmd as any).positions).toEqual([1, 2, 3, 4, 5, 6]);
        });

        test("should skip a MeshNode whose mesh.position is falsy", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const { node } = mockVisualNode("mesh", {});
            asInstance(node, MeshNode);
            (node as any).mesh = {}; // no position
            (doc.selection as any).getSelectedVisualNodes = () => [node];

            const ok = await (cmd as any).canExcute();

            expect(ok).toBe(true);
            expect((cmd as any).positions).toEqual([]);
        });

        test("should flatten GeometryNode mesh.edges.position through the node transform", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const { node } = mockVisualNode("geometry", { edgesPosition: [7, 8, 9] });
            asInstance(node, GeometryNode);
            (doc.selection as any).getSelectedVisualNodes = () => [node];

            const ok = await (cmd as any).canExcute();

            expect(ok).toBe(true);
            expect((cmd as any).positions).toEqual([7, 8, 9]);
        });

        test("should skip a GeometryNode whose mesh.edges.position is falsy", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const { node } = mockVisualNode("geometry", {});
            asInstance(node, GeometryNode);
            (node as any).mesh = { edges: {} };
            (doc.selection as any).getSelectedVisualNodes = () => [node];

            const ok = await (cmd as any).canExcute();

            expect(ok).toBe(true);
            expect((cmd as any).positions).toEqual([]);
        });

        test("should flatten a ComponentNode via BoundingBox.wireframe", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const { node } = mockVisualNode("component", {});
            asInstance(node, ComponentNode);
            // canExcute reads model.boundingBox() then BoundingBox.wireframe(box);
            // return a real BoundingBox so wireframe can read min/max.
            (node as any).boundingBox = () =>
                new BoundingBox(new XYZ({ x: 0, y: 0, z: 0 }), new XYZ({ x: 1, y: 1, z: 1 }));
            (doc.selection as any).getSelectedVisualNodes = () => [node];

            const ok = await (cmd as any).canExcute();

            expect(ok).toBe(true);
            // BoundingBox.wireframe emits 12 edges × 2 endpoints × 3 coords = 72 numbers.
            const positions = (cmd as any).positions as number[];
            expect(positions.length).toBe(72);
        });

        test("should return false when no models can be resolved", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            (doc.selection as any).getSelectedVisualNodes = () => [];
            (doc.picker as any).pickNode = rs.fn(async () => []);

            const ok = await (cmd as any).canExcute();

            expect(ok).toBe(false);
            expect((cmd as any).positions).toBeUndefined();
        });
    });

    describe("applyPlacement", () => {
        test("publishes a toast when the node's transform hook refuses the move", () => {
            const cmd = new Move();
            wireCommand(cmd);
            const pubSpy = rs.spyOn(PubSub.default, "pub").mockImplementation(() => {});
            const node = { transform: Matrix4.identity(), applyTransform: () => false } as any;

            try {
                (cmd as any).applyPlacement(node, Matrix4.fromTranslation(1, 0, 0));
                expect(pubSpy).toHaveBeenCalledWith("showToast", "toast.node.transformRefused");
            } finally {
                pubSpy.mockRestore();
            }
        });

        test("treats a hook that returns nothing as accepted, like the AI tool", () => {
            const cmd = new Move();
            wireCommand(cmd);
            const pubSpy = rs.spyOn(PubSub.default, "pub").mockImplementation(() => {});
            const node = {
                transform: Matrix4.identity(),
                applyTransform: rs.fn(() => undefined),
            } as any;

            try {
                (cmd as any).applyPlacement(node, Matrix4.fromTranslation(1, 0, 0));
                expect(pubSpy).not.toHaveBeenCalledWith("showToast", "toast.node.transformRefused");
            } finally {
                pubSpy.mockRestore();
            }
        });
    });

    describe("executeMainTask", () => {
        /**
         * A node that records the last transform assigned to it, so tests can
         * assert what the base class wrote without depending on Matrix4 internals.
         * `multiply` on the identity transform yields the assigned matrix directly.
         */
        function trackingNode(parent?: any) {
            const cloneHolder: any = { transform: undefined as unknown as Matrix4 };
            return {
                node: {
                    parent,
                    get transform() {
                        return Matrix4.identity();
                    },
                    set transform(value: Matrix4) {
                        (this as any)._assigned = value;
                    },
                    assigned(): Matrix4 {
                        return (this as any)._assigned;
                    },
                    worldTransform() {
                        return Matrix4.identity();
                    },
                    clone() {
                        return cloneHolder;
                    },
                },
                cloneHolder,
            };
        }

        test("should multiply each model's transform in place when isClone is false", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                const { node } = trackingNode();
                wireCommand(cmd);
                (cmd as any).models = [node];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 10, y: 20, z: 30 }) }),
                ]);

                (cmd as any).executeMainTask();

                // identity.multiply(translation) == translation; move by (10,20,30).
                const expected = Matrix4.fromTranslation(10, 20, 30);
                const assigned = node.assigned();
                for (let i = 0; i < 16; i++) {
                    expect(assigned.array[i]).toBeCloseTo(expected.array[i], 6);
                }
            } finally {
                restore();
            }
        });

        test("should clone each model and insertAfter the original when isClone is true", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                cmd.isClone = true;
                const parent = makeParent({ id: "parent" });
                const { node, cloneHolder } = trackingNode(parent);
                wireCommand(cmd);
                (cmd as any).models = [node];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 1, y: 2, z: 3 }) }),
                ]);

                (cmd as any).executeMainTask();

                expect(parent.insertedAfter).toHaveLength(1);
                expect(parent.insertedAfter[0].target).toBe(node);
                expect(parent.insertedAfter[0].node).toBe(cloneHolder);
                // the clone received the multiplied transform (identity * translation)
                const expected = Matrix4.fromTranslation(1, 2, 3);
                for (let i = 0; i < 16; i++) {
                    expect(cloneHolder.transform.array[i]).toBeCloseTo(expected.array[i], 6);
                }
            } finally {
                restore();
            }
        });

        test("should let a node choose how its copy is made (instance copy)", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                cmd.isClone = true;
                const parent = makeParent({ id: "parent" });
                const { node } = trackingNode(parent);
                const instance = { marker: "instance" };
                const cloneForCopy = rs.fn((_transform: Matrix4) => instance as any);
                (node as any).cloneForCopy = cloneForCopy;
                wireCommand(cmd);
                (cmd as any).models = [node];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 1, y: 2, z: 3 }) }),
                ]);

                (cmd as any).executeMainTask();

                expect(cloneForCopy).toHaveBeenCalledTimes(1);
                expect(parent.insertedAfter[0].node).toBe(instance);
            } finally {
                restore();
            }
        });

        test("a primitive body copies as an instance of itself", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                cmd.isClone = true;
                const { doc } = wireCommand(cmd);
                const parent = makeParent({ id: "parent" });
                const box = new BoxNode({
                    document: doc as any,
                    plane: Plane.XY,
                    dx: 1,
                    dy: 1,
                    dz: 1,
                });
                box.parent = parent as any;
                (cmd as any).models = [box];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 1, y: 2, z: 3 }) }),
                ]);

                (cmd as any).executeMainTask();

                const inserted = parent.insertedAfter[0].node as BodyInstanceNode;
                expect(inserted).toBeInstanceOf(BodyInstanceNode);
                expect(inserted.sourceId).toBe(box.id);
                expect(inserted.transform.equals(Matrix4.fromTranslation(1, 2, 3))).toBe(true);
            } finally {
                restore();
            }
        });

        test("should call document.visual.update() after mutating models", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                const { node } = trackingNode();
                const { doc } = wireCommand(cmd);
                (cmd as any).models = [node];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 0, y: 0, z: 0 }) }),
                ]);
                const updateSpy = doc.visual.update as unknown as ReturnType<typeof rs.fn>;

                (cmd as any).executeMainTask();

                expect(updateSpy).toHaveBeenCalled();
            } finally {
                restore();
            }
        });

        test("should not clone a consumed boolean tool and show a hint", async () => {
            const cmd = new Move();
            cmd.isClone = true;
            // A plain-object parent is not a FolderNode → the node reads as a consumed tool.
            const bodyParent = { insertAfter: rs.fn() };
            const { node } = trackingNode(bodyParent);
            const { doc } = wireCommand(cmd);
            (doc.selection as any).getSelectedVisualNodes = () => [node];
            const pubSpy = rs.spyOn(PubSub.default, "pub");
            try {
                const ok = await (cmd as any).canExcute();

                expect(ok).toBe(false);
                expect((cmd as any).models).toEqual([]);
                expect(bodyParent.insertAfter).not.toHaveBeenCalled();
                expect(pubSpy).toHaveBeenCalledWith("showToast", "toast.consumedTool.forbidden");
            } finally {
                pubSpy.mockRestore();
            }
        });

        test("should not move a consumed boolean tool and show a hint", async () => {
            const cmd = new Move();
            // Consumed: parent set, not a FolderNode.
            const { node } = trackingNode({});
            const { doc } = wireCommand(cmd);
            (doc.selection as any).getSelectedVisualNodes = () => [node];
            const pubSpy = rs.spyOn(PubSub.default, "pub");
            try {
                const ok = await (cmd as any).canExcute();

                expect(ok).toBe(false);
                expect(node.assigned()).toBeUndefined();
                expect(pubSpy).toHaveBeenCalledWith("showToast", "toast.consumedTool.forbidden");
            } finally {
                pubSpy.mockRestore();
            }
        });

        test("should move only the free nodes of a mixed selection", async () => {
            const restore = stubTransactionRun();
            const pubSpy = rs.spyOn(PubSub.default, "pub");
            try {
                const cmd = new Move();
                const free = trackingNode(makeParent());
                const consumed = trackingNode({});
                const { doc } = wireCommand(cmd);
                (doc.selection as any).getSelectedVisualNodes = () => [free.node, consumed.node];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 5, y: 0, z: 0 }) }),
                ]);

                expect(await (cmd as any).canExcute()).toBe(true);
                (cmd as any).executeMainTask();

                const expected = Matrix4.fromTranslation(5, 0, 0);
                for (let i = 0; i < 16; i++) {
                    expect(free.node.assigned().array[i]).toBeCloseTo(expected.array[i], 6);
                }
                expect(consumed.node.assigned()).toBeUndefined();
                expect(pubSpy).toHaveBeenCalledWith("showToast", "toast.consumedTool.forbidden");
            } finally {
                pubSpy.mockRestore();
                restore();
            }
        });
    });

    describe("annotations", () => {
        function dimension() {
            return new DimensionAnnotation({
                document: new TestDocument() as any,
                annotationType: "dimension",
                name: "dim",
                startPoint: XYZ.zero,
                endPoint: new XYZ({ x: 10, y: 0, z: 0 }),
                textPoint: new XYZ({ x: 5, y: 8, z: 0 }),
            });
        }

        test("moves an annotation through its transform, leaving the points local", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                const anno = dimension();
                wireCommand(cmd);
                (cmd as any).models = [anno];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 1, y: 2, z: 3 }) }),
                ]);

                (cmd as any).executeMainTask();

                expect(anno.startPoint).toEqual(XYZ.zero);
                expect(anno.endPoint).toEqual(new XYZ({ x: 10, y: 0, z: 0 }));
                expect(anno.textPoint).toEqual(new XYZ({ x: 5, y: 8, z: 0 }));
                expect(anno.transform.equals(Matrix4.fromTranslation(1, 2, 3))).toBe(true);
            } finally {
                restore();
            }
        });

        test("moving a bound annotation detaches it", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                const anno = dimension();
                anno.association = {
                    kind: "circleEdge",
                    nodeId: "body",
                    edge: {},
                    axis: { x: 0, y: 0, z: 1 },
                    leader: { x: 1, y: 0, z: 0 },
                    distance: 10,
                };
                wireCommand(cmd);
                (cmd as any).models = [anno];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 1, y: 2, z: 3 }) }),
                ]);

                (cmd as any).executeMainTask();

                expect(anno.association).toBeUndefined();
            } finally {
                restore();
            }
        });

        test("clones an annotation onto the translated copy when isClone is true", () => {
            const restore = stubTransactionRun();
            try {
                const cmd = new Move();
                cmd.isClone = true;
                const parent = makeParent({ id: "parent" });
                const anno = dimension();
                anno.parent = parent as any;
                wireCommand(cmd);
                (cmd as any).models = [anno];
                seedStepDatas(cmd, [
                    pointStepResult({ point: XYZ.zero }),
                    pointStepResult({ point: new XYZ({ x: 5, y: 0, z: 0 }) }),
                ]);

                (cmd as any).executeMainTask();

                expect(parent.insertedAfter).toHaveLength(1);
                const clone = parent.insertedAfter[0].node as DimensionAnnotation;
                expect(clone).not.toBe(anno);
                expect(clone.startPoint).toEqual(XYZ.zero);
                expect(clone.endPoint).toEqual(new XYZ({ x: 10, y: 0, z: 0 }));
                expect(clone.textPoint).toEqual(new XYZ({ x: 5, y: 8, z: 0 }));
                expect(clone.transform.equals(Matrix4.fromTranslation(5, 0, 0))).toBe(true);
                // the original stays put
                expect(anno.startPoint).toEqual(XYZ.zero);
                expect(anno.transform.equals(Matrix4.identity())).toBe(true);
            } finally {
                restore();
            }
        });

        test("previews an annotation through its transformed bounding-box wireframe", async () => {
            const cmd = new Move();
            const { doc } = wireCommand(cmd);
            const anno = dimension();
            anno.transform = Matrix4.fromTranslation(100, 0, 0);
            (doc.selection as any).getSelectedVisualNodes = () => [anno];

            const ok = await (cmd as any).canExcute();

            expect(ok).toBe(true);
            const positions = (cmd as any).positions as number[];
            expect(positions.length).toBe(72);
            // the wireframe's min corner moved with the annotation's transform
            expect([positions[0], positions[1], positions[2]]).toEqual([100, 0, 0]);
        });
    });
});
