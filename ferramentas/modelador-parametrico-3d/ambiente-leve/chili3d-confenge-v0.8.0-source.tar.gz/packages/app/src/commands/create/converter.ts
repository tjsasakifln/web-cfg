// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import {
    AsyncController,
    CancelableCommand,
    command,
    EditableShapeNode,
    type GeometryNode,
    type IDocument,
    type IEdge,
    type IFace,
    type INode,
    type IShape,
    type IShapeFilter,
    type IShell,
    instanceSourcesInUse,
    isReferenceGeometryNode,
    PubSub,
    Result,
    retargetInstanceSources,
    SelectNodeStep,
    type ShapeNode,
    ShapeNodeFilter,
    ShapeTypes,
    Transaction,
} from "@chili3d/core";
import { FaceNode } from "../../bodys/face";
import { WireNode } from "../../bodys/wire";
import { repairShape } from "../modify";

abstract class ConvertCommand extends CancelableCommand {
    async executeAsync(): Promise<void> {
        const models = await this.getOrPickModels(this.document);
        if (!models) {
            PubSub.default.pub("showToast", "toast.select.noSelected");
            return;
        }
        // Converting several nodes produces one successor-less result; a single node is
        // a one-for-one replacement its instances can follow.
        const inUse = instanceSourcesInUse(this.document, models);
        if (inUse.size > 0 && models.length > 1) {
            PubSub.default.pub("showToast", "toast.instance.sourceInUse");
            return;
        }

        Transaction.execute(this.document, `excute ${Object.getPrototypeOf(this).data.name}`, () => {
            const node = this.create(this.document, models);
            if (!node.isOk) {
                PubSub.default.pub("showToast", "error.default:{0}", node.error);
            } else {
                this.document.modelManager.rootNode.add(node.value);
                if (inUse.size > 0) {
                    retargetInstanceSources(this.document, models[0].id, node.value.id);
                }
                models.forEach((x) => x.parent?.remove(x));
                this.document.visual.update();
                PubSub.default.pub("showToast", "toast.success");
            }
        });
    }

    protected abstract create(document: IDocument, models: INode[]): Result<GeometryNode>;
    protected shapeFilter(): IShapeFilter {
        return {
            allow: (shape: IShape) =>
                shape.shapeType === ShapeTypes.edge || shape.shapeType === ShapeTypes.wire,
        };
    }

    async getOrPickModels(document: IDocument) {
        const filter = this.shapeFilter();
        const models = this._getSelectedModels(document, filter);
        document.selection.clearSelection();
        if (models.length > 0) return models;

        const step = new SelectNodeStep("prompt.select.models", {
            filter: new ShapeNodeFilter(filter),
            multiple: true,
        });
        this.controller = new AsyncController();
        const data = await step.execute(document, this.controller);
        document.selection.clearSelection();
        return data?.nodes;
    }

    private _getSelectedModels(document: IDocument, filter?: IShapeFilter) {
        return document.selection
            .getSelectedNodes()
            .map((x) => x as ShapeNode)
            .filter((x) => {
                if (x === undefined || isReferenceGeometryNode(x)) return false;
                const shape = x.shape.value;
                if (shape === undefined) return false;
                if (filter !== undefined && !filter.allow(shape, x.transform)) return false;
                return true;
            });
    }
}

@command({
    key: "convert.toWire",
    icon: "icon-toPoly",
})
export class ConvertToWire extends ConvertCommand {
    protected override create(document: IDocument, models: ShapeNode[]): Result<GeometryNode> {
        const edges = models
            .map((x) => x.shape.value.transformedMul(x.worldTransform()))
            .flatMap((s) => {
                if (s.shapeType === ShapeTypes.edge) {
                    return [s];
                } else if (s.shapeType === ShapeTypes.wire) {
                    return s.findSubShapes(ShapeTypes.edge);
                }
                return [];
            }) as IEdge[];
        const wireBody = new WireNode({ document, edges });
        const shape = wireBody.generateShape();
        if (!shape.isOk) return Result.err(shape.error);

        return Result.ok(wireBody);
    }
}

@command({
    key: "convert.toFace",
    icon: "icon-toFace",
})
export class ConvertToFace extends ConvertCommand {
    protected override create(document: IDocument, models: ShapeNode[]): Result<GeometryNode> {
        const edges = models.map((x) => x.shape.value.transformedMul(x.worldTransform())) as IEdge[];
        const wireBody = new FaceNode({ document, shapes: edges });
        const shape = wireBody.generateShape();
        if (!shape.isOk) return Result.err(shape.error);

        return Result.ok(wireBody);
    }
}

@command({
    key: "convert.toShell",
    icon: "icon-toShell",
})
export class ConvertToShell extends ConvertCommand {
    protected override shapeFilter(): IShapeFilter {
        return {
            allow: (shape: IShape) => shape.shapeType === ShapeTypes.face,
        };
    }

    protected override create(document: IDocument, models: ShapeNode[]): Result<GeometryNode> {
        const faces = models.map((x) => x.shape.value.transformedMul(x.worldTransform())) as IFace[];
        const shape = shapeFactory.shell(faces);
        faces.forEach((x) => x.dispose());
        if (!shape.isOk) return Result.err(shape.error);

        const shell = new EditableShapeNode({ document, name: "shell", shape });
        return Result.ok(shell);
    }
}

@command({
    key: "convert.toSolid",
    icon: "icon-toSolid",
})
export class ConvertToSolid extends ConvertCommand {
    protected override shapeFilter(): IShapeFilter {
        return {
            allow: (shape: IShape) => shape.shapeType === ShapeTypes.shell,
        };
    }

    protected override create(document: IDocument, models: ShapeNode[]): Result<GeometryNode> {
        const shells = models.map((x) => x.shape.value.transformedMul(x.worldTransform())) as IShell[];
        // An imported shell often has gaps too small to see. The sew that closes them used to
        // run on the built solid, but `solid` now refuses an open shell — repair first, then
        // let the builder validate whatever the repair could not close.
        const compound = shapeFactory.combine(shells);
        shells.forEach((x) => x.dispose());
        // `combine` reads well under real handles; this keeps a binding-level JS exception
        // (which `convertShapeResult` reports as Result.err) from becoming a crash. A real
        // OCCT raise aborts the release wasm outright, so it is not what this guards.
        if (!compound.isOk) return Result.err(compound.error);

        const repaired = repairShape(compound.value, 1e-7);
        if (repaired !== compound.value) compound.value.dispose();
        const shape = shapeFactory.solid(repaired.findSubShapes(ShapeTypes.shell) as IShell[]);
        repaired.dispose();
        if (!shape.isOk) return Result.err(shape.error);

        const solid = new EditableShapeNode({ document, name: "solid", shape: shape.value });
        return Result.ok(solid);
    }
}

@command({
    key: "convert.toCompound",
    icon: "icon-compound",
})
export class ConvertToCompound extends ConvertCommand {
    protected override shapeFilter(): IShapeFilter {
        return {
            allow: () => true,
        };
    }

    protected override create(document: IDocument, models: ShapeNode[]): Result<GeometryNode> {
        const shapes = models.map((x) => x.shape.value.transformedMul(x.worldTransform()));
        const shape = shapeFactory.combine(shapes);
        shapes.forEach((x) => x.dispose());
        if (!shape.isOk) return Result.err(shape.error);

        const compound = new EditableShapeNode({ document, name: "compound", shape });
        return Result.ok(compound);
    }
}
