// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import type { Result } from "../foundation";
import type { Line, Plane, XYZ, XYZLike } from "../math";
import type { Continuity, ICurve } from "./curve";
import type {
    ICompound,
    IEdge,
    IFace,
    IShape,
    IShell,
    ISolid,
    IVertex,
    IWire,
    JoinType,
    OffsetMode,
    SweepProfileMode,
} from "./shape";

export interface TrackedShape {
    shape: IShape;
    /**
     * Every (output, input) face derivation as flat pairs (out0, in0, out1, in1, ...), in
     * ascending input order (identity first for each input). This is the kernel's WHOLE
     * relation, not a first-ancestor-only map: a face MERGED from several inputs records each
     * of them, whichever operation merged it, and "the first ancestor" is derived where a
     * single index is wanted (`primaryAncestors` below) rather than dropped here.
     * A sub-shape no input derives from simply has no pair.
     */
    faceAncestors: number[];
    /**
     * The edge counterpart of `faceAncestors`, emitted alongside it and consumed exactly as it
     * is — by `mapBooleanIds`/`mapOperationIds`/`mapFusedIds` alike, through the pairs
     * `completeTrackedHistory` verified: a fuse of two touching swept prisms reports pairs the
     * geometry contradicts (measured: a merged top edge recorded as derived from a BOTTOM edge),
     * and composing those unverified minted ids naming sub-shapes millimetres away.
     */
    edgeAncestors: number[];
    /**
     * output face index (findSubShapes order) -> input edge index for faces generated
     * from an input edge (a sweep's side faces), -1 = not edge-generated. Lets callers
     * seed side faces with the generating edge's stable id instead of a fragile
     * enumeration-order-scoped one. Absent when the kernel predates this map.
     */
    faceEdgeMap?: number[];
    /**
     * Output face indexes (findSubShapes order) of a sweep's end cap, reported
     * directly by the kernel (LastShape): a prism's top face, a PARTIAL revolve's
     * end cap. Empty for non-sweeps and full-turn revolves (first/last shapes
     * coincide — those keep the geometric probe). Deliberately separate from the
     * derivation: the cap must not claim the profile face's ancestors and collide
     * with the identical bottom/start face. Absent when the kernel predates this
     * channel — callers then fall back to the history-less-face heuristic.
     * A solid loft reports BOTH caps here instead, in [start, end] section order
     * (a vertex end has no cap): loft inputs are wires/vertices, so no derivation
     * channel can name a cap.
     */
    capFaces?: number[];
    /**
     * Output face index (findSubShapes order) -> input face index of the PARALLEL COPY a
     * thicken offsets that face into (its "offset surface"), -1 = not an offset image.
     * A separate channel on purpose: the derivation pairs report the input face as its own
     * descendant AND report the copy off it, so a caller reading only the pairs would stamp
     * one id on two distinct faces (a box top thickened by -2 yields the kept top, 4 rim
     * bands, and a copy 2mm below, the copy derived from the same input face). Only the
     * kernel can tell the copy from the kept face.
     */
    offsetFaceMap?: number[];
    /** The edge counterpart of `offsetFaceMap`. */
    offsetEdgeMap?: number[];
}

/**
 * The FIRST ancestor of every output — one index per output in findSubShapes order, -1 where no
 * input derives it. Most callers want exactly this single index ("is this sub-shape new?",
 * "which input did it come from?"), and it is derived from the pairs rather than emitted beside
 * them, so the two can never disagree and no operation has to decide whether its merges are
 * worth recording. "First" is the smallest input index: the pairs arrive in ascending input
 * order, identity first.
 */
export function primaryAncestors(ancestors: readonly number[] | undefined, count: number): number[] {
    const map = new Array<number>(count).fill(-1);
    // A producer predating the pair channel reports no ancestors at all: every sub-shape is then
    // "new", which is exactly the id-less state tracking degrades to (`trackedIds`).
    if (ancestors === undefined) return map;
    for (let i = 0; i + 1 < ancestors.length; i += 2) {
        const output = ancestors[i];
        if (output >= 0 && output < count && map[output] < 0) map[output] = ancestors[i + 1];
    }
    return map;
}

/**
 * Why an offset of faces failed. The kernel CLASSIFIES the failure rather than wording it —
 * the wording is per locale and belongs to the feature — and for the common failure it also
 * reports how far the body would have taken, which it only knows by searching for it.
 */
export interface OffsetFaceProblem {
    /**
     * `1` the distance is too far (read `maxDistance`), `2` no distance works on these faces,
     * `3` the body is not a solid, `4` the body has a sealed void inside, `5` OCCT raised,
     * `6` rounded edges meet at a sharp corner inside one smooth chain, `7` the rounds beside a
     * moving face cannot be kept (only with `requireRounds`, and only when the move would
     * otherwise have succeeded). `0` when the kernel gave no classification at all.
     */
    readonly status: number;
    /**
     * With status 1, the largest distance OF THE SAME SIGN that does work, in millimetres —
     * the "max ≈ this" of the message. With status 2, the smallest distance known to fail: the
     * probe the kernel answered without a search, which a caller may cache as a lower bound for
     * THIS direction only. 0 when the kernel knows of no such distance.
     */
    readonly maxDistance: number;
}

export interface IShapeFactory {
    readonly kernelName: string;
    edge(curve: ICurve): IEdge;
    face(wire: IWire[]): Result<IFace>;
    faceFromSurface(wires: IWire[], sourceFace: IFace): Result<IFace>;
    /**
     * Minimal bounded planar regions enclosed by `edges` on `plane`: the edges are split
     * at mutual intersections first, so crossing curves (e.g. overlapping sketch
     * rectangles without shared endpoints) yield every bounded region — unlike `face`,
     * which only chains endpoint-connected wires. Dangling edges produce no region.
     * `sources[k]` is the sorted unique indexes of the input edges bounding `faces[k]`.
     */
    facesFromEdges(edges: IEdge[], plane: Plane): Result<{ faces: IFace[]; sources: number[][] }>;
    shell(faces: IFace[]): Result<IShell>;
    solid(shells: IShell[]): Result<ISolid>;
    bezier(points: XYZLike[], weights?: number[]): Result<IEdge>;
    /**
     * A rational B-spline edge, clamped at both ends: the general form `bezier` is a special
     * case of. `knots` is the *flat* vector (one entry per index, repeats and all, length
     * `poles + degree + 1`), the way a sketch entity stores it; an empty `weights` is the
     * non-rational form. Anything the kernel cannot build — a degree the pole count cannot
     * carry, an unclamped or decreasing knot vector, a non-positive weight — comes back as an
     * error result rather than a shape.
     */
    bspline(poles: XYZLike[], weights: number[] | undefined, knots: number[], degree: number): Result<IEdge>;
    helix(
        origin: XYZLike,
        normal: XYZLike,
        xDir: XYZLike,
        radius: number,
        pitch: number,
        angle: number,
    ): Result<IWire>;
    point(point: XYZLike): Result<IVertex>;
    line(start: XYZLike, end: XYZLike): Result<IEdge>;
    arc(normal: XYZLike, center: XYZLike, start: XYZLike, angle: number): Result<IEdge>;
    circle(normal: XYZLike, center: XYZLike, radius: number): Result<IEdge>;
    rect(plane: Plane, dx: number, dy: number): Result<IFace>;
    polygon(points: XYZLike[]): Result<IWire>;
    box(plane: Plane, dx: number, dy: number, dz: number): Result<ISolid>;
    ellipse(
        normal: XYZLike,
        center: XYZLike,
        xvec: XYZLike,
        majorRadius: number,
        minorRadius: number,
    ): Result<IEdge>;
    cylinder(normal: XYZLike, center: XYZLike, radius: number, dz: number): Result<ISolid>;
    cone(normal: XYZLike, center: XYZLike, radius: number, radiusUp: number, dz: number): Result<ISolid>;
    sphere(center: XYZLike, radius: number): Result<ISolid>;
    pyramid(plane: Plane, dx: number, dy: number, dz: number): Result<ISolid>;
    wire(edges: IEdge[]): Result<IWire>;
    prism(shape: IShape, vec: XYZ): Result<IShape>;
    pushPull(shape: IShape, face: IShape, vec: XYZ): Result<IShape>;
    fuse(bottom: IShape, top: IShape): Result<IShape>;
    sweep(profile: IShape[], path: IWire, isRoundCorner: boolean): Result<IShape>;
    revolve(profile: IShape, axis: Line, angle: number): Result<IShape>;
    booleanCommon(shape1: IShape[], shape2: IShape[]): Result<IShape>;
    booleanCut(shape1: IShape[], shape2: IShape[]): Result<IShape>;
    booleanFuse(shape1: IShape[], shape2: IShape[], simplifyShape: boolean): Result<IShape>;
    sewing(shapes: IShape[]): Result<IShape>;
    /**
     * General-fuse gluing: every shape's image keeps its own dimension (a solid stays a solid,
     * a flange face stays a face), while sub-shapes that coincide across shapes become a single
     * shared instance — e.g. a face drawn against a body's edge shares that edge instead of
     * duplicating it (sewing refuses such non-manifold merges). Optional: kernels predating it
     * fall back to a plain combine (coincident edges stay duplicated).
     *
     * The inputs must not interfere in volume: BOPAlgo_GlueFull assumes non-overlapping
     * shapes, and overlapping solids come back as an unmerged compound reported as success.
     * Use booleanFuse for inputs that may overlap.
     */
    glueShapes?(shapes: IShape[]): Result<IShape>;
    combine(shapes: IShape[]): Result<ICompound>;
    makeThickSolidBySimple(shape: IShape, thickness: number): Result<IShape>;
    /**
     * Tracked thicken: `makeThickSolidBySimple` with kernel history, so the bodies a
     * thicken feature appends keep stable sub-shape ids (see the parametric module).
     */
    makeThickSolidBySimpleTracked?(shape: IShape, thickness: number): Result<TrackedShape>;
    makeThickSolidByJoin(
        shape: IShape,
        openFaces: IShape[],
        thickness: number,
        joinType: JoinType,
        mode?: OffsetMode,
        intersection?: boolean,
    ): Result<IShape>;
    /** Tracked shell: `makeThickSolidByJoin` with kernel history, for stable sub-shape ids. */
    makeThickSolidByJoinTracked?(
        shape: IShape,
        openFaces: IShape[],
        thickness: number,
        joinType: JoinType,
        mode?: OffsetMode,
        intersection?: boolean,
    ): Result<TrackedShape>;
    fillet(shape: IShape, edges: number[], radius: number): Result<IShape>;
    chamfer(shape: IShape, edges: number[], distance: number): Result<IShape>;
    /**
     * Two-distance chamfer: `faces[i]` is the reference face of `edges[i]` (both indexes in the
     * shape's own findSubShapes enumeration, as with `chamfer`) — d1 is measured ON that face,
     * d2 on the edge's other face.
     */
    chamferTwoDist?(shape: IShape, edges: number[], d1: number, d2: number, faces: number[]): Result<IShape>;
    /** Tracked two-distance chamfer, for stable sub-shape ids. */
    chamferTwoDistTracked?(
        shape: IShape,
        edges: number[],
        d1: number,
        d2: number,
        faces: number[],
    ): Result<TrackedShape>;
    /**
     * Variable-radius fillet: `radii` carries one (R1, R2) pair per edge, flat — R1 at the
     * edge's start point, R2 at its end point, interpolated linearly along the edge by the
     * kernel. Equal pairs are a constant-radius fillet by another name.
     */
    filletVariable?(shape: IShape, edges: number[], radii: number[]): Result<IShape>;
    /** Tracked variable-radius fillet, for stable sub-shape ids. */
    filletVariableTracked?(shape: IShape, edges: number[], radii: number[]): Result<TrackedShape>;
    /**
     * Draft: taper each of `faces` about its intersection line with `neutralPlane`, rotating it
     * by `angle` (in degrees, converted at this boundary — as `revolve` does). `pullDirection` is
     * the side of the plane a POSITIVE angle removes material from, so the UI's opposite-direction
     * option flips it rather than negating the angle. Only planar, cylindrical and conical faces
     * can be drafted; anything else fails rather than being silently skipped. `faces` must be
     * sub-shapes of `shape` (same TShape) — the kernel matches them by identity, and its edge
     * index would miss a transformed copy.
     */
    draft(
        shape: IShape,
        faces: IFace[],
        pullDirection: XYZLike,
        angle: number,
        neutralPlane: Plane,
    ): Result<IShape>;
    /** Tracked draft: `draft` with kernel history, for stable sub-shape ids. */
    draftTracked?(
        shape: IShape,
        faces: IFace[],
        pullDirection: XYZLike,
        angle: number,
        neutralPlane: Plane,
    ): Result<TrackedShape>;
    /**
     * Offset Face: move each of `faces` by `distance` along its own outward normal, the faces
     * that run smoothly into it following. Positive moves a face OUT (the body grows there, a
     * hole's wall closes in), negative moves it in; a curved wall's radius changes with the
     * move, which is how a cylinder or a hole is resized. A distance of 0 is an error, not a
     * no-op: there is no other reading of it.
     *
     * `faces` must be sub-shapes of `shape` (same TShape) — the kernel matches them by
     * IDENTITY, so a transformed copy is a different shape and would not be found. The body is
     * refused rather than attempted when it is not a solid, has a sealed void, or has a smooth
     * chain with a sharp edge inside it (OCCT corrupts the wasm heap on the last, whichever
     * face is picked — the floor included).
     *
     * A failure carries more than a message: `OffsetFaceProblem` says which kind it was and,
     * for the common one, how far the body would have taken.
     *
     * `rounds` names the ROUND faces of a fillet whose radius must be kept. They are taken off
     * the body before the move and made again at their own radius between the faces they ran
     * between, so moving a wall does not re-radius the rounds beside it — Fusion's behavior.
     * Omit them for OCCT's own, where a round is a smooth neighbour like any other and travels
     * with the face, growing or shrinking by the distance. Only a cylinder or a torus among the
     * faces given counts as a round; the rest are ignored.
     *
     * `requireRounds` makes keeping them a requirement rather than a preference: when the plain
     * path could do the move but only by re-radiusing a named round beside a moving face, the
     * call is refused (status 7) instead of returning that body silently. A distance or a body
     * the plain path refuses too keeps its own classification (too far / a crease) — that is
     * the answer the caller can act on. A named round nowhere near the moving faces is not at
     * risk and never causes a refusal.
     */
    offsetFacesTracked?(
        shape: IShape,
        faces: IFace[],
        distance: number,
        rounds?: IFace[],
        requireRounds?: boolean,
    ): Result<TrackedShape, OffsetFaceProblem>;
    prismTracked?(shape: IShape, vec: XYZ): Result<TrackedShape>;
    /**
     * Tracked prism terminated BY a face: the profile sweeps along `direction` until the
     * limit face, the end capped by the limit SURFACE itself (a curved target gives a
     * conforming cap) instead of by a plane — kernel `BRepFeat_MakePrism::Perform(Until)`.
     *
     * `mode` says what the prism is for: "cut"/"join" combine it with `sbase` (which must
     * be the body `until` belongs to), "new" returns the limited prism alone (`sbase` is
     * ignored, pass `until`). The history input enumerates [`sbase`, `pbase`, `until`] for
     * "cut"/"join" and [`pbase`, `until`] for "new", as the tracked boolean's [args, tools].
     *
     * The kernel refuses (Result.err, never a raise) when `until` has no face, the profile
     * is not a face, the direction is zero, or the sweep never meets the limit — the caller
     * falls back to the planar-cap path.
     */
    prismToFaceTracked?(
        sbase: IShape,
        pbase: IFace,
        until: IFace,
        direction: XYZ,
        mode: "cut" | "join" | "new",
    ): Result<TrackedShape>;
    revolveTracked?(profile: IShape, axis: Line, angle: number): Result<TrackedShape>;
    /**
     * Tracked sweep: ONE profile per call along the whole spine (the TS side loops the
     * profiles and combines — same geometry as the multi-profile `sweep`). The history
     * input is that single profile face; the end-cap face indexes (the sweep's
     * LastShape) travel through `capFaces`, empty for a closed path.
     */
    sweepTracked?(profile: IShape, path: IWire, isRoundCorner: boolean): Result<TrackedShape>;
    /**
     * Sweep with an explicit profile-orientation mode (`SweepProfileMode`): `frenet` is what
     * `sweep`/`sweepTracked` run today; `fixed` carries the profile untwisted, holding
     * `fixedDirection` as a constant binormal — required for `fixed`, ignored otherwise, and
     * refused by the kernel when it runs parallel to the path's tangent (the frame collapses
     * there; measured: a graceful "Failed to sweep profile", not a raise).
     */
    sweepWithMode?(
        profiles: IShape[],
        path: IWire,
        mode: SweepProfileMode,
        isRoundCorner: boolean,
        fixedDirection?: XYZLike,
    ): Result<IShape>;
    /** Tracked counterpart of `sweepWithMode` — one profile per call, as `sweepTracked`. */
    sweepWithModeTracked?(
        profile: IShape,
        path: IWire,
        mode: SweepProfileMode,
        isRoundCorner: boolean,
        fixedDirection?: XYZLike,
    ): Result<TrackedShape>;
    /**
     * Tracked loft: the history input enumerates the sections' edges in section order
     * (section 0's edges first), faces of the input are always empty (loft inputs are
     * wires/vertices), and a solid loft's start AND end cap face indexes travel through
     * `capFaces` — neither cap can be named by the derivation channels.
     */
    loftTracked?(
        sections: (IVertex | IEdge | IWire)[],
        isSolid: boolean,
        isRuled: boolean,
        continuity: Continuity,
    ): Result<TrackedShape>;
    booleanCommonTracked?(shape1: IShape[], shape2: IShape[]): Result<TrackedShape>;
    booleanCutTracked?(shape1: IShape[], shape2: IShape[]): Result<TrackedShape>;
    booleanFuseTracked?(shape1: IShape[], shape2: IShape[]): Result<TrackedShape>;
    filletTracked?(shape: IShape, edges: number[], radius: number): Result<TrackedShape>;
    chamferTracked?(shape: IShape, edges: number[], distance: number): Result<TrackedShape>;
    fillet2d(face: IFace, edge1: IEdge, edge2: IEdge, radius: number): Result<IFace>;
    chamfer2d(face: IFace, edge1: IEdge, edge2: IEdge, distance: number): Result<IFace>;
    filletEdge2d(edge1: IEdge, edge2: IEdge, radius: number): Result<IEdge[]>;
    chamferEdge2d(edge1: IEdge, edge2: IEdge, distance: number): Result<IEdge[]>;
    loft(
        sections: (IVertex | IEdge | IWire)[],
        isSolid: boolean,
        isRuled: boolean,
        continuity: Continuity,
    ): Result<IShape>;
    /**
     * A Gordon surface (transfinite interpolation) over a network of two edge groups:
     * every profile must intersect every guide. The result is ONE face spanning the whole
     * network — not a solid — and the input edges are not consumed.
     *
     * The order inside each group does not matter (the kernel sorts the network); swapping
     * the two groups usually yields the same surface with U and V transposed. `tolerance` is
     * the distance, in model units, within which a profile and a guide count as meeting
     * (default `Precision.Distance`). With `approximate` the kernel may fall back to a
     * sampled surface when the exact construction fails; that fallback does not interpolate
     * the input curves exactly.
     */
    gordon(profiles: IEdge[], guides: IEdge[], tolerance?: number, approximate?: boolean): Result<IFace>;
    removeFeature(shape: IShape, faces: IFace[]): Result<IShape>;
    removeFillet(
        shape: IShape,
        faces: IFace[],
    ): Result<{
        shape: IShape;
        newEdges: IEdge[];
    }>;
    removeSubShape(shape: IShape, subShapes: IShape[]): Result<IShape>;
    replaceSubShapes(shape: IShape, oldSubShapes: IShape[], newSubShapes: IShape[]): Result<IShape>;
    curveProjection(curve: IEdge | IWire, targetFace: IFace, vec: XYZ): Result<IShape>;
    simplifyShape(
        shape: IShape,
        removeEdges: boolean,
        removeFaces: boolean,
        keepShapes: IShape[],
        linearTolerance?: number,
        angleTolerance?: number,
    ): Result<IShape>;
}
