// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import type { IDocument } from "./document";
import {
    type CollectionChangedArgs,
    NodeLinkedListHistoryRecord,
    type NodeRecord,
    Observable,
    ObservableCollection,
    Transaction,
} from "./foundation";
import { Material } from "./material";
import { type Component, ComponentNode } from "./model/component";
import { FolderNode, isPlainFolder } from "./model/folderNode";
import { type INode, NodeUtils } from "./model/node";
import { type Serialized, Serializer } from "./serialize";

export type OnNodeChanged = (records: NodeRecord[]) => void;

/** The material reference a node carries, if any — both `GeometryNode` and `MeshNode` have one. */
function materialIdOf(node: INode): string | string[] | undefined {
    return (node as { materialId?: string | string[] }).materialId;
}

/** A node's material reference as a list; a missing one contributes nothing. */
function materialIdsOf(materialId: string | string[] | undefined): readonly string[] {
    if (materialId === undefined) return [];
    return Array.isArray(materialId) ? materialId : [materialId];
}

/** `node` itself or one below it — true when `ancestor` is on the parent chain. */
function isSelfOrDescendant(node: INode, ancestor: INode): boolean {
    let current: INode | undefined = node;
    while (current !== undefined) {
        if (current === ancestor) return true;
        current = current.parent;
    }
    return false;
}

export class ModelManager extends Observable {
    private readonly _nodeChangedObservers = new Set<OnNodeChanged>();
    private _deserializing = false;

    readonly components: ObservableCollection<Component> = new ObservableCollection();
    readonly materials: ObservableCollection<Material> = new ObservableCollection();

    private _rootNode: FolderNode | undefined;
    get rootNode(): FolderNode {
        if (this._rootNode === undefined) {
            this._rootNode = this.initRootNode();
        }
        return this._rootNode;
    }
    set rootNode(value: FolderNode) {
        if (this._rootNode === value) return;

        this._rootNode?.removePropertyChanged(this.handleRootNodeNameChanged);
        this._rootNode = value ?? new FolderNode({ document: this.document, name: this.document.name });
        this._rootNode.onPropertyChanged(this.handleRootNodeNameChanged);
    }

    /**
     * The folder new nodes land in. Only a plain `FolderNode` qualifies: a parametric
     * body is a linked list too (holding hidden consumed tools), and a `GroupNode`
     * subclass carries semantics of its own.
     */
    private _currentNode?: FolderNode;
    get currentNode(): FolderNode | undefined {
        return this._currentNode;
    }
    set currentNode(value: FolderNode | undefined) {
        // A `GroupNode` satisfies the type but not the contract: a node added there would
        // inherit the group's transform. Refuse it here so no future writer can slip one in.
        this.setProperty("currentNode", isPlainFolder(value) ? value : undefined);
    }

    constructor(readonly document: IDocument) {
        super();
        this.rootNode = this.initRootNode();
        this.materials.onCollectionChanged(this.handleMaterialChanged);
        this.components.onCollectionChanged(this.handleComponentChanged);
    }

    private readonly handleRootNodeNameChanged = (prop: string) => {
        if (prop === "name") {
            this.document.name = this.rootNode.name;
        }
    };

    initRootNode() {
        return new FolderNode({ document: this.document, name: this.document.name });
    }

    /**
     * The saved root is always a folder (a `GroupNode` counts, being a subclass). Hand-edited
     * data could hold a bare linked list instead: wrap it rather than drop the whole tree, which
     * would open the document empty with no trace.
     */
    private folderRoot(node: INode | undefined): FolderNode {
        if (node instanceof FolderNode) return node;
        const folder = this.initRootNode();
        if (node !== undefined) {
            console.warn(`document root is not a folder, wrapping it: ${node.id}`);
            folder.add(node);
        }
        return folder;
    }

    addNodeObserver(observer: OnNodeChanged) {
        this._nodeChangedObservers.add(observer);
    }

    removeNodeObserver(observer: OnNodeChanged) {
        this._nodeChangedObservers.delete(observer);
    }

    notifyNodeChanged(records: NodeRecord[]) {
        if (this._deserializing) return;
        this.resetDetachedCurrentNode(records);
        Transaction.add(this.document, new NodeLinkedListHistoryRecord(records));
        this._nodeChangedObservers.forEach((x) => {
            x(records);
        });
    }

    /**
     * The current folder is where the next node a command creates lands, so it must leave the
     * document together with it. A detached folder that is never cleared is disposed by its
     * history record later — `document` is nulled on dispose — and the next `addNode` would throw
     * while notifying the change. Reset to the root instead, which is also where nodes the user
     * swears they created used to vanish.
     */
    private resetDetachedCurrentNode(records: NodeRecord[]) {
        const current = this._currentNode;
        if (current === undefined) return;
        const detached = records.some(
            (record) =>
                (record.action === "remove" || record.action === "transfer") &&
                isSelfOrDescendant(current, record.node),
        );
        if (detached) this.currentNode = this.rootNode;
    }

    addNode(...nodes: INode[]): void {
        const current = this.currentNode;
        if (current === undefined || !isSelfOrDescendant(current, this.rootNode)) {
            // No folder chosen, or one that left the tree (undone creation, deletion, a
            // component): new nodes cannot go there — they would be invisible. Only a stale
            // node is cleared; an absent one stays absent, so the root is not marked current.
            if (current !== undefined) this.currentNode = this.rootNode;
            this.rootNode.add(...nodes);
            return;
        }
        current.add(...nodes);
    }

    findNode(predicate: (value: INode) => boolean) {
        if (!this._rootNode) return undefined;

        return NodeUtils.findNode(this._rootNode, predicate);
    }

    findNodes(predicate?: (value: INode) => boolean) {
        if (!this._rootNode) return [];

        return NodeUtils.findNodes(this._rootNode, predicate);
    }

    /**
     * Also looks inside `components`. A Component owns its nodes outside the document tree
     * (`group` transfers them there), so a plain `findNode` misses a body that an instance
     * still reads.
     */
    findNodeDeep<T extends INode>(predicate: (value: INode) => value is T): T | undefined;
    findNodeDeep(predicate: (value: INode) => boolean): INode | undefined;
    findNodeDeep(predicate: (value: INode) => boolean): INode | undefined {
        return this.findNode(predicate) ?? this.findComponentNodes(predicate)[0];
    }

    /** Tree nodes first, then every Component's nodes (nested components included). */
    findNodesDeep<T extends INode>(predicate: (value: INode) => value is T): T[];
    findNodesDeep(predicate?: (value: INode) => boolean): INode[];
    findNodesDeep(predicate?: (value: INode) => boolean): INode[] {
        return [...this.findNodes(predicate), ...this.findComponentNodes(predicate)];
    }

    private findComponentNodes(predicate?: (value: INode) => boolean): INode[] {
        const result: INode[] = [];
        // A Component's members keep their own child lists (consumed tools, folders) and
        // can nest more components; both are part of the definition.
        const seen = new Set<INode>();
        const visitedComponents = new Set<Component>();
        const visitNode = (node: INode) => {
            if (seen.has(node)) return;
            seen.add(node);
            if (predicate === undefined || predicate(node)) result.push(node);
            if (NodeUtils.isLinkedListNode(node)) {
                for (let child = node.firstChild; child !== undefined; child = child.nextSibling) {
                    visitNode(child);
                }
            }
            // `component` is resolved through the collection rather than the node's
            // getter: a partially deserialized node may not have its component yet.
            if (node instanceof ComponentNode) {
                const nested = this.components.find((c) => c.id === node.componentId);
                if (nested !== undefined && !visitedComponents.has(nested)) {
                    visitedComponents.add(nested);
                    for (const member of nested.nodes as ReadonlyArray<INode>) visitNode(member);
                }
            }
        };
        for (const component of this.components) {
            if (visitedComponents.has(component)) continue;
            visitedComponents.add(component);
            for (const member of component.nodes as ReadonlyArray<INode>) visitNode(member);
        }
        return result;
    }

    serialize() {
        return {
            components: this.components.map((x) => Serializer.serializeObject(x)),
            nodes: NodeUtils.serializeNode(this.rootNode),
            materials: this.materials.map((x) => Serializer.serializeObject(x)),
        };
    }

    async deserialize(data: { components: Serialized[]; nodes: Serialized[]; materials: Serialized[] }) {
        this.materials.push(
            ...data.materials.map((x: Serialized) => Serializer.deserializeObject(this.document, x)),
        );

        this.components.push(
            ...data.components.map((x: Serialized) => Serializer.deserializeObject(this.document, x)),
        );

        // Defer node notifications until the new tree replaces rootNode: displaying a
        // node mid-load can generate shapes that reference other nodes (e.g. a
        // parametric body referencing a sketch), which findNode cannot reach while
        // _rootNode is still the old root.
        this._deserializing = true;
        try {
            const rootNode = await NodeUtils.deserializeNode(this.document, data.nodes);
            this.rootNode = this.folderRoot(rootNode);
            this.ensureMaterials();
        } finally {
            this._deserializing = false;
        }
        this.notifyNodeChanged([{ action: "add", node: this.rootNode }]);
    }

    /**
     * Fills in the materials a loaded document references but its `materials` list no longer
     * holds, so rendering does not throw `Material not found` — the node tree and the material
     * list are separate arrays, and an interrupted or hand-edited save can leave them out of step.
     *
     * The placeholder keeps the referenced id, so every node resolves; it is a grey
     * `Material` the user can restyle.
     */
    private ensureMaterials() {
        const known = new Set(this.materials.map((x) => x.id));
        const backfill = (materialId: string | string[] | undefined) => {
            for (const id of materialIdsOf(materialId)) {
                // An empty id is "nothing assigned" — the `GeometryNode` default when the
                // document had no materials yet — not a reference to repair. Backfilling it
                // would write a nameless material into every later save.
                if (id === "" || known.has(id)) continue;
                known.add(id);
                this.materials.push(
                    new Material({ id, document: this.document, name: "replaced", color: 0xaaaaaa }),
                );
            }
        };

        // The nodes a component owns hang off the component, not off the linked-list tree,
        // so both walks are needed to cover everything that can carry a `materialId`.
        for (const node of NodeUtils.children(this.rootNode)) backfill(materialIdOf(node));
        for (const component of this.components) {
            for (const node of component.nodes) backfill(materialIdOf(node));
        }
    }

    override disposeInternal(): void {
        super.disposeInternal();
        this._nodeChangedObservers.clear();
        this.materials.removeCollectionChanged(this.handleMaterialChanged);
        this.components.removeCollectionChanged(this.handleComponentChanged);
        this._rootNode?.removePropertyChanged(this.handleRootNodeNameChanged);
        this._rootNode?.dispose();
        this.materials.forEach((x) => x.dispose());
        this.materials.clear();
        this._rootNode = undefined;
        this._currentNode = undefined;
    }

    private readonly handleMaterialChanged = (args: CollectionChangedArgs) => {
        if (args.action === "add") {
            Transaction.add(this.document, {
                name: "MaterialChanged",
                dispose() {},
                undo: () => this.materials.remove(...args.items),
                redo: () => this.materials.push(...args.items),
            });
        } else if (args.action === "remove") {
            Transaction.add(this.document, {
                name: "MaterialChanged",
                dispose() {},
                undo: () => this.materials.push(...args.items),
                redo: () => this.materials.remove(...args.items),
            });
        }
    };

    private readonly handleComponentChanged = (args: CollectionChangedArgs) => {
        if (args.action === "add") {
            Transaction.add(this.document, {
                name: "ComponentChanged",
                dispose() {},
                undo: () => this.components.remove(...args.items),
                redo: () => this.components.push(...args.items),
            });
        } else if (args.action === "remove") {
            Transaction.add(this.document, {
                name: "ComponentChanged",
                dispose() {},
                undo: () => this.components.push(...args.items),
                redo: () => this.components.remove(...args.items),
            });
        }
    };
}
