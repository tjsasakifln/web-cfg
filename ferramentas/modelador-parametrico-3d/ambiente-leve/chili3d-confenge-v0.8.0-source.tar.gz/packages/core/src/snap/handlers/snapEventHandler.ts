// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import { Config, VisualConfig } from "../../config";
import type { IDocument } from "../../document";
import { type AsyncController, type MessageType, Precision, PubSub, Result } from "../../foundation";
import type { I18nKeys } from "../../i18n";
import type { XYZ } from "../../math";
import { NOT_REFERENCE_GEOMETRY_FILTER } from "../../selectionFilter";
import { MeshDataUtils, type ShapeType, ShapeTypes } from "../../shape";
import { ObjectSnapTypes, ObjectSnapTypeUtils } from "../../snapType";
import { type IEventHandler, type IView, type MeshOption, screenDistance } from "../../visual";
import { parseDimensionInput } from "../dimension";
import type { ISnap, MouseAndDetected, SnapData, SnapResult } from "../snap";

type SnapState = "idle" | "snapping" | "inputing" | "cancelled" | "completed";

export abstract class SnapEventHandler<D extends SnapData = SnapData> implements IEventHandler {
    private _tempPoint?: number;
    private _tempShapes?: number[];
    protected showTempPoint: boolean = true;
    protected _snaped?: SnapResult;
    private _state: SnapState = "idle";

    facePreviewOpion: MeshOption = { meshOpacity: 1 };
    /** Mesh option for the snapped-point marker; undefined keeps the default depth-tested rendering. */
    tempPointOption?: MeshOption;
    isEnabled: boolean = true;

    constructor(
        readonly document: IDocument,
        readonly controller: AsyncController,
        readonly snaps: ISnap[],
        readonly data: D,
    ) {
        this.showTempShape(undefined);
        controller.onCancelled(() => this.handleCancel());
        controller.onCompleted(() => this.handleSuccess());
        data.onPreviewReady?.(this.redrawPreview);
    }

    get snaped() {
        return this._snaped;
    }
    get state() {
        return this._state;
    }

    dispose() {
        this._snaped = undefined;
        this._state = "completed";
    }

    private handleSuccess() {
        if (this._state === "completed") return;

        this._state = "completed";
        this.controller.success();
        this.cleanupResources();
    }

    private handleCancel() {
        if (this._state === "cancelled") return;

        this._state = "cancelled";
        this.controller.cancel();
        this.cleanupResources();
    }

    private cleanupResources() {
        this.clearSnapPrompt();
        this.clearInput();
        this.removeTempVisuals();
        this.snaps.forEach((snap) => snap.clear());
    }

    private clearInput() {
        PubSub.default.pub("clearInput");
    }

    pointerMove(view: IView, event: PointerEvent): void {
        this._state = "snapping";
        this.removeTempVisuals();
        this.updateSnapPoint(view, event);
        this.updateVisualFeedback(view);
    }

    private updateSnapPoint(view: IView, event: PointerEvent) {
        this.setSnaped(view, event);
        if (this._snaped) {
            this.showSnapPrompt(this._snaped);
        } else {
            this.clearSnapPrompt();
        }
    }

    private updateVisualFeedback(view: IView) {
        this.showTempShape(this._snaped?.point);
        view.document.visual.update();
    }

    protected setSnaped(view: IView, event: PointerEvent) {
        this.findSnapPoint(SnapEventHandler.detectShapeType(), view, event);

        this.snaps.forEach((snap) => snap.handleSnaped?.(view.document.visual.document, this._snaped));
    }

    /**
     * The shapes a snap round detects. Vertices are requested only when vertex snapping
     * is on: reading a body's points builds its whole point mesh and one wrapper per
     * topological vertex, which a session that cannot snap to a vertex has no use for.
     */
    private static detectShapeType(): ShapeType {
        const base = (ShapeTypes.edge | ShapeTypes.face) as ShapeType;
        return ObjectSnapTypeUtils.hasType(Config.instance.snapType, ObjectSnapTypes.vertex)
            ? ((base | ShapeTypes.vertex) as ShapeType)
            : base;
    }

    private findNearestFeaturePoint(view: IView, event: PointerEvent) {
        let minDist = Number.MAX_VALUE;
        let nearest;

        for (const point of this.data.featurePoints || []) {
            if (point.when && !point.when()) continue;

            const dist = screenDistance(view, event.offsetX, event.offsetY, point.point);
            if (dist < minDist) {
                minDist = dist;
                nearest = point;
            }
        }

        return minDist < Config.instance.SnapDistance ? nearest : undefined;
    }

    protected findSnapPoint(shapeType: ShapeType, view: IView, event: PointerEvent) {
        const featurePoint = this.findNearestFeaturePoint(view, event);
        if (featurePoint) {
            this._snaped = {
                view,
                point: featurePoint.point,
                info: featurePoint.prompt,
                shapes: [],
                type: "feature",
            };
        } else {
            const detected = this.detectShapes(shapeType, view, event);
            for (const snap of this.snaps) {
                const snaped = snap.snap(detected);
                if (snaped && this.validateSnapPoint(snaped)) {
                    this._snaped = snaped;
                    return;
                }
            }
        }
    }

    private validateSnapPoint(snaped: SnapResult) {
        return !this.data.validator || this.data.validator(snaped.point!);
    }

    private detectShapes(shapeType: ShapeType, view: IView, event: MouseEvent): MouseAndDetected {
        const shapes = view.detectShapes(
            shapeType,
            event.offsetX,
            event.offsetY,
            this.data.filter,
            NOT_REFERENCE_GEOMETRY_FILTER,
            this.data.includeHiddenVisuals,
        );
        return {
            shapes,
            view,
            mx: event.offsetX,
            my: event.offsetY,
            filter: this.data.filter,
            includeHiddenVisuals: this.data.includeHiddenVisuals,
        };
    }

    protected clearSnapPrompt() {
        PubSub.default.pub("clearFloatTip");
    }

    protected showSnapPrompt(snaped: SnapResult) {
        const prompt = this.formatSnapPrompt(snaped);
        if (!prompt) {
            this.clearSnapPrompt();
            return;
        }
        PubSub.default.pub("showFloatTip", prompt);
    }

    protected formatSnapPrompt(
        snaped: SnapResult,
    ): HTMLElement | { level: MessageType; msg: string } | undefined {
        let prompt = this.data.prompt?.(snaped);
        if (!prompt) {
            const distance = snaped.distance ?? snaped.refPoint?.distanceTo(snaped.point!);
            if (distance) {
                prompt = this.formatSnapDistance(distance);
            }
        }

        if (!prompt && !snaped.info) {
            return undefined;
        }

        return {
            level: "info",
            msg: [snaped.info, prompt].filter((x) => x !== undefined).join(" -> "),
        };
    }

    protected formatSnapDistance(num: number) {
        return num.toFixed(2);
    }

    private removeTempVisuals() {
        this.removeTempShapes();
        this.snaps.forEach((snap) => snap.removeDynamicObject());
    }

    private showTempShape(point: XYZ | undefined) {
        if (point && this.showTempPoint) {
            const data = MeshDataUtils.createVertexMesh(
                point,
                VisualConfig.temporaryVertexSize,
                VisualConfig.temporaryVertexColor,
            );
            this._tempPoint = this.document.visual.context.displayMesh([data], this.tempPointOption);
        }

        this._tempShapes = this.data
            .preview?.(point)
            ?.map((shape) => this.document.visual.context.displayMesh([shape], this.facePreviewOpion));
    }

    /**
     * Draw the preview again where the pointer last snapped to. This is the function
     * `SnapData.onPreviewReady` is handed.
     *
     * What the preview is made of is the command's decision, and its parameters can be edited
     * while the step is being picked — a line of text, a height, a font. Pointer movement is
     * otherwise the only thing that redraws it, which would leave an edit showing nothing
     * until the pointer happened to move next.
     */
    private readonly redrawPreview = () => {
        // A caller is handed this function and may hold it past the step, so it has to be
        // harmless then: drawing would leave temp shapes in the viewport that the cleanup
        // the step already ran is not going to take away again.
        if (this._state === "completed" || this._state === "cancelled") return;

        this.removeTempShapes();
        this.showTempShape(this._snaped?.point);
        this.document.visual.update();
    };

    private removeTempShapes() {
        if (this._tempPoint) {
            this.document.visual.context.removeMesh(this._tempPoint);
            this._tempPoint = undefined;
        }
        this._tempShapes?.forEach((id) => {
            this.document.visual.context.removeMesh(id);
        });
        this.document.visual.update();
        this._tempShapes = undefined;
    }

    pointerDown(view: IView, event: PointerEvent): void {
        if (event.pointerType === "mouse" && event.button === 0) {
            if (this._snaped) {
                this.handleSuccess();
            } else {
                PubSub.default.pub("showToast", "toast.snap.notFoundValidPoint");
            }
        }
    }

    pointerUp(view: IView, event: PointerEvent): void {
        if (event.pointerType !== "mouse" && event.isPrimary && this._snaped) {
            this.handleSuccess();
        }
    }

    pointerOut(view: IView, event: PointerEvent) {
        this._snaped = undefined;
    }

    mouseWheel(view: IView, event: WheelEvent): void {
        view.update();
    }

    keyDown(view: IView, event: KeyboardEvent): void {
        this.data.onKeyDown?.(event);

        if (event.key === "Escape") {
            this._snaped = undefined;
            this.handleCancel();
        } else if (event.key === "Enter" || event.key === " ") {
            // should cancel when enter or space keydown, and should not trigger HotKeyService
            event.preventDefault();
            event.stopImmediatePropagation();
            this._snaped = undefined;
            this.handleCancel();
        } else {
            this.handleNumericInput(view, event);
        }
    }

    /**
     * A typed offset on one axis, read the way the pointer last stood along it: the number is a
     * magnitude, and which way it goes is the pointer's — so a pair of offsets a readout shows
     * is a pair the user can type back in, and a lone number does not always land on the
     * positive side of the point it is measured from.
     *
     * `refPoint` is what the number is read as an offset from: `_snaped` is where the pointer
     * is, which is not necessarily the same point a handler draws its offsets from.
     */
    protected followSnapedSign(refPoint: XYZ, axis: XYZ, value: number): number {
        const offset = this._snaped?.point?.sub(refPoint).dot(axis);
        return offset !== undefined && offset < -Precision.Distance ? -value : value;
    }

    private handleNumericInput(view: IView, event: KeyboardEvent) {
        if (!["#", "-", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"].includes(event.key)) return;

        this._state = "inputing";
        PubSub.default.pub("showInput", event.key, (text: string) => {
            const error = this.inputError(text);
            if (error) return Result.err(error);

            // Annotated here, the one place the typed text is ever in hand, so that a handler's
            // own `getPointFromInput` need not carry the record through — and so that what the
            // result says was typed cannot drift from what this read.
            this._snaped = { ...this.getPointFromInput(view, text), input: parseDimensionInput(text) };
            this.handleSuccess();
            return Result.ok(text);
        });
    }

    protected abstract getPointFromInput(view: IView, text: string): SnapResult;
    protected abstract inputError(text: string): I18nKeys | undefined;
}
