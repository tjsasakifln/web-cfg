// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import type { CommandKeys, ICommand } from "../command";
import type { IDocument } from "../document";
import type { I18nKeys } from "../i18n";
import type { Material } from "../material";
import type { INode } from "../model";
import type { DialogButton, FloatPanelOptions } from "../ui";
import type { CursorType, IView } from "../visual";
import type { AsyncController } from "./asyncController";
import type { IDisposable } from "./disposable";
import type { MessageType } from "./messageType";
import type { Result } from "./result";

/** How the floating input opens (see `PubSubEventMap.showInput`). */
export interface ShowInputOptions {
    /**
     * Opens with the text taken as a whole, so the first thing typed replaces what is
     * there — what a box standing on a value wants, and not what a box seeded with the
     * digit somebody just pressed wants, since that digit is the start of the number
     * rather than something to type over.
     */
    selectAll?: boolean;
    /**
     * Whether the box takes the keyboard focus on open (the default). A readout riding a
     * drag passes false: the keys stay with the drag, so Enter still confirms and a digit
     * still opens the numeric box, rather than being swallowed by a box the hand never
     * aimed at.
     */
    takeFocus?: boolean;
    /** Called when the box comes down, however it came down — Enter, Escape, or replaced. */
    onClose?: () => void;
}

export type BridgeStatus = "connected" | "retrying" | "blocked" | "replaced" | "closed";

export interface PubSubEventMap {
    activeViewChanged: (view: IView | undefined) => void;
    applicationError: (message: unknown, optionalParams: unknown[]) => void;
    applicationErrorReady: () => void;
    bridgeStatusChanged: (status: BridgeStatus | undefined, title?: string) => void;
    /** Hide the standalone confirm bar (see `showConfirmControl`). */
    clearConfirmControl: () => void;
    clearFloatTip: () => void;
    clearInput: () => void;
    clearSelectionControl: () => void;
    clearStatusBarTip: () => void;
    closeFloatPanel: (content: HTMLElement) => void;
    closeCommandContext: () => void;
    /** Shows an operational failure and records it in the error log. */
    displayError: (message: string) => void;
    displayHome: (show: boolean) => void;
    /** Shows retryable input or selection feedback without recording it in the error log. */
    displayValidation: (message: string) => void;
    documentClosed: (document: IDocument) => void;
    editMaterial: (document: IDocument, material: Material, callback: (material: Material) => void) => void;
    editVariables: (document: IDocument, onApplied: () => void) => void;
    executeCommand: (commandName: CommandKeys) => void;
    loggerError: (message: unknown, optionalParams: unknown[]) => void;
    modelUpdate: (model: INode) => void;
    nodeDoubleClicked: (node: INode) => void;
    openCommandContext: (command: ICommand) => void;
    parentVisibleChanged: (model: INode) => void;
    /**
     * A confirm/cancel bar for a step that is not a selection — a drag that edits a
     * value, say. `showSelectionControl` carries the picked-shape count, which means
     * nothing there.
     */
    showConfirmControl: (controller: AsyncController) => void;
    showDialog: (title: I18nKeys, content: HTMLElement, buttons?: DialogButton[] | (() => void)) => void;
    showFloatPanel: (options: FloatPanelOptions) => void;
    showFloatTip: (dom: HTMLElement | { level: MessageType; msg: string }) => void;
    /**
     * Puts up the floating input. See `ShowInputOptions` for how the box opens; without any,
     * it takes the focus with its text as typed into.
     */
    showInput: (
        text: string,
        handler: (text: string) => Result<string, I18nKeys>,
        options?: ShowInputOptions,
    ) => void;
    showPermanent: (action: () => Promise<void>, message: I18nKeys, ...args: any[]) => void;
    showProperties(document: IDocument, nodes: INode[]): void;
    showSelectionControl: (controller: AsyncController) => void;
    showToast: (message: I18nKeys, ...args: any[]) => void;
    statusBarTip: (tip: I18nKeys, ...args: any[]) => void;
    toggleChatPanel: () => void;
    /**
     * Replaces what the floating input holds, for a drag that keeps it up as a readout. A box
     * the user has started typing in is left alone — see `Input.setText`.
     */
    updateInput: (text: string) => void;
    viewClosed: (view: IView) => void;
    viewCursor: (cursor: CursorType) => void;
    visibleChanged: (model: INode) => void;
}

type EventCallback = (...args: any[]) => void;
type EventMap = Map<keyof PubSubEventMap, Set<EventCallback>>;

export class PubSub implements IDisposable {
    static readonly default = new PubSub();
    private readonly events: EventMap = new Map();
    private isDisposed = false;

    dispose(): void {
        this.isDisposed = true;
        this.events.forEach((callbacks) => callbacks.clear());
        this.events.clear();
    }

    sub<K extends keyof PubSubEventMap>(event: K, callback: PubSubEventMap[K]): void {
        if (this.isDisposed) {
            return;
        }

        const callbacks = this.events.get(event) ?? new Set<EventCallback>();
        callbacks.add(callback);
        this.events.set(event, callbacks);
    }

    pub<K extends keyof PubSubEventMap>(event: K, ...args: Parameters<PubSubEventMap[K]>): void {
        if (this.isDisposed) {
            return;
        }

        this.events.get(event)?.forEach((callback) => {
            try {
                callback(...args);
            } catch (error) {
                console.error(`PubSub: a subscriber of "${String(event)}" threw`, error);
            }
        });
    }

    remove<K extends keyof PubSubEventMap>(event: K, callback: PubSubEventMap[K]): void {
        if (this.isDisposed) {
            return;
        }

        this.events.get(event)?.delete(callback);
    }

    removeAll<K extends keyof PubSubEventMap>(event: K): void {
        if (this.isDisposed) {
            return;
        }

        this.events.get(event)?.clear();
    }
}
