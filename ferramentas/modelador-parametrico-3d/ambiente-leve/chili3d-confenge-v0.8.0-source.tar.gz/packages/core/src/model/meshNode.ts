// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import type { IDocument } from "../document";
import { Id } from "../foundation";
import type { I18nKeys } from "../i18n";
import { BoundingBox } from "../math";
import { property } from "../property";
import { serializable, serialize } from "../serialize";
import type { Mesh } from "../shape";
import { VisualNode } from "./visualNode";

export interface MeshNodeOptions {
    document: IDocument;
    mesh: Mesh;
    name: string;
    materialId?: string | string[];
    id?: string;
}

@serializable()
export class MeshNode extends VisualNode {
    /** A mesh is copied as a `MeshInstanceNode`; see `cloneForCopyNode`. */
    override get copiesAsInstance(): boolean {
        return true;
    }

    override display(): I18nKeys {
        return "body.meshNode";
    }

    @serialize()
    @property("common.material", { type: "materialId" })
    get materialId(): string | string[] {
        return this.getPrivateValue("materialId");
    }
    set materialId(value: string | string[]) {
        this.setProperty("materialId", value);
    }

    protected _mesh: Mesh;
    @serialize()
    get mesh(): Mesh {
        return this._mesh;
    }
    set mesh(value: Mesh) {
        this.setProperty("mesh", value);
    }

    constructor(options: MeshNodeOptions) {
        super(options.document, options.name, options.id ?? Id.generate());
        this._mesh = options.mesh;
        this.setPrivateValue(
            "materialId",
            options.materialId ?? options.document.modelManager.materials.at(0)?.id ?? "",
        );
    }

    override boundingBox(): BoundingBox | undefined {
        const points = this.transform.ofPoints(this.mesh.position!);
        return BoundingBox.fromNumbers(points);
    }
}
