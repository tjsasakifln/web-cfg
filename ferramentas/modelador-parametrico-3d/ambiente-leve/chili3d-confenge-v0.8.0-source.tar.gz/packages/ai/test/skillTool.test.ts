// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import { AppGuideStore } from "@chili3d/core";
import { SKILLS } from "../src/skills";
import { SkillStore } from "../src/skills/skillStore";
import { buildSkillTool } from "../src/skills/skillTool";
import type { Skill } from "../src/skills/types";

const contributed: Skill = {
    name: "contributed",
    description: "A skill a module contributed",
    content: "Contributed body.",
};

/** The stored schema is an open record; prefer a narrower view over index-signature access. */
function advertisedSkills(tool: ReturnType<typeof buildSkillTool>): string[] {
    const schema = tool.parameters as { properties: { name: { enum: string[] } } };
    return schema.properties.name.enum;
}

afterEach(() => {
    // Unregistering a built-in name only drops the override, so this is a safe reset even for
    // tests that never touched app-guide — and the one that does is covered if it throws.
    SkillStore.unregister("contributed");
    SkillStore.unregister("app-guide");
});

describe("skillTool", () => {
    test("returns the shape family document for shape-query", async () => {
        const tool = buildSkillTool();
        const content = (await tool.handler({ name: "shape-query" })) as string;

        expect(content).toContain("face.area");
        expect(content).toContain("shape.volume");
        expect(content).toContain("wire.toFace");
        // The curve and surface families live in their own skills now.
        expect(content).not.toContain("curve.length");
        expect(content).not.toContain("surface.bounds");
    });

    test("splits the query reference by geometry family", async () => {
        const tool = buildSkillTool();
        const curve = (await tool.handler({ name: "curve-query" })) as string;
        const surface = (await tool.handler({ name: "surface-query" })) as string;

        expect(curve).toContain("curve.length");
        expect(curve).toContain("circle.radius");
        expect(curve).toContain("trimmedCurve.basisCurve");
        expect(curve).not.toContain("shape.volume");

        expect(surface).toContain("surface.bounds");
        expect(surface).toContain("cylindricalSurface");
        expect(surface).not.toContain("curve.length");
    });

    test("every registered skill is loadable and distinct", async () => {
        const tool = buildSkillTool();
        const contents = new Map<string, string>();

        for (const skill of SKILLS) {
            const content = (await tool.handler({ name: skill.name })) as string;
            expect(content.length).toBeGreaterThan(0);
            expect(contents.has(content)).toBe(false);
            contents.set(content, skill.name);
        }

        expect(new Set(SKILLS.map((s) => s.name)).size).toBe(SKILLS.length);
        for (const skill of SKILLS) expect(skill.description.length).toBeGreaterThan(0);
    });

    test("the modeling API skill carries the catalog together with its encoding rules", async () => {
        const tool = buildSkillTool();
        const api = (await tool.handler({ name: "modeling-api" })) as string;

        expect(api).toContain("box(plane: plane, dx: number, dy: number, dz: number) -> solid");
        expect(api).toContain("booleanCut(shape1: refArray, shape2: refArray) -> shape");
        // Nothing else states these now that the catalog left the system prompt, so they
        // have to travel with it — Line={point,direction} and the corner-vs-center rules
        // are what make a hand-written op call correct on the first try.
        expect(api).toContain("JSON encoding:");
        expect(api).toContain("Line={point:{x,y,z},direction:{x,y,z}}");
        expect(api).toContain("Placement:");
    });

    test("the parametric skill describes variables rather than ranking them", async () => {
        const tool = buildSkillTool();
        // Whitespace-normalized: the skill wraps its prose by hand, so a phrase can straddle a line.
        const content = ((await tool.handler({ name: "parametric-modeling" })) as string).replace(
            /\s+/g,
            " ",
        );

        // The model loads this before every run_parametric call, so how it puts variables is what
        // decides whether "a 40x30x20 plate" comes back with a parameter table attached. It used to
        // call a body without them "merely feature-based" — a ranking, when what the model needs is
        // the two forms a dimension accepts and what each one does.
        expect(content).toContain("takes a plain number or an expression string");
        expect(content).not.toContain("merely feature-based");
    });

    test("the app guide teaches the app, not the modeling API", async () => {
        const tool = buildSkillTool();
        const guide = (await tool.handler({ name: "app-guide" })) as string;

        expect(guide).toContain("## Sketching");
        expect(guide).toContain("## Documents and files");
        expect(guide).toContain("## Parametric features");
        // Where a button sits is deliberately not in the manual — the live ribbon answers that.
        expect(guide).toContain("get_ribbon");
        // The app manual stays distinct from the shape-query reference it sits next to.
        expect(guide).not.toContain("shape.findSubShapes");
    });

    test("appends the sections modules and plugins registered to the app manual", async () => {
        const tool = buildSkillTool();
        try {
            AppGuideStore.registerSection({ name: "demo-plugin", content: "Press the Demo button." });

            const guide = (await tool.handler({ name: "app-guide" })) as string;

            expect(guide).toContain("## demo-plugin\nPress the Demo button.");
            // The built-in manual is still there ahead of the contribution.
            expect(guide).toContain("## Sketching");
        } finally {
            AppGuideStore.unregisterSection("demo-plugin");
        }
    });

    test("drops a contributed section once it is unregistered", async () => {
        const tool = buildSkillTool();
        AppGuideStore.registerSection({ name: "demo-plugin", content: "Press the Demo button." });
        AppGuideStore.unregisterSection("demo-plugin");

        const guide = (await tool.handler({ name: "app-guide" })) as string;

        expect(guide).not.toContain("Press the Demo button.");
    });

    test("serves a base override in place of the built-in manual, still followed by sections", async () => {
        const tool = buildSkillTool();
        try {
            AppGuideStore.setBase("A trimmed manual for this deployment.");
            AppGuideStore.registerSection({ name: "demo-plugin", content: "Press the Demo button." });

            const guide = (await tool.handler({ name: "app-guide" })) as string;

            expect(guide).toBe(
                "A trimmed manual for this deployment.\n\n## demo-plugin\nPress the Demo button.",
            );
        } finally {
            AppGuideStore.clearBase();
            AppGuideStore.unregisterSection("demo-plugin");
        }
    });

    test("falls back to the built-in manual after the override is cleared", async () => {
        const tool = buildSkillTool();
        AppGuideStore.setBase("A trimmed manual for this deployment.");
        AppGuideStore.clearBase();

        const guide = (await tool.handler({ name: "app-guide" })) as string;

        expect(guide).toContain("## Sketching");
        expect(guide).not.toContain("A trimmed manual for this deployment.");
    });

    test("reports an error listing available skills for an unknown name", async () => {
        const tool = buildSkillTool();
        const result = JSON.parse((await tool.handler({ name: "nope" })) as string);

        expect(result.error).toContain("nope");
        expect(result.available).toEqual(SKILLS.map((s) => s.name));
    });

    test("tool description advertises every registered skill", () => {
        const tool = buildSkillTool();
        expect(tool.name).toBe("load_skill");
        for (const skill of SKILLS) {
            expect(tool.description).toContain(skill.name);
        }
    });

    test("advertises and serves a skill a module registered", async () => {
        SkillStore.register(contributed);

        const tool = buildSkillTool();
        expect(tool.description).toContain("contributed");
        expect(advertisedSkills(tool)).toContain("contributed");
        expect(await tool.handler({ name: "contributed" })).toBe("Contributed body.");
    });

    test("replaces a built-in skill without moving it in the advertised order", async () => {
        const override: Skill = {
            name: "app-guide",
            description: "Retargeted guide",
            content: "Retargeted body.",
        };
        try {
            SkillStore.register(override);

            const names = SkillStore.getAll().map((s) => s.name);
            expect(names.indexOf("app-guide")).toBe(SKILLS.findIndex((s) => s.name === "app-guide"));
            expect(await buildSkillTool().handler({ name: "app-guide" })).toBe("Retargeted body.");
        } finally {
            SkillStore.unregister("app-guide");
        }

        // Unregistering a built-in name drops only the override, as the store documents.
        expect(SkillStore.getAll().find((s) => s.name === "app-guide")).toBe(
            SKILLS.find((s) => s.name === "app-guide"),
        );
    });

    test("drops a registered skill once it is unregistered", () => {
        SkillStore.register(contributed);
        SkillStore.unregister("contributed");

        expect(SkillStore.getAll().some((s) => s.name === "contributed")).toBe(false);
        expect(advertisedSkills(buildSkillTool())).not.toContain("contributed");
    });
});
