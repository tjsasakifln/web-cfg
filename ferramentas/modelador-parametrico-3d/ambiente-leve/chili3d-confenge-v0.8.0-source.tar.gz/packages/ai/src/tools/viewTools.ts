// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import {
    CAMERA_FLY_DURATION,
    I18n,
    type IDocument,
    type INode,
    Material,
    type MaterialPreset,
    MaterialPresets,
    type ToImageOptions,
    Transaction,
    type XYZLike,
} from "@chili3d/core";
import { splitDataUrl } from "../llm/imageData";
import type { Tool, ToolResult } from "../llm/types";
import { findNode, getDocument } from "./documentContext";
import { summarizeTexture } from "./propertyBag";
import { rasterTextureSource } from "./textureImage";

const Z_UP: XYZLike = { x: 0, y: 0, z: 1 };

/** The gray a node shows when no colour was ever set. */
const DEFAULT_MATERIAL_COLOR = 0xcccccc;

/** Preset standard views: dir is the camera offset from the target (Z-up world). */
const VIEW_PRESETS: Record<string, { dir: [number, number, number]; up: XYZLike }> = {
    front: { dir: [0, -1, 0], up: Z_UP },
    back: { dir: [0, 1, 0], up: Z_UP },
    left: { dir: [-1, 0, 0], up: Z_UP },
    right: { dir: [1, 0, 0], up: Z_UP },
    top: { dir: [0, 0, 1], up: { x: 0, y: 1, z: 0 } },
    bottom: { dir: [0, 0, -1], up: { x: 0, y: -1, z: 0 } },
    iso: { dir: [1, -1, 1], up: Z_UP },
};

const NAMED_COLORS: Record<string, number> = {
    red: 0xff0000,
    green: 0x00ff00,
    blue: 0x0000ff,
    white: 0xffffff,
    black: 0x000000,
    gray: 0x888888,
    grey: 0x888888,
    yellow: 0xffff00,
    orange: 0xff8800,
};

export function parseColor(v: unknown): number {
    if (typeof v === "number") return v;
    const s = String(v).trim().replace(/^#/, "");
    if (/^[0-9a-fA-F]{3}$/.test(s)) {
        return Number.parseInt([...s].map((c) => c + c).join(""), 16);
    }
    if (/^[0-9a-fA-F]{6}$/.test(s)) return Number.parseInt(s, 16);
    return NAMED_COLORS[s.toLowerCase()] ?? DEFAULT_MATERIAL_COLOR;
}

/**
 * The tool's colour input, where an unrecognized value is an error rather than the silent gray
 * `parseColor` falls back to (that fallback is for reading back colours already stored).
 */
export function parseToolColor(v: unknown): number | string {
    const names = Object.keys(NAMED_COLORS).join(", ");
    if (typeof v === "number") {
        if (Number.isInteger(v) && v >= 0 && v <= 0xffffff) return v;
        return "color as a number must be an integer in 0x000000..0xffffff";
    }
    const s = String(v).trim().replace(/^#/, "");
    if (/^[0-9a-fA-F]{3}$/.test(s) || /^[0-9a-fA-F]{6}$/.test(s)) return parseColor(v);
    if (NAMED_COLORS[s.toLowerCase()] !== undefined) return parseColor(v);
    return `unknown color "${v}" — use a hex string ("#ff0000"), one of ${names}, or a number like 0xff0000`;
}

export function buildViewTools(): Tool[] {
    return [
        captureScreenshotTool(),
        setMaterialTool(),
        fitContentTool(),
        isolateViewTool(),
        rotateViewTool(),
        setCameraTypeTool(),
    ];
}

/**
 * Long-edge cap and encoding for screenshots sent to the model. The API downsizes anything past
 * ~1568px anyway, so a full-Retina PNG (a few MB of base64 each) buys nothing — and a verifying
 * run accumulates one screenshot per check in the resent history.
 */
const SCREENSHOT_IMAGE: ToImageOptions = { maxSize: 1568, mimeType: "image/jpeg", quality: 0.85 };

/**
 * The viewport image as a tool result: the JSON payload plus the screenshot itself, so the model
 * sees the result and the picture in one step. Shared with `click_view`, whose whole point after a
 * select is to show the highlight.
 */
export function imageResult(
    view: { toImage(options?: ToImageOptions): string },
    payload: Record<string, unknown>,
): ToolResult {
    const image = splitDataUrl(view.toImage(SCREENSHOT_IMAGE));
    // The canvas's own PNG header always names a type; the fallback is for a renderer that does not.
    const mediaType = image.mediaType || "image/png";
    return {
        content: JSON.stringify({ ...payload, mediaType }),
        images: [{ mediaType, data: image.data }],
    };
}

const DEFAULT_VIEWS = ["iso", "front", "top"];
const MIN_VIEW_SIZE = 256;
const MAX_VIEW_SIZE = 1600;
/** Each view costs a full render, so a long list is a freeze, not a richer answer. */
const MAX_CAPTURE_VIEWS = 6;

interface CaptureFrame {
    target: XYZLike;
    distance: number;
}

/**
 * Several standard views of the model in one call, at one projection and one output size, so the
 * pictures can be compared with each other and with a reference image. Everything the camera is
 * asked to do happens with `duration: 0` and the pose is restored before returning — the user is
 * looking at this viewport, and a capture must not leave it somewhere else.
 */
export function buildCaptureViewsTool(): Tool {
    return {
        name: "capture_views",
        description:
            "Capture several standard views of the viewport in one call — the deterministic counterpart of capture_screenshot. Use it to compare a model with a reference image: all views share one projection, one framing and one pixel size, and the response lists which image is which. The camera is restored afterwards.",
        parameters: {
            type: "object",
            properties: {
                views: {
                    type: "array",
                    items: {
                        type: "string",
                        enum: ["front", "back", "left", "right", "top", "bottom", "iso"],
                    },
                    maxItems: MAX_CAPTURE_VIEWS,
                    description: `Views to capture, in image order (default ${DEFAULT_VIEWS.join(", ")}; at most ${MAX_CAPTURE_VIEWS}, duplicates are dropped)`,
                },
                orthographic: {
                    type: "boolean",
                    description: "Use orthographic projection (default true); false uses perspective",
                },
                framing: {
                    type: "string",
                    enum: ["all", "selection"],
                    description:
                        'What to frame: "all" ignores the current selection (default), "selection" frames it when one exists',
                },
                width: {
                    type: "number",
                    description: `Output width in pixels (default 1024, ${MIN_VIEW_SIZE}..${MAX_VIEW_SIZE})`,
                },
                height: {
                    type: "number",
                    description: `Output height in pixels (default 768, ${MIN_VIEW_SIZE}..${MAX_VIEW_SIZE})`,
                },
                frame: {
                    type: "object",
                    description:
                        "Reuse a framing returned by an earlier call, so two captures are directly comparable",
                    properties: {
                        target: {
                            type: "object",
                            properties: {
                                x: { type: "number" },
                                y: { type: "number" },
                                z: { type: "number" },
                            },
                            required: ["x", "y", "z"],
                        },
                        distance: { type: "number" },
                    },
                    required: ["target", "distance"],
                },
            },
        },
        handler: captureViewsHandler,
    };
}

const captureViewsHandler: Tool["handler"] = async (args) => {
    const view = globalThis.app.activeView;
    if (!view) return textResult({ error: "no active view" });

    const views = parseViews(args["views"]);
    if (typeof views === "string") return textResult({ error: views });
    const frame = parseFrame(args["frame"]);
    if (typeof frame === "string") return textResult({ error: frame });
    const orthographic = typeof args["orthographic"] === "boolean" ? args["orthographic"] : true;
    const framing = args["framing"] === "selection" ? "selection" : "all";
    const width = boundedSize(args["width"], 1024);
    const height = boundedSize(args["height"], 768);

    const camera = view.cameraController;
    // A fly-to still running would be cancelled by the capture and restored at its midpoint.
    camera.settle?.();
    const saved = {
        type: camera.cameraType,
        position: camera.cameraPosition,
        target: camera.cameraTarget,
        up: camera.cameraUp,
    };

    // Switch the drawing-buffer size once for the whole batch; without it each view would resize
    // and restore the renderer twice over.
    const restoreCapture = view.beginImageCapture?.(width, height);
    try {
        camera.cameraType = orthographic ? "orthographic" : "perspective";
        // Fit the shape this capture will actually have, not the viewport's shape.
        const distance = frame?.distance ?? frameAll(camera, framing, width / height);
        const target = frame?.target ?? camera.cameraTarget;
        // Same encoding as capture_screenshot: these pictures are replayed with every request,
        // and a full-resolution PNG buys nothing the API does not downscale away.
        const imageOptions = {
            ...SCREENSHOT_IMAGE,
            ...(restoreCapture ? {} : { width, height }),
        };
        const images = views.map((name) => {
            const preset = VIEW_PRESETS[name];
            const { eye, up } = presetEye(preset, target, distance);
            camera.lookAt(eye, target, up, { duration: 0 });
            view.update();
            const image = splitDataUrl(view.toImage(imageOptions));
            return { mediaType: image.mediaType || "image/jpeg", data: image.data };
        });
        return {
            content: JSON.stringify({
                ok: true,
                views,
                imageOrder: views,
                orthographic,
                framing,
                frame: { target: toPlainPoint(target), distance: Math.round(distance * 100) / 100 },
                mediaType: images[0]?.mediaType || "image/jpeg",
            }),
            images,
        };
    } finally {
        restoreCapture?.();
        camera.cameraType = saved.type;
        camera.lookAt(saved.position, saved.target, saved.up, { duration: 0 });
        view.update();
    }
};

/** Frame the content at once and report the distance the views will keep from the target. */
function frameAll(
    camera: {
        fitContent(options?: { duration?: number; scope?: "all" | "selection"; aspect?: number }): void;
        cameraPosition: XYZLike;
        cameraTarget: XYZLike;
    },
    framing: "all" | "selection",
    aspect: number,
): number {
    camera.fitContent({ duration: 0, scope: framing, aspect });
    const dx = camera.cameraPosition.x - camera.cameraTarget.x;
    const dy = camera.cameraPosition.y - camera.cameraTarget.y;
    const dz = camera.cameraPosition.z - camera.cameraTarget.z;
    return Math.hypot(dx, dy, dz) || 1;
}

function parseViews(raw: unknown): string[] | string {
    if (raw === undefined) return [...DEFAULT_VIEWS];
    if (!Array.isArray(raw) || raw.some((value) => typeof value !== "string")) {
        return "views must be an array of view names";
    }
    if (raw.length === 0) return "views must name at least one view";
    // Each view is a full render, so duplicates buy nothing and a long list freezes the tab.
    const names = [...new Set(raw as string[])];
    // hasOwn, not a truthiness check: "constructor" and "toString" live on the prototype chain
    // and would pass `VIEW_PRESETS[name] === undefined` and then fail inside presetEye.
    const unknown = names.filter((name) => !Object.hasOwn(VIEW_PRESETS, name));
    if (unknown.length) {
        return `unknown view(s) ${unknown.join(", ")}, expected one of ${Object.keys(VIEW_PRESETS).join("|")}`;
    }
    if (names.length > MAX_CAPTURE_VIEWS) {
        return `capture at most ${MAX_CAPTURE_VIEWS} views, got ${names.length}`;
    }
    return names;
}

function parseFrame(raw: unknown): CaptureFrame | string | undefined {
    if (raw === undefined) return undefined;
    const frame = raw as { target?: { x?: unknown; y?: unknown; z?: unknown }; distance?: unknown };
    const target = frame?.target;
    // Finite, not just `typeof number`: 1e999 parses to Infinity, which reaches the camera matrix
    // as NaN and leaves the capture blank.
    const finite = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value);
    if (!target || !finite(target.x) || !finite(target.y) || !finite(target.z)) {
        return "frame.target must be a finite { x, y, z }";
    }
    if (typeof frame.distance !== "number" || !Number.isFinite(frame.distance) || frame.distance <= 0) {
        return "frame.distance must be a positive number";
    }
    return { target: { x: target.x, y: target.y, z: target.z }, distance: frame.distance };
}

function boundedSize(value: unknown, fallback: number): number {
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    return Math.min(MAX_VIEW_SIZE, Math.max(MIN_VIEW_SIZE, Math.round(value)));
}

function textResult(value: unknown): ToolResult {
    return { content: JSON.stringify(value) };
}

function captureScreenshotTool(): Tool {
    return {
        name: "capture_screenshot",
        description: "Capture the current viewport as an image so you can see the model's current state.",
        parameters: { type: "object", properties: {} },
        handler: async () => {
            const view = globalThis.app.activeView;
            if (!view) return textResult({ error: "no active view" });
            return imageResult(view, { ok: true });
        },
    };
}

function setMaterialTool(): Tool {
    return {
        name: "set_material",
        description:
            "Set the appearance of a node by id: color, opacity and/or surface texture. Pass at least one of them (preset names a ready-made surface); the omitted ones keep their current value, or the preset's when one is given. Materials are shared between nodes, so a material with exactly these values is reused when one exists and created otherwise — the other nodes are never changed. This styles one node; to change a material itself — a colour on a surface several nodes share, or how shiny it is — read it with get_material and write it with set_material_properties.",
        parameters: {
            type: "object",
            properties: {
                id: { type: "string", description: "Node id" },
                color: {
                    anyOf: [{ type: "string" }, { type: "number" }],
                    description: `Color: "#ff0000", a name (${Object.keys(NAMED_COLORS).join("/")}), or 0xRRGGBB`,
                },
                opacity: {
                    type: "number",
                    description: "0 = fully transparent, 1 = opaque (0..1)",
                },
                texture: {
                    type: "string",
                    description:
                        'Surface texture as an image data URL ("data:image/png;base64,..."), an http(s)/blob URL or a same-origin path; "" removes the texture. An SVG is rasterized to a PNG before it is stored. The image is never sent back to you — a result reads as the stored image\'s kind and size, so to put the same image on another node pass textureFrom rather than the image again.',
                },
                textureFrom: {
                    type: "string",
                    description:
                        "Material id (from list_materials) whose texture this node should wear — the way to reuse an image the document already holds without passing it again. Pass either texture or textureFrom, not both.",
                },
                preset: {
                    type: "string",
                    enum: MaterialPresets.map((x) => x.name),
                    description:
                        "A ready-made surface: its colour, opacity, roughness and metalness are applied, and a colour or opacity you pass as well overrides the preset's.",
                },
            },
            required: ["id"],
        },
        handler: setMaterialHandler,
    };
}

const setMaterialHandler: Tool["handler"] = async (args) => {
    const doc = getDocument();
    if (!doc) return textResult({ error: I18n.translate("ai.error.noDocument") });
    const id = args["id"] as string;
    const node = findNode(doc, id);
    if (!node || !("materialId" in node)) {
        return textResult({ error: `node not found or has no material: ${id}` });
    }

    const preset = resolvePreset(args["preset"]);
    if (typeof preset === "string") return textResult({ error: preset });

    const borrowed = borrowedTexture(doc, args);
    if (typeof borrowed === "object") return textResult(borrowed); // the response, not an image to use

    // An SVG source is stored as pixels rather than as a document every reader renders its own
    // way — see `rasterTextureSource`.
    const texture = await rasterTextureSource(borrowed ?? args["texture"]);
    const appearance = resolveAppearance(doc, node, { ...args, texture }, preset);
    if (typeof appearance === "string") return textResult({ error: appearance });

    const material = ensureMaterial(doc, appearance, preset?.name);
    Transaction.execute(doc, "AI set material", () => {
        (node as { materialId: string | string[] }).materialId = material.id;
    });
    doc.visual.update();
    // The appearance as the model gets it back: numbers, and a texture that is named rather than
    // carried — see `summarizeTexture` for why the image itself must not come back.
    return textResult({
        ...appearance,
        texture: summarizeTexture(appearance.texture),
        id,
        materialId: material.id,
    });
};

/** The image a `textureFrom` argument names, or the response saying why there is none to take. */
type Borrowed = string | undefined | { error: string; available?: { id: string; name: string }[] };

/**
 * The texture on the material `textureFrom` names — the way an image the document already holds is
 * reused without passing its bytes again. Undefined when the argument is not given; the error
 * response when it disagrees with `texture`, or names a material with no image on it.
 */
function borrowedTexture(doc: IDocument, args: Record<string, unknown>): Borrowed {
    const from = args["textureFrom"];
    if (from === undefined) return undefined;
    if (args["texture"] !== undefined) {
        return { error: "pass either texture or textureFrom, not both" };
    }
    const source = doc.modelManager.materials.find((m) => m.id === from);
    if (source === undefined) {
        return {
            error: `material not found: ${from}`,
            available: doc.modelManager.materials.map((m) => ({ id: m.id, name: m.name })),
        };
    }
    if (!source.map.image) return { error: `material ${from} has no texture to take` };
    return source.map.image;
}

/** The surface to apply: every value the material will carry, or the message saying why not. */
interface Appearance {
    color: number;
    opacity: number;
    texture: string;
    roughness: number;
    metalness: number;
    envMapIntensity: number;
}

/** The preset the arguments name, `undefined` when none is given, or the message listing them. */
function resolvePreset(arg: unknown): MaterialPreset | undefined | string {
    if (arg === undefined) return undefined;
    if (typeof arg === "string") {
        const preset = MaterialPresets.find((x) => x.name.toLowerCase() === arg.toLowerCase());
        if (preset !== undefined) return preset;
    }
    return `unknown preset ${describe(arg)} — one of: ${MaterialPresets.map((x) => x.name).join(", ")}`;
}

/** colour / opacity / texture / preset to apply, or the message saying why the arguments do not. */
function resolveAppearance(
    doc: IDocument,
    node: unknown,
    args: Record<string, unknown>,
    preset: MaterialPreset | undefined,
): Appearance | string {
    if (
        args["color"] === undefined &&
        args["opacity"] === undefined &&
        args["texture"] === undefined &&
        preset === undefined
    ) {
        return "provide at least one of color, opacity, texture, preset";
    }
    // An omitted field keeps what the node already has — or, when a preset was asked for, that
    // preset's value: "make it satin plastic" is about the whole surface, so passing only the
    // preset must not leave the node's old colour on it.
    const current = materialOf(doc, node);
    const color = resolveColor(args["color"], preset ?? current);
    if ("error" in color) return color.error;
    const opacity = resolveOpacity(args["opacity"], preset ?? current);
    if ("error" in opacity) return opacity.error;
    const texture = resolveTexture(args["texture"], current);
    if ("error" in texture) return texture.error;
    return {
        color: color.value,
        opacity: opacity.value,
        texture: texture.value,
        // the last resort is what a fresh Material carries; read from it rather than restated here
        roughness: preset?.roughness ?? current?.roughness ?? Material.DefaultRoughness,
        metalness: preset?.metalness ?? current?.metalness ?? Material.DefaultMetalness,
        envMapIntensity:
            preset?.envMapIntensity ?? current?.envMapIntensity ?? Material.DefaultEnvMapIntensity,
    };
}

type Resolved<T> = { value: T } | { error: string };

function resolveColor(arg: unknown, fallback: Material | MaterialPreset | undefined): Resolved<number> {
    if (arg !== undefined) {
        const color = parseToolColor(arg);
        return typeof color === "string" ? { error: color } : { value: color };
    }
    if (fallback === undefined) return { value: DEFAULT_MATERIAL_COLOR };
    // In the numeric form `ensureMaterial` compares in.
    return { value: typeof fallback.color === "number" ? fallback.color : parseColor(fallback.color) };
}

function resolveOpacity(arg: unknown, fallback: Material | MaterialPreset | undefined): Resolved<number> {
    const opacity = arg === undefined ? (fallback?.opacity ?? 1) : arg;
    return typeof opacity === "number" && Number.isFinite(opacity) && opacity >= 0 && opacity <= 1
        ? { value: opacity }
        : { error: `opacity must be a number in [0,1], got ${describe(opacity)}` };
}

function resolveTexture(arg: unknown, current: Material | undefined): Resolved<string> {
    const texture = arg === undefined ? (current?.map.image ?? "") : arg;
    if (typeof texture !== "string") return { error: "texture must be a string" };
    if (texture === "" || isTextureSource(texture)) return { value: texture };
    return {
        error: `texture must be an image data URL ("data:image/png;base64,..."), an http(s)/blob URL, a path, or "" to remove it — got ${describe(texture)}`,
    };
}

/** The material the node points at, so an omitted argument can keep its current value. */
function materialOf(doc: IDocument, node: unknown): Material | undefined {
    const materialId = (node as { materialId?: string | string[] }).materialId;
    const first = Array.isArray(materialId) ? materialId[0] : materialId;
    return doc.modelManager.materials.find((m) => m.id === first);
}

/** A string the texture loader can actually fetch; anything else is a typo the model should see. */
function isTextureSource(texture: string): boolean {
    return /^(data:image\/|https?:\/\/|blob:|\/|\.{1,2}\/)/.test(texture);
}

function describe(value: unknown): string {
    return typeof value === "string" ? JSON.stringify(value) : String(value);
}

/**
 * Finds the document's material with exactly these values, creating one when none matches. Every
 * value the caller applies is compared: matching on colour alone would hand back a material whose
 * roughness or metalness differs, and silently restyle the node with it.
 */
function ensureMaterial(doc: IDocument, appearance: Appearance, presetName?: string): Material {
    // Material.color is number | string; normalize both sides before comparing.
    const existing = doc.modelManager.materials.find(
        (m) =>
            parseColor(m.color) === appearance.color &&
            m.opacity === appearance.opacity &&
            m.map.image === appearance.texture &&
            m.roughness === appearance.roughness &&
            m.metalness === appearance.metalness &&
            m.envMapIntensity === appearance.envMapIntensity,
    );
    if (existing !== undefined) return existing;

    const material = new Material({
        document: doc,
        name: presetName ?? `AI ${appearance.color.toString(16)}`,
        color: appearance.color,
    });
    material.opacity = appearance.opacity;
    material.roughness = appearance.roughness;
    material.metalness = appearance.metalness;
    material.envMapIntensity = appearance.envMapIntensity;
    material.map.image = appearance.texture;
    doc.modelManager.materials.push(material);
    return material;
}

function fitContentTool(): Tool {
    return {
        name: "fit_content",
        description:
            "Zoom the viewport camera to fit content. When nodes are selected, it fits only the selection; otherwise it fits all visible content.",
        parameters: { type: "object", properties: {} },
        handler: async () => {
            const view = globalThis.app.activeView;
            if (!view) return textResult({ error: "no active view" });
            view.cameraController.fitContent({ duration: CAMERA_FLY_DURATION });
            view.update();
            return textResult({ ok: true });
        },
    };
}

function isolateViewTool(): Tool {
    return {
        name: "isolate_view",
        description:
            "Show only the given nodes: hide everything else in the viewport without changing node visibility. Replaces any previous isolation, so pass just the set you want visible; an empty array clears the isolation and shows everything again.",
        parameters: {
            type: "object",
            properties: {
                ids: {
                    type: "array",
                    items: { type: "string" },
                    description: "Node ids to isolate; an empty array clears the isolation",
                },
            },
            required: ["ids"],
        },
        handler: isolateViewHandler,
    };
}

const isolateViewHandler: Tool["handler"] = async (args) => {
    const doc = getDocument();
    const view = globalThis.app.activeView;
    if (!doc || !view) {
        return textResult({ error: I18n.translate("ai.error.noDocument") });
    }
    const ids = (args as { ids?: unknown }).ids;
    if (!Array.isArray(ids)) {
        return textResult({ error: "ids must be an array of node ids" });
    }
    if (ids.length === 0) {
        view.unisolate();
        view.update();
        return textResult({ ok: true, isolated: [] });
    }
    const nodes = ids.map((id) => findNode(doc, String(id)));
    const missing = ids.filter((_, i) => nodes[i] === undefined);
    if (missing.length) {
        return textResult({ error: `nodes not found: ${missing.join(", ")}` });
    }
    // `view.isolate` accumulates (the viewport treats a second call as widening the isolation),
    // but this tool is documented as "isolate these nodes", so each call replaces the set.
    view.unisolate();
    view.isolate(nodes.filter((node): node is INode => node !== undefined));
    view.update();
    return textResult({ ok: true, isolated: ids });
};

function rotateViewTool(): Tool {
    return {
        name: "rotate_view",
        description:
            "Rotate the viewport camera around the current target, keeping its distance. Either a preset standard view, or relative orbit angles in degrees (azimuth orbits around the Z axis, elevation climbs above the XY plane).",
        parameters: {
            type: "object",
            properties: {
                view: {
                    type: "string",
                    enum: ["front", "back", "left", "right", "top", "bottom", "iso"],
                    description: "Preset standard view; takes precedence over azimuth/elevation",
                },
                azimuth: {
                    type: "number",
                    description: "Relative horizontal orbit in degrees, around the Z axis",
                },
                elevation: { type: "number", description: "Relative vertical orbit in degrees" },
            },
        },
        handler: rotateViewHandler,
    };
}

const rotateViewHandler: Tool["handler"] = async (args) => {
    const view = globalThis.app.activeView;
    if (!view) return textResult({ error: "no active view" });

    const camera = view.cameraController;
    const target = camera.cameraTarget;
    const position = camera.cameraPosition;
    const dx = position.x - target.x;
    const dy = position.y - target.y;
    const dz = position.z - target.z;
    const distance = Math.hypot(dx, dy, dz) || 1;

    const orientation = resolveOrientation(
        args as { view?: string; azimuth?: number; elevation?: number },
        target,
        { x: dx, y: dy, z: dz },
        distance,
    );
    if (typeof orientation === "string") return textResult({ error: orientation });

    camera.lookAt(orientation.eye, target, orientation.up, { duration: CAMERA_FLY_DURATION });
    view.update();
    return textResult({ ok: true, eye: toPlainPoint(orientation.eye) });
};

type CameraOrientation = { eye: XYZLike; up: XYZLike };

/** Resolves a preset or relative orbit; returns the message to report when the args are unusable. */
function resolveOrientation(
    a: { view?: string; azimuth?: number; elevation?: number },
    target: XYZLike,
    offset: XYZLike,
    distance: number,
): CameraOrientation | string {
    if (a.view !== undefined) {
        // Own property only: a prototype name would otherwise reach presetEye as a non-preset.
        if (!Object.hasOwn(VIEW_PRESETS, a.view)) {
            return `unknown view "${a.view}", expected one of ${Object.keys(VIEW_PRESETS).join("|")}`;
        }
        return presetEye(VIEW_PRESETS[a.view], target, distance);
    }
    if (a.azimuth === undefined && a.elevation === undefined) {
        return "provide view or azimuth/elevation";
    }
    return { eye: orbitEye(a, offset.x, offset.y, offset.z, target, distance), up: Z_UP };
}

function setCameraTypeTool(): Tool {
    return {
        name: "set_camera_type",
        description:
            "Switch the viewport camera projection: perspective (natural depth) or orthographic (no foreshortening — suited for technical views and alignment checks). Omit the type to toggle between the two.",
        parameters: {
            type: "object",
            properties: {
                type: {
                    type: "string",
                    enum: ["perspective", "orthographic"],
                    description: "Projection to switch to; omit to toggle",
                },
            },
        },
        handler: setCameraTypeHandler,
    };
}

const setCameraTypeHandler: Tool["handler"] = async (args) => {
    const view = globalThis.app.activeView;
    if (!view) return textResult({ error: "no active view" });
    const camera = view.cameraController;
    const type = args["type"] as string | undefined;
    if (type !== undefined && type !== "perspective" && type !== "orthographic") {
        return textResult({
            error: `unknown camera type "${type}", expected perspective|orthographic`,
        });
    }
    camera.cameraType = type ?? (camera.cameraType === "perspective" ? "orthographic" : "perspective");
    view.update();
    return textResult({ ok: true, cameraType: camera.cameraType });
};

function presetEye(
    preset: { dir: [number, number, number]; up: XYZLike },
    target: XYZLike,
    distance: number,
): { eye: XYZLike; up: XYZLike } {
    const len = Math.hypot(...preset.dir);
    const eye = {
        x: target.x + (preset.dir[0] / len) * distance,
        y: target.y + (preset.dir[1] / len) * distance,
        z: target.z + (preset.dir[2] / len) * distance,
    };
    return { eye, up: preset.up };
}

function orbitEye(
    a: { azimuth?: number; elevation?: number },
    dx: number,
    dy: number,
    dz: number,
    target: XYZLike,
    distance: number,
): XYZLike {
    const azimuth = Math.atan2(dy, dx) + ((a.azimuth ?? 0) * Math.PI) / 180;
    const limit = (Math.PI / 180) * 89.9;
    const elevation = Math.min(
        limit,
        Math.max(-limit, Math.atan2(dz, Math.hypot(dx, dy)) + ((a.elevation ?? 0) * Math.PI) / 180),
    );
    return {
        x: target.x + distance * Math.cos(elevation) * Math.cos(azimuth),
        y: target.y + distance * Math.cos(elevation) * Math.sin(azimuth),
        z: target.z + distance * Math.sin(elevation),
    };
}

function toPlainPoint(p: XYZLike) {
    const round = (v: number) => Math.round(v * 100) / 100;
    return { x: round(p.x), y: round(p.y), z: round(p.z) };
}
