// Part of the Chili3d Project, under the AGPL-3.0 License.
// See LICENSE file in the project root for full license information.

import { ObservableCollection } from "@chili3d/core";
import { SketchRibbonProfiles } from "@chili3d/parametric";
import {
    DefaultRibbon,
    mergeRibbonProfiles,
    ParametricRibbonProfiles,
    type RibbonProfileExtra,
} from "../src/ribbon";

describe("DefaultRibbon", () => {
    test("should be a non-empty array of tab profiles", () => {
        expect(Array.isArray(DefaultRibbon)).toBe(true);
        expect(DefaultRibbon.length).toBeGreaterThan(0);
    });

    test("each tab should have a tabName and groups", () => {
        for (const tab of DefaultRibbon) {
            expect(tab.tabName).toBeDefined();
            expect(typeof tab.tabName).toBe("string");
            expect(Array.isArray(tab.groups)).toBe(true);
        }
    });

    test("each group should have a groupName and items array", () => {
        for (const tab of DefaultRibbon) {
            for (const group of tab.groups) {
                expect(group.groupName).toBeDefined();
                expect(typeof group.groupName).toBe("string");
                expect(Array.isArray(group.items)).toBe(true);
            }
        }
    });

    test("first tab should be model tab", () => {
        expect(DefaultRibbon[0].tabName).toBe("ribbon.tab.basic");
    });

    test("second tab should be manager tab", () => {
        expect(DefaultRibbon[1].tabName).toBe("ribbon.tab.manager");
    });

    test("should not contain any sketch commands without useParametric", () => {
        const allItems = flattenItems(DefaultRibbon.flatMap((t) => t.groups.flatMap((g) => g.items)));
        expect(allItems.some((x) => x.startsWith("sketch."))).toBe(false);
        expect(DefaultRibbon.some((t) => t.tabName === "ribbon.tab.sketch")).toBe(false);
    });

    test("model tab should contain draw, modify, converter, boolean groups", () => {
        const modelTab = DefaultRibbon[0];
        const groupNames = modelTab.groups.map((g) => g.groupName);
        expect(groupNames).toContain("ribbon.group.draw");
        expect(groupNames).toContain("ribbon.group.modify");
        expect(groupNames).toContain("ribbon.group.converter");
        expect(groupNames).toContain("ribbon.group.boolean");
        expect(groupNames).toContain("ribbon.group.workingPlane");
        expect(groupNames).toContain("ribbon.group.tools");
        expect(groupNames).toContain("ribbon.group.measure");
        expect(groupNames).toContain("ribbon.group.act");
        expect(groupNames).toContain("ribbon.group.importExport");
    });

    test("draw group should contain create commands", () => {
        const drawGroup = DefaultRibbon[0].groups.find((g) => g.groupName === "ribbon.group.draw");
        expect(drawGroup).toBeDefined();
        const allItems = flattenItems(drawGroup!.items);
        expect(allItems).toContain("create.extrude");
        expect(allItems).toContain("create.box");
    });

    test("modify group should contain modify commands", () => {
        const modifyGroup = DefaultRibbon[0].groups.find((g) => g.groupName === "ribbon.group.modify");
        expect(modifyGroup).toBeDefined();
        const allItems = flattenItems(modifyGroup!.items);
        expect(allItems).toContain("modify.move");
        expect(allItems).toContain("modify.rotate");
        expect(allItems).toContain("modify.fillet");
    });

    test("boolean group should contain boolean commands", () => {
        const booleanGroup = DefaultRibbon[0].groups.find((g) => g.groupName === "ribbon.group.boolean");
        expect(booleanGroup).toBeDefined();
        const allItems = flattenItems(booleanGroup!.items);
        expect(allItems).toContain("boolean.common");
        expect(allItems).toContain("boolean.cut");
        expect(allItems).toContain("boolean.join");
    });

    test("split-type items should have type and items properties", () => {
        const drawGroup = DefaultRibbon[0].groups.find((g) => g.groupName === "ribbon.group.draw");
        const splitItems = drawGroup!.items.filter(
            (item) => typeof item === "object" && "type" in item && item.type === "split",
        );
        expect(splitItems.length).toBeGreaterThan(0);
        // The filter above guarantees every entry is a split item.
        for (const split of splitItems as { type: string; items: unknown[] }[]) {
            expect(split.type).toBe("split");
            expect(Array.isArray(split.items)).toBe(true);
        }
    });

    test("groups should support collapsedItems", () => {
        const drawGroup = DefaultRibbon[0].groups.find((g) => g.groupName === "ribbon.group.draw");
        expect(drawGroup!.collapsedItems).toBeDefined();
        expect(Array.isArray(drawGroup!.collapsedItems)).toBe(true);
    });

    test("all tab names should start with ribbon.tab.", () => {
        for (const tab of DefaultRibbon) {
            expect(tab.tabName.startsWith("ribbon.tab.")).toBe(true);
        }
    });

    test("all group names should start with ribbon.group.", () => {
        for (const tab of DefaultRibbon) {
            for (const group of tab.groups) {
                expect(group.groupName.startsWith("ribbon.group.")).toBe(true);
            }
        }
    });
});

describe("SketchRibbonProfiles", () => {
    test("parametric tab should hold the sketch entry commands", () => {
        const tab = SketchRibbonProfiles.find((t) => t.tabName === "ribbon.tab.parametric");
        expect(tab).toBeDefined();
        expect(tab!.contextual).toBeUndefined();
        const allItems = flattenItems(tab!.groups.flatMap((g) => g.items));
        expect(allItems).toEqual(["sketch.create", "sketch.enter"]);
    });

    test("sketch tab should be contextual and contain sketch, draw, constraint, dimension groups", () => {
        const sketchTab = SketchRibbonProfiles.find((t) => t.tabName === "ribbon.tab.sketch");
        expect(sketchTab).toBeDefined();
        expect(sketchTab!.contextual).toBe(true);
        const groupNames = sketchTab!.groups.map((g) => g.groupName);
        expect(groupNames).toContain("ribbon.group.sketch");
        expect(groupNames).toContain("ribbon.group.draw");
        expect(groupNames).toContain("ribbon.group.constraint");
        expect(groupNames).toContain("ribbon.group.dimension");
        const allItems = flattenItems(sketchTab!.groups.flatMap((g) => g.items));
        expect(allItems).toContain("sketch.array");
        expect(allItems).toContain("sketch.bezier");
        expect(allItems).toContain("sketch.exit");
        expect(allItems).toContain("sketch.line");
        expect(allItems).toContain("sketch.nurbs");
        // the free curves' one tool until garlic's families were split into bezier and nurbs
        expect(allItems).not.toContain("sketch.spline");
        expect(allItems).toContain("sketch.mirror");
        expect(allItems).toContain("sketch.offset");
        expect(allItems).toContain("sketch.polygon");
        expect(allItems).toContain("constraint.coincident");
        expect(allItems).toContain("dimension.distance");
        expect(allItems).not.toContain("sketch.create");
    });
});

describe("ParametricRibbonProfiles", () => {
    test("should contribute the feature group to the parametric tab", () => {
        const tab = ParametricRibbonProfiles.find((t) => t.tabName === "ribbon.tab.parametric");
        expect(tab).toBeDefined();
        expect(tab!.before).toBe("ribbon.tab.manager");
        const createGroup = tab!.groups.find((g) => g.groupName === "ribbon.group.create");
        expect(createGroup).toBeDefined();
        expect(flattenItems(createGroup!.items)).toContain("feature.extrude");
    });

    test("should split building a shape from modifying one into two groups", () => {
        // What builds geometry out of a profile, then what rewrites geometry already there — the
        // split every other CAD tool's toolbar makes, and the reason a draft (which rewrites the
        // body it is applied to) does not sit next to an extrude.
        const tab = ParametricRibbonProfiles.find((t) => t.tabName === "ribbon.tab.parametric");
        const itemsOf = (groupName: string) =>
            flattenItems(tab!.groups.find((g) => g.groupName === groupName)!.items);

        // Thicken sits with the builders, not the modifiers — Fusion's CREATE panel holds it too.
        expect(itemsOf("ribbon.group.create")).toEqual([
            "feature.plane",
            "feature.primitiveBox",
            "feature.primitiveCylinder",
            "feature.primitiveSphere",
            "feature.primitiveCone",
            "feature.extrude",
            "feature.revolve",
            "feature.loft",
            "feature.sweep",
            "feature.thicken",
            "feature.rib",
            "feature.helix",
        ]);
        expect(itemsOf("ribbon.group.feature")).toEqual([
            "feature.pressPull",
            "feature.fillet",
            "feature.chamfer",
            "feature.modifyFillet",
            "feature.modifyChamfer",
            "feature.draft",
            "feature.shell",
            "feature.offsetFace",
            "feature.split",
            "feature.hole",
            "feature.removeFeature",
            "feature.patternLinear",
            "feature.patternCircular",
            "feature.patternCurve",
            "feature.mirror",
        ]);
    });

    test("should keep the node operations in a group of their own", () => {
        // These act on the document's nodes rather than on a body's geometry, so they carry their
        // own label instead of borrowing the model tab's "modify".
        const tab = ParametricRibbonProfiles.find((t) => t.tabName === "ribbon.tab.parametric");
        const nodeGroup = tab!.groups.find((g) => g.groupName === "ribbon.group.node");
        expect(nodeGroup).toBeDefined();
        expect(flattenItems(nodeGroup!.items)).toEqual([
            "modify.move",
            "modify.rotate",
            "modify.mirror",
            "modify.detach",
            "modify.deleteNode",
            "modify.paintBucket",
            "modify.array",
        ]);
        expect(tab!.groups.some((g) => g.groupName === "ribbon.group.modify")).toBe(false);
    });

    test("should merge into the sketch module's parametric tab without duplicating it", () => {
        const merged = mergeRibbonProfiles(DefaultRibbon, [
            ...SketchRibbonProfiles,
            ...ParametricRibbonProfiles,
        ]);
        const parametricTabs = merged.filter((t) => t.tabName === "ribbon.tab.parametric");

        expect(parametricTabs.length).toBe(1);
        const allItems = flattenItems(parametricTabs[0].groups.flatMap((g) => g.items));
        expect(allItems).toEqual([
            "sketch.create",
            "sketch.enter",
            "feature.plane",
            "feature.primitiveBox",
            "feature.primitiveCylinder",
            "feature.primitiveSphere",
            "feature.primitiveCone",
            "feature.extrude",
            "feature.revolve",
            "feature.loft",
            "feature.sweep",
            "feature.thicken",
            "feature.rib",
            "feature.helix",
            "feature.pressPull",
            "feature.fillet",
            "feature.chamfer",
            "feature.modifyFillet",
            "feature.modifyChamfer",
            "feature.draft",
            "feature.shell",
            "feature.offsetFace",
            "feature.split",
            "feature.hole",
            "feature.removeFeature",
            "feature.patternLinear",
            "feature.patternCircular",
            "feature.patternCurve",
            "feature.mirror",
            "feature.fuse",
            "feature.cut",
            "feature.common",
            "modify.move",
            "modify.rotate",
            "modify.mirror",
            "modify.detach",
            "modify.deleteNode",
            "modify.paintBucket",
            "modify.array",
            "annotate.dimension",
            "annotate.radius",
            "annotate.diameter",
            "annotate.angle",
            "annotate.text",
            "file.import",
            "file.export",
            "feature.variable",
            "wechat.group",
            "ai.toggleChat",
        ]);
    });
});

describe("mergeRibbonProfiles", () => {
    test("should insert the parametric tab before the manager tab and append the sketch tab", () => {
        const merged = mergeRibbonProfiles(DefaultRibbon, SketchRibbonProfiles);
        const tabNames = merged.map((t) => t.tabName);

        expect(tabNames).toEqual([
            "ribbon.tab.basic",
            "ribbon.tab.parametric",
            "ribbon.tab.manager",
            "ribbon.tab.sketch",
        ]);
    });

    test("should not add sketch commands to the model tab", () => {
        const merged = mergeRibbonProfiles(DefaultRibbon, SketchRibbonProfiles);
        const drawGroup = merged
            .find((t) => t.tabName === "ribbon.tab.basic")!
            .groups.find((g) => g.groupName === "ribbon.group.draw")!;

        expect(flattenItems(drawGroup.items).some((x) => x.startsWith("sketch."))).toBe(false);
    });

    test("should not mutate the base profiles", () => {
        mergeRibbonProfiles(DefaultRibbon, SketchRibbonProfiles);

        const allItems = flattenItems(DefaultRibbon.flatMap((t) => t.groups.flatMap((g) => g.items)));
        expect(allItems.some((x) => x.startsWith("sketch."))).toBe(false);
        expect(DefaultRibbon.some((t) => t.tabName === "ribbon.tab.sketch")).toBe(false);
    });

    test("merging the same extras twice leaves them unchanged and repeats the result", () => {
        const extras = [...SketchRibbonProfiles, ...ParametricRibbonProfiles];
        const before = JSON.stringify(extras);

        const first = mergeRibbonProfiles(DefaultRibbon, extras);
        const second = mergeRibbonProfiles(DefaultRibbon, extras);

        expect(JSON.stringify(extras)).toBe(before);
        expect(JSON.stringify(second)).toBe(JSON.stringify(first));
    });

    test("an extra group merged into an existing group is not grown by the merge", () => {
        const extras: RibbonProfileExtra[] = [
            {
                tabName: "ribbon.tab.basic",
                groups: [
                    {
                        groupName: "ribbon.group.draw",
                        items: ["create.point", { type: "split", items: ["create.line", "create.rect"] }],
                    },
                ],
            },
        ];

        const first = mergeRibbonProfiles(DefaultRibbon, extras);
        mergeRibbonProfiles(DefaultRibbon, extras);
        mergeRibbonProfiles(DefaultRibbon, extras);

        expect(flattenItems(extras[0].groups[0].items)).toEqual([
            "create.point",
            "create.line",
            "create.rect",
        ]);
        const second = mergeRibbonProfiles(DefaultRibbon, extras);
        expect(JSON.stringify(second)).toBe(JSON.stringify(first));
    });

    test("the merged result shares no array or object with base or extras", () => {
        const extras = [...SketchRibbonProfiles, ...ParametricRibbonProfiles];
        const merged = mergeRibbonProfiles(DefaultRibbon, extras);

        const mergedRefs = collectRefs(merged);
        const sourceRefs = collectRefs(DefaultRibbon);
        collectRefs(extras, sourceRefs);

        for (const ref of mergedRefs) {
            expect(sourceRefs.has(ref)).toBe(false);
        }
    });
});

/** Every array and plain object reachable from `root`; runtime collections are shared by design. */
function collectRefs(root: unknown, into: Set<object> = new Set()): Set<object> {
    if (typeof root !== "object" || root === null || root instanceof ObservableCollection) return into;
    into.add(root);
    for (const value of Object.values(root)) {
        collectRefs(value, into);
    }
    return into;
}

/** Recursively flatten item entries that may be strings, string arrays, or {type, items} objects. */
function flattenItems(items: any[]): string[] {
    const result: string[] = [];
    for (const item of items) {
        if (typeof item === "string") {
            result.push(item);
        } else if (Array.isArray(item)) {
            result.push(...flattenItems(item));
        } else if (typeof item === "object" && "items" in item && Array.isArray(item.items)) {
            result.push(...flattenItems(item.items));
        }
    }
    return result;
}
