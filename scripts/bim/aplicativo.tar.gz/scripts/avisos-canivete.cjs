// Collect installed runtime dependency notices, including nested npm versions.
// Use the installed lock trees; builds never need an online license service.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'), out=path.join(root,'dist/web/avisos');
fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true});
const prefacio=fs.readFileSync(path.join(root,'docs/LICENCAS-CANIVETE.md'),'utf8');
const resultados=[prefacio,'\nPacotes, versões, distribuições e avisos incluídos\n'];
const json=p=>JSON.parse(fs.readFileSync(p));
const extras={
 'clipper-lib':'chapas-LICENCA.txt',
 'laz-perf':'avisos-nativos-canivete.txt',
 'tr46':'avisos-nativos-canivete.txt',
 '@ifc-lite/wasm-lifecycle':'MPL-2.0.txt',
 '@tesseract.js-data/por':'avisos-nativos-canivete.txt'
};
function arquivos(dir,base='',nivel=0){
 let list=[];
 for(const item of fs.readdirSync(path.join(dir,base),{withFileTypes:true})){
  const rel=path.join(base,item.name);
  if(item.isDirectory()&&nivel<5&&!['node_modules','.git','test','tests','__tests__'].includes(item.name))list=list.concat(arquivos(dir,rel,nivel+1));
  if(item.isFile()&&/(^|\.)(licen[cs]e|copying|copyright|notice|third[-_]?party|unlicense)([._-]|$)/i.test(item.name)&&!/[.](js|ts|map|png|wasm)$/i.test(item.name)&&fs.statSync(path.join(dir,rel)).size<1e6)list.push(rel);
 }return list.sort();
}
function inventario(base,prefixo,roots){
 const mapa=json(path.join(base,'package-lock.json')).packages,visitados=new Set();
 function visitar(nome,parent=''){
  let ptr=parent,chave;
  do{
   chave=path.posix.join(ptr,'node_modules',nome);
   if(mapa[chave])break;
   const i=ptr.lastIndexOf('/node_modules/');ptr=i<0?'':ptr.slice(0,i);
   if(!ptr)chave='node_modules/'+nome;
  }while(ptr);
  const lock=mapa[chave],dir=path.join(base,chave);
  if(!lock||!fs.existsSync(path.join(dir,'package.json')))throw Error('Dependência sem manifesto: '+prefixo+'/'+nome);
  if(visitados.has(chave))return;visitados.add(chave);
  const pkg=json(path.join(dir,'package.json')),id=prefixo+'/'+chave.replaceAll('node_modules/','').replaceAll('/','_')+'-'+pkg.version;
  const notices=arquivos(dir),copiados=[];
  for(const x of notices){const dst=path.join(out,id,x);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(path.join(dir,x),dst);copiados.push(id+'/'+x);}
  if(!notices.length && extras[nome])copiados.push(extras[nome]);
  const upstream=typeof pkg.repository==='string'?pkg.repository:pkg.repository?.url;
  const readme=fs.readdirSync(dir).find(f=>/^readme(?:\.md|\.txt)?$/i.test(f));
  if(!copiados.length&&readme){
   const txt=fs.readFileSync(path.join(dir,readme),'utf8');const match=/^#{1,4}\s+(license|licen[cs]ing)\b/im.exec(txt);
   if(match){fs.mkdirSync(path.join(out,id),{recursive:true});fs.writeFileSync(path.join(out,id,'README-licenca.txt'),txt.slice(match.index));copiados.push(id+'/README-licenca.txt');}
  }
  resultados.push([nome+' '+pkg.version,typeof pkg.license==='string'?pkg.license:'ver licença na origem',lock.resolved,upstream,copiados.join(', ')||'Consulte o arquivo de distribuição e os avisos incorporados ao código.'].filter(Boolean).join(' | '));
  for(const child of Object.keys(lock.dependencies||{}))visitar(child,chave);
  for(const child of Object.keys(lock.peerDependencies||{})){
   if(!lock.peerDependenciesMeta?.[child]?.optional && mapa['node_modules/'+child])visitar(child,chave);
  }
 }
 for(const nome of roots)visitar(nome);
}
for(const fn of ['avisos-nativos-canivete.txt','avisos-exceljs.txt','LICENCAS-WEB.txt','fontes-ifclite.txt'])fs.copyFileSync(path.join(root,'docs',fn),path.join(out,fn));
fs.copyFileSync(path.join(root,'web/chapas-LICENCA.txt'),path.join(out,'chapas-LICENCA.txt'));
fs.copyFileSync(path.join(root,'node_modules/@ifc-lite/create/LICENSE'),path.join(out,'MPL-2.0.txt'));
resultados.push('Código das versões MPL | fontes-ifclite.txt');
const roots=Object.keys(json(path.join(root,'package.json')).dependencies).filter(n=>!['exceljs','three','web-ifc'].includes(n));
inventario(root,'bim',roots);
if(fs.existsSync(path.join(root,'dist/fotogrametria/index.html'))){
 const sfm=path.resolve(process.env.WEBSFM_SOURCE||path.join(root,'.cache-bim/websfm'));
 const lock=fs.readFileSync(path.join(sfm,'crates/Cargo.lock'));
 const rust=fs.readFileSync(path.join(root,'docs/avisos-rust-websfm.txt'),'utf8');
 if(!rust.includes('SHA256 Cargo.lock '+crypto.createHash('sha256').update(lock).digest('hex')))throw Error('Os avisos Rust precisam acompanhar a revisão de WebSfM.');
 fs.writeFileSync(path.join(out,'WebSfM-Rust.txt'),rust);
 for(const [src,dest] of [['LICENSE','LICENSE-WebSfM.txt'],['src/core/help/licenses.js','WebSfM-creditos.js.txt'],['crates/mesh/vendor/poisson_reconstruction/Cargo.toml','WebSfM-poisson.txt']])fs.copyFileSync(path.join(sfm,src),path.join(out,dest));
 const usados=Object.keys(json(path.join(sfm,'package.json')).dependencies).filter(n=>n!=='onnxruntime-web');
 inventario(sfm,'websfm',usados);
 resultados.push('WebSfM | LICENSE-WebSfM.txt | WebSfM-Rust.txt | WebSfM-creditos.js.txt | WebSfM-poisson.txt');
}
fs.writeFileSync(path.join(out,'INDEX.txt'),resultados.join('\n')+'\n');
console.log('Avisos e fontes do canivete em dist/web/avisos/INDEX.txt.');
