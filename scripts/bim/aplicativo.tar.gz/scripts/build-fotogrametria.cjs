// Build only at deployment time. No images are uploaded to a service.
const fs = require('node:fs'),
  path = require('node:path'),
  { createHash } = require('node:crypto'),
  { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..'),
  upstream = 'https://github.com/fdahle/websfm.git',
  ref = '6c998172e240ede1676ac4416e261d01e0e5d5e0';
const source = process.env.WEBSFM_SOURCE
  ? path.resolve(process.env.WEBSFM_SOURCE)
  : path.join(root, '.cache-bim', 'websfm');
const dist = path.join(root, 'dist/fotogrametria');
function git(...args) {
  return execFileSync('git', ['-C', source, ...args], { encoding: 'utf8' }).trim();
}
if (!fs.existsSync(path.join(source, '.git'))) {
  fs.mkdirSync(source, { recursive: true });
  git('init', '-q');
  git('fetch', '--depth', '1', upstream, ref);
  git('checkout', '-q', '--detach', ref);
}
if (
  git('rev-parse', 'HEAD') !== ref ||
  git('diff', '--name-only', 'HEAD') ||
  git('ls-files', '--others', '--exclude-standard', '--', 'public')
)
  throw Error('A revisão do WebSfM diverge da versão homologada.');
if (!fs.existsSync(path.join(source, 'node_modules/vite/bin/vite.js')))
  execFileSync('npm', ['ci', '--ignore-scripts', '--no-fund', '--no-audit'], {
    cwd: source,
    stdio: 'inherit',
  });
// Keep the upstream checkout clean: patch only the two final PLY/OBJ delivery
// call-sites while Vite builds, then restore the pinned source byte-for-byte.
// This deliberately does not wrap downloadBlob(), which is also used by session
// and intermediate-product downloads that must remain free.
const commerceSource = path.join(source, 'src/composables/exports/clouds.js');
function aplicarCreditosFotogrametria(original) {
  if (createHash('sha256').update(original).digest('hex') !== '9175b554e07390d3b14beccd8ba1b328f4e8ff22e6156bbc72db339da86fdb17')
    throw Error('A fonte de exportação do WebSfM mudou. Revise os pontos PLY/OBJ antes de publicar.');
  let code = original.toString('utf8');
  const saveTarget = `  async function saveTarget(filename, estimate, mime) {
    if (estimateExportBytes(estimate) < EXPORT_TUNING.savePickerMinMiB * 1024 ** 2) {
      return { save: (blob) => downloadBlob(filename, blob) }
    }
    const ext = filename.slice(filename.lastIndexOf('.'))
    const target = await pickSaveTarget(filename, [
      { description: \`${'${'}ext.slice(1).toUpperCase()} file\`, accept: { [mime]: [ext] } },
    ])
    if (!target) log(\`Export of ${'${'}filename} cancelled\`, 'info', 'Export')
    return target
  }
`;
  const credits = `${saveTarget}
  async function entregarFotogrametria(format, blob, deliver) {
    const { exportToolResult } = await import(/* @vite-ignore */ '/assets/js/tool-credits.mjs')
    return exportToolResult({ toolId: 'bim-fotogrametria', format, content: blob, deliver })
  }
`;
  if (!code.includes(saveTarget)) throw Error('Não encontrei o seletor de destino do WebSfM.');
  code = code.replace(saveTarget, credits);
  const streamed = `      const { blob } = await useReconstructionStore().exportCloudLod(cloud, { format, color: includeColor })
      await out.save(blob)`;
  const streamedPatched = `      const { blob } = await useReconstructionStore().exportCloudLod(cloud, { format, color: includeColor })
      if (format.startsWith('ply')) await entregarFotogrametria('ply', blob, () => out.save(blob))
      else await out.save(blob)`;
  const cloud = `    )
    await out.save(blob)
  }

  // Mesh (screened Poisson)`;
  const cloudPatched = `    )
    if (format.startsWith('ply')) await entregarFotogrametria('ply', blob, () => out.save(blob))
    else await out.save(blob)
  }

  // Mesh (screened Poisson)`;
  const mesh = `    )
    await out.save(blob)
  }

  // SfM cameras`;
  const meshPatched = `    )
    if (format === 'obj' || format.startsWith('ply')) await entregarFotogrametria(format === 'obj' ? 'obj' : 'ply', blob, () => out.save(blob))
    else await out.save(blob)
  }

  // SfM cameras`;
  for (const [before, after, label] of [[streamed, streamedPatched, 'nuvem LOD'], [cloud, cloudPatched, 'nuvem'], [mesh, meshPatched, 'malha']]) {
    if (!code.includes(before)) throw Error('Não encontrei o ponto de exportação ' + label + ' do WebSfM.');
    code = code.replace(before, after);
  }
  return Buffer.from(code);
}
const config = path.join(source, '.confenge.vite.mjs');
let commerceOriginal;
try {
  commerceOriginal = fs.readFileSync(commerceSource);
  fs.writeFileSync(commerceSource, aplicarCreditosFotogrametria(commerceOriginal));
  fs.copyFileSync(path.join(__dirname, 'fotogrametria-vite.mjs'), config);
  execFileSync(
    process.execPath,
    ['node_modules/vite/bin/vite.js', 'build', '--config', config, '--outDir', dist, '--emptyOutDir'],
    { cwd: source, env: { ...process.env, NODE_OPTIONS: '--max-old-space-size=4096' }, stdio: 'inherit' },
  );
} finally {
  if (commerceOriginal) fs.writeFileSync(commerceSource, commerceOriginal);
  fs.rmSync(config, { force: true });
}
fs.copyFileSync(path.join(source, 'LICENSE'), path.join(dist, 'LICENSE'));
