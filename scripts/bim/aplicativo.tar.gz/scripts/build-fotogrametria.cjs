// Build only at deployment time. No images are uploaded to a service.
const fs = require('node:fs'),
  path = require('node:path'),
  { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..'),
  upstream = 'https://github.com/fdahle/websfm.git',
  ref = '6c998172e240ede1676ac4416e261d01e0e5d5e0';
const source = process.env.WEBSFM_SOURCE
  ? path.resolve(process.env.WEBSFM_SOURCE)
  : path.join(root, '.cache-bim', 'websfm');
const dist = path.join(root, 'dist/fotogrametria');
function git(...args) {
  return execFileSync('git', ['-C', source, ...args], { encoding: 'utf8' }).trim();
}
if (!fs.existsSync(path.join(source, '.git'))) {
  fs.mkdirSync(source, { recursive: true });
  git('init', '-q');
  git('fetch', '--depth', '1', upstream, ref);
  git('checkout', '-q', '--detach', ref);
}
if (
  git('rev-parse', 'HEAD') !== ref ||
  git('diff', '--name-only', 'HEAD') ||
  git('ls-files', '--others', '--exclude-standard', '--', 'public')
)
  throw Error('A revisão do WebSfM diverge da versão homologada.');
if (!fs.existsSync(path.join(source, 'node_modules/vite/bin/vite.js')))
  execFileSync('npm', ['ci', '--ignore-scripts', '--no-fund', '--no-audit'], {
    cwd: source,
    stdio: 'inherit',
  });
const config = path.join(source, '.confenge.vite.mjs');
fs.copyFileSync(path.join(__dirname, 'fotogrametria-vite.mjs'), config);
try {
  execFileSync(
    process.execPath,
    ['node_modules/vite/bin/vite.js', 'build', '--config', config, '--outDir', dist, '--emptyOutDir'],
    { cwd: source, env: { ...process.env, NODE_OPTIONS: '--max-old-space-size=4096' }, stdio: 'inherit' },
  );
} finally {
  fs.rmSync(config, { force: true });
}
fs.copyFileSync(path.join(source, 'LICENSE'), path.join(dist, 'LICENSE'));
