const fs = require('node:fs');
const path = require('node:path');
const esbuild = require('esbuild');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'dist/web/vendor/oficina');
fs.mkdirSync(out, { recursive: true });
for (const mode of ['fornecedor', 'malha', 'perfil', 'ids']) {
  esbuild.buildSync({
    entryPoints: [path.join(root, 'web/oficina-' + mode + '.mjs')],
    outfile: path.join(out, mode + '.js'),
    bundle: true,
    minify: true,
    legalComments: 'eof',
    platform: 'browser',
    format: mode === 'ids' ? 'esm' : 'iife',
    loader: { '.wasm': 'file' },
    external: ['fs', 'stream', 'path', 'node:module'],
    logLevel: 'error',
  });
}
const copy = (pkg, from, to) =>
  fs.copyFileSync(path.join(root, 'node_modules', pkg, from), path.join(out, to || path.basename(from)));
for (const file of [
  'occt-import-js.js',
  'occt-import-js.wasm',
  'license.occt-import-js.txt',
  'license.occt.txt',
])
  copy('occt-import-js', 'dist/' + file);
copy('laz-perf', 'lib/web/laz-perf.wasm');
copy('copc', 'license', 'copc-license.txt');
