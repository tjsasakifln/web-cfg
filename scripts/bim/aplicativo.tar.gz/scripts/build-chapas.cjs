const fs=require('node:fs');
const path=require('node:path');
const dir=path.resolve(__dirname,'../dist/web/vendor-chapas');
fs.mkdirSync(dir,{recursive:true});
fs.copyFileSync(require.resolve('clipper-lib'),path.join(dir,'clipper.js'));
