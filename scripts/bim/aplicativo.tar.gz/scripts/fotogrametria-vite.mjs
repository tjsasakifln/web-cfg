// This configuration runs in the pinned WebSfM checkout. The served product is
// the local SIFT + geometric reconstruction path, without neural weights or a PWA.
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
function localOnly() {
  return {
    name: 'confenge-local',
    enforce: 'pre',
    resolveId(id) {
      if (id === 'virtual:pwa-register' || id === 'onnxruntime-web/webgpu') return '\0confenge:' + id;
    },
    load(id) {
      if (id === '\0confenge:virtual:pwa-register') return 'export function registerSW(){return async()=>{}}';
      if (id === '\0confenge:onnxruntime-web/webgpu')
        return 'throw Error("Use SIFT e correspondência clássica nesta edição local."); export const env={}; export const InferenceSession={}; export class Tensor {}';
    },
  };
}
export default defineConfig({
  base: './',
  plugins: [
    localOnly(),
    vue(),
    {
      name: 'local-policy',
      transformIndexHtml() {
        return [
          {
            tag: 'meta',
            attrs: {
              'http-equiv': 'Content-Security-Policy',
              content:
                "default-src 'self' data: blob:; script-src 'self' blob: 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self' blob: data:; object-src 'none'; form-action 'none'; base-uri 'self'",
            },
            injectTo: 'head-prepend',
          },
        ];
      },
    },
  ],
  worker: { format: 'es', plugins: () => [localOnly()] },
  build: {
    target: 'es2022',
    chunkSizeWarningLimit: 2500,
    // This site-level module is served by CONFENGE beside the Vite application.
    // Keep its absolute runtime URL; it is not a WebSfM source dependency.
    rollupOptions: { external: ['/assets/js/tool-credits.mjs'] },
  },
});
