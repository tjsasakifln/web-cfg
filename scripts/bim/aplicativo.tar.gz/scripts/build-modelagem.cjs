const fs = require('node:fs');
const path = require('node:path');
const { buildSync } = require('esbuild');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'dist/web/vendor/modelagem');
fs.mkdirSync(out, {recursive:true});
for (const [name,contents] of Object.entries({
  'ifc': "export {IfcCreator} from './node_modules/@ifc-lite/create/dist/ifc-creator.js';export {landXmlToIfc} from './node_modules/@ifc-lite/create/dist/landxml/landxml-to-ifc.js'",
  'suncalc': "export {getPosition} from 'suncalc'",
  'step': "export {draw,makeBox,makeCylinder,setOC} from 'replicad'",
})) {
  buildSync({stdin:{contents,resolveDir:root},bundle:true,platform:'browser',format:'esm',
    loader:{'.wasm':'file'},target:'es2022',minify:true,legalComments:'eof',outfile:path.join(out,name+'.mjs')});
}
// The kernel stays separate and replaceable. It is loaded only for STEP output.
const pkg = path.join(root,'node_modules/replicad-opencascadejs');
for(const file of ['replicad_single.js','replicad_single.wasm']) fs.copyFileSync(path.join(pkg,'dist',file),path.join(out,file));
for(const name of ['@ifc-lite/create','@ifc-lite/data','@ifc-lite/encoding','replicad','replicad-opencascadejs','flatbush','flatqueue','opentype.js','suncalc']){
  const dir=path.join(root,'node_modules',name);
  const license=fs.readdirSync(dir).find(x=>/^licen[cs]e(\.|$)/i.test(x));
  if(license)fs.copyFileSync(path.join(dir,license),path.join(out,name.replace('/','-')+'-LICENSE.txt'));
}
