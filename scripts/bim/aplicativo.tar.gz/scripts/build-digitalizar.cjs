const fs=require('node:fs');
const path=require('node:path');
const raiz=path.resolve(__dirname,'..');
const destino=path.join(raiz,'dist/web/vendor-ocr');
fs.mkdirSync(destino,{recursive:true});
const arquivos=[
  ['tesseract.js/dist/tesseract.esm.min.js','tesseract.mjs'],
  ['tesseract.js/dist/worker.min.js','worker.min.js'],
  ['tesseract.js/dist/worker.min.js.LICENSE.txt','worker.min.js.LICENSE.txt'],
  ['tesseract.js/dist/tesseract.min.js.LICENSE.txt','tesseract.min.js.LICENSE.txt'],
  ['tesseract.js/LICENSE.md','LICENSE-Tesseract.txt'],
  ['tesseract.js-core/LICENSE','LICENSE-Core.txt'],
  ['tesseract.js-core/tesseract-core-lstm.wasm.js','tesseract-core-lstm.wasm.js'],
  ['@tesseract.js-data/por/4.0.0_best_int/por.traineddata.gz','por.traineddata.gz'],
];
for(const [entrada,saida] of arquivos) fs.copyFileSync(path.join(raiz,'node_modules',entrada),path.join(destino,saida));
fs.writeFileSync(path.join(destino,'FONTES.txt'),[
  'Tesseract.js e tesseract.js-core 7.0.0 (Apache-2.0).',
  'https://github.com/naptha/tesseract.js · https://github.com/naptha/tesseract.js-core',
  'Idioma português distribuído por @tesseract.js-data/por 1.0.0 (pacote MIT).',
  'https://github.com/naptha/tessdata · dados de treinamento Tesseract (Apache-2.0): https://github.com/tesseract-ocr/tessdata_best',
].join('\n')+'\n');
