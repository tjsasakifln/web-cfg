// GlobalId anchors occurrences across documents. STEP IDs distinguish them only within a document.
function agrupar(itens, chave) {
  const grupos = new Map();
  for (const item of itens) {
    const k = chave(item);
    if (!grupos.has(k)) grupos.set(k, []);
    grupos.get(k).push(item);
  }
  return grupos;
}
function medidas(linhas) {
  return agrupar(linhas.filter(l => l.estado !== 'sem_quantidade'),
    l => JSON.stringify([l.conjunto,l.quantidade,l.tipo]));
}
function uniao(a,b) {
  return new Set([...a.keys(), ...b.keys()]);
}
function ausentes(ids) {
  return Array.from(ids, ([expressId, itens]) => ({id:expressId, objeto:itens[0].objeto}));
}
export function compararQuantitativos(revA, revB) {
  const A = agrupar(revA.linhas, l => l.globalId);
  const B = agrupar(revB.linhas, l => l.globalId);
  const linhas = [];
  for (const globalId of uniao(A,B)) {
    const ocorrA = agrupar(A.get(globalId) || [], l=>l.expressId);
    const ocorrB = agrupar(B.get(globalId) || [], l=>l.expressId);
    const refA = ausentes(ocorrA);
    const refB = ausentes(ocorrB);
    const base = {globalId, objetoA:refA[0]?.objeto || '', objetoB:refB[0]?.objeto || '', refA,refB,
      conjunto:'',quantidade:'',tipo:'',a:null,b:null,unidadeA:'',unidadeB:'',diferenca:null};
    if (!globalId || ocorrA.size > 1 || ocorrB.size > 1) {
      linhas.push({...base, estado: !globalId ? 'id_ausente' : 'id_duplicado'});
      continue;
    }
    if (!ocorrA.size || !ocorrB.size) {
      linhas.push({...base, estado:ocorrA.size ? 'elemento_so_a' : 'elemento_so_b'});
      continue;
    }
    const qa = medidas(ocorrA.values().next().value);
    const qb = medidas(ocorrB.values().next().value);
    const chaves = uniao(qa,qb);
    if (!chaves.size) linhas.push({...base, estado:'sem_quantidades'});
    for (const chave of chaves) {
      const as = qa.get(chave) || [], bs = qb.get(chave) || [];
      const a = as[0], b = bs[0], origem = a || b;
      const l = {...base, conjunto:origem.conjunto, quantidade:origem.quantidade, tipo:origem.tipo};
      if (as.length > 1 || bs.length > 1) {
        linhas.push({...l, estado:'quantidade_ambigua'});
        continue;
      }
      Object.assign(l,{a:a?.valor ?? null, b:b?.valor ?? null, unidadeA:a?.unidade || '', unidadeB:b?.unidade || ''});
      if (!origem.conjunto || !origem.quantidade || (a && a.estado !== 'declarado') || (b && b.estado !== 'declarado')) l.estado = 'dado_inconclusivo';
      else if (!a || !b) l.estado = a ? 'quantidade_so_a' : 'quantidade_so_b';
      else if (a.unidade && b.unidade && a.unidade !== b.unidade) l.estado = 'unidades_diferentes';
      else if (!a.chaveUnidade || !b.chaveUnidade || a.chaveUnidade !== b.chaveUnidade) l.estado = 'unidade_inconclusiva';
      else if (!Number.isFinite(a.valor) || !Number.isFinite(b.valor) || !Number.isFinite(b.valor - a.valor)) l.estado = 'dado_inconclusivo';
      else {
        l.estado = a.valor === b.valor ? 'igual' : 'alterado';
        l.diferenca = b.valor - a.valor;
      }
      linhas.push(l);
    }
  }
  const resumo = {linhas:linhas.length, contagem:{}};
  for (const l of linhas) resumo.contagem[l.estado] = (resumo.contagem[l.estado] || 0) + 1;
  return {linhas,resumo};
}
