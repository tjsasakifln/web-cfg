import {extrairQuantitativos, gerarExcel} from './quantitativos.mjs';
import {comModelo} from './ifc-runtime.mjs';

export const LIMITE_PLANILHA = 25 * 1024 * 1024;

export async function prepararPlanilha(arquivo, nome) {
  if (!/\.ifc$/i.test(nome) || !arquivo.size || arquivo.size > LIMITE_PLANILHA) {
    throw new Error('Selecione um arquivo .ifc de até 25 MiB com conteúdo.');
  }
  const relatorio = await comModelo(await arquivo.arrayBuffer(), extrairQuantitativos);
  await import('./vendor/exceljs/exceljs.min.js');
  const dados = await gerarExcel(relatorio, globalThis.ExcelJS);
  const blob = new Blob([dados], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  return {relatorio, blob, nome: nome.replace(/\.ifc$/i, '') + '-quantitativos.xlsx'};
}
