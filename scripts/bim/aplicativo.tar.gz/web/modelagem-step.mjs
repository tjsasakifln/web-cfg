import {plateArea} from './modelagem-core.mjs';

import {executar} from './oficina-worker.mjs';

executar(async p=>{
  plateArea(p);
  const {draw,makeBox,makeCylinder,setOC} = await import('./vendor/modelagem/step.mjs');
  const {default:create} = await import('./vendor/modelagem/replicad_single.js');
  setOC(await create());
  let shape;
  if(p.shape==='photo'){
    const pen=draw(p.outline[0]);for(const pt of p.outline.slice(1))pen.lineTo(pt);
    shape=pen.close().sketchOnPlane('XY').extrude(p.thickness);
  }else shape=p.shape==='disk'?makeCylinder(p.width/2,p.thickness):makeBox([-p.width/2,-p.depth/2,0],[p.width/2,p.depth/2,p.thickness]);
  try{
    for(const [x,y,d] of p.holes){
      const cutter=makeCylinder(d/2,p.thickness+2,[x,y,-1]);
      try{const next=shape.cut(cutter);shape.delete();shape=next;}finally{cutter.delete();}
    }
    return shape.blobSTEP();
  }finally{shape.delete();}
});
