// The same locally bundled CAD implementation is used by the scan and model tools.
const bytes = input => input instanceof Uint8Array ? input : new Uint8Array(input);
const limite = 25 * 1024 * 1024;
function validar(input) {
  const data=bytes(input);
  if (!data.length || data.length>limite) throw new Error('Use um desenho de até 25 MiB.');
  return data;
}
function monitorar(avisar) {
  return (_,evento)=>{
    if ([-1,1,3].includes(evento.notificationType)||/not supported|unsupported|skipping|skipped/i.test(evento.message)) throw new Error(String(evento.message).slice(0,300));
    if (evento.notificationType!==0) {
      if (!avisar) throw new Error('Conversão CAD com restrição: '+String(evento.message).slice(0,210));
      avisar(String(evento.message).slice(0,210));
    }
  };
}
function escreverDxf(lib,doc,notificar) {
  // Modern DXF uses UTF-8. Older code-page DXF would corrupt accented text here.
  doc.header.version=lib.ACadVersion.AC1027;
  const partes=[];
  let total=0;
  lib.DxfWriter.writeToStream({write(parte){
    total+=parte.length;
    if(total>64*1024*1024) throw new Error('O DXF supera o limite de saída.');
    partes.push(parte);
  }},doc,false,undefined,notificar);
  return new TextEncoder().encode(partes.join(''));
}
export function escreverDocumento(lib,doc,formato,avisar) {
  if(!['dwg','dxf'].includes(formato))throw new Error('Formato CAD inválido.');
  doc.header.version=formato==='dwg'?lib.ACadVersion.AC1015:lib.ACadVersion.AC1027;
  const n=monitorar(avisar);
  return formato==='dwg'?lib.DwgWriter.writeToBuffer(doc,null,n):escreverDxf(lib,doc,n);
}
// Reject drawings that depend on geometry outside the supported model-space subset.
export function conferirDesenho(doc){
  const simples=new Set(['LINE','LWPOLYLINE','POLYLINE','TEXT','MTEXT','ARC','CIRCLE','ELLIPSE','POINT']);
  if(!doc.modelSpace?.entities.count)throw new Error('O espaço do modelo está vazio.');
  const folhas=Array.from(doc.layouts || []).filter(l=>l.name?.toLowerCase()!=='model');
  if(folhas.length>1)throw new Error('Desenho com múltiplas folhas. Exporte a vista separadamente.');
  for(const bloco of doc.blockRecords || []){
    if((bloco.combinedFlags & 12)||bloco.blockEntity?.xRefPath)throw new Error('Desenho com referência externa (XREF). Incorpore a referência antes de converter.');
    if(/^\*Paper_Space/i.test(bloco.name)&&(bloco.entities.count||/\d$/.test(bloco.name)))throw new Error('Layouts de impressão com conteúdo pedem conferência em CAD. Exporte apenas o espaço do modelo.');
    for(const e of bloco.entities)if(!simples.has(e.objectName))throw new Error('A conversão de desenhos aceita traçados 2D simples. Entidade sem homologação: '+e.objectName);
  }
}
export async function dxfParaDwg(input,avisar) {
  const data=validar(input),lib=await import('./vendor-cad/acad.mjs'),n=monitorar(avisar);
  const doc=lib.DxfReader.readFromStream(data,n);
  conferirDesenho(doc);
  doc.header.version=lib.ACadVersion.AC1015;
  return lib.DwgWriter.writeToBuffer(doc,null,n);
}
export async function dwgParaDxf(input,avisar) {
  const data=validar(input),lib=await import('./vendor-cad/acad.mjs'),n=monitorar(avisar);
  if(!/^AC10\d{2}$/.test(new TextDecoder().decode(data.subarray(0,6)))) throw new Error('Assinatura DWG inválida.');
  const doc=lib.DwgReader.readFromStream(data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength),n);
  conferirDesenho(doc);
  return escreverDxf(lib,doc,n);
}
export async function escreverPrancha({linhas,textos},formato,fator,avisar) {
  if(!Number.isFinite(fator)||fator<=0) throw new Error('Informe uma escala positiva.');
  const lib=await import('./vendor-cad/acad.mjs');
  const doc=new lib.CadDocument();
  doc.header.version=lib.ACadVersion.AC1027;
  doc.header.insUnits=4; // millimetres
  function xyz(p){return new lib.XYZ(p[0]*fator,p[1]*fator,0);}
  for (const [a,b] of linhas) {
    const e=new lib.Line();e.startPoint=xyz(a);e.endPoint=xyz(b);doc.modelSpace.entities.add(e);
  }
  for(const t of textos){
    const e=new lib.TextEntity(t.valor);e.insertPoint=xyz(t.origem);e.height=t.altura*fator;e.rotation=t.rotacao;
    doc.modelSpace.entities.add(e);
  }
  if(!linhas.length && !textos.length) throw new Error('Nenhuma entidade vetorial para exportar.');
  return escreverDocumento(lib,doc,formato,avisar);
}
