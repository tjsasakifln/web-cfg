import {simplePolygon,polyArea} from './regua-geometria.mjs';
// All axes in a model are horizontal, measured in metres after explicit CAD unit selection.
export const MAX_WALLS = 2000;
const check = (ok, message) => { if (!ok) throw new Error(message); };
const positive = n => Number.isFinite(n) && n > 0;
export function cadAxes(dxf) {
  check(dxf.length <= 32 * 1024 ** 2 && !dxf.includes('\x00'), 'Use DXF ASCII de até 32 MiB.');
  let breaks=0;
  for(let i=0;i<dxf.length;i++)if((dxf[i]==='\n'||(dxf[i]==='\r'&&dxf[i+1]!=='\n'))&&++breaks>1000000)throw Error('O desenho supera 500 mil pares DXF.');
  const raw = dxf.trimEnd().split(/\r\n|\n|\r/);
  check(raw.length % 2 === 0, 'DXF incompleto.');
  let section = '', entering = false, kind = '', fields = new Map(), ended = false, units = 0, varName = '';
  const axes = [], omitted = new Map();
  function flush() {
    if (section !== 'ENTITIES' || !kind || kind === 'SECTION' || fields.get(67) === '1' ||
        (fields.has(410) && fields.get(410).toUpperCase() !== 'MODEL')) return;
    if (kind !== 'LINE') { omitted.set(kind,(omitted.get(kind)||0)+1); return; }
    const values = [10,20,11,21].map(k => fields.has(k) && fields.get(k) !== '' ? Number(fields.get(k)) : NaN);
    check(values.every(Number.isFinite), 'Uma linha possui coordenadas inválidas.');
    if ([30,31].some(k=>Number(fields.get(k)||0)!==0)) { omitted.set('LINE 3D',(omitted.get('LINE 3D')||0)+1); return; }
    check(axes.length < MAX_WALLS, 'O limite é de 2.000 eixos por desenho.');
    if (values[0]!==values[2] || values[1]!==values[3]) axes.push({start:values.slice(0,2),end:values.slice(2),layer:fields.get(8)||'0'});
  }
  for(let i=0;i<raw.length;i+=2){
    const code=Number(raw[i].trim()), value=raw[i+1].trim();
    if(code===0){
      flush(); fields=new Map(); kind=value;
      if(value==='SECTION'){entering=true;section='';}
      if(value==='ENDSEC'){section='';entering=false;}
      if(value==='EOF'){ended=true;break;}
    }else if(entering&&code===2){section=value;entering=false;}
    else if(section==='HEADER'&&code===9)varName=value;
    else if(section==='HEADER'&&varName==='$INSUNITS'&&code===70){units=Number(value);varName='';}
    else fields.set(code,value);
  }
  check(ended && axes.length,'O arquivo deve conter LINEs horizontais no espaço de modelo e terminar com EOF.');
  return {axes, units:({4:'mm',5:'cm',6:'m',1:'in',2:'ft'})[units]||'', omitted:[...omitted].map(([k,n])=>k+' × '+n).join(', ')};
}

export function scaleAxes(axes,unit) {
  const scale=({mm:.001,cm:.01,m:1,in:.0254,ft:.3048})[unit];
  check(positive(scale),'Confirme a unidade dos eixos.');
  return axes.map(a=>({...a,start:a.start.map(x=>x*scale),end:a.end.map(x=>x*scale)}));
}

export function sketchAxis(points, calibration, known) {
  check(calibration?.length===2 && positive(known),'Marque dois pontos e informe a cota em metros.');
  const [origin, other]=calibration;
  const distance=Math.hypot(other[0]-origin[0],other[1]-origin[1]);
  check(distance>=2,'Separe os pontos de referência na imagem.');
  const p=([x,y])=>[(x-origin[0])*known/distance,(origin[1]-y)*known/distance];
  return points.map(([start,end])=>({start:p(start),end:p(end),layer:'Croqui'}));
}

export function wallsIfc(IfcCreator, axes, height, thickness, storeyName, elevation=0) {
  check(axes.length>0 && axes.length<=MAX_WALLS,'Selecione pelo menos um eixo.');
  check(positive(height) && positive(thickness) && Number.isFinite(elevation) && Math.max(height,thickness,Math.abs(elevation))<=1e6,'Confira as dimensões e a cota do pavimento.');
  const creator=new IfcCreator({Name:'Paredes por eixos', Organization:'CONFENGE'}), floor=creator.addIfcBuildingStorey({Name:storeyName||'Pavimento',Elevation:elevation});
  axes.forEach(({start,end,layer},i)=>{
    const length=Math.hypot(end[0]-start[0],end[1]-start[1]);
    check(start.length===2 && end.length===2 && [...start,...end].every(n=>Number.isFinite(n)&&Math.abs(n)<=1e9) && length>1e-5,'Há um eixo sem comprimento válido.');
    const id=creator.addIfcWall(floor,{Name:'Parede '+(i+1),Description:'Eixo confirmado: '+layer,Start:[...start,0],End:[...end,0],Thickness:thickness,Height:height});
    creator.addIfcElementQuantity(id,{Name:'Qto_WallBaseQuantities',Quantities:[
      {Kind:'IfcQuantityLength',Name:'Length',Value:length},{Kind:'IfcQuantityLength',Name:'Width',Value:thickness},{Kind:'IfcQuantityLength',Name:'Height',Value:height},
      {Kind:'IfcQuantityVolume',Name:'GrossVolume',Value:length*height*thickness}
    ]});
  });
  return creator.toIfc().content;
}

// Plate dimensions and hole positions are in millimetres relative to its centre.
export function plateArea(p) {
  check(['rect','disk','photo'].includes(p.shape) && [p.width,p.depth,p.thickness].every(positive),'Informe as dimensões positivas em mm.');
  check(Math.max(p.width,p.depth,p.thickness)<=1e7,'As dimensões da peça excedem o intervalo de trabalho.');
  check(Array.isArray(p.holes)&&p.holes.length<=48&&p.holes.every(h=>Array.isArray(h)&&h.length===3),'São permitidos até 48 furos.');
  if(p.shape==='photo')check(Array.isArray(p.outline)&&p.outline.length>=3&&p.outline.length<=200&&p.outline.every(v=>Array.isArray(v)&&v.length===2&&v.every(Number.isFinite))&&simplePolygon(p.outline),'Contorno da foto inválido.');
  let area=p.shape==='photo'?polyArea(p.outline):p.shape==='disk'?Math.PI*(p.width/2)**2:p.width*p.depth;
  p.holes.forEach(([x,y,d],i)=>{
    check([x,y,d].every(Number.isFinite)&&positive(d),'Cada furo precisa de centro e diâmetro válidos.');
    const r=d/2;
    const inside=p.shape==='photo'?fitsPolygon(x,y,r,p.outline):p.shape==='disk'?Math.hypot(x,y)+r<p.width/2:Math.abs(x)+r<p.width/2&&Math.abs(y)+r<p.depth/2;
    check(inside,'Um furo alcança a borda externa.');
    for(const [a,b,other] of p.holes.slice(0,i))check(Math.hypot(a-x,b-y)>(d+other)/2,'Há furos sobrepostos ou tangentes.');
    area-=Math.PI*r*r;
  });
  return area;
}

export function plateIfc(IfcCreator, W, api, p) {
  const area=plateArea(p), m=n=>n/1000;
  const creator=new IfcCreator({Name:'Componente confirmado', Organization:'CONFENGE'});
  const floor=creator.addIfcBuildingStorey({Name:'Origem',Elevation:0});
  const plate=creator.addIfcPlate(floor,{Name:p.shape==='disk'?'Flange':'Chapa',Position:[0,0,0],Width:m(p.width),Depth:m(p.depth),Thickness:m(p.thickness)});
  creator.addIfcElementQuantity(plate,{Name:'Qto_PlateBaseQuantities',Quantities:[
    {Kind:'IfcQuantityArea',Name:'NetArea',Value:area*1e-6},{Kind:'IfcQuantityVolume',Name:'NetVolume',Value:area*p.thickness*1e-9}]});
  const mid=api.OpenModel(new TextEncoder().encode(creator.toIfc().content));
  if(mid<0)throw Error('O leitor não conseguiu abrir a peça.');
  try{
    const line=(type,...args)=>api.CreateIfcEntity(mid,W[type],...args);
    const length=n=>api.CreateIfcType(mid,W.IFCLENGTHMEASURE,m(n));
    const pt=(x,y)=>line('IFCCARTESIANPOINT',[length(x),length(y)]);
    const circle=(x,y,d)=>line('IFCCIRCLE',line('IFCAXIS2PLACEMENT2D',pt(x,y),null),api.CreateIfcType(mid,W.IFCPOSITIVELENGTHMEASURE,m(d/2)));
    const a=p.width/2,b=p.depth/2,points=(p.outline||[[-a,-b],[a,-b],[a,b],[-a,b]]).map(v=>pt(...v));
    const outer=p.shape==='disk'?circle(0,0,p.width):line('IFCPOLYLINE',[...points,points[0]]);
    const areaType={type:3,value:'AREA'};
    const profile=p.holes.length?line('IFCARBITRARYPROFILEDEFWITHVOIDS',areaType,null,outer,p.holes.map(h=>circle(...h))):line('IFCARBITRARYCLOSEDPROFILEDEF',areaType,null,outer);
    const solid=api.GetLine(mid,api.GetLineIDsWithType(mid,W.IFCEXTRUDEDAREASOLID).get(0));
    solid.SweptArea=profile;
    solid.Depth=api.CreateIfcType(mid,W.IFCPOSITIVELENGTHMEASURE,m(p.thickness));
    api.WriteLine(mid,solid);
    return api.SaveModel(mid);
  }finally{api.CloseModel(mid);}
}

// A calibrated photograph uses image Y-down. The drawing uses Y-up and a centre datum.
export function photoProfile(points) {
  check(Array.isArray(points)&&points.length>=3&&points.length<=200,'Marque entre 3 e 200 vértices.');
  check(points.every(p=>Array.isArray(p)&&p.length===2&&p.every(v=>Number.isFinite(v)&&Math.abs(v)<=1e7)),'Contorno fora do intervalo de trabalho.');
  check(simplePolygon(points),'O contorno deve ser simples e ter área positiva.');
  const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]);
  const w=Math.max(...xs)-Math.min(...xs),h=Math.max(...ys)-Math.min(...ys), cx=Math.min(...xs)+w/2,cy=Math.min(...ys)+h/2;
  const contour=points.map(([x,y])=>[x-cx,cy-y]);
  check(contour.every((p,i)=>Math.hypot(p[0]-contour[(i+1)%contour.length][0],p[1]-contour[(i+1)%contour.length][1])>.001),'Vértices duplicados ou muito próximos.');
  const signed=contour.reduce((a,p,i)=>{const q=contour[(i+1)%contour.length];return a+p[0]*q[1]-p[1]*q[0];},0);
  return {width:w,depth:h,outline:signed<0?contour.reverse():contour};
}

function fitsPolygon(x,y,r,pts) {
  let inside=false;
  for(let i=0,j=pts.length-1;i<pts.length;j=i++){
    const [ax,ay]=pts[j],[bx,by]=pts[i],dx=bx-ax,dy=by-ay;
    const t=Math.max(0,Math.min(1,((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy)));
    if(Math.hypot(x-ax-t*dx,y-ay-t*dy)<=r)return false;
    if((ay>y)!==(by>y)&&x<ax+(y-ay)*dx/dy)inside=!inside;
  }
  return inside;
}
