const el=id=>document.getElementById(id);
let url=null,worker=null,versao=0,tempo=null;
const status=s=>{el('status').textContent=s;};
function parar(){clearTimeout(tempo);worker?.terminate();worker=null;el('organizar').disabled=false;el('parar').hidden=true;}
function limpar(){++versao;parar();if(url)URL.revokeObjectURL(url);url=null;el('salvar').hidden=el('vista').hidden=true;el('vista').removeAttribute('src');el('salvar').removeAttribute('href');status('');}
for(const id of ['largura','altura','folga','margem','giro','contornos'])el(id).addEventListener('input',limpar);
el('parar').onclick=()=>{limpar();status('Busca cancelada.');};
el('organizar').onclick=()=>{
 limpar();
 try{
  const pecas=el('contornos').value.trim().split(/\r?\n/).map((s,i)=>{
   const col=s.split('|').map(v=>v.trim());
   if(col.length!==3||!col[2])throw new Error('Confira o formato da linha '+(i+1)+'.');
   return {nome:col[0],quantidade:Number(col[1]),pontos:col[2].split(/\s+/).map(v=>v.split(',').map(n=>n.length?Number(n):NaN))};
  });
  worker=new Worker('./chapas-worker.mjs',{type:'module'});el('organizar').disabled=true;el('parar').hidden=false;status('Distribuindo peças…');
  tempo=setTimeout(()=>{parar();status('Tempo de busca esgotado. Reduza o lote.');},20000);
  worker.onerror=()=>{parar();status('Não foi possível iniciar a busca.');};
  worker.onmessage=({data})=>{
   parar();if(data.erro){status(data.erro);return;}
   const r=data.resultado;
   status(r.pecas.length+' peça(s) posicionada(s). Aproveitamento de '+r.aproveitamento.toLocaleString('pt-BR',{maximumFractionDigits:2})+'%.'+
   (r.pendentes.length?'\nSem posição encontrada nesta chapa: '+r.pendentes.join(', ')+'.':'')+(r.buscaLimitada?' A busca atingiu o limite de tentativas.':''));
   if(!r.pecas.length)return;
   url=URL.createObjectURL(new Blob([data.svg],{type:'image/svg+xml'}));el('salvar').href=el('vista').src=url;el('salvar').hidden=el('vista').hidden=false;
  };
  worker.postMessage({pecas,largura:el('largura').valueAsNumber,altura:el('altura').valueAsNumber,folga:el('folga').valueAsNumber,margem:el('margem').valueAsNumber,rotacionar:el('giro').checked});
 }catch(e){parar();status(e.message);}
};
el('dxf').onchange=async()=>{
 limpar();const turno=versao,f=el('dxf').files[0];if(!f)return;
 try{
  if(f.size>4*1024*1024)throw new Error('Use um DXF de até 4 MiB para esta ferramenta.');
  const lib=await import('./vendor-cad/acad.mjs'),doc=lib.DxfReader.readFromStream(new Uint8Array(await f.arrayBuffer()));
  if(doc.header.insUnits!==4)throw new Error('A unidade de inserção do DXF deve ser milímetros.');
  const itens=Array.from(doc.modelSpace.entities);
  if(!itens.length||itens.length>40)throw new Error('Informe de 1 a 40 polilinhas no espaço do modelo.');
  const linhas=itens.map((e,i)=>{
    if(e.objectName!=='LWPOLYLINE'||!e.isClosed||e.vertices.some(v=>v.bulge)||e.vertices.length>120||Math.abs(e.normal.z-1)>1e-9)throw new Error('Use apenas polilinhas leves fechadas, no plano XY, com segmentos retos.');
    return 'Peça '+(i+1)+' | 1 | '+e.vertices.map(v=>v.location.x+','+v.location.y).join(' ');
  });
  if(turno===versao){el('contornos').value=linhas.join('\n');status(linhas.length+' contorno(s) importado(s). Confira o lote e distribua na chapa.');}
 }catch(e){if(turno===versao)status(e.message);}
};
