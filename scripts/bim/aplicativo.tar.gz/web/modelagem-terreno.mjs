// Narrow LandXML 1.x adapter. Preserve authored face references; never re-triangulate.
const scales={meter:1,metre:1,millimeter:.001,centimeter:.01,foot:.3048,ussurveyfoot:1200/3937};
export function readTin(xml) {
  if(typeof xml!=='string'||xml.length>12*1024*1024||/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('Use LandXML até 12 MiB com as entidades padrão do XML.');
  const doc=new DOMParser().parseFromString(xml,'application/xml'),root=doc.documentElement;
  if(root.localName!=='LandXML'||doc.getElementsByTagNameNS('*','parsererror').length)throw Error('Documento LandXML inválido.');
  const children=(el,name)=>Array.from(el?.children||[]).filter(x=>x.localName===name);
  const first=(el,name)=>children(el,name)[0];
  const all=(el,name)=>Array.from(el.getElementsByTagNameNS('*',name));
  const rawUnits=first(root,'Units')?.firstElementChild;
  const linear=rawUnits?.getAttribute('linearUnit')||'', vertical=rawUnits?.getAttribute('elevationUnit')||linear;
  if(!Object.hasOwn(scales,linear.toLowerCase())||!Object.hasOwn(scales,vertical.toLowerCase()))throw Error('Informe no LandXML as unidades horizontal e vertical suportadas.');
  const notices=new Set(), surfaces=[];
  for(const s of children(first(root,'Surfaces'),'Surface')){
    const definition=first(s,'Definition'),points=[],faces=[],faceVisibility=[],byId=new Map();
    if(definition?.getAttribute('surfType')?.toUpperCase()!=='TIN'){notices.add('superfície que não é TIN');continue;}
    const name=s.getAttribute('name')||'Terreno', sourceId='surface:'+surfaces.length+':'+name;
    for(const p of children(first(definition,'Pnts'),'P')){
      const id=p.getAttribute('id'),xyz=p.textContent.trim().split(/\s+/).map(Number);
      if(!id||byId.has(id)||xyz.length!==3||!xyz.every(Number.isFinite))throw Error('Ponto ausente, duplicado ou inválido no TIN.');
      byId.set(id,xyz);points.push({sourceId:sourceId+':'+id,id,northing:xyz[0],easting:xyz[1],elevation:xyz[2]});
    }
    for(const f of children(first(definition,'Faces'),'F')){
      const ids=f.textContent.trim().split(/\s+/);
      if(ids.length!==3 || new Set(ids).size!==3 || ids.some(id=>!byId.has(id)))throw Error('Uma face tem vértice inválido ou ausente.');
      const [a,b,c]=ids.map(id=>byId.get(id));
      if((b[0]-a[0])*(c[1]-a[1])===(b[1]-a[1])*(c[0]-a[0]))throw Error('Face degenerada no TIN.');
      faces.push(ids);faceVisibility.push(!['true','1'].includes(f.getAttribute('i')?.toLowerCase()));
    }
    if(!faces.length||!faceVisibility.some(Boolean))throw Error('Superfície TIN sem faces visíveis.');
    surfaces.push({sourceId,name,kind:'TIN',renderState:'rendered',points,faces,faceVisibility});
  }
  if(!surfaces.length)throw Error('O LandXML não contém superfície TIN com pontos e faces.');
  for(const [tag,title] of Object.entries({Alignments:'alinhamentos',Parcels:'parcelas',CgPoints:'pontos de levantamento avulsos',Breaklines:'linhas de quebra',Boundaries:'limites',Contours:'curvas de nível',PipeNetworks:'redes',PlanFeatures:'elementos de planta',Roadways:'vias'}))if(all(root,tag).length)notices.add(title);
  const cs=first(root,'CoordinateSystem');
  const name=cs?.getAttribute('epsgCode')||cs?.getAttribute('name')||'';
  const crs=name?{Name:/^\d+$/.test(name)?'EPSG:'+name:name,VerticalDatum:cs.getAttribute('verticalDatum')||undefined,GeodeticDatum:cs.getAttribute('horizontalDatum')||undefined}:undefined;
  return {source:{schema:root.namespaceURI||'LandXML',version:root.getAttribute('version')||'1.2',
    units:{linearUnit:linear,elevationUnit:vertical,linearScaleToMeters:scales[linear.toLowerCase()],elevationScaleToMeters:scales[vertical.toLowerCase()],assumed:false},surfaces},
    crs,notices:[...notices]};
}
