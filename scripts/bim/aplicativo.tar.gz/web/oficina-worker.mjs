export function executar(fn) {
  self.onmessage = async ({ data }) => {
    try {
      self.postMessage(await fn(data));
    } catch (e) {
      self.postMessage({ error: e.message || String(e) });
    }
  };
}
