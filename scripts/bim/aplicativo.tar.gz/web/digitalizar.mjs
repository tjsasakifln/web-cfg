import {LIMITE_PIXELS, LIMITE_PALAVRAS, palavrasDoOcr, escalaPorCota, binarizar, contornos, montarDocumento, localizarTexto, verificarRaster, posicaoTexto} from './digitalizar-core.mjs';
const el=id=>document.getElementById(id);
const vista=el('vista'), papel=document.createElement('canvas');
const local=arquivo=>new URL(arquivo,import.meta.url).href;
let pdf=null, leituraPdf=null, imagem=null, arquivo=null, geracao=0, desenho=false, ocupado=false, revisado=false;
let pontos=[], palavras=[], destaque=null, previa=null, recorte=null, vistaCad=false;
const estado=msg=>el('estado').textContent=msg;
function acompanhar(controle){controle.closest('section').append(el('estado'));}
function botoes() {
  let escala=false;
  try {escalaPorCota(pontos,el('medida').valueAsNumber); escala=true;} catch {}
  for(const id of ['baixar-dwg','baixar-dxf']) el(id).disabled=!(escala && revisado && el('conferi').checked && !ocupado);
  el('vista-cad').disabled=el('preview').disabled=el('ler-regiao').disabled=!revisado||ocupado;
  el('original').disabled=!desenho||ocupado;
  for(const id of ['remarcar','usar-pontos','ler','buscar']) el(id).disabled=!desenho||ocupado;
  for(const id of ['origem','giro']) el(id).disabled=ocupado;
  el('pagina').disabled=!pdf || ocupado;
}
function limpar() {
  desenho=false; revisado=false; el('conferi').checked=false; pontos=[]; palavras=[]; destaque=null; previa=null; recorte=null; vistaCad=false;
  el('palavras').replaceChildren();el('medida').value='';
  for(const id of ['ax','ay','bx','by'])el(id).value='';
  el('painel-vista').hidden=vista.hidden=true; ajustarZoom(false);
  el('escala').textContent='Marque uma referência na folha.';
  botoes();
}
function ajustarZoom(real) {
  const quadro=el('quadro-vista');
  quadro.classList.toggle('tamanho-real',real);
  quadro.tabIndex=real?0:-1;
  el('zoom-vista').setAttribute('aria-pressed',String(real));
  if(!real){quadro.scrollLeft=0;quadro.scrollTop=0;}
}
el('zoom-vista').onclick=()=>ajustarZoom(!el('quadro-vista').classList.contains('tamanho-real'));
function mostrar() {
  if(!desenho)return;
  const ctx=vista.getContext('2d');
  el('original').setAttribute('aria-pressed',String(!vistaCad));
  el('vista-cad').setAttribute('aria-pressed',String(vistaCad));
  const selecionar=!vistaCad && (recorte!==null || pontos.length<2);
  vista.classList.toggle('selecionando',selecionar);
  if(vistaCad){
    ctx.fillStyle='#fff';ctx.fillRect(0,0,vista.width,vista.height);
    ctx.strokeStyle='#116853';ctx.lineWidth=Math.max(1,vista.width/1100);ctx.beginPath();
    for(const p of previa){ctx.moveTo(...p[0]);for(let i=1;i<p.length;i++)ctx.lineTo(...p[i]);ctx.closePath();}
    ctx.stroke();ctx.fillStyle='#182e2b';
    const textos=palavras.filter(p=>p.incluir && p.texto.trim());
    ctx.font='100px Arial, sans-serif';
    const alturaMaiuscula=ctx.measureText('H').actualBoundingBoxAscent;
    for(const p of textos){
      const t=posicaoTexto(p);ctx.save();ctx.translate(t.x,t.y);ctx.rotate(t.angulo);
      ctx.font=(t.altura*100/alturaMaiuscula)+'px Arial, sans-serif';
      const texto=p.texto.trim(), largura=ctx.measureText(texto).width;
      if(t.largura && largura)ctx.scale(t.largura/largura,1);
      ctx.fillText(texto,0,0);ctx.restore();
    }
    vista.setAttribute('aria-label','Resultado CAD da folha');
    el('legenda-vista').textContent=previa.length+' contornos em verde · '+textos.length+' textos editáveis';
    return;
  }
  ctx.drawImage(papel,0,0);
  vista.setAttribute('aria-label','Imagem original da folha');
  el('legenda-vista').textContent=recorte?'Marque os dois cantos da região que deseja ler.':pontos.length<2?
    (pontos.length?'Marque a segunda extremidade da cota.':'Marque a primeira extremidade da cota.'):'Folha digitalizada';
  if(destaque){const [x,y,r,b]=destaque;ctx.strokeStyle='#ab3300';ctx.lineWidth=Math.max(2,vista.width/500);ctx.strokeRect(x,y,r-x,b-y);}
  if(!recorte && pontos.length===1){
    ctx.fillStyle='#1d7a62';ctx.beginPath();ctx.arc(...pontos[0],Math.max(3,vista.width/180),0,Math.PI*2);ctx.fill();
  }
}
function atualizarEscala() {
  let msg='Referência com '+pontos.length+' de 2 pontos. Prévia de '+papel.width+' × '+papel.height+' px.';
  if(pontos.length===2) {
    try{const mm=escalaPorCota(pontos,el('medida').valueAsNumber); msg='Escala da vista: '+mm.toLocaleString('pt-BR',{maximumSignificantDigits:7})+' mm por pixel.';}
    catch(e){msg=e.message;}
  }
  el('escala').textContent=msg; mostrar(); botoes();
}
vista.onclick=e=>{
  if(!desenho||ocupado||vistaCad||(!recorte && pontos.length===2))return;
  const r=vista.getBoundingClientRect();
  const ponto=[Math.max(0,Math.min(vista.width,(e.clientX-r.left)*vista.width/r.width)),Math.max(0,Math.min(vista.height,(e.clientY-r.top)*vista.height/r.height))];
  if(recorte){
    recorte.push(ponto);
    if(recorte.length===2)lerRecorte(recorte);
    else{destaque=[ponto[0]-3,ponto[1]-3,ponto[0]+3,ponto[1]+3];mostrar();estado('Marque o canto oposto da região de texto.');}
    return;
  }
  destaque=null;el('conferi').checked=false;
  pontos.push(ponto);
  atualizarEscala();
};
el('remarcar').onclick=()=>{vistaCad=false;recorte=null;pontos=[];destaque=null;el('conferi').checked=false;atualizarEscala();};
el('usar-pontos').onclick=()=>{
  acompanhar(el('usar-pontos'));
  const p=['ax','ay','bx','by'].map(id=>el(id).valueAsNumber);
  if(!p.every((v,i)=>Number.isFinite(v) && v>=0 && v<=(i%2?papel.height:papel.width))){estado('Confira as coordenadas. Os quatro números devem estar dentro da prévia.');return;}
  const par=[[p[0],p[1]],[p[2],p[3]]];if(recorte){lerRecorte(par);return;}pontos=par;el('conferi').checked=false;atualizarEscala();
};
el('medida').oninput=()=>{el('conferi').checked=false;atualizarEscala();}; el('conferi').onchange=botoes;
function ajustar(w,h,maxEscala) {
  const fator=Math.min(maxEscala,Math.sqrt(LIMITE_PIXELS/(w*h)),4096/w,4096/h);
  return [Math.max(1,Math.floor(w*fator)),Math.max(1,Math.floor(h*fator)),fator];
}
async function rasterPdf(numero,giro,alvo) {
  const pagina=await pdf.getPage(numero);
  try {
    const rotation=(pagina.rotate+giro)%360,base=pagina.getViewport({scale:1,rotation});
    const [w,h,fator]=ajustar(base.width,base.height,3);
    alvo.width=w;alvo.height=h;
    await pagina.render({canvasContext:alvo.getContext('2d',{willReadFrequently:true}),viewport:pagina.getViewport({scale:fator,rotation}),background:'#fff'}).promise;
  } finally {pagina.cleanup();}
}
async function renderizar(token) {
  const giro=Number(el('giro').value);
  if(pdf) {
    const numero=el('pagina').valueAsNumber;
    if(!Number.isInteger(numero)||numero<1||numero>pdf.numPages)throw Error('Página fora do intervalo de 1 a '+pdf.numPages+'.');
    await rasterPdf(numero,giro,papel);
  } else if(imagem) {
    const [w,h]=ajustar(imagem.width,imagem.height,1);
    const lado=giro%180!==0;
    papel.width=lado?h:w;papel.height=lado?w:h;
    const ctx=papel.getContext('2d',{willReadFrequently:true});
    ctx.fillStyle='white';ctx.fillRect(0,0,papel.width,papel.height);ctx.save();
    ctx.translate(papel.width/2,papel.height/2);ctx.rotate(giro*Math.PI/180);ctx.drawImage(imagem,-w/2,-h/2,w,h);ctx.restore();
  }
  if(token!==geracao)return;
  vista.width=papel.width;vista.height=papel.height;el('painel-vista').hidden=vista.hidden=false;desenho=true;atualizarEscala();
  estado(pdf?'Página '+el('pagina').value+' de '+pdf.numPages+'. Confira a escala e os textos.':'Imagem aberta. Confira a escala e os textos.');
}
async function carregar(nova) {
  acompanhar(el('origem'));
  const token=++geracao;
  limpar();ocupado=true;botoes();
  try {
    if(nova) {
      el('achados').replaceChildren();
      if(leituraPdf)await leituraPdf.destroy();leituraPdf=null;pdf=null;
      imagem?.close();imagem=null;
      arquivo=el('origem').files[0];el('pagina').value='1';el('giro').value='0';
      if(!arquivo){estado('Selecione um arquivo.');return;}
      if(arquivo.size>20*1024*1024)throw Error('O arquivo excede 20 MiB.');
      if(arquivo.type==='application/pdf'||/\.pdf$/i.test(arquivo.name)) {
        const lib=await import('./vendor-cad/pdf.mjs');lib.GlobalWorkerOptions.workerSrc=local('./vendor-cad/pdf.worker.mjs');
        leituraPdf=lib.getDocument({data:new Uint8Array(await arquivo.arrayBuffer()),isEvalSupported:false,stopAtErrors:true,wasmUrl:local('./vendor-cad/wasm/'),standardFontDataUrl:local('./vendor-cad/standard_fonts/'),cMapUrl:local('./vendor-cad/cmaps/'),cMapPacked:true});
        pdf=await leituraPdf.promise;
        el('pagina').max=String(pdf.numPages);
      } else {
        if(!['image/png','image/jpeg','image/webp'].includes(arquivo.type))throw Error('Escolha um PDF, PNG, JPEG ou WebP.');
        verificarRaster(new Uint8Array(await arquivo.slice(0,1024*1024).arrayBuffer()));
        imagem=await createImageBitmap(arquivo);
      }
    }
    if(!pdf&&!imagem)throw Error('Escolha um arquivo legível.');
    await renderizar(token);
  }catch(e){if(token===geracao)estado('Falha ao abrir. '+e.message);}
  finally{if(token===geracao){ocupado=false;botoes();}}
}
el('origem').onchange=()=>carregar(true);
el('pagina').onchange=()=>carregar(false);
el('giro').onchange=()=>{el('achados').replaceChildren();return carregar(false);};
function revisar() {
  const frag=document.createDocumentFragment(); el('palavras').replaceChildren();
  palavras.forEach((p,i)=>{
    const linha=document.createElement('div');linha.className='ocr-linha';
    const check=document.createElement('input');check.type='checkbox';check.checked=p.incluir;check.setAttribute('aria-label','Incluir palavra '+(i+1));check.onchange=()=>{p.incluir=check.checked;invalidarPrevia();};
    const txt=document.createElement('input');txt.type='text';txt.value=p.texto;txt.maxLength=180;txt.setAttribute('aria-label','Editar palavra '+(i+1));
    txt.oninput=()=>{p.texto=txt.value;invalidarPrevia();};txt.onfocus=()=>{vistaCad=false;destaque=p.caixa;mostrar();};
    const conf=document.createElement('small');const rot=p.base?(-p.base.angulo*180/Math.PI).toLocaleString('pt-BR',{maximumFractionDigits:1})+'°':'horizontal sem base confiável';conf.textContent='Confiança '+Math.round(p.confianca)+'% · '+rot;if(p.confianca<70)conf.className='aviso';
    linha.append(check,txt,conf);frag.append(linha);
  });el('palavras').append(frag);
}
async function criarLeitor(progresso,linhaUnica=false) {
    const {default:T}=await import('./vendor-ocr/tesseract.mjs');
    const worker=await T.createWorker('por',T.OEM.LSTM_ONLY,{workerPath:local('./vendor-ocr/worker.min.js'),corePath:local('./vendor-ocr/tesseract-core-lstm.wasm.js'),langPath:local('./vendor-ocr/'),workerBlobURL:false, logger:m=>{if(m.status==='recognizing text')progresso(Math.round(m.progress*100));}});
    await worker.setParameters({tessedit_pageseg_mode:linhaUnica?T.PSM.SINGLE_LINE:T.PSM.SPARSE_TEXT});
    return worker;
}
el('ler').onclick=async()=>{
  acompanhar(el('ler'));
  ocupado=true;recorte=null;revisado=false;invalidarPrevia();botoes();let worker;
  try{
    estado('Carregando o leitor de português…');
    worker=await criarLeitor(n=>estado('Lendo textos: '+n+'%.'));
    const {data}=await worker.recognize(papel,{}, {blocks:true,text:true});
    palavras=palavrasDoOcr(data.blocks,papel.getContext('2d'));destaque=null;revisar();revisado=true;mostrar();
    estado(palavras.length?palavras.length+' palavra(s). Confira os textos antes de baixar.':'Nenhuma palavra reconhecida. A exportação conterá apenas contornos.');
  }catch(e){estado('Falha no reconhecimento. '+e.message);}
  finally{try{await worker?.terminate();}finally{ocupado=false;botoes();}}
};
el('ler-regiao').onclick=()=>{
  acompanhar(el('original'));
  recorte=recorte?null:[];
  vistaCad=false;destaque=null;mostrar();
  if(recorte){vista.scrollIntoView({block:'center'});estado('Marque dois cantos em volta de uma linha de texto ou informe os quatro valores em “Informar os pontos pelo teclado”.');}
  else estado('Seleção da região encerrada.');
};
async function lerRecorte([[ax,ay],[bx,by]]) {
  recorte=null;
  const x=Math.floor(Math.min(ax,bx)), y=Math.floor(Math.min(ay,by));
  const largura=Math.ceil(Math.max(ax,bx))-x, altura=Math.ceil(Math.max(ay,by))-y;
  if(largura<10||altura<8){estado('Selecione uma região maior ao redor do texto.');return;}
  ocupado=true;invalidarPrevia();
  destaque=[x,y,x+largura,y+altura];mostrar();
  const trecho=document.createElement('canvas');trecho.width=largura;trecho.height=altura;
  trecho.getContext('2d').drawImage(papel,x,y,largura,altura,0,0,largura,altura);
  let worker;
  try{
    estado('Relendo a região selecionada…');
    worker=await criarLeitor(n=>estado('Lendo a região: '+n+'%.'),true);
    const {data}=await worker.recognize(trecho,{}, {blocks:true,text:true});
    const novas=palavrasDoOcr(data.blocks,trecho.getContext('2d'));
    let adicionadas=0;
    for(const p of novas){
      const [x0,y0,x1,y1]=p.caixa;p.caixa=[x+x0,y+y0,x+x1,y+y1];
      if(p.base){p.base.x+=x;p.base.y+=y;}
      const repetida=palavras.some(q=>{const [a,b,c,d]=q.caixa;const px=(a+c)/2,py=(b+d)/2;return px>=p.caixa[0]&&px<=p.caixa[2]&&py>=p.caixa[1]&&py<=p.caixa[3];});
      if(!repetida){if(palavras.length>=LIMITE_PALAVRAS)throw Error('Limite de palavras atingido. Recorte a vista.');palavras.push(p);adicionadas++;}
    }
    revisar();mostrar();estado('Região concluída. '+adicionadas+' palavra(s) acrescentada(s). Confira as leituras.');
  }catch(e){estado('Falha na leitura da região. '+e.message);}
  finally{try{await worker?.terminate();}finally{ocupado=false;botoes();}}
}
function geometria() {
    const mascara=el('mascarar').checked?palavras.filter(p=>p.incluir&&p.texto.trim()).map(p=>p.caixa):[];
    const img=papel.getContext('2d').getImageData(0,0,papel.width,papel.height);
    const pixels=binarizar(img,el('limiar').valueAsNumber,mascara);
    return contornos(pixels,papel.width,papel.height);
}
function invalidarPrevia(){previa=null;vistaCad=false;el('conferi').checked=false;mostrar();botoes();}
el('limiar').oninput=el('mascarar').onchange=invalidarPrevia;
function mostrarResultado(controle){
  acompanhar(controle);
  try{previa??=geometria();recorte=null;destaque=null;vistaCad=true;mostrar();botoes();estado(el('legenda-vista').textContent+'.');}
  catch(e){invalidarPrevia();estado(e.message);}
}
el('vista-cad').onclick=()=>mostrarResultado(el('vista-cad'));
el('preview').onclick=()=>{
  mostrarResultado(el('preview'));
  if(vistaCad){el('vista-cad').focus({preventScroll:true});el('painel-vista').scrollIntoView({block:'start'});}
};
el('original').onclick=()=>{acompanhar(el('original'));vistaCad=false;destaque=null;recorte=null;mostrar();estado('Imagem original da folha.');};
async function exportar(formato) {
  acompanhar(el('baixar-'+formato));
  ocupado=true;botoes();
  try{
    const mm=escalaPorCota(pontos,el('medida').valueAsNumber);
    const polis=previa??geometria();
    const lib=await import('./vendor-cad/acad.mjs');
    const {escreverDocumento}=await import('./cad-codec.mjs');
    const doc=montarDocumento(lib,polis,palavras,papel.height,mm);
    const bytes=escreverDocumento(lib,doc,formato);
    const url=URL.createObjectURL(new Blob([bytes],{type:'application/octet-stream'})), a=document.createElement('a');
    a.href=url;a.download=arquivo.name.replace(/\.[^.]+$/,'')+'-p'+el('pagina').value+'.'+formato;a.click();
    setTimeout(()=>URL.revokeObjectURL(url),30000);
    estado(formato.toUpperCase()+' gerado com '+polis.length+' contornos e '+palavras.filter(p=>p.incluir&&p.texto.trim()).length+' textos.');
  }catch(e){estado('Falha na exportação. '+e.message);}
  finally{ocupado=false;botoes();}
}
el('baixar-dxf').onclick=()=>exportar('dxf');el('baixar-dwg').onclick=()=>exportar('dwg');

let pararBusca=false;
el('parar').onclick=()=>{pararBusca=true;estado('Encerrando ao terminar esta folha…');};
el('buscar').onclick=async()=>{
  acompanhar(el('buscar'));
  const consulta=el('consulta').value.trim();
  if(!consulta){estado('Informe um código ou texto para procurar.');return;}
  ocupado=true;pararBusca=false;botoes();el('achados').replaceChildren();el('parar').hidden=false;
  let worker, paginaAtual=pdf?el('pagina').valueAsNumber:1, total=0, lidas=0;
  const fim=Math.min(pdf?.numPages || 1,paginaAtual+11), inicio=paginaAtual;
  const aux=document.createElement('canvas'), giro=Number(el('giro').value);
  try {
    estado('Preparando a busca em português…');
    worker=await criarLeitor(n=>{if(!pararBusca)estado('Buscando na página '+paginaAtual+' de '+fim+' ('+n+'%).');});
    for(;paginaAtual<=fim && !pararBusca && total<100;paginaAtual++) {
      if(pdf && paginaAtual!==inicio)await rasterPdf(paginaAtual,giro,aux);
      const {data}=await worker.recognize(paginaAtual===inicio?papel:aux,{}, {blocks:true,text:true});
      lidas++;
      const numero=paginaAtual;
      for(const achado of localizarTexto(data.blocks,consulta)) {
        if(++total>100)break;
        const botao=document.createElement('button');botao.type='button';
        botao.textContent='Página '+numero+' · '+achado.texto;
        botao.onclick=async()=>{
          if(ocupado)return;
          if(pdf && Number(el('pagina').value)!==numero){el('pagina').value=numero;await carregar(false);}
          if(!desenho)return;
          vistaCad=false;recorte=null;destaque=achado.caixa;mostrar();vista.scrollIntoView({block:'center'});
          estado('Trecho destacado na página '+numero+'.');
        };
        el('achados').append(botao,' ');
      }
    }
    estado((pararBusca?'Busca interrompida. ':'')+Math.min(total,100)+' ocorrência(s) em '+lidas+' folha(s) examinada(s).'+(total>=100?' Limite de 100 resultados.':''));
  }catch(e){estado('Falha na busca. '+e.message);}
  finally{try{await worker?.terminate();}finally{aux.width=1;aux.height=1;ocupado=false;el('parar').hidden=true;botoes();}}
};
