// Only direct IfcElementQuantity assignments on occurrences are exported.
const campos = {
  IFCQUANTITYLENGTH: ['LengthValue', 'LENGTHUNIT'],
  IFCQUANTITYAREA: ['AreaValue', 'AREAUNIT'],
  IFCQUANTITYVOLUME: ['VolumeValue', 'VOLUMEUNIT'],
  IFCQUANTITYWEIGHT: ['WeightValue', 'MASSUNIT'],
  IFCQUANTITYTIME: ['TimeValue', 'TIMEUNIT'],
  IFCQUANTITYCOUNT: ['CountValue', null],
  IFCQUANTITYNUMBER: ['NumberValue', null],
};
const prefixos = {EXA:'E',PETA:'P',TERA:'T',GIGA:'G',MEGA:'M',KILO:'k',HECTO:'h',DECA:'da',DECI:'d',CENTI:'c',MILLI:'m',MICRO:'µ',NANO:'n',PICO:'p',FEMTO:'f',ATTO:'a'};
const unidadesSI = {
  LENGTHUNIT: ['METRE', 'm'], AREAUNIT: ['SQUARE_METRE', 'm²'], VOLUMEUNIT: ['CUBIC_METRE', 'm³'],
  MASSUNIT: ['GRAM', 'g'], TIMEUNIT: ['SECOND', 's'],
};
const LIMITE_LINHAS = 50000;

function valor(campo) {
  return campo?.value ?? campo;
}
function texto(campo) {
  const v = valor(campo);
  return typeof v === 'string' ? v : '';
}
function ids(api, modelo, tipo, herdar = false) {
  const lista = api.GetLineIDsWithType(modelo, tipo, herdar);
  try {
    return Array.from({length: lista.size()}, (_, i) => lista.get(i));
  } finally {
    lista.delete?.();
  }
}
function referencias(campo) {
  const v = valor(campo);
  return Array.isArray(v) ? v.flatMap(referencias) : Number.isInteger(v) ? [v] : [];
}
export function extrairQuantitativos(api, modelo, IFC) {
  const ler = (id) => api.GetLine(modelo, id);
  const tipo = (item) => api.GetNameFromTypeCode(item.type).toUpperCase();
  const projetos = ids(api, modelo, IFC.IFCPROJECT);
  const unidades = new Map();
  if (projetos.length === 1) {
    const atribuicao = referencias(ler(projetos[0])?.UnitsInContext)[0];
    if (atribuicao) {
      for (const unidadeId of referencias(ler(atribuicao)?.Units)) {
        const u = ler(unidadeId);
        const chave = texto(u?.UnitType);
        // Ambiguous or unreadable assignments must not silently choose a unit.
        unidades.set(chave, unidades.has(chave) ? null : u);
      }
    }
  }

  function unidade(q, tipoIFC, esperado) {
    const explicita = q.Unit != null;
    if (!explicita && tipoIFC === 'IFCQUANTITYCOUNT') return ['un', 'contagem', 'contagem'];
    if (!explicita && tipoIFC === 'IFCQUANTITYNUMBER') return ['', 'número sem unidade explícita'];
    const id = referencias(q.Unit)[0];
    const u = explicita ? (id && ler(id)) : unidades.get(esperado);
    const origem = explicita ? 'explícita' : 'projeto';
    const dimensao = texto(u?.UnitType);
    const nome = texto(u?.Name);
    if (!u || !nome) return ['', explicita ? 'explícita não identificada' : 'não identificada'];
    if (esperado && dimensao !== esperado) return ['', origem + ' incompatível'];
    if (u.type !== IFC.IFCSIUNIT) {
      // Names of conversion-based units are labels, not proof of equivalence across files.
      return [nome, origem];
    }
    if (!Object.hasOwn(unidadesSI, dimensao)) return ['', origem + ' com dimensão SI não reconhecida'];
    const [nomeSI, simbolo] = unidadesSI[dimensao];
    if (nome !== nomeSI) return ['', origem + ' com unidade SI incompatível'];
    const prefixo = texto(u.Prefix);
    if (prefixo && !Object.hasOwn(prefixos, prefixo)) return ['', origem + ' com prefixo SI não reconhecido'];
    return [(prefixos[prefixo] || '') + simbolo, origem, ['SI', dimensao, prefixo, nome].join(':')];
  }

  const elementos = ids(api, modelo, IFC.IFCELEMENT, true);
  if (elementos.length > LIMITE_LINHAS) throw new Error('Extração limitada a 50.000 linhas por planilha.');
  const conjuntosPorElemento = new Map(elementos.map(id => [id, new Set()]));
  const cacheConjuntos = new Map();
  for (const relId of ids(api, modelo, IFC.IFCRELDEFINESBYPROPERTIES)) {
    const rel = ler(relId);
    for (const conjuntoId of referencias(rel.RelatingPropertyDefinition)) {
      if (!cacheConjuntos.has(conjuntoId)) {
        const c = ler(conjuntoId);
        cacheConjuntos.set(conjuntoId, c?.type === IFC.IFCELEMENTQUANTITY ? c : null);
      }
      if (!cacheConjuntos.get(conjuntoId)) continue;
      for (const elemento of referencias(rel.RelatedObjects)) {
        conjuntosPorElemento.get(elemento)?.add(conjuntoId);
      }
    }
  }

  const linhas = [];
  const resumo = {objetos: elementos.length, quantidades: 0, semQuantidade: 0, pendencias: 0, semUnidade: 0};
  function adicionar(linha) {
    if (linhas.length >= LIMITE_LINHAS) throw new Error('Extração limitada a 50.000 linhas por planilha.');
    linhas.push(linha);
  }
  for (const [elementoId, conjuntos] of conjuntosPorElemento) {
    const e = ler(elementoId);
    const base = {globalId:texto(e.GlobalId), expressId:elementoId, entidade:tipo(e), objeto:texto(e.Name),
      conjunto:'', conjuntoId:null, quantidade:'', quantidadeId:null, tipo:'', valor:null, unidade:'', origemUnidade:''};
    if (!conjuntos.size) {
      adicionar({...base, estado:'sem_quantidade'});
      resumo.semQuantidade++;
      continue;
    }
    for (const conjuntoId of conjuntos) {
      const c = cacheConjuntos.get(conjuntoId);
      const fonte = {...base, conjunto:texto(c.Name), conjuntoId};
      const itens = [...new Set(referencias(c.Quantities))];
      if (!itens.length) {
        adicionar({...fonte, estado:'conjunto_vazio'});
        resumo.pendencias++;
      }
      for (const qid of itens) {
        const q = ler(qid);
        const tipoIFC = q ? tipo(q) : '';
        const linha = {...fonte, quantidade:texto(q?.Name), quantidadeId:qid, tipo:tipoIFC};
        if (!Object.hasOwn(campos, tipoIFC)) {
          adicionar({...linha, estado:'tipo_nao_suportado'});
          resumo.pendencias++;
          continue;
        }
        const [campo, esperado] = campos[tipoIFC];
        const numero = valor(q[campo]);
        const [nome, origem, chave = ''] = unidade(q, tipoIFC, esperado);
        linha.unidade = nome;
        linha.origemUnidade = origem;
        linha.chaveUnidade = chave;
        if (typeof numero !== 'number' || !Number.isFinite(numero)) {
          adicionar({...linha, estado:'valor_ausente_ou_invalido'});
          resumo.pendencias++;
          continue;
        }
        adicionar({...linha, valor:numero, estado:'declarado'});
        resumo.quantidades++;
        if (!nome && tipoIFC !== 'IFCQUANTITYNUMBER') resumo.semUnidade++;
      }
    }
  }
  return {linhas, resumo};
}

const colunas = [
  ['GlobalId','globalId',26], ['ID STEP do elemento','expressId',22],
  ['Classe IFC','entidade',24], ['Objeto','objeto',32],
  ['Conjunto de quantidades','conjunto',34], ['ID STEP do conjunto','conjuntoId',22],
  ['Quantidade','quantidade',30], ['ID STEP da quantidade','quantidadeId',24],
  ['Tipo de quantidade','tipo',26], ['Valor declarado','valor',20],
  ['Unidade','unidade',18], ['Origem da unidade','origemUnidade',29], ['Situação','estado',32],
];

export async function gerarExcel(relatorio, ExcelJS) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'CONFENGE BIM';
  const aba = wb.addWorksheet('Quantitativos', {views:[{state:'frozen', ySplit:1}]});
  aba.columns = colunas.map(([header, key, width]) => ({header, key, width}));
  // ExcelJS writes primitive strings as OOXML text, including strings beginning with "=".
  // Never pass model-derived objects to ExcelJS, which also accepts formula objects.
  for (const linha of relatorio.linhas) {
    aba.addRow(colunas.map(([, chave]) => {
      const v = linha[chave];
      if (v == null || typeof v === 'number') return v;
      return String(v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').slice(0,32767);
    }));
  }
  const cab = aba.getRow(1);
  cab.height = 26;
  cab.font = {color:{argb:'FFFFFFFF'}, bold:true};
  cab.fill = {type:'pattern', pattern:'solid', fgColor:{argb:'FF174B40'}};
  cab.alignment = {vertical:'middle'};
  aba.autoFilter = {from:'A1',to:{row:Math.max(1,aba.rowCount),column:colunas.length}};
  return new Uint8Array(await wb.xlsx.writeBuffer());
}
