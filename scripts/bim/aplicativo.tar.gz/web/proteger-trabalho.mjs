export function protegerTrabalho(target = window) {
  const pendentes = new Set();
  const confirmacoes = new Map();
  const revisoes = new Map();
  let proximaRevisao = 0;
  let ativo = false;

  function confirmarSaida(event) {
    if (!pendentes.size) return;
    event.preventDefault();
    event.returnValue = '';
  }

  function sincronizar() {
    if (pendentes.size && !ativo) {
      target.addEventListener('beforeunload', confirmarSaida);
      ativo = true;
    } else if (!pendentes.size && ativo) {
      target.removeEventListener('beforeunload', confirmarSaida);
      ativo = false;
    }
  }

  function concluir(escopo) {
    if (escopo == null) {
      pendentes.clear();
      revisoes.clear();
      for (const aviso of confirmacoes.values()) aviso.remove();
      confirmacoes.clear();
    } else {
      pendentes.delete(escopo);
      revisoes.delete(escopo);
      confirmacoes.get(escopo)?.remove();
      confirmacoes.delete(escopo);
    }
    sincronizar();
  }

  return {
    marcar(escopo = 'trabalho') {
      pendentes.add(escopo);
      revisoes.set(escopo, ++proximaRevisao);
      confirmacoes.get(escopo)?.remove();
      confirmacoes.delete(escopo);
      sincronizar();
    },
    concluir,
    revisao(escopo = 'trabalho') {
      return revisoes.get(escopo) || 0;
    },
    confirmarSalvamento(escopo, controle, revisao = revisoes.get(escopo)) {
      if (!pendentes.has(escopo) || !controle || !target.document) return;
      if (revisao !== revisoes.get(escopo)) return;
      confirmacoes.get(escopo)?.remove();
      const aviso = target.document.createElement('span');
      aviso.setAttribute('role', 'status');
      aviso.append(' Verifique a pasta de downloads. ');
      const botao = target.document.createElement('button');
      botao.type = 'button';
      botao.textContent = 'Confirmar arquivo salvo';
      botao.onclick = () => {
        if (revisao === revisoes.get(escopo)) concluir(escopo);
      };
      aviso.append(botao);
      controle.insertAdjacentElement('afterend', aviso);
      confirmacoes.set(escopo, aviso);
    },
    pendente(escopo) {
      return escopo == null ? pendentes.size > 0 : pendentes.has(escopo);
    },
    encerrar() {
      concluir();
    },
  };
}
