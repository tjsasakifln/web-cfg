import {cadAxes,scaleAxes,sketchAxis,wallsIfc,plateArea,plateIfc,photoProfile} from './modelagem-core.mjs';
import {readTin} from './modelagem-terreno.mjs';
import {protegerTrabalho} from './proteger-trabalho.mjs';
import {exportToolResult} from '/assets/js/tool-credits.mjs';
const $=id=>document.getElementById(id), val=id=>$(id).value, num=id=>$(id).valueAsNumber;
const fmt=n=>n.toLocaleString('pt-BR',{maximumFractionDigits:3});
const data={cad:null,tin:null,points:[],url:'',ready:false,cadRun:0,landRun:0,skRun:0};
const vendor=()=>import('./vendor/modelagem/ifc.mjs');
let lastIfc;
const trabalho=protegerTrabalho();
const current=()=>['croqui','peca','terreno'].includes(location.hash.slice(1))?location.hash.slice(1):'paredes';
function tab(){lastIfc=null;$('ver-modelo').hidden=true;for(const s of document.querySelectorAll('main section'))s.hidden=s.id!==current();$('wall-params').hidden=!['paredes','croqui'].includes(current());for(const a of document.querySelectorAll('.tabs a')){if(a.hash==='#'+current())a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');}$('result').textContent='';if(current()==='croqui')drawSketch();}
addEventListener('hashchange',tab);
function message(s,error=false){$('result').textContent=s;$('result').className=error?'error':'';}
function button(id,fn){$(id).onclick=async()=>{const pane=current(),revisao=trabalho.revisao(pane),processo='processamento:'+pane;trabalho.marcar(processo);$(id).disabled=true;message('Preparando arquivo…');try{const [name,contents]=await fn();if(current()===pane){const atual=trabalho.revisao(pane)===revisao;const format=name.split('.').pop().toLowerCase();const entregue=await exportToolResult({toolId:'bim-modelagem',format,content:contents instanceof Blob?contents:new Blob([contents],{type:'application/octet-stream'}),deliver:()=>download(name,contents)});if(!entregue)return;if(atual)trabalho.marcar(pane);if(atual)trabalho.confirmarSalvamento(pane,$(id),trabalho.revisao(pane));message('Arquivo gerado: '+name+(atual?'':' Há alterações posteriores que ainda não foram exportadas.'));}}catch(e){if(current()===pane)message(e.message,true);}finally{trabalho.concluir(processo);$(id).disabled=false;}};}
$('ver-modelo').onclick=()=>{if(!lastIfc)return;$('dialog-modelo').showModal();$('frame-modelo').src='./visualizador.html#previa-local';};
$('dialog-modelo').onclose=()=>{$('frame-modelo').src='about:blank';};
addEventListener('message',e=>{if(e.origin===location.origin && e.source===$('frame-modelo').contentWindow && e.data==='visor-local-pronto' && lastIfc)e.source.postMessage({arquivoIFC:lastIfc},location.origin);});
function download(name,data){if(name.endsWith('.ifc')){lastIfc=new File([data],name);$('ver-modelo').hidden=false;}const url=URL.createObjectURL(data instanceof Blob?data:new Blob([data],{type:'application/octet-stream'})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function svg(parent,name,attrs){const n=document.createElementNS('http://www.w3.org/2000/svg',name);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,v);parent.append(n);return n;}
function selected(){return (data.cad?.axes||[]).filter(a=>a.layer===val('layer'));}
function showCad(){
 const p=selected(),s=$('cad-view');s.replaceChildren();if(!p.length)return;
 const points=p.flatMap(a=>[a.start,a.end]),xs=points.map(a=>a[0]),ys=points.map(a=>-a[1]);
 const x=Math.min(...xs),y=Math.min(...ys),w=Math.max(...xs)-x,h=Math.max(...ys)-y,pad=Math.max(w,h)*.06;
 s.setAttribute('viewBox',[x-pad,y-pad,w+2*pad,h+2*pad].join(' '));for(const a of p)svg(s,'line',{x1:a.start[0],y1:-a.start[1],x2:a.end[0],y2:-a.end[1],stroke:'#14543a','vector-effect':'non-scaling-stroke','stroke-width':2});
 $('cad-preview').textContent=p.length+' eixo(s) na camada. '+(data.cad.omitted?'Fora da conversão: '+data.cad.omitted+'.':'');
}
$('cad-file').onchange=async e=>{
 const run=++data.cadRun;data.cad=null;$('layer').replaceChildren();$('cad-view').replaceChildren();$('cad-preview').textContent='Lendo desenho…';message('');
 try{
  const f=e.target.files[0];if(!f||f.size>16*1024**2)throw Error('Selecione um arquivo CAD de até 16 MiB.');
  let bytes=new Uint8Array(await f.arrayBuffer());
  if(/\.dwg$/i.test(f.name)){const {dwgParaDxf}=await import('./cad-codec.mjs');bytes=await dwgParaDxf(bytes);}
  const parsed=cadAxes(typeof bytes==='string'?bytes:new TextDecoder().decode(bytes));
  if(run!==data.cadRun)return;data.cad=parsed;for(const layer of new Set(parsed.axes.map(a=>a.layer)))$('layer').add(new Option(layer,layer));
  $('cad-unit').value=parsed.units;showCad();
 }catch(err){if(run===data.cadRun)$('cad-preview').textContent=err.message;}
};
$('layer').onchange=()=>{showCad();trabalho.marcar('paredes');};
function drawSketch(){
 const g=$('lines');g.replaceChildren();const pts=data.points, s=$('sheet').viewBox.baseVal;const radius=Math.max(s.width,s.height)*.005;
 pts.forEach(([x,y],i)=>{const color=i<2?'#bb3a12':'#00554a';if(i%2===1)svg(g,'line',{x1:pts[i-1][0],y1:pts[i-1][1],x2:x,y2:y,stroke:color,'stroke-width':radius*.55});svg(g,'circle',{cx:x,cy:y,r:radius,fill:color});});
 $('sk-status').textContent=!data.ready?'Abra uma imagem para traçar.':pts.length<2?'Marque os dois extremos da cota de referência.':Math.floor((pts.length-2)/2)+' eixo(s) completo(s). '+(pts.length%2?'Marque o final do eixo.':'Marque o início do próximo eixo.');
}
$('sk-file').onchange=async e=>{
 const run=++data.skRun;data.ready=false;data.points=[];if(data.url)URL.revokeObjectURL(data.url);data.url='';$('underlay').removeAttribute('href');drawSketch();message('');
 try{const f=e.target.files[0];if(!f||f.size>12*1024**2||!['image/png','image/jpeg','image/webp'].includes(f.type))throw Error('Use JPEG, PNG ou WebP até 12 MiB.');
 const url=URL.createObjectURL(f);data.url=url;const img=new Image();img.src=url;await img.decode();if(run!==data.skRun)return;
 if(img.width*img.height>40e6)throw Error('Reduza a imagem para até 40 megapixels.');
 const width=900,height=width*img.height/img.width;$('sheet').setAttribute('viewBox','0 0 '+width+' '+height);
 $('underlay').setAttribute('href',url);$('underlay').setAttribute('width',width);$('underlay').setAttribute('height',height);data.ready=true;drawSketch();
 }catch(err){if(run===data.skRun)message(err.message,true);}
};
$('sheet').onclick=e=>{if(!data.ready)return;if(data.points.length>=402){message('Limite de 200 eixos por croqui.',true);return;}
 const p=new DOMPoint(e.clientX,e.clientY).matrixTransform($('sheet').getScreenCTM().inverse()), b=$('sheet').viewBox.baseVal;
 if(p.x<0||p.y<0||p.x>b.width||p.y>b.height)return;data.points.push([p.x,p.y]);trabalho.marcar('croqui');drawSketch();};
$('undo').onclick=()=>{data.points.pop();if(data.points.length)trabalho.marcar('croqui');else trabalho.concluir('croqui');drawSketch();};$('sk-reset').onclick=()=>{data.points=[];trabalho.concluir('croqui');drawSketch();};
button('wall-ifc',async()=>{
 const cad=current()==='paredes', pts=data.points;let axes;
 if(cad)axes=scaleAxes(selected(),val('cad-unit'));
 else{if(!data.ready||pts.length<4||pts.length%2)throw Error('Conclua a referência e cada par de pontos dos eixos.');const walls=[];for(let i=2;i<pts.length;i+=2)walls.push([pts[i],pts[i+1]]);axes=sketchAxis(walls,pts.slice(0,2),num('known'));}
 const {IfcCreator}=await vendor();return [cad?'paredes-cad.ifc':'paredes-croqui.ifc',wallsIfc(IfcCreator,axes,num('height'),num('thick'),val('level'),num('elev'))];
});
function plate(){
 const shape=val('shape'),holes=val('holes').trim().split(/\n+/).filter(x=>x.trim()).map(row=>{const ns=row.trim().split(/\s+/).map(x=>Number(x.replace(',','.')));if(ns.length!==3)throw Error('Cada furo deve conter exatamente três números.');return ns;});
 return {shape,outline:shape==='photo'?data.photo?.outline:undefined,width:num('width'),depth:shape==='disk'?num('width'):num('depth'),thickness:num('gauge'),holes};
}
function preview(){
 $('width').disabled=val('shape')==='photo';$('depth').disabled=val('shape')!=='rect';const el=$('plate-view');el.replaceChildren();
 try{const p=plate(),area=plateArea(p),a=p.width/2,b=p.depth/2,margin=Math.max(a,b)*.12;
 el.setAttribute('viewBox',[-a-margin,-b-margin,2*(a+margin),2*(b+margin)].join(' '));
 if(p.shape==='photo')svg(el,'polygon',{points:p.outline.map(([x,y])=>[x,-y].join(',')).join(' '),fill:'#2e6c54'});else if(p.shape==='disk')svg(el,'circle',{cx:0,cy:0,r:a,fill:'#2e6c54'});else svg(el,'rect',{x:-a,y:-b,width:2*a,height:2*b,fill:'#2e6c54'});
 for(const [x,y,d]of p.holes)svg(el,'circle',{cx:x,cy:-y,r:d/2,fill:'#f2f4ee'});$('plate-info').textContent='Área líquida '+fmt(area)+' mm² · Volume '+fmt(area*p.thickness)+' mm³';
 }catch(e){$('plate-info').textContent=e.message;}
}
for(const id of ['shape','width','depth','gauge','holes'])$(id).addEventListener('input',()=>{trabalho.marcar('peca');preview();});
button('plate-ifc',async()=>{const p=plate();plateArea(p);const [{IfcCreator},W]=await Promise.all([vendor(),import('./vendor/web-ifc/web-ifc-api.js')]);
 const api=new W.IfcAPI();await api.Init(name=>new URL('./vendor/web-ifc/'+name,import.meta.url).href,true);
 try{return [p.shape==='photo'?'peca-foto.ifc':'peca.ifc',plateIfc(IfcCreator,W,api,p)];}finally{api.Dispose();}});
button('plate-step',async()=>{
 const p=plate();plateArea(p);
 const worker=new Worker(new URL('./modelagem-step.mjs',import.meta.url),{type:'module'});
 try{
  const arquivo=await new Promise((resolve,reject)=>{
   worker.onmessage=({data})=>data.error?reject(Error(data.error)):resolve(data);
   worker.onerror=event=>reject(Error(event.message));
   worker.postMessage(p);
  });
  return [p.shape==='photo'?'peca-foto.step':'peca.step',arquivo];
 }finally{worker.terminate();}
});
$('land-file').onchange=async e=>{
 const run=++data.landRun;data.tin=null;$('land-info').textContent='Lendo superfície…';
 try{const f=e.target.files[0];if(!f||f.size>12*1024**2)throw Error('Use LandXML até 12 MiB.');
 const tin=readTin(await f.text());if(run!==data.landRun)return;data.tin=tin;
 const p=tin.source.surfaces[0].points[0];
 $('land-info').textContent=tin.source.surfaces.length+' superfície(s). Primeiro ponto na unidade original. Norte '+p.northing+', leste '+p.easting+', cota '+p.elevation+'. Referencial '+(tin.crs?.Name||'não declarado')+'. '+(tin.notices.length?'Fora da exportação: '+tin.notices.join(', ')+'.':'');
 }catch(err){if(run===data.landRun)$('land-info').textContent=err.message;}
};
button('land-ifc',async()=>{const t=data.tin;if(!t)throw Error('Selecione primeiro um LandXML válido.');const {landXmlToIfc}=await vendor();
 const r=landXmlToIfc(t.source,{crs:t.crs,Organization:'CONFENGE'});if(r.status!=='exported')throw Error(r.reason);
 return ['terreno.ifc',r.content];});
let fromPhoto;
try{fromPhoto=sessionStorage.getItem('cfg-contorno-foto');sessionStorage.removeItem('cfg-contorno-foto');}catch{}
if(fromPhoto&&current()==='peca'){
 try{data.photo=photoProfile(JSON.parse(fromPhoto));$('shape-photo').hidden=false;$('shape').value='photo';$('gauge').value='';$('holes').value='';trabalho.marcar('peca');}
 catch(e){$('shape-photo').hidden=true;message(e.message,true);}
}
function setPhotoDims(){if(val('shape')==='photo'&&data.photo){$('width').value=data.photo.width;$('depth').value=data.photo.depth;}}
$('shape').addEventListener('input',()=>{setPhotoDims();preview();});
for(const id of ['cad-unit','height','thick','level','elev','known'])$(id).addEventListener('input',()=>trabalho.marcar(current()));
setPhotoDims();preview();tab();
