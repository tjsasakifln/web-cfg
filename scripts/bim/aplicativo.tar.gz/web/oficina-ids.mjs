import {validarEnvelope} from './ifc-envelope.mjs';
import {IfcParser} from '@ifc-lite/parser';
import {createDataAccessor} from '@ifc-lite/ids/bridge';
import {DOMParser} from '@xmldom/xmldom';
globalThis.DOMParser=DOMParser;
const {auditIDSDocument,validateIDS}=await import('@ifc-lite/ids');
import {executar} from './oficina-worker.mjs';
executar(async({fonte,regras})=>{
 const xml=await regras.text();if(/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('Declarações externas não são aceitas no IDS.');
 const audit=await auditIDSDocument(xml); if(audit.status==='error')throw Error('IDS inválido: '+audit.issues.filter(i=>i.severity==='error').map(i=>i.message).slice(0,3).join(' / '));
 const ids=audit.parsedDocument;if(!ids?.specifications?.length)throw Error('Especificação IDS vazia.');
 const buffer=await fonte.arrayBuffer();
 validarEnvelope(new Uint8Array(buffer));
 const store=await new IfcParser().parseColumnar(buffer,{disableWorkerScan:true});
 const accessor=createDataAccessor(store);const modelInfo={modelId:fonte.name,schemaVersion:accessor.getSchemaVersion(),entityCount:accessor.getAllEntityIds().length};
 const report=await validateIDS(ids,accessor,modelInfo);report.avisosEspecificacao=audit.issues;const s=report.summary;
 return {nome:'conferencia-ids.json',resumo:s.passedSpecifications+' de '+s.totalSpecifications+' especificações atendidas.',detalhes:'Elementos verificados: '+s.totalEntitiesChecked+' · Ocorrências com falha: '+s.totalEntitiesFailed,blob:new Blob([JSON.stringify(report,null,2)],{type:'application/json'})};
});
