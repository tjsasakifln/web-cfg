export function perfilPontos(pontos,x1,y1,x2,y2,largura) {
  const dx=x2-x1,dy=y2-y1,comprimento=Math.hypot(dx,dy);
  if (![x1,y1,x2,y2,largura,comprimento].every(Number.isFinite)||comprimento===0||largura<=0) throw Error('Informe dois pontos distintos e uma largura positiva, na unidade da nuvem.');
  const saida=[];
  for (const [x,y,z] of pontos) {
    if (![x,y,z].every(Number.isFinite)) throw Error('Coordenada inválida na nuvem.');
    const s=((x-x1)*dx+(y-y1)*dy)/comprimento;
    const d=((y-y1)*dx-(x-x1)*dy)/comprimento;
    if(s>=0&&s<=comprimento&&Math.abs(d)<=largura/2) saida.push([s,z,d,x,y]);
  }
  return saida.sort((a,b)=>a[0]-b[0]);
}
export function lerXYZ(s) {
  const linhas=s.trim().split(/\r?\n/).filter(l=>l.trim()&&!l.trim().startsWith('#'));
  if (linhas.length>500000) throw Error('Até 500 mil pontos por arquivo.');
  const numero=/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/;
  return linhas.map((l,i)=>{
    const txt=l.trim(), partes=txt.includes(';')?txt.split(';'):txt.includes(',')?txt.split(','):txt.split(/\s+/);
    if(partes.length!==3||!partes.every(k=>numero.test(k.trim())))throw Error('XYZ inválido na linha '+(i+1)+'. Use exatamente três coordenadas e ponto decimal.');
    const v=partes.map(Number);
    if (!v.every(Number.isFinite)) throw Error('XYZ inválido na linha '+(i+1)+'. Use três números e ponto decimal.');
    return v;
  });
}
