import './vendor-chapas/clipper.js';
import {organizar,desenhoSvg} from './chapas-core.mjs';
self.onmessage=({data})=>{try{const resultado=organizar(self.ClipperLib,data);self.postMessage({resultado,svg:desenhoSvg(resultado)});}catch(e){self.postMessage({erro:e.message});}};
