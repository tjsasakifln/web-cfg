// PDF.js 5.6 packed drawing operators. Geometry remains in paper millimetres until export.
const PT_MM=25.4/72;
const limite=80000;
const cruz=(a,b)=>a[0]*b[1]-a[1]*b[0];
const sub=(a,b)=>[a[0]-b[0],a[1]-b[1]];
const meio=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2];
export function matriz(a,b){
  return [a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],
    a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],
    a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];
}
const ponto=(m,x,y)=>[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]];
function retangulo(x0,y0,x1,y1){return [[x0,y0],[x1,y0],[x1,y1],[x0,y1]];}
function limitar(a,b,poligono) {
  const sinal=Math.sign(cruz(sub(poligono[1],poligono[0]),sub(poligono[2],poligono[1])));
  if(!sinal)return null;
  let t0=0,t1=1;
  const d=sub(b,a);
  for(let i=0;i<poligono.length;i++){
    const p=poligono[i],v=sub(poligono[(i+1)%poligono.length],p);
    const f=sinal*cruz(v,sub(a,p)),g=sinal*cruz(v,d);
    if(Math.abs(g)<1e-12){if(f < -1e-9)return null;continue;}
    if(g>0)t0=Math.max(t0,-f/g);else t1=Math.min(t1,-f/g);
    if(t1<=t0)return null;
  }
  return [[a[0]+t0*d[0],a[1]+t0*d[1]],[a[0]+t1*d[0],a[1]+t1*d[1]]];
}
function caminhos(packed,m,emitir){
  let atual=null,inicio=null;
  function linha(p){if(!atual)throw new Error('Caminho vetorial inválido.');emitir(atual,p);atual=p;}
  // Bound error using the distance of each control point to the chord segment.
  function distancia(p,a,b){const d=sub(b,a),l=d[0]**2+d[1]**2;const t=l?Math.max(0,Math.min(1,((p[0]-a[0])*d[0]+(p[1]-a[1])*d[1])/l)):0;return Math.hypot(p[0]-a[0]-t*d[0],p[1]-a[1]-t*d[1]);}
  function curva(a,b,c,d,n){
    if(n>=16||Math.max(distancia(b,a,d),distancia(c,a,d))<=0.05){linha(d);return;}
    const ab=meio(a,b),bc=meio(b,c),cd=meio(c,d),u=meio(ab,bc),v=meio(bc,cd),w=meio(u,v);
    curva(a,ab,u,w,n+1);curva(w,v,cd,d,n+1);
  }
  let i=0;
  function ler(){if(i+1>=packed.length)throw new Error('Vetor incompleto no PDF.');const p=ponto(m,packed[i++],packed[i++]);if(!p.every(Number.isFinite))throw new Error('Coordenada inválida no PDF.');return p;}
  while(i<packed.length){
    const op=packed[i++];
    if(op===0)atual=inicio=ler();
    else if(op===1)linha(ler());
    else if(op===2&&atual)curva(atual,ler(),ler(),ler(),0);
    else if(op===3&&atual){
      const a=atual,b=ler(),c=ler();
      curva(a,[(a[0]+2*b[0])/3,(a[1]+2*b[1])/3],[(c[0]+2*b[0])/3,(c[1]+2*b[1])/3],c,0);
    }else if(op===4&&inicio)linha(inicio);
    else throw new Error('Comando de desenho não reconhecido no PDF.');
  }
}
export function extrairPagina(operadores,ops,vista,itens=[]){
  const largura=vista.width*PT_MM,altura=vista.height*PT_MM;
  const base=matriz([PT_MM,0,0,-PT_MM,0,altura],vista.transform);
  let estado={m:base,limites:[retangulo(0,0,largura,altura)]},recorte=false,total=0,imagens=0,temRecorte=false;
  const pilha=[],linhas=[],textos=[],avisos=[];
  for(let i=0;i<operadores.fnArray.length;i++){
    const op=operadores.fnArray[i],args=operadores.argsArray[i];
    if(op===ops.save||op===ops.paintFormXObjectBegin){
      pilha.push(estado);estado={...estado};
      if(op===ops.paintFormXObjectBegin){
        if(args[0])estado.m=matriz(estado.m,args[0]);
        if(args[1]){const pol=retangulo(...args[1]).map(p=>ponto(estado.m,...p));estado.limites=[...estado.limites,pol];temRecorte=true;}
      }
    }else if(op===ops.restore||op===ops.paintFormXObjectEnd){if(!pilha.length)throw new Error('Pilha gráfica inválida.');estado=pilha.pop();}
    else if(op===ops.transform)estado.m=matriz(estado.m,args);
    else if(op===ops.clip||op===ops.eoClip)recorte=true;
    else if(op===ops.beginGroup)throw new Error('Esta página contém um grupo de transparência. Exporte a vista sem transparência ou use uma prancha simplificada.');
    else if([ops.paintImageXObject,ops.paintInlineImageXObject,ops.paintImageMaskXObject,ops.paintImageXObjectRepeat].includes(op))imagens++;
    else if(op===ops.constructPath){
      const packed=args[1]?.[0];
      if(!packed?.length){if(recorte)throw new Error('Máscara de recorte sem contorno.');continue;}
      const segs=[];
      caminhos(packed,estado.m,(a,b)=>{if(++total>limite)throw new Error('A página supera 80 mil segmentos. Exporte uma vista menor.');if(a[0]!==b[0]||a[1]!==b[1])segs.push([a,b]);});
      if(args[0]!==ops.endPath){
        for(let seg of segs){for(const pol of estado.limites){seg=limitar(...seg,pol);if(!seg)break;}if(seg)linhas.push(seg);}
      }
      if(recorte){
        const p=segs.map(s=>s[0]);const eq=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1])<1e-7;
        const z=p.map((pt,k)=>Math.sign(cruz(sub(p[(k+1)%p.length],pt),sub(p[(k+2)%p.length],p[(k+1)%p.length]))));
        if(p.length!==4||!segs.every((s,k)=>eq(s[1],p[(k+1)%4]))||!z[0]||!z.every(t=>t===z[0]))throw new Error('Máscara de recorte irregular. A conversão foi interrompida para preservar a geometria.');
        estado.limites=[...estado.limites,p];temRecorte=true;recorte=false;
      }
    }
  }
  if(pilha.length||recorte)throw new Error('Página com operações gráficas incompletas.');
  const itensTexto=itens.filter(t=>t.str?.trim());
  for(const t of temRecorte?[]:itensTexto){
    if(linhas.length+textos.length>=limite)throw new Error('A página supera o limite de entidades.');
    const m=matriz(base,t.transform),origem=[m[4],m[5]],h=Math.hypot(m[2],m[3]);
    if(!m.every(Number.isFinite)||h<=0||origem[0]<0||origem[1]<0||origem[0]>largura||origem[1]>altura)continue;
    textos.push({origem,altura:h,rotacao:Math.atan2(m[1],m[0]),valor:t.str});
  }
  if(temRecorte&&itensTexto.length)avisos.push('Textos omitidos por haver recorte gráfico na página.');
  if(imagens)avisos.push('Imagens rasterizadas foram omitidas. Use a digitalização para recuperar seus contornos.');
  return {largura,altura,linhas,textos,avisos};
}
