import {lerMalhaPLY} from './ply-triangulos.mjs';
import {malhasParaIFC} from './malha-ifc.mjs';
import {executar} from './oficina-worker.mjs';
executar(async({fonte,classe,unidade})=>{
  const mesh=lerMalhaPLY(await fonte.arrayBuffer(),unidade);
  return {nome:'levantamento.ifc',resumo:mesh.indices.length/3+' triângulos. Escala aplicada em '+unidade+'.',
    detalhes:mesh.colors?'Cores RGB por triângulo calculadas pela média dos três vértices.':'',
    blob:new Blob([malhasParaIFC([{...mesh,name:fonte.name}],classe)])};
});
