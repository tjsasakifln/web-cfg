// IFC4, with SI metres, a spatial hierarchy, and explicit tessellated geometry.
function guid() {
  let n = 0n;
  for (const b of crypto.getRandomValues(new Uint8Array(16))) n = (n << 8n) | BigInt(b);
  const alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$';
  let text = '';
  for (let i = 0; i < 22; i++) {
    text = alphabet[Number(n & 63n)] + text;
    n >>= 6n;
  }
  return "'" + text + "'";
}
function label(value) {
  const s = (value || 'Elemento').slice(0, 100);
  const hex = Array.from({ length: s.length }, (_, i) => s.charCodeAt(i).toString(16).padStart(4, '0'))
    .join('')
    .toUpperCase();
  return "'\\X2\\" + hex + "\\X0\\'";
}
function real(value) {
  if (!Number.isFinite(value)) throw Error('O modelo contém uma coordenada inválida.');
  const s = String(value).toUpperCase();
  const [mantissa, power] = s.split('E');
  return (mantissa.includes('.') ? mantissa : mantissa + '.') + (power === undefined ? '' : 'E' + power);
}
export function malhasParaIFC(meshes, classe = 'IFCBUILDINGELEMENTPROXY', offset = [0, 0, 0]) {
  if (!['IFCBUILDINGELEMENTPROXY', 'IFCPLATE', 'IFCMEMBER'].includes(classe))
    throw Error('Classe IFC inválida.');
  if (!meshes.length || !offset.every(Number.isFinite))
    throw Error('O arquivo precisa conter superfícies com triângulos e uma origem válida.');
  const lines = [],
    add = (type, args) => {
      const id = '#' + (lines.length + 1);
      lines.push(id + '=' + type + '(' + args + ');');
      return id;
    };
  const pt = add('IFCCARTESIANPOINT', '(0.,0.,0.)'),
    axis = add('IFCAXIS2PLACEMENT3D', pt + ',$,$');
  const placement = add('IFCLOCALPLACEMENT', '$,' + axis),
    context = add('IFCGEOMETRICREPRESENTATIONCONTEXT', "$,'Model',3,1.E-6," + axis + ',$');
  const metres = add('IFCSIUNIT', '*,.LENGTHUNIT.,$,.METRE.'),
    units = add('IFCUNITASSIGNMENT', '(' + metres + ')');
  const project = add('IFCPROJECT', guid() + ",$,'CONFENGE BIM',$,$,$,$,(" + context + '),' + units);
  const rel = (p, c) => add('IFCRELAGGREGATES', guid() + ',$,$,$,' + p + ',(' + c + ')');
  const site = add('IFCSITE', guid() + ",$,'Local',$,$," + placement + ',$,$,.ELEMENT.,$,$,$,$,$');
  rel(project, site);
  const building = add('IFCBUILDING', guid() + ",$,'Edificio',$,$," + placement + ',$,$,.ELEMENT.,$,$,$');
  rel(site, building);
  const storey = add('IFCBUILDINGSTOREY', guid() + ",$,'Referencia',$,$," + placement + ',$,$,.ELEMENT.,0.');
  rel(building, storey);
  const elements = [];
  let triangles = 0;
  for (const m of meshes) {
    const { positions, indices } = m;
    if (!positions.length || !indices.length || positions.length % 3 || indices.length % 3)
      throw Error('Malha sem triângulos válidos.');
    triangles += indices.length / 3;
    if (triangles > 500000 || positions.length > 4500000)
      throw Error('O limite é 500 mil triângulos por exportação.');
    const coord = [],
      faces = [];
    for (let i = 0; i < positions.length; i += 3)
      coord.push('(' + [0, 1, 2].map((k) => real(positions[i + k] + offset[k])).join(',') + ')');
    for (let i = 0; i < indices.length; i += 3) {
      const a = [indices[i], indices[i + 1], indices[i + 2]];
      if (!a.every((v) => Number.isInteger(v) && v >= 0 && v < positions.length / 3) || new Set(a).size !== 3)
        throw Error('Índice de face inválido.');
      faces.push('(' + a.map((v) => v + 1).join(',') + ')');
    }
    const points = add('IFCCARTESIANPOINTLIST3D', '(' + coord.join(',') + ')');
    const mesh = add('IFCTRIANGULATEDFACESET', points + ',$,$,(' + faces.join(',') + '),$');
    if (m.colors) {
      if (m.colors.length !== positions.length) throw Error('RGB incompatível com os vértices.');
      const palette = new Map(), paletteRows = [], colorIndices = [];
      for (let i = 0; i < indices.length; i += 3) {
        const rgb = [0, 1, 2].map(k => Math.round((m.colors[3*indices[i]+k] +
          m.colors[3*indices[i+1]+k] + m.colors[3*indices[i+2]+k]) / 3));
        const key = rgb.join(',');
        if (!palette.has(key)) {
          paletteRows.push('(' + rgb.map(v => real(v / 255)).join(',') + ')');
          palette.set(key, paletteRows.length);
        }
        colorIndices.push(palette.get(key));
      }
      const colors = add('IFCCOLOURRGBLIST', '(' + paletteRows.join(',') + ')');
      add('IFCINDEXEDCOLOURMAP', mesh + ',$,' + colors + ',(' + colorIndices.join(',') + ')');
    }
    const shape = add('IFCSHAPEREPRESENTATION', context + ",'Body','Tessellation',(" + mesh + ')');
    const rep = add('IFCPRODUCTDEFINITIONSHAPE', '$,$,(' + shape + ')');
    elements.push(
      add(classe, guid() + ',$,' + label(m.name) + ',$,$,' + placement + ',' + rep + ',$,.NOTDEFINED.'),
    );
  }
  add('IFCRELCONTAINEDINSPATIALSTRUCTURE', guid() + ',$,$,$,(' + elements.join(',') + '),' + storey);
  return (
    "ISO-10303-21;\nHEADER;\nFILE_DESCRIPTION(('Coordination geometry'),'2;1');\nFILE_NAME('modelo.ifc','" +
    new Date().toISOString().slice(0, 19) +
    "',('CONFENGE'),('CONFENGE'),'CONFENGE BIM','CONFENGE BIM','');\nFILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n" +
    lines.join('\n') +
    '\nENDSEC;\nEND-ISO-10303-21;\n'
  );
}
