import { malhasParaIFC } from './malha-ifc.mjs';
import { executar } from './oficina-worker.mjs';
executar(async ({ fonte, classe }) => {
  importScripts('./occt-import-js.js');
  const occt = await self.occtimportjs({ locateFile: (f) => new URL(f, self.location.href).href });
  const bytes = new Uint8Array(await fonte.arrayBuffer());
  const fn = /\.(stp|step)$/i.test(fonte.name)
    ? 'ReadStepFile'
    : /\.ige?s$/i.test(fonte.name)
      ? 'ReadIgesFile'
      : null;
  if (!fn) throw Error('Escolha um STEP ou IGES.');
  const shape = occt[fn](bytes, {
    linearUnit: 'meter',
    linearDeflectionType: 'bounding_box_ratio',
    linearDeflection: 0.001,
    angularDeflection: 0.3,
  });
  if (!shape.success || !shape.meshes?.length) throw Error('O leitor não encontrou faces convertíveis.');
  const meshes = shape.meshes.map((m) => ({
    name: m.name || fonte.name,
    positions: m.attributes.position.array,
    indices: m.index.array,
  }));
  const n = meshes.reduce((s, m) => s + m.indices.length / 3, 0),
    min = [Infinity, Infinity, Infinity],
    max = [-Infinity, -Infinity, -Infinity];
  for (const m of meshes)
    m.positions.forEach((v, i) => {
      min[i % 3] = Math.min(min[i % 3], v);
      max[i % 3] = Math.max(max[i % 3], v);
    });
  return {
    nome: 'fornecedor.ifc',
    resumo: meshes.length + ' malha(s) e ' + n + ' triângulos.',
    detalhes: 'Envelope em metros (X × Y × Z): ' + max.map((v, i) => (v - min[i]).toPrecision(6)).join(' × '),
    blob: new Blob([malhasParaIFC(meshes, classe)]),
  };
});
