// Millimetres are quantized to hundredths before using Clipper's integer polygon primitives.
const U=100, maxPecas=40, maxTentativas=80000;
function inteiro(n){if(!Number.isFinite(n)||Math.abs(n)>100000)throw new Error('Coordenadas e medidas devem ser números até 100.000 mm.');return Math.round(n*U);}
function caixa(p){return {x0:Math.min(...p.map(a=>a.X)),x1:Math.max(...p.map(a=>a.X)),y0:Math.min(...p.map(a=>a.Y)),y1:Math.max(...p.map(a=>a.Y))};}
const deslocar=(p,x,y)=>p.map(a=>({X:a.X+x,Y:a.Y+y}));
function validarPoligono(p){
 const orient=(a,b,c)=>(b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);
 function alcança(a,b,c){return Math.min(a.X,b.X)<=c.X&&c.X<=Math.max(a.X,b.X)&&Math.min(a.Y,b.Y)<=c.Y&&c.Y<=Math.max(a.Y,b.Y);}
 for(let i=0;i<p.length;i++){
  const a=p[i],b=p[(i+1)%p.length];
  if(a.X===b.X&&a.Y===b.Y)throw new Error('Remova vértices repetidos.');
  for(let j=i+2;j<p.length;j++){
   if(i===0&&j===p.length-1)continue;
   const c=p[j],d=p[(j+1)%p.length],o=orient(a,b,c),q=orient(a,b,d),r=orient(c,d,a),s=orient(c,d,b);
   if((Math.sign(o)*Math.sign(q)<0&&Math.sign(r)*Math.sign(s)<0)||(!o&&alcança(a,b,c))||(!q&&alcança(a,b,d))||(!r&&alcança(c,d,a))||(!s&&alcança(c,d,b)))throw new Error('Cada contorno deve ser simples, sem cruzamentos.');
  }
 }
}
function choque(lib,a,b){
 const c=new lib.Clipper(),saida=[];
 c.AddPath(a,lib.PolyType.ptSubject,true);c.AddPaths(b,lib.PolyType.ptClip,true);
 c.Execute(lib.ClipType.ctIntersection,saida,lib.PolyFillType.pftNonZero,lib.PolyFillType.pftNonZero);
 return saida.some(p=>Math.abs(lib.Clipper.Area(p))>0);
}
function proteger(lib,p,folga){
 if(!folga)return [p];const offset=new lib.ClipperOffset();const out=[];
 offset.AddPath(p,lib.JoinType.jtMiter,lib.EndType.etClosedPolygon);offset.Execute(out,folga);return out;
}
export function organizar(lib,{largura,altura,folga,margem,rotacionar=false,pecas}){
 const w=inteiro(largura),h=inteiro(altura),gap=inteiro(folga),borda=inteiro(margem);
 if(w<=0||h<=0||gap<0||borda<0||borda*2>=Math.min(w,h))throw new Error('Confira largura, altura, folga e margem.');
 if(!Array.isArray(pecas)||!pecas.length||pecas.length>maxPecas)throw new Error('Informe de 1 a 40 peças no lote.');
 const fila=[];
 for(const item of pecas){
  if(!item||typeof item.nome!=='string'||!item.nome.trim()||item.nome.length>80||!Number.isInteger(item.quantidade)||item.quantidade<1||fila.length+item.quantidade>maxPecas)throw new Error('Informe nomes de até 80 caracteres e até 40 peças no lote.');
  if(!Array.isArray(item.pontos)||item.pontos.length<3||item.pontos.length>120)throw new Error('Use de 3 a 120 vértices por peça.');
  const p=item.pontos.map(v=>{if(!Array.isArray(v)||v.length!==2)throw new Error('Vértice inválido.');return {X:inteiro(v[0]),Y:inteiro(v[1])};});
  if(p[0].X===p.at(-1).X&&p[0].Y===p.at(-1).Y)p.pop();
  if(p.length<3)throw new Error('O contorno precisa de três vértices distintos.');
  validarPoligono(p);
  const area=Math.abs(lib.Clipper.Area(p));if(!area)throw new Error('Contorno sem área.');
  if(!lib.Clipper.Orientation(p))p.reverse();
  for(let ix=0;ix<item.quantidade;ix++)fila.push({nome:item.nome,area,p});
 }
 fila.sort((a,b)=>b.area-a.area);
 const atendidas=[],pendentes=[];let tentativas=0;
 for(const item of fila){
  const xs=new Set([borda]),ys=new Set([borda]);
  // Candidate corners from previous parts, sorted bottom-to-top then left-to-right.
  for(const k of atendidas)for(const q of k.pol){xs.add(q.X);xs.add(q.X+gap);ys.add(q.Y);ys.add(q.Y+gap);}
  const variantes=(rotacionar?[0,90]:[0]).map(giro=>{
    let p=giro?item.p.map(q=>({X:-q.Y,Y:q.X})):item.p;const b=caixa(p);
    return {p:deslocar(p,-b.x0,-b.y0),w:b.x1-b.x0,h:b.y1-b.y0,giro};
  });let melhor=null;
  encontrar:for(const y of [...ys].sort((a,b)=>a-b))for(const x of [...xs].sort((a,b)=>a-b))for(const v of variantes){
   if(++tentativas>maxTentativas)break encontrar;
   if(x<borda||y<borda||x+v.w>w-borda||y+v.h>h-borda)continue;
   const pol=deslocar(v.p,x,y);
   if(atendidas.some(k=>x<k.box.x1&&x+v.w>k.box.x0&&y<k.box.y1&&y+v.h>k.box.y0&&choque(lib,pol,k.protegido)))continue;
   const protegido=proteger(lib,pol,gap),box=caixa(protegido.flat());
   melhor={nome:item.nome,area:item.area,pol,protegido,box,giro:v.giro};break encontrar;
  }
  if(melhor)atendidas.push(melhor);else pendentes.push(item.nome);
 }
 return {largura,altura,pecas:atendidas.map(k=>({nome:k.nome,giro:k.giro,pontos:k.pol.map(v=>[v.X/U,v.Y/U])})),pendentes,
   aproveitamento:atendidas.reduce((t,k)=>t+k.area,0)*100/(w*h),buscaLimitada:tentativas>maxTentativas};
}
export function desenhoSvg(r){
 const esc=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
 return '<svg xmlns="http://www.w3.org/2000/svg" width="'+r.largura+'mm" height="'+r.altura+'mm" viewBox="0 0 '+r.largura+' '+r.altura+'"><rect width="100%" height="100%" fill="#f7f8ef" stroke="#66816f"/><g transform="translate(0 '+r.altura+') scale(1 -1)">'+r.pecas.map((p,i)=>'<polygon points="'+p.pontos.map(q=>q.join(',')).join(' ')+'" fill="'+['#aed8be','#b4d2e0','#dfcc9c'][i%3]+'" stroke="#214e42" stroke-width="0.5"><title>'+esc(p.nome)+'</title></polygon>').join('')+'</g></svg>';
}
