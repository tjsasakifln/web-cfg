// StreamAllMeshes only guarantees that geometry is readable inside the callback.
// Copy each unique buffer and keep the placement of each occurrence separately.
const LIMIT_MESSAGE = 'A geometria ultrapassou o limite deste visor. Exporte apenas um pavimento ou uma disciplina e abra o recorte.';
const MAX_INSTANCES = 6000;
const MAX_TRIANGLES = 2000000;
const MAX_BYTES = 128 * 1024 * 1024;

export function extrairCena(api, modelID) {
  const buffers = new Map();
  const elements = [];
  let instances = 0;
  let triangles = 0;
  let bytesUsed = 0;
  api.StreamAllMeshes(modelID, flat => {
    const parts = [];
    for (let i = 0; i < flat.geometries.size(); ++i) {
      const placed = flat.geometries.get(i);
      const key = placed.geometryExpressID;
      if (!buffers.has(key)) {
        const geom = api.GetGeometry(modelID, key);
        try {
          // GetVertexData prepares the packed position/normal buffer in web-ifc.
          const vertexPointer = geom.GetVertexData();
          const vertexSize = geom.GetVertexDataSize();
          const indexPointer = geom.GetIndexData();
          const indexSize = geom.GetIndexDataSize();
          if (!vertexSize || !indexSize) continue;
          bytesUsed += 4 * (vertexSize + indexSize);
          if (bytesUsed > MAX_BYTES || indexSize / 3 > MAX_TRIANGLES) throw Error(LIMIT_MESSAGE);
          const vertices = api.GetVertexArray(vertexPointer, vertexSize);
          const indices = api.GetIndexArray(indexPointer, indexSize);
          buffers.set(key, {key, vertices, indices});
        } finally {
          geom.delete();
        }
      }
      triangles += buffers.get(key).indices.length / 3;
      instances++;
      if (instances > MAX_INSTANCES || triangles > MAX_TRIANGLES) throw Error(LIMIT_MESSAGE);
      const {x, y, z, w} = placed.color;
      parts.push({key, matrix: Array.from(placed.flatTransformation), color: [x, y, z, w]});
    }
    if (parts.length) {
      const id = flat.expressID;
      const line = api.GetLine(modelID, id);
      elements.push({id, name: line?.Name?.value || '', guid: line?.GlobalId?.value || '',
        ifcClass: api.GetNameFromTypeCode(api.GetLineType(modelID, id)), parts});
    }
  });
  if (!elements.length) throw Error('Nenhum elemento com geometria 3D pôde ser exibido. Confira se o arquivo inclui sólidos de construção.');
  return {buffers: [...buffers.values()], elements};
}

if (typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope) {
  self.onmessage = async ({data}) => {
    try {
      const {comModelo} = await import('./ifc-runtime.mjs');
      const bytes = new Uint8Array(await data.arrayBuffer());
      const scene = await comModelo(bytes, extrairCena);
      const transfer = scene.buffers.flatMap(({vertices, indices}) => [vertices.buffer, indices.buffer]);
      self.postMessage({scene}, transfer);
    } catch (error) {
      self.postMessage({error: error instanceof Error ? error.message : 'O leitor IFC não conseguiu processar este arquivo.'});
    }
  };
}
