import {solarData} from './modelagem-solar.mjs';
import {LIMITE_PLANILHA, prepararPlanilha} from './planilha-modelo.mjs';
import {protegerTrabalho} from './proteger-trabalho.mjs';
import {exportToolResult} from '/assets/js/tool-credits.mjs';

const el = id => document.getElementById(id);
const trabalho = protegerTrabalho();
const stage = el('palco');
const list = el('elementos');
const emptyOption = list.firstElementChild;
const geometries = new Map();
const materials = new Map();
const objects = new Map();
const limit = 50 * 1024 * 1024;
let THREE, OrbitControls, scene, model, light, camera, selectedMaterial;
let renderer, controls, worker, fetchController, selected, active = 0;
let arquivoAberto, planilhaPronta, solarResult, ground;
el('sol-data').value = new Date().toISOString().slice(0,10)+'T12:00';
async function ensureViewerRuntime() {
  if (THREE) return;
  const [three, controlsModule] = await Promise.all([
    import('./vendor/three/three.module.js'),
    import('./vendor/three/addons/controls/OrbitControls.js'),
  ]);
  THREE = three;
  OrbitControls = controlsModule.OrbitControls;
  scene = new THREE.Scene();
  model = new THREE.Group();
  scene.add(model, new THREE.HemisphereLight(0xffffff, 0x85928a, 2));
  light = new THREE.DirectionalLight(0xfff3df, 1.55);
  light.position.set(3, 6, 4);
  scene.add(light);
  camera = new THREE.PerspectiveCamera(42, 1, 0.01, 1000);
  selectedMaterial = new THREE.MeshLambertMaterial({color: 0xf2a337, side: THREE.DoubleSide});
}
function clearSun(){
  if (!scene || !light) return;
  if(ground){scene.remove(ground);ground.geometry.dispose();ground.material.dispose();ground=null;}
  if(renderer)renderer.shadowMap.enabled=false;
  light.castShadow=false;light.intensity=1.55;light.position.set(3,6,4);
  solarResult=null;el('sol-exportar').hidden=true;el('sol-limpar').hidden=true;el('sol-status').textContent='';
}
el('sol-limpar').onclick=()=>{clearSun();render();};
el('sol-aplicar').onclick=async()=>{
  const token=active;
  try{
    const {getPosition}=await import('./vendor/modelagem/suncalc.mjs');
    if(token!==active||!objects.size)return;
    const latitude=el('sol-lat').valueAsNumber,longitude=el('sol-lon').valueAsNumber,dataHora=el('sol-data').value,fuso=el('sol-fuso').valueAsNumber,norte=el('sol-norte').valueAsNumber;
    const solar=solarData(getPosition,latitude,longitude,dataHora,fuso,norte);
    clearSun();el('sol-limpar').hidden=false;
    solarResult={latitude,longitude,dataHora,fuso,norte,...solar};el('sol-exportar').hidden=false;
    const info='Altura solar '+solar.altitude.toFixed(1)+'°, azimute '+solar.azimuth.toFixed(1)+'°. ';
    if(solar.altitude<=0){light.intensity=0;el('sol-status').textContent=info+'Sol abaixo do horizonte.';render();return;}
    const bounds=new THREE.Box3().setFromObject(model), r=Math.max(bounds.getBoundingSphere(new THREE.Sphere()).radius,.001);
    const span=Math.min(25*r,Math.max(3*r,2*r/Math.sin(solar.altitude*Math.PI/180)));
    ground=new THREE.Mesh(new THREE.PlaneGeometry(2*span,2*span),new THREE.MeshLambertMaterial({color:0xe5e7dd,side:THREE.DoubleSide}));
    ground.rotation.x=-Math.PI/2;ground.position.y=bounds.min.y-r*.001;ground.receiveShadow=true;scene.add(ground);
    model.children.forEach(m=>{m.castShadow=true;m.receiveShadow=true;});
    light.position.fromArray(solar.vector).multiplyScalar(span*2);light.castShadow=true;
    Object.assign(light.shadow.camera,{left:-span,right:span,top:span,bottom:-span,near:r*.001,far:span*4});
    light.shadow.camera.updateProjectionMatrix();light.shadow.normalBias=r*.0005;light.shadow.mapSize.set(1024,1024);
    renderer.shadowMap.enabled=true;renderer.shadowMap.needsUpdate=true;
    el('sol-status').textContent=info+'Sombra projetada no plano da base do modelo.';render();
  }catch(e){clearSun();el('sol-status').textContent=e.message;render();}
};
el('sol-exportar').onclick=async()=>{
  if(!solarResult)return;
  const s=solarResult,esc=value=>'"'+String(value??'').replaceAll('"','""')+'"';
  const rows=[['campo','valor','unidade'],['latitude',s.latitude,'graus'],['longitude',s.longitude,'graus'],['data_hora_local',s.dataHora,'ISO 8601'],['fuso_utc',s.fuso,'horas'],['norte_verdadeiro',s.norte,'graus'],['altura_solar',s.altitude,'graus'],['azimute_solar',s.azimuth,'graus'],['vetor_x',s.vector[0],''],['vetor_y',s.vector[1],''],['vetor_z',s.vector[2],''],['sombra_projetada',s.altitude>0?'sim':'nao','']];
  const content='\ufeff'+rows.map(row=>row.map(esc).join(';')).join('\r\n')+'\r\n';
  await exportToolResult({toolId:'bim-visualizador',format:'csv',content,deliver:()=>{const url=URL.createObjectURL(new Blob([content],{type:'text/csv;charset=utf-8'})),link=document.createElement('a');link.href=url;link.download='estudo-solar.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}});
};

function status(message, error = false) {
  el('status').textContent = message;
  el('status').toggleAttribute('data-error', error);
}

function render() {
  if (renderer && !renderer.getContext().isContextLost()) renderer.render(scene, camera);
}

function sizeView() {
  if (!renderer) return;
  renderer.setSize(stage.clientWidth, stage.clientHeight, false);
  camera.aspect = stage.clientWidth / Math.max(stage.clientHeight, 1);
  camera.updateProjectionMatrix();
  render();
}

function pick(id) {
  const previous = objects.get(selected);
  if (previous) for (const mesh of previous.meshes) mesh.material = mesh.userData.base;
  selected = id;
  const next = objects.get(id);
  if (next) for (const mesh of next.meshes) mesh.material = selectedMaterial;
  list.value = next ? String(id) : '';
  el('nome').textContent = next ? next.name || 'Sem nome declarado' : 'Nenhum selecionado';
  el('classe').textContent = next?.ifcClass || '·';
  el('guid').textContent = next ? next.guid || 'Ausente no arquivo' : '·';
  el('linha').textContent = next ? `#${id}` : '·';
  render();
}

function createView() {
  if (renderer) {
    if (renderer.getContext().isContextLost()) throw Error('A janela 3D perdeu a conexão com a placa gráfica. Recarregue a página.');
    return;
  }
  try {
    renderer = new THREE.WebGLRenderer({alpha: true, antialias: true});
  } catch {
    throw Error('O navegador não conseguiu iniciar o WebGL 2. Ative a aceleração gráfica ou abra o visor em outro dispositivo.');
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  const canvas = renderer.domElement;
  canvas.setAttribute('aria-label', 'Vista 3D do modelo IFC');
  stage.prepend(canvas);
  controls = new OrbitControls(camera, canvas);
  controls.addEventListener('change', render);
  const ray = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  let down;
  canvas.addEventListener('pointerdown', e => { down = e.isPrimary && e.button === 0 ? [e.clientX, e.clientY] : null; });
  canvas.addEventListener('pointercancel', () => { down = null; });
  canvas.addEventListener('pointerup', e => {
    if (!down || !e.isPrimary) return;
    const distance = Math.hypot(e.clientX - down[0], e.clientY - down[1]);
    down = null;
    if (distance > 5 || !objects.size) return;
    const rect = canvas.getBoundingClientRect();
    pointer.set(2 * (e.clientX - rect.left) / rect.width - 1, 1 - 2 * (e.clientY - rect.top) / rect.height);
    ray.setFromCamera(pointer, camera);
    const hit = ray.intersectObjects(model.children, false)[0];
    pick(hit?.object.userData.id);
  });
  canvas.addEventListener('webglcontextlost', e => {
    e.preventDefault();
    clearFile();
    status('A conexão gráfica foi interrompida. Reabra um arquivo menor após a recuperação da placa gráfica.', true);
  });
  new ResizeObserver(sizeView).observe(stage);
  sizeView();
}

function clearFile() {
  active++;
  clearSun();el('sol-aplicar').disabled=true;
  arquivoAberto = null;
  planilhaPronta = null;
  const excel = el('excel-modelo');
  if (!trabalho.pendente('planilha')) {
    if (excel.hasAttribute('href')) URL.revokeObjectURL(excel.href);
    excel.removeAttribute('href');
    excel.hidden = true;
  }
  el('gerar-excel').hidden = true;
  el('gerar-excel').disabled = false;
  el('status-excel').textContent = '';
  fetchController?.abort();
  fetchController = null;
  worker?.terminate();
  worker = null;
  model?.clear();
  model?.position.set(0, 0, 0);
  for (const geom of geometries.values()) geom.dispose();
  for (const mat of materials.values()) mat.dispose();
  objects.clear(); geometries.clear(); materials.clear();
  renderer?.renderLists.dispose();
  list.replaceChildren(emptyOption);
  list.disabled = true;
  el('arquivo').value = '';
  el('fechar').hidden = true;
  el('enquadrar').disabled = true;
  el('vazio').hidden = false;
  stage.removeAttribute('aria-busy');
  pick(undefined);
}

function fit() {
  if (!model.children.length) return;
  const {center, radius} = new THREE.Box3().setFromObject(model).getBoundingSphere(new THREE.Sphere());
  const r = Math.max(radius, 0.001);
  const vertical = THREE.MathUtils.degToRad(camera.fov / 2);
  const halfAngle = Math.min(vertical, Math.atan(Math.tan(vertical) * camera.aspect));
  const distance = 1.08 * r / Math.sin(halfAngle);
  controls.target.copy(center);
  camera.position.set(1, 0.8, 1.3).normalize().multiplyScalar(distance).add(center);
  camera.near = Math.max(r * 0.0001, 0.000001);
  camera.far = distance + 200 * r;
  controls.minDistance = camera.near * 4;
  controls.maxDistance = 100 * r;
  camera.updateProjectionMatrix();
  controls.update();
  render();
}

function display({buffers, elements}) {
  for (const {key, vertices, indices} of buffers) {
    const g = new THREE.BufferGeometry();
    const data = new THREE.InterleavedBuffer(vertices, 6);
    g.setAttribute('position', new THREE.InterleavedBufferAttribute(data, 3, 0));
    g.setAttribute('normal', new THREE.InterleavedBufferAttribute(data, 3, 3));
    g.setIndex(new THREE.BufferAttribute(indices, 1));
    geometries.set(key, g);
  }
  const options = document.createDocumentFragment();
  for (const {parts, ...record} of elements) {
    const meshes = [];
    for (const part of parts) {
      const key = part.color.join(',');
      if (!materials.has(key)) {
        const [r, g, b, a] = part.color;
        materials.set(key, new THREE.MeshLambertMaterial({color: new THREE.Color(r,g,b), opacity: a, transparent: a < 1, side: THREE.DoubleSide}));
      }
      const mat = materials.get(key);
      const mesh = new THREE.Mesh(geometries.get(part.key), mat);
      mesh.matrix.fromArray(part.matrix);
      mesh.matrixAutoUpdate = false;
      mesh.userData = {base: mat, id: record.id};
      model.add(mesh);
      meshes.push(mesh);
    }
    objects.set(record.id, {...record, meshes});
    options.append(new Option(`${record.name || record.ifcClass} · #${record.id}`, String(record.id)));
  }
  model.position.sub(new THREE.Box3().setFromObject(model).getCenter(new THREE.Vector3()));
  list.append(options);
  list.disabled = false;
  el('enquadrar').disabled = false;
  el('vazio').hidden = true;
  el('sol-aplicar').disabled=false;
  fit();
}

async function load(file, example = false) {
  clearFile();
  const token = active;
  function fail(message) {
    if (token !== active) return;
    clearFile();
    status(message, true);
  }
  try {
    if (file && (!/\.ifc$/i.test(file.name) || file.size > limit || file.size === 0)) {
      throw Error('Escolha um arquivo .ifc com conteúdo e até 50 MiB.');
    }
    await ensureViewerRuntime();
    if (token !== active) return;
    createView();
    el('fechar').hidden = false;
    el('fechar').textContent = 'Cancelar leitura';
    stage.setAttribute('aria-busy', 'true');
    const name = example ? 'modelo-piloto.ifc' : file.name;
    status(`Abrindo ${name}…`);
    if (example) {
      fetchController = new AbortController();
      const response = await fetch('../examples/modelo-piloto.ifc', {signal: fetchController.signal});
      if (!response.ok) throw Error('O exemplo não está disponível. Você ainda pode abrir um IFC do seu dispositivo.');
      file = await response.blob();
      if (token !== active) return;
      fetchController = null;
    }
    worker = new Worker(new URL('./visualizador-worker.mjs', import.meta.url), {type: 'module'});
    worker.onerror = () => fail('O leitor não pôde iniciar ou ficou sem memória. Recarregue a página e tente um IFC menor.');
    worker.onmessage = ({data}) => {
      if (token !== active) return;
      worker.terminate();
      worker = null;
      if (data.error) return fail(data.error);
      try {
        display(data.scene);
        if (file.size <= LIMITE_PLANILHA) {
          arquivoAberto = {file, name};
          el('gerar-excel').hidden = false;
        } else {
          el('status-excel').textContent = 'Para extrair o Excel, abra um IFC de até 25 MiB.';
        }
        stage.removeAttribute('aria-busy');
        el('fechar').textContent = 'Fechar modelo';
        const count = objects.size.toLocaleString('pt-BR');
        status(`${name} · ${count} ${objects.size === 1 ? 'elemento exibido' : 'elementos exibidos'}.`);
      } catch {
        fail('A janela 3D não conseguiu apresentar a geometria deste IFC. Tente um modelo menor.');
      }
    };
    worker.postMessage(file);
  } catch (error) {
    fail(error.message || 'Não foi possível abrir o arquivo.');
  }
}

el('gerar-excel').addEventListener('click', async () => {
  const token = active;
  if (!arquivoAberto) return;
  const {file, name} = arquivoAberto;
  const botao = el('gerar-excel');
  trabalho.marcar('processamento:planilha');
  botao.disabled = true;
  el('status-excel').textContent = 'Preparando o Excel do modelo aberto…';
  try {
    const planilha = await prepararPlanilha(file, name);
    if (active !== token) return;
    planilhaPronta = planilha;
    const excel = el('excel-modelo');
    if (excel.hasAttribute('href')) URL.revokeObjectURL(excel.href);
    excel.removeAttribute('href');
    excel.download = planilha.nome;
    excel.hidden = false;
    trabalho.marcar('planilha');
    botao.hidden = true;
    el('status-excel').textContent = 'Planilha pronta.';
  } catch (erro) {
    if (active === token) {
      botao.disabled = false;
      el('status-excel').textContent = 'Não foi possível gerar o Excel. ' + erro.message;
    }
  } finally {
    trabalho.concluir('processamento:planilha');
  }
});
el('excel-modelo').addEventListener('click', async e => { e.preventDefault(); if (!planilhaPronta) return; const {blob,nome}=planilhaPronta; const entregue = await exportToolResult({ toolId:'bim-visualizador', format:'xlsx', content:blob, deliver:()=>{ const link=document.createElement('a'); link.href=URL.createObjectURL(blob); link.download=nome; link.click(); setTimeout(()=>URL.revokeObjectURL(link.href),30000); } }); if (entregue) trabalho.confirmarSalvamento('planilha', e.currentTarget); });

list.addEventListener('change', () => pick(list.value ? Number(list.value) : undefined));
el('arquivo').addEventListener('change', e => { if (e.target.files[0]) load(e.target.files[0]); });
el('exemplo').addEventListener('click', () => load(null, true));
el('fechar').addEventListener('click', () => {
  const reading = stage.getAttribute('aria-busy');
  clearFile();
  status(reading ? 'Leitura cancelada. Escolha outro IFC para continuar.' : 'Modelo fechado. Escolha outro IFC para continuar.');
});
el('enquadrar').addEventListener('click', fit);
window.addEventListener('pagehide', () => { clearFile(); status('Escolha um arquivo para continuar.'); });

el('arquivo').disabled = false;
el('exemplo').disabled = false;

if (window.parent !== window && location.hash === '#previa-local') {
  window.addEventListener('message', e => {
    if (e.origin === location.origin && e.source === window.parent && e.data?.arquivoIFC instanceof File) load(e.data.arquivoIFC);
  });
  window.parent.postMessage('visor-local-pronto', location.origin);
}
