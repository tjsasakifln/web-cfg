export const LIMITE_IFC = 50 * 1024 * 1024;

// A biblioteca pode aceitar arquivos interrompidos como modelos parciais.
function fimUtil(bytes, pos) {
  while (pos > 0) {
    const c = bytes[pos - 1];
    if ([9, 10, 11, 12, 13, 32].includes(c)) {
      pos--;
    } else if (pos > 1 && c === 47 && bytes[pos - 2] === 42) {
      pos -= 2;
      while (pos > 1 && !(bytes[pos - 2] === 47 && bytes[pos - 1] === 42)) pos--;
      if (pos < 2) return 0;
      pos -= 2;
    } else break;
  }
  return pos;
}

export function validarEnvelope(bytes) {
  if (!bytes.length || bytes.length > LIMITE_IFC) throw new Error('Escolha um IFC de até 50 MiB.');
  const decoder = new TextDecoder();
  const inicio = decoder.decode(bytes.subarray(0, 256)).trimStart();
  if (!inicio.startsWith('ISO-10303-21;')) throw new Error('O arquivo não tem o cabeçalho de um IFC STEP (.ifc).');
  let pos = bytes.length;
  for (const token of ['END-ISO-10303-21;', 'ENDSEC;']) {
    pos = fimUtil(bytes, pos);
    if (pos < token.length || decoder.decode(bytes.subarray(pos - token.length, pos)) !== token) {
      throw new Error('O IFC parece incompleto. Exporte novamente o arquivo inteiro.');
    }
    pos -= token.length;
  }
}
