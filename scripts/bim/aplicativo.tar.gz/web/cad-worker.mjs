import {dxfParaDwg,dwgParaDxf,escreverPrancha} from './cad-codec.mjs';
self.onmessage=async({data})=>{
  try{
    const avisos=new Set(),notificar=m=>{if(avisos.size<8)avisos.add(m);};
    const bytes=data.pagina?await escreverPrancha(data.pagina,data.formato,data.fator,notificar):
      data.formato==='dwg'?await dxfParaDwg(data.bytes,notificar):await dwgParaDxf(data.bytes,notificar);
    self.postMessage({bytes,avisos:[...avisos]},[bytes.buffer]);
  }catch(e){self.postMessage({erro:e.message||'Arquivo não reconhecido.'});}
};
