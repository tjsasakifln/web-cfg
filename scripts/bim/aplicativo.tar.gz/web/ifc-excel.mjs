import {prepararPlanilha} from './planilha-modelo.mjs';
import {protegerTrabalho} from './proteger-trabalho.mjs';

const campo = document.getElementById('arquivo');
const trabalho = protegerTrabalho();
const extrair = document.getElementById('extrair');
const exemplo = document.getElementById('exemplo');
const mensagem = document.getElementById('mensagem');
const resultado = document.getElementById('resultado');
const baixar = document.getElementById('baixar');
const estados = {
  declarado:'Declarado', sem_quantidade:'Sem conjunto direto', conjunto_vazio:'Conjunto vazio',
  tipo_nao_suportado:'Tipo fora do escopo', valor_ausente_ou_invalido:'Valor ausente ou inválido',
};
let url;
let ocupado = false;
function ajustar() {
  campo.disabled = ocupado;
  extrair.disabled = ocupado || !campo.files.length;
  exemplo.disabled = ocupado;
}
function limpar() {
  resultado.hidden = true;
  mensagem.textContent = '';
  baixar.removeAttribute('href');
  if (url) URL.revokeObjectURL(url);
  url = null;
}
function exibir({relatorio, blob, nome: nomePlanilha}, nome) {
  if (url) URL.revokeObjectURL(url);
  const {linhas, resumo} = relatorio;
  document.getElementById('resumo').textContent =
    nome + ' · Elementos: ' + resumo.objetos + ' · Valores declarados: ' + resumo.quantidades
    + ' · Elementos sem conjunto direto: ' + resumo.semQuantidade + '.';
  const notas = [];
  if (resumo.pendencias) notas.push('Linhas para revisão: ' + resumo.pendencias + '.');
  if (resumo.semUnidade) notas.push('Valores com unidade não identificada: ' + resumo.semUnidade + '.');
  if (!linhas.length) notas.push('O modelo não contém ocorrências de IfcElement reconhecidas. A planilha contém somente o cabeçalho.');
  document.getElementById('aviso').textContent = notas.join(' ');
  const amostra = linhas.slice(0, 10);
  document.getElementById('legenda').textContent = 'Prévia · ' + amostra.length + ' de ' + linhas.length + ' linhas';
  const tbody = document.getElementById('previa');
  tbody.replaceChildren();
  for (const l of amostra) {
    const tr = tbody.insertRow();
    for (const v of [l.objeto || l.entidade, l.quantidade, l.valor, l.unidade, estados[l.estado]]) {
      tr.insertCell().textContent = v == null || v === '' ? '·' : String(v);
    }
  }
  url = URL.createObjectURL(blob);
  baixar.href = url;
  baixar.download = nomePlanilha;
  resultado.hidden = false;
  trabalho.marcar('planilha');
}
async function processar(amostra) {
  if (ocupado) return;
  trabalho.marcar('processamento:ifc-excel');
  ocupado = true;
  ajustar();
  try {
    mensagem.textContent = 'Lendo o IFC e preparando o Excel…';
    let arquivo = campo.files[0];
    if (amostra) {
      const resp = await fetch('../examples/modelo-piloto.ifc');
      if (!resp.ok) throw new Error('O modelo de exemplo não está disponível.');
      arquivo = await resp.blob();
    }
    if (!arquivo) throw new Error('Selecione um arquivo IFC.');
    const nome = amostra ? 'modelo-piloto.ifc' : arquivo.name;
    exibir(await prepararPlanilha(arquivo, nome), nome);
    mensagem.textContent = 'Concluído. A planilha está disponível para download.';
  } catch (err) {
    mensagem.textContent = 'A extração não foi concluída. ' + (err?.message || 'Confira o arquivo e tente novamente.');
  } finally {
    trabalho.concluir('processamento:ifc-excel');
    ocupado = false;
    ajustar();
  }
}
campo.addEventListener('change', ajustar);
extrair.addEventListener('click', () => processar(false));
exemplo.addEventListener('click', () => processar(true));
baixar.addEventListener('click', e => trabalho.confirmarSalvamento('planilha', e.currentTarget));
window.addEventListener('pagehide', () => {if (url) URL.revokeObjectURL(url);});
window.addEventListener('pageshow', ev => {if(ev.persisted) ajustar();});
ajustar();
