// PLY 1.0: scalar vertex properties and an explicit triangular face-index list.
// A missing or unsupported face never falls back to sequential vertex indices.
const types={char:'Int8',int8:'Int8',uchar:'Uint8',uint8:'Uint8',short:'Int16',int16:'Int16',ushort:'Uint16',uint16:'Uint16',int:'Int32',int32:'Int32',uint:'Uint32',uint32:'Uint32',float:'Float32',float32:'Float32',double:'Float64',float64:'Float64'};
const need=(ok,msg)=>{if(!ok)throw Error(msg);};
const num=/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/;

export function lerMalhaPLY(buffer,unidade='m'){
  const bytes=new Uint8Array(buffer),factor=({m:1,mm:.001,cm:.01})[unidade];
  need(Number.isFinite(factor),'Unidade do PLY inválida.');
  need(bytes.length>0&&bytes.length<=50*1024**2,'Use um PLY de até 50 MiB.');
  const prefix=new TextDecoder('latin1').decode(bytes.subarray(0,65536)),end=/^end_header\r?\n/m.exec(prefix);
  need(end&&/^ply\r?\n/.test(prefix),'Cabeçalho PLY inválido ou interrompido.');
  const start=end.index+end[0].length;
  const header=prefix.slice(0,end.index).trim().split(/\r?\n/),format=/^format (ascii|binary_little_endian|binary_big_endian) 1\.0$/.exec(header[1]);
  need(format,'Formato PLY 1.0 não reconhecido.');
  const elements=[];
  for(const line of header.slice(2)){
    const [key,...a]=line.trim().split(/\s+/);
    if(!key||key==='comment'||key==='obj_info')continue;
    if(key==='element'){
      need(['vertex','face'].includes(a[0])&&a.length===2&&/^\d+$/.test(a[1])&&!elements.some(e=>e.name===a[0]),'Use um PLY de malha somente com vertex e face.');
      elements.push({name:a[0],count:Number(a[1]),props:[]});
    }else{
      const e=elements.at(-1),list=a[0]==='list',name=a.at(-1);
      need(key==='property'&&e&&e.props.length<64&&!e.props.some(p=>p.name===name),'Propriedade PLY inválida.');
      need(list?(a.length===4&&Object.hasOwn(types,a[1])&&Object.hasOwn(types,a[2])):(a.length===2&&Object.hasOwn(types,a[0])),'Tipo de propriedade PLY desconhecido.');
      if(list)need(e.name==='face'&&['vertex_indices','vertex_index'].includes(name)&&!types[a[1]].includes('Float')&&!types[a[2]].includes('Float'),'Lista PLY sem suporte.');
      e.props.push({name,type:list?a[2]:a[0],countType:list?a[1]:null});
    }
  }
  const [verts,faces]=elements;
  need(verts?.name==='vertex'&&faces?.name==='face'&&verts.count>=3&&verts.count<=1500000&&faces.count>=1&&faces.count<=500000,'Use vertex e face, nesta ordem, até 1,5 milhão de vértices e 500 mil faces.');
  const idx=['x','y','z'].map(k=>verts.props.findIndex(p=>p.name===k));
  need(idx.every(i=>i>=0)&&faces.props.filter(p=>p.countType).length===1,'Faltam coordenadas ou a lista de índices das faces.');
  const rgb=['red','green','blue'].map(k=>verts.props.findIndex(p=>p.name===k||p.name==='diffuse_'+k));
  const colored=rgb.every(i=>i>=0);
  need(!rgb.some(i=>i>=0)||colored,'RGB incompleto no PLY.');
  if(colored)need(rgb.every(i=>types[verts.props[i].type]==='Uint8'),'Use canais RGB de 8 bits no PLY.');
  const ascii=format[1]==='ascii', little=format[1]==='binary_little_endian';
  const view=new DataView(buffer),body=ascii?new TextDecoder().decode(bytes.subarray(start)):null;
  const tokens=/\S+/g;let offset=start;
  function read(t){
    const type=types[t],size=Number(type.match(/\d+/)[0])/8;
    if(ascii){
      const token=tokens.exec(body)?.[0];need(token&&num.test(token),'Dado PLY interrompido ou inválido.');
      const v=Number(token);need(Number.isFinite(v),'Valor PLY não finito.');
      if(!type.startsWith('Float')){const unsigned=type.startsWith('Uint'),bits=size*8,max=2**(unsigned?bits:bits-1);need(Number.isInteger(v)&&v>=(unsigned?0:-max)&&v<max,'Número PLY fora do tipo declarado.');}
      return v;
    }
    need(offset+size<=view.byteLength,'Dados PLY interrompidos.');
    const v=view['get'+type](offset,little);offset+=size;need(Number.isFinite(v),'Valor PLY não finito.');return v;
  }
  const positions=new Float64Array(verts.count*3),indices=new Uint32Array(faces.count*3),colors=colored?new Uint8Array(verts.count*3):null;
  for(let i=0;i<verts.count;i++){
    const row=verts.props.map(p=>read(p.type));
    for(let k=0;k<3;k++){positions[3*i+k]=row[idx[k]]*factor;if(colored)colors[3*i+k]=row[rgb[k]];}
  }
  for(let i=0;i<faces.count;i++){
    for(const p of faces.props){
      if(!p.countType){read(p.type);continue;}
      need(read(p.countType)===3,'A face PLY não é triangular. Triangule a malha de origem.');
      const a=read(p.type),b=read(p.type),c=read(p.type);
      need([a,b,c].every(v=>Number.isInteger(v)&&v>=0&&v<verts.count)&&a!==b&&b!==c&&c!==a,'Índices de face PLY inválidos.');
      indices.set([a,b,c],i*3);
    }
  }
  need(ascii?!tokens.exec(body):offset===bytes.length,'Dados PLY excedem as contagens do cabeçalho.');
  return {positions,indices,colors};
}
