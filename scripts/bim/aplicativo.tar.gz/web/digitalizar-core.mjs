// Coordenadas de imagem têm origem no canto superior esquerdo. O CAD usa Y para cima.
export const LIMITE_PIXELS = 6_000_000;
export const LIMITE_PALAVRAS = 1_200;

// Verifica a imagem compactada antes de solicitar sua decodificação ao navegador.
export function verificarRaster(bytes) {
  const b=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),n=bytes.length;
  let w=0,h=0;
  const texto=(pos,t)=>pos+t.length<=n && [...t].every((c,i)=>bytes[pos+i]===c.charCodeAt(0));
  if(n>=24 && b.getUint32(0)===0x89504e47 && texto(12,'IHDR')){w=b.getUint32(16);h=b.getUint32(20);}
  else if(n>=4 && b.getUint16(0)===0xffd8) {
    let pos=2;
    while(pos+4<=n && bytes[pos]===255) {
      while(pos<n && bytes[pos]===255)pos++;
      const marcador=bytes[pos++];if(pos+2>n)break;
      const tam=b.getUint16(pos);
      if([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(marcador) && pos+7<=n) {
        h=b.getUint16(pos+3);w=b.getUint16(pos+5);break;
      }
      if(tam<2 || marcador===0xda || marcador===0xd9)break;
      pos+=tam;
    }
  } else if(n>=30 && texto(0,'RIFF') && texto(8,'WEBP')) {
    if(texto(12,'VP8X')){w=1+bytes[24]+bytes[25]*256+bytes[26]*65536;h=1+bytes[27]+bytes[28]*256+bytes[29]*65536;}
    else if(texto(12,'VP8 ') && bytes[23]===157 && bytes[24]===1 && bytes[25]===42){w=b.getUint16(26,true)&16383;h=b.getUint16(28,true)&16383;}
    else if(texto(12,'VP8L') && bytes[20]===47){const dim=b.getUint32(21,true);w=(dim&16383)+1;h=((dim>>>14)&16383)+1;}
  }
  if(!w||!h)throw new Error('Cabeçalho de imagem inválido ou formato sem suporte.');
  if(w*h>40_000_000)throw new Error('A imagem excede 40 megapixels. Recorte a vista antes de abrir.');
  return [w,h];
}

export function escalaPorCota(pontos, comprimento) {
  if (pontos.length !== 2 || !pontos.flat().every(Number.isFinite) || !Number.isFinite(comprimento) || comprimento <= 0)
    throw new Error('Marque duas extremidades e informe a distância real em milímetros.');
  const distancia = Math.hypot(pontos[1][0] - pontos[0][0], pontos[1][1] - pontos[0][1]);
  if (distancia < 10) throw new Error('Escolha uma referência mais longa na imagem.');
  return comprimento / distancia;
}

// Cada palavra compartilha a linha de base de sua linha OCR. O eixo Y da
// imagem cresce para baixo; a conversão para CAD inverte o sinal do ângulo.
function referenciaTexto(base, caixa) {
  if(!base || ![base.x0,base.y0,base.x1,base.y1].every(Number.isFinite))return null;
  const dx=base.x1-base.x0;
  if(dx<15)return null;
  const pente=(base.y1-base.y0)/dx, angulo=Math.atan(pente);
  if(Math.abs(angulo)>15*Math.PI/180)return null;
  const [x0,y0,x1,y1]=caixa;
  const y=base.y0+(x0-base.x0)*pente, h=y1-y0;
  if(y<y0-h*.25 || y>y1+h*.25)return null;
  // Caixa alinhada à imagem inclui o desnível ao longo de toda a palavra.
  const altura=(h-Math.abs(pente)*(x1-x0))*Math.cos(angulo);
  if(altura<1)return null;
  return {x:x0,y,angulo,altura};
}

// Os símbolos de altura cheia permitem separar a altura de maiúscula de
// acentos, descendentes e traços do desenho que o OCR anexou à palavra.
function alturasDeLetras(palavra, angulo) {
  return (palavra.symbols || [])
    .filter(s=>/^[A-PR-Z0-9bdfhikl]$/.test(s.text) && !s.is_superscript && !s.is_subscript)
    .map(({bbox:b})=>(b.y1-b.y0)*Math.cos(angulo)-(b.x1-b.x0)*Math.abs(Math.sin(angulo)))
    .filter(h=>h>=1);
}

function mediana(valores) {
  if(!valores.length)return null;
  const ordem=valores.slice().sort((a,b)=>a-b), meio=Math.floor(ordem.length/2);
  return ordem.length%2?ordem[meio]:(ordem[meio-1]+ordem[meio])/2;
}

// Uma linha de desenho pode inflar a caixa até a borda do recorte. Para uma
// inscrição de maiúsculas sem diacríticos, procure a tinta dentro da faixa
// de maiúsculas antes de mascarar a imagem e posicionar o TEXT.
function recortarFaixa(ctx,caixa,base,altura) {
  const [x0,y0,x1,y1]=caixa,w=x1-x0,h=y1-y0;
  const {data}=ctx.getImageData(x0,y0,w,h);
  const cos=Math.cos(base.angulo), pente=Math.tan(base.angulo);
  const espessura=altura/cos, minimo=Math.max(1,Math.round(espessura*.12));
  let inicio=w,fim=0;
  for(let x=0;x<w;x++){
    const yBase=base.y+x*pente-y0;
    const topo=Math.max(0,Math.floor(yBase-espessura)),baixo=Math.min(h,Math.ceil(yBase));
    let pretos=0;
    for(let y=topo;y<baixo;y++){
      const i=4*(y*w+x);
      if((299*data[i]+587*data[i+1]+114*data[i+2])<160000)pretos++;
    }
    if(pretos>=minimo){inicio=Math.min(inicio,x);fim=x+1;}
  }
  if(fim<=inicio)return caixa;
  const a=base.y+inicio*pente,b=base.y+fim*pente;
  return [x0+inicio,Math.max(y0,Math.floor(Math.min(a,b)-espessura)),x0+fim,Math.min(y1,Math.ceil(Math.max(a,b)))];
}

export function posicaoTexto(p) {
  const [x,y0,x1,y1]=p.caixa;
  const pos=p.base || {x,y:y1,angulo:0,altura:y1-y0};
  // Uma correção curta conserva a largura original. Um texto substituído por
  // uma anotação maior mantém a altura de letra e cresce naturalmente.
  const ajustar=p.comprimentoOcr && Math.abs(p.texto.trim().length-p.comprimentoOcr)<=1;
  const largura=ajustar?(x1-x-pos.altura*Math.abs(Math.sin(pos.angulo)))/Math.cos(pos.angulo):null;
  return {...pos,largura:largura>0?largura:undefined};
}

export function palavrasDoOcr(blocos = [],ctx=null) {
  const saida = [];
  for (const bloco of blocos || []) for (const p of bloco.paragraphs || [])
    for (const l of p.lines || []) {
      const palavras=l.words || [],b=l.baseline;
      const angulo=b?Math.atan2(b.y1-b.y0,b.x1-b.x0):0;
      const alturas=palavras.map(w=>alturasDeLetras(w,angulo));
      const alturaLinha=mediana(alturas.flat());
      palavras.forEach((w,i)=>{
        const {x0, y0, x1, y1} = w.bbox, texto=w.text.trim();
        if (!texto || !(x1 > x0 && y1 > y0)) return;
        if (saida.length >= LIMITE_PALAVRAS) throw new Error('Muitos textos em uma folha. Recorte a vista e tente novamente.');
        let caixa=[x0,y0,x1,y1];
        const base=referenciaTexto(b,caixa), altura=mediana(alturas[i]) || alturaLinha;
        if(base && altura){
          if(ctx && /^[A-PR-Z0-9]+$/.test(texto) && base.altura>altura*1.65){
            caixa=recortarFaixa(ctx,caixa,base,altura);
            base.y+=(caixa[0]-base.x)*Math.tan(base.angulo);
            base.x=caixa[0];
          }
          base.altura=altura;
        }
        saida.push({texto,comprimentoOcr:texto.length,caixa,confianca:w.confidence,incluir:true,base});
      });
    }
  return saida;
}

function normalizarTexto(s) {
  return s.normalize('NFD').replace(/\p{M}/gu,'').toUpperCase().replace(/\s*([-.,/])\s*/g,'$1').replace(/\s+/g,' ').trim();
}

export function localizarTexto(blocos, consulta) {
  const termo=normalizarTexto(consulta);
  const resultados=[];
  if(!termo)return resultados;
  for(const b of blocos || []) for(const par of b.paragraphs || []) for(const linha of par.lines || []) {
    const palavras=linha.words || [];
    for(let i=0;i<palavras.length;i++) {
      let trecho='',caixa=[Infinity,Infinity,-Infinity,-Infinity];
      for(let j=i; j<palavras.length;j++) {
        const w=palavras[j],p=w.bbox;
        trecho+=(trecho?' ':'')+w.text;
        caixa=[Math.min(caixa[0],p.x0),Math.min(caixa[1],p.y0),Math.max(caixa[2],p.x1),Math.max(caixa[3],p.y1)];
        const n=normalizarTexto(trecho);
        if(n.includes(termo)){resultados.push({texto:trecho,caixa});i=j;break;}
        if(!termo.startsWith(n) && !termo.startsWith(n+' '))break;
      }
    }
  }
  return resultados;
}

export function binarizar({data,width,height}, limite, exclusoes) {
  if (!width || !height || width * height > LIMITE_PIXELS || data.length !== width*height*4)
    throw new Error('A imagem excede o limite de processamento.');
  if (!Number.isFinite(limite) || limite < 1 || limite > 254) throw new Error('Limiar inválido.');
  const pixels = new Uint8Array(width*height);
  for (let i=0; i<pixels.length; i++) {
    const k=4*i;
    const cinza=(299*data[k]+587*data[k+1]+114*data[k+2])/1000;
    pixels[i]=255-(255-cinza)*(data[k+3]/255)<limite ? 1 : 0;
  }
  for (const caixa of exclusoes) {
    const [x0,y0,x1,y1]=caixa;
    for(let y=Math.max(0,Math.floor(y0)-1); y<Math.min(height, Math.ceil(y1)+1); y++)
      pixels.fill(0, y*width+Math.max(0,Math.floor(x0)-1), y*width+Math.min(width,Math.ceil(x1)+1));
  }
  return pixels;
}

// Perímetro exato das células escuras. Virar à direita em uma junta diagonal
// mantém duas ilhas distintas. A direção oposta conserva os vazios de cada forma.
export function contornos(pixels, width, height, limiteArestas=250_000) {
  const passo=width+1, deltas=[1, passo, -1, -passo], bordas=new Map();
  let total=0;
  function adicionar(vertice, direcao) {
    if (++total > limiteArestas) throw new Error('Traçado muito denso. Recorte a vista ou ajuste o limiar.');
    bordas.set(vertice, (bordas.get(vertice) || 0) | (1<<direcao));
  }
  for(let y=0; y<height; y++) for(let x=0; x<width; x++) {
    const i=y*width+x;
    if(!pixels[i]) continue;
    const v=y*passo+x;
    if(y===0 || !pixels[i-width]) adicionar(v,0);
    if(x===width-1 || !pixels[i+1]) adicionar(v+1,1);
    if(y===height-1 || !pixels[i+width]) adicionar(v+passo+1,2);
    if(x===0 || !pixels[i-1]) adicionar(v+passo,3);
  }
  const poligonos=[];
  // O iterador visita cada chave no máximo uma vez. A mesma chave pode iniciar
  // dois laços quando ilhas se tocam por um canto.
  for(const inicio of bordas.keys()) while(bordas.has(inicio)) {
    const pontos=[];
    let v=inicio, anterior=-1, primeira=-1;
    do {
      const bits=bordas.get(v);
      const dir=[(anterior+1)&3, anterior&3, (anterior+3)&3, (anterior+2)&3].find(d=>bits&(1<<d));
      if(dir===undefined) throw new Error('Contorno interrompido.');
      if (dir!==anterior) pontos.push([v%passo,Math.floor(v/passo)]);
      if (primeira<0) primeira=dir;
      const resto=bits&~(1<<dir);
      if(resto) bordas.set(v,resto); else bordas.delete(v);
      v+=deltas[dir]; anterior=dir;
    } while(v!==inicio);
    if(primeira===anterior) pontos.shift();
    if(pontos.length>=3) poligonos.push(pontos);
  }
  return poligonos;
}


export function montarDocumento(lib, poligonos, palavras, altura, mmPorPixel) {
  if (!(Number.isFinite(mmPorPixel) && mmPorPixel>0)) throw new Error('Escala inválida.');
  const textos=palavras.filter(p=>p.incluir && p.texto.trim());
  if(!poligonos.length && !textos.length) throw new Error('Nenhum texto ou contorno para exportar.');
  if(poligonos.length>12_000) throw new Error('Muitos contornos. Recorte a vista ou ajuste o limiar.');
  const doc=new lib.CadDocument();
  doc.header.version=lib.ACadVersion.AC1027;
  doc.header.insUnits=4;
  const borda=new lib.Layer('CONTORNOS'), ocr=new lib.Layer('OCR');
  doc.layers.add(borda); doc.layers.add(ocr);
  for (const pontos of poligonos) {
    const poly=new lib.LwPolyline(pontos.map(([x,y])=>new lib.LwPolylineVertex(new lib.XY(x*mmPorPixel,(altura-y)*mmPorPixel))));
    poly.isClosed=true; poly.layer=borda; doc.modelSpace.entities.add(poly);
  }
  for(const p of textos) {
    const pos=posicaoTexto(p);
    const ent=new lib.TextEntity(p.texto.trim());
    ent.insertPoint=new lib.XYZ(pos.x*mmPorPixel,(altura-pos.y)*mmPorPixel,0);
    ent.rotation=-pos.angulo;
    if(pos.largura){
      ent.horizontalAlignment=lib.TextHorizontalAlignment.Fit;
      ent.alignmentPoint=new lib.XYZ(
        ent.insertPoint.x+pos.largura*mmPorPixel*Math.cos(ent.rotation),
        ent.insertPoint.y+pos.largura*mmPorPixel*Math.sin(ent.rotation),0);
    }
    ent.height=pos.altura*mmPorPixel; ent.layer=ocr; doc.modelSpace.entities.add(ent);
  }
  return doc;
}
