const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
export const length = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
export const polyArea = (pts) =>
  Math.abs(
    pts.reduce((s, p, i) => {
      const q = pts[(i + 1) % pts.length];
      return s + p[0] * q[1] - p[1] * q[0];
    }, 0),
  ) / 2;
function usableFour(pts, W, H) {
  const bends = pts.map((p, i) => cross(p, pts[(i + 1) % 4], pts[(i + 2) % 4]));
  return (
    bends.every((n) => n > W * H * 1e-5) &&
    polyArea(pts) > W * H * 0.0005 &&
    pts.every((p, i) => length(p, pts[(i + 1) % 4]) > Math.max(W, H) * 0.003)
  );
}
function solve(A) {
  for (let i = 0; i < 8; i++) {
    let k = i;
    for (let j = i + 1; j < 8; j++) if (Math.abs(A[j][i]) > Math.abs(A[k][i])) k = j;
    if (Math.abs(A[k][i]) < 1e-12) return null;
    [A[i], A[k]] = [A[k], A[i]];
    const v = A[i][i];
    for (let l = i; l <= 8; l++) A[i][l] /= v;
    for (let j = 0; j < 8; j++) {
      if (j === i) continue;
      const c = A[j][i];
      for (let l = i; l <= 8; l++) A[j][l] -= c * A[i][l];
    }
  }
  return A.map((row) => row[8]);
}
export function makeMap(pts, w, h, W, H) {
  if (!(w > 0 && h > 0 && Number.isFinite(w) && Number.isFinite(h)) || !usableFour(pts, W, H)) return null;
  const target = [
      [0, 0],
      [1, 0],
      [1, 1],
      [0, 1],
    ],
    equations = [];
  pts.forEach(([px, py], i) => {
    const x = px / W,
      y = py / H,
      [u, v] = target[i];
    equations.push([x, y, 1, 0, 0, 0, -u * x, -u * y, u], [0, 0, 0, x, y, 1, -v * x, -v * y, v]);
  });
  const t = solve(equations);
  if (!t) return null;
  const at = ([px, py]) => {
    const x = px / W,
      y = py / H,
      z = t[6] * x + t[7] * y + 1;
    return [z, ((t[0] * x + t[1] * y + t[2]) * w) / z, ((t[3] * x + t[4] * y + t[5]) * h) / z];
  };
  const side = Math.sign(at(pts[0])[0]);
  return (p) => {
    const [z, x, y] = at(p);
    return z * side > 1e-7 && Number.isFinite(x) && Number.isFinite(y) ? [x, y] : null;
  };
}
function crosses(a, b, c, d) {
  const tol = 1e-7;
  const on = (x, y, z) =>
    Math.abs(cross(x, y, z)) < tol &&
    z[0] >= Math.min(x[0], y[0]) - tol &&
    z[0] <= Math.max(x[0], y[0]) + tol &&
    z[1] >= Math.min(x[1], y[1]) - tol &&
    z[1] <= Math.max(x[1], y[1]) + tol;
  return (
    (cross(a, b, c) * cross(a, b, d) < 0 && cross(c, d, a) * cross(c, d, b) < 0) ||
    on(a, b, c) ||
    on(a, b, d) ||
    on(c, d, a) ||
    on(c, d, b)
  );
}
export function simplePolygon(pts) {
  for (let i = 0; i < pts.length; i++)
    for (let j = i + 1; j < pts.length; j++) {
      if (j === i + 1 || (i === 0 && j === pts.length - 1)) continue;
      if (crosses(pts[i], pts[(i + 1) % pts.length], pts[j], pts[(j + 1) % pts.length])) return false;
    }
  return polyArea(pts) > 1e-5;
}
