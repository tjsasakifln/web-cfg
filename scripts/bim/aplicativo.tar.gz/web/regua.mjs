import { verificarRaster } from './digitalizar-core.mjs';
import { length, polyArea, makeMap, simplePolygon } from './regua-geometria.mjs';
import { protegerTrabalho } from './proteger-trabalho.mjs';

('use strict');
const root = document.getElementById('regua'),
  el = (id) => root.querySelector('#rg-' + id);
const svg = el('svg'),
  bg = el('bg'),
  overlay = el('overlay'),
  width = el('w'),
  height = el('h'),
  mode = el('mode'),
  known = el('known'),
  file = el('file');
const trabalho = protegerTrabalho();
const ns = 'http://www.w3.org/2000/svg',
  fmt = (n) => new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 2 }).format(n);
let W = 900,
  H = 510,
  refs = [],
  marks = [],
  map = null,
  demo = false,
  moving = false,
  done = false,
  cursor = null,
  objectUrl = '',
  request = 0,
  notice = '';
const demoRef = [
    [0, 0],
    [200, 0],
    [200, 120],
    [0, 120],
  ],
  panelMap = ([x, y]) => {
    const z = 1 + 0.00105 * x + 0.00045 * y;
    return [(140 + 3.68 * x + 0.54 * y) / z, (110 + 0.06 * x + 3.22 * y) / z];
  };
const probe = [
    [45, 72],
    [145, 72],
  ].map(panelMap),
  corners = demoRef.map(panelMap);
function tag(parent, name, attrs, content) {
  const n = document.createElementNS(ns, name);
  Object.entries(attrs).forEach(([k, v]) => n.setAttribute(k, v));
  if (content != null) n.textContent = content;
  parent.appendChild(n);
  return n;
}
const xy = (points) => points.map((p) => p.join(',')).join(' ');
function label(parent, p, text, size, fill) {
  tag(
    parent,
    'text',
    {
      x: p[0],
      y: p[1],
      fill,
      'font-size': size,
      'font-weight': 700,
      'font-family': 'system-ui,sans-serif',
      'paint-order': 'stroke',
      'stroke-width': 3,
      stroke: '#f7fbf7',
      'stroke-linejoin': 'round',
    },
    text,
  );
}
function drawExample() {
  bg.replaceChildren();
  tag(bg, 'rect', { width: W, height: H, fill: '#dfe9e1' });
  tag(bg, 'polygon', { points: xy(corners), fill: '#f2f7eb', stroke: '#809b8e', 'stroke-width': 3 });
  for (let i = 20; i < 200; i += 20)
    tag(bg, 'polyline', {
      points: xy(
        [
          [i, 0],
          [i, 120],
        ].map(panelMap),
      ),
      stroke: '#d7e5d8',
      fill: 'none',
    });
  for (let i = 20; i < 120; i += 20)
    tag(bg, 'polyline', {
      points: xy(
        [
          [0, i],
          [200, i],
        ].map(panelMap),
      ),
      stroke: '#d7e5d8',
      fill: 'none',
    });
  tag(bg, 'polyline', {
    points: xy(probe),
    stroke: '#963f22',
    'stroke-width': 4,
    'stroke-dasharray': '8 7',
    fill: 'none',
  });
  probe.forEach((p, i) => {
    tag(bg, 'circle', { cx: p[0], cy: p[1], r: 9, fill: '#fff', stroke: '#963f22', 'stroke-width': 3 });
    tag(bg, 'circle', { cx: p[0], cy: p[1], r: 2.5, fill: '#963f22' });
    label(bg, [p[0] - 5, p[1] + 31], i ? 'B' : 'A', 19, '#773319');
  });
  label(bg, panelMap([64, 46]), 'Controle de 100 mm', 18, '#753a22');
  label(bg, [22, 42], 'Painel de exemplo', 20, '#214b42');
}
function fit(w, h) {
  W = w;
  H = h;
  svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
  svg.setAttribute('width', w);
  svg.setAttribute('height', h);
  cursor = null;
}
function resetState() {
  refs = [];
  marks = [];
  map = null;
  moving = false;
  done = false;
  notice = '';
  cursor = null;
}
function freeImage() {
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl = '';
}
function example() {
  trabalho.concluir();
  request++;
  freeImage();
  file.value = '';
  resetState();
  demo = true;
  fit(900, 510);
  width.value = 200;
  height.value = 120;
  known.value = 100;
  mode.value = 'check';
  refs = corners.map((p) => [...p]);
  map = makeMap(refs, 200, 120, W, H);
  drawExample();
  render();
}
async function loadFile(f) {
  if (!f) return;
  const seq = ++request;
  freeImage();
  resetState();
  demo = false;
  fit(900, 510);
  width.value = '';
  height.value = '';
  known.value = '';
  mode.value = 'dist';
  bg.replaceChildren();
  notice = 'Abrindo a imagem…';
  render();
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) {
    notice = 'Escolha um arquivo JPEG, PNG ou WebP.';
    render();
    return;
  }
  if (f.size > 25 * 1024 * 1024) {
    notice = 'Escolha uma imagem de até 25 MiB.';
    render();
    return;
  }
  try {
    verificarRaster(new Uint8Array(await f.arrayBuffer()));
  } catch (e) {
    if (seq === request) {
      notice = e.message;
      render();
    }
    return;
  }
  if (seq !== request) return;
  const uri = URL.createObjectURL(f);
  objectUrl = uri;
  const img = new Image();
  img.onload = () => {
    if (seq !== request) return;
    const scale = 900 / Math.max(img.naturalWidth, img.naturalHeight);
    fit(img.naturalWidth * scale, img.naturalHeight * scale);
    tag(bg, 'image', { href: uri, x: 0, y: 0, width: W, height: H });
    notice = 'Informe a largura e a altura da referência e selecione Marcar referência.';
    render();
  };
  img.onerror = () => {
    if (seq !== request) return;
    freeImage();
    notice = 'A imagem não abriu. Escolha outro JPEG, PNG ou WebP.';
    render();
  };
  img.src = uri;
}
function resetMeasurement() {
  marks = [];
  done = false;
  notice = '';
  render();
}
function startCalibration() {
  if (!bg.children.length) {
    notice = 'Abra uma foto ou carregue o exemplo.';
    render();
    return false;
  }
  if (!(width.valueAsNumber > 0 && height.valueAsNumber > 0)) {
    notice = 'Informe largura e altura maiores que zero, em milímetros.';
    render();
    (width.valueAsNumber > 0 ? height : width).focus();
    return false;
  }
  resetState();
  moving = true;
  render();
  return true;
}
function add(p) {
  if (moving) {
    if (refs.some((q) => length(p, q) < Math.max(W, H) * 0.003)) {
      notice = 'Dois cantos estão muito próximos. Marque outro ponto.';
      render();
      return;
    }
    refs.push(p);
    trabalho.marcar('medicao');
    notice = '';
    if (refs.length === 4) {
      map = makeMap(refs, width.valueAsNumber, height.valueAsNumber, W, H);
      if (!map) {
        refs = [];
        notice = 'Referência inválida. Recomece com um retângulo amplo e marque os cantos na ordem indicada.';
      } else moving = false;
    }
    render();
    return;
  }
  if (!map) return;
  if (done) {
    marks = [];
    done = false;
  }
  if (!map(p)) {
    notice = 'Ponto fora da região calibrável. Aproxime a referência da área de medição.';
    render();
    return;
  }
  if (marks.some((q) => length(p, q) < Math.max(W, H) * 0.0005)) {
    notice = 'Marque um ponto diferente.';
    render();
    return;
  }
  marks.push(p);
  trabalho.marcar('medicao');
  notice = '';
  done = mode.value !== 'area' && marks.length === (mode.value === 'angle' ? 3 : 2);
  render();
}
function putOverlay() {
  overlay.replaceChildren();
  const s = Math.max(W, H) / 900;
  function strokePath(pts, closed, color) {
    if (pts.length < 2) return;
    tag(overlay, closed ? 'polygon' : 'polyline', {
      points: xy(pts),
      fill: 'none',
      stroke: '#fff',
      'stroke-width': 5 * s,
      'stroke-opacity': 0.8,
    });
    tag(overlay, closed ? 'polygon' : 'polyline', {
      points: xy(pts),
      fill: 'none',
      stroke: color,
      'stroke-width': 2.6 * s,
    });
  }
  strokePath(refs, !!map, '#236251');
  strokePath(marks, done && mode.value === 'area', '#8d3218');
  function points(pts, ref) {
    pts.forEach((p, i) => {
      tag(overlay, 'circle', {
        cx: p[0],
        cy: p[1],
        r: 5 * s,
        fill: ref ? '#276752' : '#a63e23',
        stroke: 'white',
        'stroke-width': 2 * s,
      });
      if (ref)
        label(
          overlay,
          [Math.min(W - 15 * s, Math.max(3 * s, p[0] + 7 * s)), Math.max(18 * s, p[1] - 8 * s)],
          String(i + 1),
          16 * s,
          '#17443b',
        );
    });
  }
  points(refs, true);
  points(marks, false);
  if (cursor) {
    tag(overlay, 'circle', {
      cx: cursor[0],
      cy: cursor[1],
      r: 8 * s,
      fill: 'none',
      stroke: '#000',
      'stroke-width': 2 * s,
    });
    tag(overlay, 'circle', {
      cx: cursor[0],
      cy: cursor[1],
      r: 10 * s,
      fill: 'none',
      stroke: '#fff',
      'stroke-width': 2 * s,
    });
  }
}
function render() {
  const op = mode.value,
    needs = op === 'angle' ? 3 : 2;
  el('close').hidden = op !== 'area';
  el('close').disabled = moving || done || marks.length < 3;
  el('undo').disabled = !(moving ? refs : marks).length;
  el('clear').disabled = !marks.length;
  mode.disabled = !map;
  el('known-label').hidden = op !== 'check';
  const directions = ['alto à esquerda', 'alto à direita', 'baixo à direita', 'baixo à esquerda'];
  const hints = {
    dist: 'Marque as duas extremidades do segmento.',
    angle: 'Marque três pontos. O segundo é o vértice do ângulo.',
    area: 'Marque o contorno em ordem e selecione Fechar polígono.',
    check: demo
      ? 'No exemplo calibrado, marque os centros A e B para conferir os 100 mm.'
      : 'Informe uma distância conhecida e marque suas duas extremidades.',
  };
  el('hint').textContent =
    notice ||
    (moving
      ? `Canto ${refs.length + 1} de 4, ${directions[refs.length]}.`
      : map
        ? hints[op]
        : 'Informe as dimensões da referência para calibrar.');
  let result = !map
    ? 'Aguardando calibração.'
    : marks.length
      ? op === 'area'
        ? `${marks.length} ponto(s) no contorno.`
        : `${marks.length} de ${needs} pontos marcados.`
      : 'Aguardando os pontos da medição.';
  if (done && map) {
    const a = marks.map(map);
    if (op === 'area') result = `Área: ${fmt(polyArea(a))} mm²`;
    else if (op === 'angle') {
      const [b, v, c] = a;
      const cos =
        ((b[0] - v[0]) * (c[0] - v[0]) + (b[1] - v[1]) * (c[1] - v[1])) / (length(b, v) * length(c, v));
      result = `Ângulo: ${fmt((Math.acos(Math.min(1, Math.max(-1, cos))) * 180) / Math.PI)}°`;
    } else {
      const n = length(...a);
      result = `Distância: ${fmt(n)} mm`;
      if (op === 'check') {
        const k = known.valueAsNumber;
        result +=
          k > 0
            ? ` · Controle: ${fmt(k)} mm · Desvio absoluto: ${fmt(Math.abs(n - k))} mm (${fmt((Math.abs(n - k) / k) * 100)}%)`
            : ' · Informe o controle em mm para conferir o desvio.';
      }
    }
  }
  el('peca').hidden = !(done && map && op === 'area');
  el('out').textContent = result;
  putOverlay();
}
svg.addEventListener('click', (e) => {
  const pt = svg.createSVGPoint();
  pt.x = e.clientX;
  pt.y = e.clientY;
  const frame = svg.getScreenCTM();
  if (!frame) return;
  const p = pt.matrixTransform(frame.inverse());
  if (p.x >= 0 && p.x <= W && p.y >= 0 && p.y <= H) {
    cursor = null;
    add([p.x, p.y]);
  }
});
svg.addEventListener('keydown', (e) => {
  const key = e.key;
  if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Enter', ' '].includes(key)) return;
  e.preventDefault();
  cursor = cursor || [W / 2, H / 2];
  const step = Math.max(W, H) * (e.shiftKey ? 0.02 : 0.002);
  if (key === 'Enter' || key === ' ') add([...cursor]);
  else {
    if (key === 'ArrowLeft') cursor[0] -= step;
    if (key === 'ArrowRight') cursor[0] += step;
    if (key === 'ArrowUp') cursor[1] -= step;
    if (key === 'ArrowDown') cursor[1] += step;
    cursor = [Math.min(W, Math.max(0, cursor[0])), Math.min(H, Math.max(0, cursor[1]))];
    putOverlay();
  }
});
el('cal').onclick = () => { if (startCalibration()) trabalho.marcar('medicao'); };
el('demo').onclick = example;
file.onchange = () => loadFile(file.files[0]);
[width, height].forEach((input) =>
  input.addEventListener('input', () => {
    resetState();
    trabalho.marcar('medicao');
    render();
  }),
);
mode.onchange = () => { resetMeasurement(); trabalho.marcar('medicao'); };
known.oninput = () => { trabalho.marcar('medicao'); render(); };
el('clear').onclick = () => { resetMeasurement(); trabalho.marcar('medicao'); };
el('undo').onclick = () => {
  (moving ? refs : marks).pop();
  done = false;
  notice = '';
  trabalho.marcar('medicao');
  render();
};
el('close').onclick = () => {
  if (marks.length < 3 || !map) return;
  if (!simplePolygon(marks.map(map))) {
    notice = 'O contorno se cruza ou tem área nula. Desfaça os pontos e marque a borda em ordem.';
  } else {
    done = true;
    notice = '';
    trabalho.marcar('medicao');
  }
  render();
};
el('peca').onclick = () => {
  if (!done || !map || mode.value !== 'area') return;
  if (marks.length > 200) {
    notice = 'Use até 200 vértices para modelar a peça.';
    render();
    return;
  }
  try {
    sessionStorage.setItem('cfg-contorno-foto', JSON.stringify(marks.map(map)));
    trabalho.concluir('medicao');
    location.assign('./modelagem.html#peca');
  } catch {
    notice = 'O navegador bloqueou a transferência local do contorno.';
    render();
  }
};
example();
