import {Copc} from 'copc';import {createLazPerf} from 'laz-perf';
import {perfilPontos,lerXYZ} from './perfil-nuvem.mjs';import {executar} from './oficina-worker.mjs';
async function pontosCOPC(file) {
 const get=async(start,end)=>{if(start<0||end>file.size||end<start)throw Error('Intervalo COPC inválido.');return new Uint8Array(await file.slice(start,end).arrayBuffer())};
 const fileInfo=await Copc.create(get);
 if(fileInfo.header.pointCount>500000)throw Error('Recorte a nuvem para até 500 mil pontos.');
 const lazPerf=await createLazPerf({locateFile:f=>new URL(f,self.location.href).href});
 const pages=[fileInfo.info.rootHierarchyPage],seen=new Set(),xyz=[];
 while(pages.length){
  const page=pages.pop();if(seen.has(page.pageOffset)||seen.size>10000)throw Error('Hierarquia COPC inválida.');seen.add(page.pageOffset);
  const tree=await Copc.loadHierarchyPage(get,page);pages.push(...Object.values(tree.pages));
  for(const node of Object.values(tree.nodes)){
   if(!node.pointCount)continue;
   if(node.pointCount>500000-xyz.length)throw Error('A nuvem excede o limite.');
   const v=await Copc.loadPointDataView(get,fileInfo,node,{lazPerf,include:['X','Y','Z']});
   const fields=['X','Y','Z'].map(k=>v.getter(k));for(let i=0;i<v.pointCount;i++)xyz.push(fields.map(f=>f(i)));
  }
 }
 if(xyz.length!==fileInfo.header.pointCount)throw Error('A contagem lida difere do cabeçalho COPC.');
 return xyz;
}
executar(async({fonte,x1,y1,x2,y2,largura})=>{
 const pts=/\.laz$/i.test(fonte.name)?await pontosCOPC(fonte):lerXYZ(await fonte.text());
 const rows=perfilPontos(pts,x1,y1,x2,y2,largura);if(!rows.length)throw Error('Nenhum ponto na faixa selecionada.');
 return {nome:'perfil.csv',resumo:rows.length+' de '+pts.length+' pontos na faixa.',blob:new Blob(['distancia,cota,afastamento,x,y\n',...rows.map(r=>r.join(',')+'\n')],{type:'text/csv'})};
});
