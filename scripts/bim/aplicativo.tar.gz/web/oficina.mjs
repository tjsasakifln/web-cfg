import {protegerTrabalho} from './proteger-trabalho.mjs';
const trabalho = protegerTrabalho();
const specs = {
  fornecedor: [
    'Peça de fornecedor em IFC',
    'Abra um STEP ou IGES para gerar uma representação triangulada de coordenação. A posição do modelo e suas unidades declaradas são conservadas. Confira o envelope antes de federar.',
    [
      ['fonte', 'Arquivo STEP ou IGES', '.step,.stp,.igs,.iges'],
      ['classe', 'Classe do elemento', ['IFCBUILDINGELEMENTPROXY', 'IFCPLATE', 'IFCMEMBER']],
    ],
  ],
  malha: [
    'Malha de fotogrametria em IFC',
    'Importe um PLY triangular com escala conhecida. O IFC preserva a superfície para coordenação. Confirme a unidade de origem.',
    [
      ['fonte', 'Malha PLY', '.ply'],
      ['unidade', 'Unidade do PLY', ['m', 'mm', 'cm']],
      ['classe', 'Classe do elemento', ['IFCBUILDINGELEMENTPROXY', 'IFCPLATE', 'IFCMEMBER']],
    ],
  ],
  perfil: [
    'Extrair perfil de nuvem de pontos',
    'Escolha um arquivo XYZ (três colunas numéricas com ponto decimal) ou COPC/LAZ. Informe o início e fim do eixo na referência do levantamento. A largura é a faixa total centrada no eixo. Baixe as cotas ordenadas por distância.',
    [
      ['fonte', 'Nuvem local', '.xyz,.txt,.laz'],
      ['x1', 'X inicial', 0],
      ['y1', 'Y inicial', 0],
      ['x2', 'X final', 10],
      ['y2', 'Y final', 0],
      ['largura', 'Largura da faixa', 2],
    ],
  ],
  ids: [
    'Conferir requisitos IDS',
    'Selecione um IFC e o checklist IDS. O relatório lista resultados por especificação e elemento. Abra o JSON para consultar as falhas e os requisitos correspondentes.',
    [
      ['fonte', 'Modelo IFC', '.ifc'],
      ['regras', 'Especificação IDS', '.ids'],
    ],
  ],
};
const key = location.hash.slice(1),
  spec = specs[key];
const el = (id) => document.getElementById(id),
  form = el('form');
let worker,
  url,
  rodada = 0;
function parar() {
  rodada++;
  worker?.terminate();
  worker = null;
  el('iniciar').disabled = false;
  el('parar').hidden = true;
  trabalho.concluir('processamento:oficina');
}
function limpar() {
  el('saida').hidden = true;
  el('baixar').removeAttribute('href');
  if (url) URL.revokeObjectURL(url);
  url = null;
}
if (!spec) {
  el('titulo').textContent = 'Escolha uma ferramenta na página inicial';
  form.hidden = true;
} else {
  document.title = spec[0] + ' | CONFENGE BIM';
  el('titulo').textContent = spec[0];
  el('orientacao').textContent = spec[1];
  for (const [id, tipo, valor] of spec[2]) {
    const l = document.createElement('label');
    l.textContent = tipo;
    const input = document.createElement(Array.isArray(valor) ? 'select' : 'input');
    input.id = id;
    input.name = id;
    input.required = true;
    if (Array.isArray(valor)) for (const v of valor) input.add(new Option(v, v));
    else if (typeof valor === 'number') {
      input.type = 'number';
      input.step = 'any';
      input.value = valor;
    } else {
      input.type = 'file';
      input.accept = valor;
    }
    l.append(input);
    form.append(l);
  }
  for (const [id, name, type] of [
    ['iniciar', 'Processar', 'submit'],
    ['parar', 'Cancelar', 'button'],
  ]) {
    const b = document.createElement('button');
    b.id = id;
    b.type = type;
    b.textContent = name;
    form.append(b, document.createTextNode(' '));
  }
  el('parar').hidden = true;
  el('parar').onclick = () => {
    parar();
    el('status').textContent = 'Processamento cancelado.';
  };
  form.oninput = () => {
    parar();
    trabalho.marcar('entrada');
    el('status').textContent = '';
  };
  form.onsubmit = (e) => {
    e.preventDefault();
    parar();
    const params = {};
    try {
      for (const [id] of spec[2]) {
        const a = el(id);
        params[id] = a.type === 'file' ? a.files[0] : a.type === 'number' ? a.valueAsNumber : a.value;
        if (
          a.type === 'file' &&
          (!params[id]?.size || params[id].size > (id === 'regras' ? 2 : 50) * 1024 * 1024)
        )
          throw Error(
            'Selecione um arquivo com conteúdo dentro do limite de ' + (id === 'regras' ? 2 : 50) + ' MiB.',
          );
      }
      const serial = rodada;
      trabalho.marcar('processamento:oficina');
      el('iniciar').disabled = true;
      el('parar').hidden = false;
      el('status').textContent = 'Processando no seu dispositivo…';
      worker = new Worker('./vendor/oficina/' + key + '.js', {
        name: 'confenge-' + key,
        type: key === 'ids' ? 'module' : 'classic',
      });
      worker.onmessage = ({ data }) => {
        if (serial !== rodada) return;
        parar();
        if (data.error) {
          el('status').textContent = data.error;
          return;
        }
        limpar();
        url = URL.createObjectURL(data.blob);
        el('baixar').href = url;
        el('baixar').download = data.nome;
        el('resumo').textContent = data.resumo;
        el('detalhes').textContent = data.detalhes || '';
        el('saida').hidden = false;
        trabalho.concluir('entrada');
        trabalho.marcar('resultado');
        el('status').textContent = 'Concluído.';
      };
      worker.onerror = () => {
        if (serial === rodada) {
          parar();
          el('status').textContent = 'Falha ao carregar o processador ou memória insuficiente.';
        }
      };
      worker.postMessage(params);
    } catch (err) {
      parar();
      el('status').textContent = err.message;
    }
  };
}
el('baixar')?.addEventListener('click', e => trabalho.confirmarSalvamento('resultado', e.currentTarget));
addEventListener('hashchange', () => location.reload());
