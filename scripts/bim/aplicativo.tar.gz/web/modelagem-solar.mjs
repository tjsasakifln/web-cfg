// North is clockwise from the +Y IFC axis towards +X (viewer coordinates +X, -Z).
export function sunVector(altitude,azimuth,north=0){
  if(![altitude,azimuth,north].every(Number.isFinite)||altitude < -90||altitude>90)throw Error('Ângulo solar inválido.');
  const rad=Math.PI/180,alt=altitude*rad,dir=(azimuth+north)*rad;
  return [Math.cos(alt)*Math.sin(dir),Math.sin(alt),-Math.cos(alt)*Math.cos(dir)];
}
export function solarData(getPosition,lat,lng,local,offset,north){
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180||!Number.isFinite(north)||Math.abs(north)>360)throw Error('Confira latitude, longitude e a orientação do norte.');
  if(!/^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(local)||!Number.isInteger(offset)||offset < -12||offset>14)throw Error('Informe data, hora e fuso UTC.');
  const date=new Date(local+':00Z');if(!Number.isFinite(+date)||date.toISOString().slice(0,16)!==local)throw Error('Data ou hora inválida.');
  date.setUTCMinutes(date.getUTCMinutes()-60*offset);
  const {altitude,azimuth}=getPosition(date,lat,lng);
  return {altitude,azimuth,vector:sunVector(altitude,azimuth,north)};
}
